USE product_service;

-- ============================================================
-- UPDATE PRODUCT MEDIA: Replace all loremflickr placeholder
-- images with real product images from Flipkart/Myntra CDN
-- Generated: 2026-05-14
-- Total products: 109
-- ============================================================

-- ============================================================
-- GROUP A: Only sort_order=1 needs updating
-- (sort_order=0 already has real images)
-- ============================================================

-- Nike Backpack (plain black)
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/i/t/v/6-unisex-laptop-backpack-college-office-bag-durable-spacious-original-imahn5yzgrygagfg.jpeg?q=70'
WHERE product_id = 'df87c28e-ef5e-453a-9774-f48a603a085d' AND sort_order = 1;

-- Nike Cap Rodger Federer (White Grey Red)
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/cap/i/p/6/free-bz-h-jl-sm-tk-15-010-bz-headwear-resized-2-original-imagrnheqa727pam.jpeg?q=70'
WHERE product_id = '30cbc90e-fa92-49f1-a04a-1bfb83982fd3' AND sort_order = 1;

-- Nike Cap Manu Core Black
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/cap/e/4/f/free-himachalicap-tahiro-original-imagxtrvwczvmfdb.jpeg?q=70'
WHERE product_id = '47af16ad-8512-4ffa-b339-a0854af1e0de' AND sort_order = 1;

-- Nike Track Pants (Casual Black)
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/a/u/b/xxl-lr-2-pair-black-xxl-loverabby-original-imahfyfs3jz9g4h5.jpeg?q=70'
WHERE product_id = '00d3ddd7-c558-4379-b820-5665342b0946' AND sort_order = 1;

-- Nike Track Pants (Solid Off-White)
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/c/i/4/m-tracksuit-sports-trading-original-imaggqhwety2u2yj.jpeg?q=70'
WHERE product_id = '351750be-6b96-468a-ab78-ee79e81b8530' AND sort_order = 1;

-- Puma Unisex Brown Backpack
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/4/t/f/4-05-nylon-finishing-10-litter-sports-casual-11-05-sports-casual-original-imahhdbgpypcnbxj.jpeg?q=70'
WHERE product_id = '9a0296b8-b083-4908-9d21-6a929c36cfcf' AND sort_order = 1;

-- Puma Women Fitness Large Hobo Purple Backpack
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/w/9/w/6-backpack-purse-for-women-fashionable-travel-vintage-polyester-original-imahkpkdymtugega.jpeg?q=70'
WHERE product_id = '67677480-4d2d-4568-9e46-2cd3da5aa407' AND sort_order = 1;

-- Puma Men Pack of 3 Sports Socks
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/m/5/o/free-7-dc-socsa03-hosvin-original-imahhzhyq4fpmhfx.jpeg?q=70'
WHERE product_id = '54ba981f-cac6-4320-8e5f-d115ea9b0c8a' AND sort_order = 1;


-- ============================================================
-- GROUP B: Both sort_order=0 and sort_order=1 need updating
-- ============================================================

-- ---- TRACKSUITS ----

-- 2go Active Gear USA Men Red Bjorn Track Pants
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/i/u/n/s-cords-track-01-fuback-original-imahk45x7zuxkhxh.jpeg?q=70'
WHERE product_id = 'd45fcc6f-8ac0-4189-ae6f-6bc596a830da' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/4/w/4/m-new501-aagraham-original-imahj5rjq75zzgx5.jpeg?q=70'
WHERE product_id = 'd45fcc6f-8ac0-4189-ae6f-6bc596a830da' AND sort_order = 1;

-- Proline Men Black Solid Tracksuits
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/a/u/b/xxl-lr-2-pair-black-xxl-loverabby-original-imahfyfs3jz9g4h5.jpeg?q=70'
WHERE product_id = 'c3008fd6-c8d2-4e5a-b0e3-7904e3034203' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/3/e/4/xxl-th-f31-pair-black-xxl-the-himalayan-original-imahhffaqzhvcbpy.jpeg?q=70'
WHERE product_id = 'c3008fd6-c8d2-4e5a-b0e3-7904e3034203' AND sort_order = 1;

-- Proline Men Charcoal Tracksuit
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/c/i/4/m-tracksuit-sports-trading-original-imaggqhwety2u2yj.jpeg?q=70'
WHERE product_id = 'cd619222-0e9e-47fa-9803-a484b5eca7a1' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/track-suit/4/w/4/m-new501-aagraham-original-imahj5rjq75zzgx5.jpeg?q=70'
WHERE product_id = 'cd619222-0e9e-47fa-9803-a484b5eca7a1' AND sort_order = 1;

-- ---- SPORTS SHOES ----

-- ADIDAS Women Purple Breeze Sports Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/n/w/i/6-wts-shoes-1111-6-0-pennen-black-original-imahhb62hgpyky96.jpeg?q=70'
WHERE product_id = '2958ac2f-1a8c-41f7-b4bf-bde828b9de68' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/f/h/j/-original-imahjghtyzddnqbb.jpeg?q=70'
WHERE product_id = '2958ac2f-1a8c-41f7-b4bf-bde828b9de68' AND sort_order = 1;

-- Btwin Mtb Shoes 7
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/7/p/d/7-sxz-shoes-1050-7-0-pennen-black-original-imahhgy9kjvhbkzf.jpeg?q=70'
WHERE product_id = 'd23bab11-ba40-4d42-8794-197803060755' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/u/p/t/10-play04-10-kaneggye-orange-original-imahkynhnbspnuue.jpeg?q=70'
WHERE product_id = 'd23bab11-ba40-4d42-8794-197803060755' AND sort_order = 1;

-- Fila Men Swift Black Sports Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shopsy-shoe/p/i/q/8-602-shoe-8-goldstar-black-original-imahjnf9rxbhm8rs.jpeg?q=70'
WHERE product_id = '27769112-e6fd-4eef-8f15-bb1cf9a08825' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/f/w/r/10-bos-1011-black-10-hs-hi-speed-black-original-imahh5sgyrq9afmt.jpeg?q=70'
WHERE product_id = '27769112-e6fd-4eef-8f15-bb1cf9a08825' AND sort_order = 1;

-- Kalenji Kiprun 2000l White/Purple Sports Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/9/a/m/-resized-2-original-imah4aapbcfhestw.jpeg?q=70'
WHERE product_id = 'b7fd3955-a6aa-4031-aeef-8147b99fb397' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/b/v/u/8-dh2987-8-nike-white-white-white-original-imaheh4fzhxyfzny.jpeg?q=70'
WHERE product_id = 'b7fd3955-a6aa-4031-aeef-8147b99fb397' AND sort_order = 1;

-- Nike Men City Court VI White Sports Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/q/p/i/-original-imahgcsbmaf8shzy.jpeg?q=70'
WHERE product_id = '92179c82-c054-4b7e-9846-d364f1b98c06' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/m/m/q/-original-imagx8gudh2xwuuk.jpeg?q=70'
WHERE product_id = '92179c82-c054-4b7e-9846-d364f1b98c06' AND sort_order = 1;

-- ---- CASUAL SHOES ----

-- Lee Cooper Men Casual Brick Canvas Shoe
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/y/t/e/7-ftzlong-41-trenduty-blue-original-imahhg7kz47bhpzk.jpeg?q=70'
WHERE product_id = 'c65c444a-1fd4-4e73-8e60-1bbf24639bfe' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/f/e/k/9-sc-162-9-sparx-blue-original-imahharys8eygqk3.jpeg?q=70'
WHERE product_id = 'c65c444a-1fd4-4e73-8e60-1bbf24639bfe' AND sort_order = 1;

-- Skechers Men Planfix-Zeta Charcoal Grey Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/a/c/y/6-210650-nvy-skechers-navy-original-imahawr5wfvbnupb.jpeg?q=70'
WHERE product_id = '5e2786ee-4ce2-4f3c-a986-99143f858468' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/a/y/3/10-232629-10-skechers-navy-blue-original-imahea3nybftf4ds.jpeg?q=70'
WHERE product_id = '5e2786ee-4ce2-4f3c-a986-99143f858468' AND sort_order = 1;

-- Vans Men Desurgent Navy Blue Casual Shoes
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shoe/c/q/v/6-20143946-6-roadster-blue-original-imahhy9vpgzherjp.jpeg?q=70'
WHERE product_id = 'bf894788-0af7-4ca2-bc0a-c339897a1bc1' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shopsy-shoe/o/k/e/8-sh-hrl2077sbu-hirolas-sky-blue-original-imagmz97tvkcbfnc.jpeg?q=70'
WHERE product_id = 'bf894788-0af7-4ca2-bc0a-c339897a1bc1' AND sort_order = 1;

-- ---- SWIMWEAR ----

-- ADIDAS Unisex Black White Swimming Cap
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/r/w/w/s-sw01-s-ds-trender-original-imahdywyyv8gt3fg.jpeg?q=70'
WHERE product_id = '02e9273d-bb2b-45d8-b371-8d638fae4096' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/goggle/h/t/f/antifog-swimming-goggle-asg-2020-by-one-shot-retail-asg2020-original-imagy64uu8b6vadc.jpeg?q=70'
WHERE product_id = '02e9273d-bb2b-45d8-b371-8d638fae4096' AND sort_order = 1;

-- Amante Brown Swimsuit WFSD06
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/p/t/q/m-swimwear-swimsuit-cap-googles-for-women-rzlecort-original-imagznezzzgb3wrx.jpeg?q=70'
WHERE product_id = '4f984ef4-b3df-4e9f-9042-e26494d24c13' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/n/b/r/13-14-years-boy-swimkit-blackk-13-14yr-jmt-wear-original-imahyp7ufzbxpa9h.jpeg?q=70'
WHERE product_id = '4f984ef4-b3df-4e9f-9042-e26494d24c13' AND sort_order = 1;

-- Nabaiji Women Solid Black Swimsuit
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/r/w/w/s-sw01-s-ds-trender-original-imahdywyyv8gt3fg.jpeg?q=70'
WHERE product_id = '68d01108-7184-4e2d-91a4-f30f81b391da' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/9/0/w/2-3-years-boy-swimket-black-jmt-wear-original-imaha5agscjfv4wx.jpeg?q=70'
WHERE product_id = '68d01108-7184-4e2d-91a4-f30f81b391da' AND sort_order = 1;

-- Nabaiji Unisex Pink Swimming Cap
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/goggle/r/m/r/swimming-goggles-for-adults-men-women-airtight-adjustable-strap-original-imaheyjgnqwpy2xh.jpeg?q=70'
WHERE product_id = '6bd12603-7165-4842-b0e8-b311a0fe999d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/swimsuit/p/t/q/m-swimwear-swimsuit-cap-googles-for-women-rzlecort-original-imagznezzzgb3wrx.jpeg?q=70'
WHERE product_id = '6bd12603-7165-4842-b0e8-b311a0fe999d' AND sort_order = 1;

-- Nabaiji Swimming Goggles Blue Black
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/goggle/r/m/r/swimming-goggles-for-adults-men-women-airtight-adjustable-strap-original-imaheyjgnqwpy2xh.jpeg?q=70'
WHERE product_id = 'c624ff87-29ea-4e7a-a927-24d8555a79ac' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/goggle/h/t/f/antifog-swimming-goggle-asg-2020-by-one-shot-retail-asg2020-original-imagy64uu8b6vadc.jpeg?q=70'
WHERE product_id = 'c624ff87-29ea-4e7a-a927-24d8555a79ac' AND sort_order = 1;

-- ---- LEGGINGS ----

-- Aneri Women Pink Leggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/g/w/4/m-lvt-r-al-baby-pink-07-loveit-original-imahgnw4zxvwgngk.jpeg?q=70'
WHERE product_id = '45865e7a-3e01-4770-b0d0-f45d1f338f35' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/m/p/d/l-dark-pink-saranyagarments-original-imahn4zwgddyubyw.jpeg?q=70'
WHERE product_id = '45865e7a-3e01-4770-b0d0-f45d1f338f35' AND sort_order = 1;

-- Aurelia Women Solid Purple Leggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/r/p/c/-original-imah8ga3w3sj4cfs.jpeg?q=70'
WHERE product_id = '37cf2537-a2e1-4fb7-a93a-59604c481198' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/s/e/i/s-ankle-leggings-minimus-original-imahhh4u7g4fqazp.jpeg?q=70'
WHERE product_id = '37cf2537-a2e1-4fb7-a93a-59604c481198' AND sort_order = 1;

-- Femella Women Charcoal Leggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/i/c/b/xxl-af-9-cosvos-original-imah7ry6avzne8mg.jpeg?q=70'
WHERE product_id = '615bea86-f46a-48ac-9d69-aafc72cf2cf5' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/x/v/8/xxl-yoga-pant-navy-blue-xxl-poojaran-original-imah2pehd7ghuypp.jpeg?q=70'
WHERE product_id = '615bea86-f46a-48ac-9d69-aafc72cf2cf5' AND sort_order = 1;

-- French Connection Women Navy Blue Leggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/r/g/k/l-navy-blue-saranyagarments-original-imahn4zpyju8t6cv.jpeg?q=70'
WHERE product_id = 'b5f0f53a-a3d2-4e1f-8964-b1d8e13590fa' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/y/g/5/xl-awlg080-n-athlisis-original-imahmhyegn7ptnhg.jpeg?q=70'
WHERE product_id = 'b5f0f53a-a3d2-4e1f-8964-b1d8e13590fa' AND sort_order = 1;

-- Pieces Women Turquoise Blue Leggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/legging/s/l/a/s-110114290turquoise-rangmanch-by-pantaloons-original-imagbn4zhdwcmpub-bb.jpeg?q=70'
WHERE product_id = '155304ff-4bf8-427a-99e9-5c224f7603e9' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/kc9eufk0/legging/z/g/y/xxl-leg02teal-spiffy-original-imaftfk4btpgzemj.jpeg?q=70'
WHERE product_id = '155304ff-4bf8-427a-99e9-5c224f7603e9' AND sort_order = 1;

-- ---- SHIRTS ----

-- Arrow Sport Men Self-Stripes White Shirts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/x/0/q/l-phsh000004-highlander-original-imagypzvhs7w4zjh.jpeg?q=70'
WHERE product_id = 'e3a5b622-2951-4108-9f24-c1c4521f7141' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/y/p/g/s-lining-formal-lyphy-original-imahgshs6sfjf9vt.jpeg?q=70'
WHERE product_id = 'e3a5b622-2951-4108-9f24-c1c4521f7141' AND sort_order = 1;

-- Mark Taylor Men Purple Striped White Shirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/a/2/b/40-11753-bd-french-crown-original-imahmgjvaf7crpkh.jpeg?q=70'
WHERE product_id = '27f09efd-d092-4ff5-8e47-93edf62b8b62' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/h/p/u/m-dpoxfchecksfull07012025-dopri-original-imahmgefzntavsx9.jpeg?q=70'
WHERE product_id = '27f09efd-d092-4ff5-8e47-93edf62b8b62' AND sort_order = 1;

-- Scullers Men Blue & Green Check Shirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/s/d/9/38-hschx-3wht-mark-albert-original-imahg7v88xg9sgjd.jpeg?q=70'
WHERE product_id = '5f265634-c423-4904-9016-80d7a76ae6f8' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/x/0/q/l-phsh000004-highlander-original-imagypzvhs7w4zjh.jpeg?q=70'
WHERE product_id = '5f265634-c423-4904-9016-80d7a76ae6f8' AND sort_order = 1;

-- United Colors of Benetton Men Solid White Shirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/f/q/i/s-frml-st2-vebnor-original-imahmy82ppzjgzdu.jpeg?q=70'
WHERE product_id = '80e142dd-91d7-4f70-9da5-b07077273980' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/6/i/o/m-formal-shirt-for-men-blue-dove-original-imahdffkm8pxf39v.jpeg?q=70'
WHERE product_id = '80e142dd-91d7-4f70-9da5-b07077273980' AND sort_order = 1;

-- Wrangler Men Check White Shirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/x/3/m/s-satin-shirt-for-men-55-solstice-original-imahmmyazgeguun4.jpeg?q=70'
WHERE product_id = 'eab8991b-dec7-4ed4-872c-2ae182eca3d1' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/shirt/k/b/9/xxl-cottan-shirt-white-ravirenterprise-original-imahhzfnsw2ffjtm.jpeg?q=70'
WHERE product_id = 'eab8991b-dec7-4ed4-872c-2ae182eca3d1' AND sort_order = 1;

-- ---- SWEATERS ----

-- Arrow Sport Men Solid Grey Sweaters
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/d/g/p/xl-tgyhnfulsweaterr-plainst162-tripr-original-imahemazhsu3bhzr.jpeg?q=70'
WHERE product_id = '904b8822-dd32-4736-8c58-f37e521dfc9d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/g/e/c/free-sweater-darkgrey-free-bfy-original-imahgj9pxgq8zu3u.jpeg?q=70'
WHERE product_id = '904b8822-dd32-4736-8c58-f37e521dfc9d' AND sort_order = 1;

-- Flying Machine Women Solid Peach Sweaters
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/k3hmj680/sweater/z/q/x/m-pv503-peach-pivl-original-imafmhwt7ewyyc4z.jpeg?q=70'
WHERE product_id = 'd2120f75-a769-453e-bd9d-64405b07e1e7' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/s/i/e/xl-half-zip-sw-grey-eddicted-original-imahcy5vcgcjnzhz.jpeg?q=70'
WHERE product_id = 'd2120f75-a769-453e-bd9d-64405b07e1e7' AND sort_order = 1;

-- Scullers Men Stripes White Sweaters
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/y/w/t/m-18259798-mast-harbour-original-imahg8cuhze5fwd3.jpeg?q=70'
WHERE product_id = '878abc4f-dc21-4489-a718-bf35889a9029' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/k/2/w/xl-asaesw4235-arrow-sport-original-imagg6gjjw88ztwd.jpeg?q=70'
WHERE product_id = '878abc4f-dc21-4489-a718-bf35889a9029' AND sort_order = 1;

-- Wrangler Women Felt Red Sweater
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/d/4/4/xl-nvlc101-red-zigo-original-imah69aky6fh7cdc.jpeg?q=70'
WHERE product_id = 'a3280647-e28d-4c55-809b-2be3b68d89fe' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweater/5/v/f/l-cg-w-md-b-28-red-aarika-original-imahfg9vqzwnudu5.jpeg?q=70'
WHERE product_id = 'a3280647-e28d-4c55-809b-2be3b68d89fe' AND sort_order = 1;

-- ---- JACKETS ----

-- Domyos Unisex Feather-light Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/g/k/o/-original-imahfwr5vhvcu7hx.jpeg?q=70'
WHERE product_id = '60f50f0c-1772-4d38-8aad-07fdc5a85065' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/d/t/j/l-1-no-women-solid-puffer-jacket-blueficus-original-imahgv46jjvpc5yu.jpeg?q=70'
WHERE product_id = '60f50f0c-1772-4d38-8aad-07fdc5a85065' AND sort_order = 1;

-- Forever New Women Puff Sleeve Tux Black Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/6/q/a/s-1-no-kttpufferjacket137-kotty-original-imah7d27skgzrnzg.jpeg?q=70'
WHERE product_id = 'effcc5c5-49a2-4c9b-8a84-c3ec79d3f6c0' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/6/c/a/m-1-no-j101-black-scoller-original-imah3xzhv2vqqn7b.jpeg?q=70'
WHERE product_id = 'effcc5c5-49a2-4c9b-8a84-c3ec79d3f6c0' AND sort_order = 1;

-- Status Quo Men Printed Red Jackets
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/b/o/j/l-no-pkr50-red-pkr-sports-original-imaghevg8cpvexmd.jpeg?q=70'
WHERE product_id = '75b1829a-8b4a-4cc3-8211-901259a76d3e' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jacket/x/g/x/l-1-no-krdbl-zip-kbjacket-kelonbro-original-imahhtz7xswbcy7d.jpeg?q=70'
WHERE product_id = '75b1829a-8b4a-4cc3-8211-901259a76d3e' AND sort_order = 1;

-- ---- RAIN JACKETS ----

-- Just Natural Unisex Olive Rain Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/p/m/m/l-arcus-olive-black-large-pu-coated-jacket-and-trouser-rainwear-original-imahjyf2bfsfphhz.jpeg?q=70'
WHERE product_id = '4090b848-591e-494d-aa5c-86e9ea4dadd4' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/b/u/u/l-cr013-olive-black-citizen-original-imahgcrh4zm7uzvr.jpeg?q=70'
WHERE product_id = '4090b848-591e-494d-aa5c-86e9ea4dadd4' AND sort_order = 1;

-- Just Natural Unisex Charcoal Rain Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/3/y/c/l-arcus-olive-black-large-pu-coated-jacket-and-trouser-rainwear-original-imahjjyutwh8y5zp.jpeg?q=70'
WHERE product_id = '643d76b6-06b8-44db-82de-faed0547cbc5' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/u/6/7/l-mdpr-115-olive-po1-s25-dollar-original-imahd8eaf5ugua7v.jpeg?q=70'
WHERE product_id = '643d76b6-06b8-44db-82de-faed0547cbc5' AND sort_order = 1;

-- Just Natural Unisex Black Olive Reversible Rain Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/l3929ow0/raincoat/r/v/e/xl-mackintosh-men-wt-04-green-xl-zacharias-original-imageezgsjj7bgsm.jpeg?q=70'
WHERE product_id = '95887ea7-2265-4f64-bc10-ee5fbbd2b1f1' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/f/e/0/l-cumulus-olive-large-pu-coated-poncho-rainwear-mallcom-original-imahjpghzzhwazbr.jpeg?q=70'
WHERE product_id = '95887ea7-2265-4f64-bc10-ee5fbbd2b1f1' AND sort_order = 1;

-- Just Natural Unisex Brown Rain Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/b/u/u/l-cr013-olive-black-citizen-original-imahgcrh4zm7uzvr.jpeg?q=70'
WHERE product_id = 'bee69c62-cc29-44e5-9663-490ab8ddd3ea' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/p/m/m/l-arcus-olive-black-large-pu-coated-jacket-and-trouser-rainwear-original-imahjyf2bfsfphhz.jpeg?q=70'
WHERE product_id = 'bee69c62-cc29-44e5-9663-490ab8ddd3ea' AND sort_order = 1;

-- Just Natural Unisex Red Rain Jacket
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/u/6/7/l-mdpr-115-olive-po1-s25-dollar-original-imahd8eaf5ugua7v.jpeg?q=70'
WHERE product_id = 'e7cbabe0-3cf1-47df-a95c-57661904a5d6' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/raincoat/3/y/c/l-arcus-olive-black-large-pu-coated-jacket-and-trouser-rainwear-original-imahjjyutwh8y5zp.jpeg?q=70'
WHERE product_id = 'e7cbabe0-3cf1-47df-a95c-57661904a5d6' AND sort_order = 1;

-- ---- BRA ----

-- Biara Women Skin Bra
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/u/e/e/lightly-padded-s-1-regular-no-regular-kopub-bra-12-blk-s-topster-original-imahmuy37g7gm48w.jpeg?q=70'
WHERE product_id = '15544bf8-3827-4926-9b15-e1fdc729879b' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/j/b/q/non-padded-32-1-regular-no-regular-tp-ly-sports-black-bra-32-original-imahgthf8cyahwpt.jpeg?q=70'
WHERE product_id = '15544bf8-3827-4926-9b15-e1fdc729879b' AND sort_order = 1;

-- Enamor Women Teal Bra
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/r/n/k/non-padded-40b-1-regular-no-styled-back-ellena-black-40b-original-imahn4qnvhkpcp9r.jpeg?q=70'
WHERE product_id = '36b12dd5-7235-42fe-8a60-24fdd9f1952b' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/a/g/q/heavily-padded-30b-1-regular-no-racerback-high-impact-sports-bra-original-imahfhf9mnegsu4e.jpeg?q=70'
WHERE product_id = '36b12dd5-7235-42fe-8a60-24fdd9f1952b' AND sort_order = 1;

-- Enamor Claret Coloured Lift Bra
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/a/g/q/heavily-padded-30b-1-regular-no-racerback-high-impact-sports-bra-original-imahfhf9mnegsu4e.jpeg?q=70'
WHERE product_id = '6b46fe5d-2913-4423-8106-76d6d25a0df0' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/r/n/k/non-padded-40b-1-regular-no-styled-back-ellena-black-40b-original-imahn4qnvhkpcp9r.jpeg?q=70'
WHERE product_id = '6b46fe5d-2913-4423-8106-76d6d25a0df0' AND sort_order = 1;

-- Hanes Women Black Sports Bra
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/j/b/q/non-padded-32-1-regular-no-regular-tp-ly-sports-black-bra-32-original-imahgthf8cyahwpt.jpeg?q=70'
WHERE product_id = 'fbd2c60e-361b-412e-ac33-ac3232ce7d5e' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/u/e/e/lightly-padded-s-1-regular-no-regular-kopub-bra-12-blk-s-topster-original-imahmuy37g7gm48w.jpeg?q=70'
WHERE product_id = 'fbd2c60e-361b-412e-ac33-ac3232ce7d5e' AND sort_order = 1;

-- Miss-T White Bra
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/u/e/e/lightly-padded-s-1-regular-no-regular-kopub-bra-12-blk-s-topster-original-imahmuy37g7gm48w.jpeg?q=70'
WHERE product_id = 'dd6b387b-9e12-4ffe-963f-51f19a92bb59' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/bra/r/n/k/non-padded-40b-1-regular-no-styled-back-ellena-black-40b-original-imahn4qnvhkpcp9r.jpeg?q=70'
WHERE product_id = 'dd6b387b-9e12-4ffe-963f-51f19a92bb59' AND sort_order = 1;

-- ---- BRIEFS ----

-- Facit Men Trophy BKN Black Briefs
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/9/n/8/m-xybrf217-xyxx-original-imahyahstdwbrvyh.jpeg?q=70'
WHERE product_id = 'eecfd968-476c-47d6-8700-98dc59b767ca' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/z/d/u/m-1-style-018-levi-s-original-imahyq42ftfhmzby.jpeg?q=70'
WHERE product_id = 'eecfd968-476c-47d6-8700-98dc59b767ca' AND sort_order = 1;

-- Hanes Men Navy Blue Premium Bikini Briefs
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/b/r/i/s-4-1blue-blck-maroon-gray-clozly-original-imahhrtmg7xaqagm.jpeg?q=70'
WHERE product_id = 'e2190b64-8b4d-4123-bd36-3b54da2ce05d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/l/l/i/-original-imahhga8rffh7ga9.jpeg?q=70'
WHERE product_id = 'e2190b64-8b4d-4123-bd36-3b54da2ce05d' AND sort_order = 1;

-- Jockey ELANCE Men Pack Of 2 Briefs 1004
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/l/l/i/-original-imahhga8rffh7ga9.jpeg?q=70'
WHERE product_id = '3efa65b4-91ef-4ebf-80f9-f925d9c2d1ff' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/m/j/n/xl-1-m594-macroman-m-series-original-imahhqrctcyetztd.jpeg?q=70'
WHERE product_id = '3efa65b4-91ef-4ebf-80f9-f925d9c2d1ff' AND sort_order = 1;

-- Parx Men White Briefs
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/s/o/o/110-3-white2pctbrief-p3-cupatex-original-imahkbm5hvbgphzh.jpeg?q=70'
WHERE product_id = '77bfd59c-d4d0-475b-b53f-5ddb4e1a550e' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/t/9/p/105-5-frenchie-white-p5-cupatex-original-imahkbm5ykgpr32q.jpeg?q=70'
WHERE product_id = '77bfd59c-d4d0-475b-b53f-5ddb4e1a550e' AND sort_order = 1;

-- Undercolors Benetton Men Black 2-Pack Brief
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/9/n/8/m-xybrf217-xyxx-original-imahyahstdwbrvyh.jpeg?q=70'
WHERE product_id = 'a3ce2893-f627-4181-8bbc-5d589aeedfb2' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/brief/z/d/u/m-1-style-018-levi-s-original-imahyq42ftfhmzby.jpeg?q=70'
WHERE product_id = 'a3ce2893-f627-4181-8bbc-5d589aeedfb2' AND sort_order = 1;

-- ---- INNERWEAR VESTS ----

-- Facit Men Square Neck Red Innerwear Vest
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/b/f/r/m-2-twt-ogvest-believer-tripr-original-imahyhxkczdq2hxz.jpeg?q=70'
WHERE product_id = 'c2466ea5-cd38-4436-9e0e-19eab9ae66be' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/g/y/q/m-3-70018-maroon-70024-70004-bike-original-imahgkfqhgfu8hjp.jpeg?q=70'
WHERE product_id = 'c2466ea5-cd38-4436-9e0e-19eab9ae66be' AND sort_order = 1;

-- Hanes Men Grey Innerwear Vests
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/7/4/l/100-4-fdsszxsd-dollar-original-imahjzbq2xevsggx.jpeg?q=70'
WHERE product_id = '70251ef0-3c34-46fe-8ede-c464cf3ee157' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/b/f/r/m-2-twt-ogvest-believer-tripr-original-imahyhxkczdq2hxz.jpeg?q=70'
WHERE product_id = '70251ef0-3c34-46fe-8ede-c464cf3ee157' AND sort_order = 1;

-- Hanes Men Pack of 3 Innerwear T-shirts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/g/y/q/m-3-70018-maroon-70024-70004-bike-original-imahgkfqhgfu8hjp.jpeg?q=70'
WHERE product_id = 'c6b745bc-01d8-461e-aace-4a6746e78dee' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/v/s/o/l-3-uc-pv-blglnv3-bull-noexcuse-cool-l-upclothingvest-original-imahgha2yreyjtde.jpeg?q=70'
WHERE product_id = 'c6b745bc-01d8-461e-aace-4a6746e78dee' AND sort_order = 1;

-- Hanes Men Racer Back Black Innerwear Vests
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/v/s/o/l-3-uc-pv-blglnv3-bull-noexcuse-cool-l-upclothingvest-original-imahgha2yreyjtde.jpeg?q=70'
WHERE product_id = 'e7d9a35e-b80a-49f9-bf8c-b736ae83e49c' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/7/4/l/100-4-fdsszxsd-dollar-original-imahjzbq2xevsggx.jpeg?q=70'
WHERE product_id = 'e7d9a35e-b80a-49f9-bf8c-b736ae83e49c' AND sort_order = 1;

-- Undercolors Benetton Men Pack Of 3 Innerwear T-Shirts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/b/f/r/m-2-twt-ogvest-believer-tripr-original-imahyhxkczdq2hxz.jpeg?q=70'
WHERE product_id = '357dc1bd-c9b4-46b0-b3c8-7f0b9f1fdfc6' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/vest/g/y/q/m-3-70018-maroon-70024-70004-bike-original-imahgkfqhgfu8hjp.jpeg?q=70'
WHERE product_id = '357dc1bd-c9b4-46b0-b3c8-7f0b9f1fdfc6' AND sort_order = 1;

-- ---- BACKPACKS ----

-- Fastrack Unisex Black Orange Single Strap Backpack
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/4/t/f/4-05-nylon-finishing-10-litter-sports-casual-11-05-sports-casual-original-imahhdbgpypcnbxj.jpeg?q=70'
WHERE product_id = '1b65cbe3-47a2-4bb4-b77d-753e75ebdd86' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/t/2/b/4-ko-newblkqchuabga875-17-10-ko-newblkqchuabga875-17-backpack-original-imahyq9dw6tncz7p.jpeg?q=70'
WHERE product_id = '1b65cbe3-47a2-4bb4-b77d-753e75ebdd86' AND sort_order = 1;

-- Wildcraft Unisex Orange Grey Backpack
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/b/e/9/-original-imahfskj67ededza.jpeg?q=70'
WHERE product_id = 'b13d4ae2-ab5d-4031-b777-430c29705f19' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/backpack/d/z/h/8-peza-14-11030-laptop-backpack-wildcraft-30-20-original-imah66wmxguuu6rg.jpeg?q=70'
WHERE product_id = 'b13d4ae2-ab5d-4031-b777-430c29705f19' AND sort_order = 1;

-- ---- SUNGLASSES ----

-- Fastrack Men Black Sunglasses M069BK3
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/h/g/j/-original-imahg3f4xygdtmsz.jpeg?q=70'
WHERE product_id = '85b92807-d005-47d6-b62f-2d14f3d32824' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/m/7/0/l-148974-vincent-chase-original-imahgzzywbracch4.jpeg?q=70'
WHERE product_id = '85b92807-d005-47d6-b62f-2d14f3d32824' AND sort_order = 1;

-- Idee Men Copper Sunglasses
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/jwnusnk0/sunglass/h/5/v/m-3026-gold-green-b-piraso-original-imafhby58ttweeqm.jpeg?q=70'
WHERE product_id = '41e6f1ec-a0b6-4b0b-a2c7-63811ec96bff' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/f/k/s/m-4494-brown-gold-piraso-original-imah4ycegpgz7vuz.jpeg?q=70'
WHERE product_id = '41e6f1ec-a0b6-4b0b-a2c7-63811ec96bff' AND sort_order = 1;

-- Mayhem Men Rectangular Sunglasses 1022-203
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/i/d/p/13-seeer1-vss-original-imahn2zsdtfszdbf.jpeg?q=70'
WHERE product_id = '7abae072-631e-41f0-8bd2-969a81ab707b' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/d/8/w/this-product-is-sold-as-large-by-the-brand-rgd-sg-87-nestyra-original-imahmantvafx5qvd.jpeg?q=70'
WHERE product_id = '7abae072-631e-41f0-8bd2-969a81ab707b' AND sort_order = 1;

-- Mayhem Women Sunglasses 1018-103
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/7/r/m/free-size-com178-dervin-original-imahyp4hzevztrqd.jpeg?q=70'
WHERE product_id = 'aa1cc61f-c6ed-4a9e-98c6-c87b1e74f4ee' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/0/v/l/medium-red-black-way-polarized-109-lens-library-original-imahf6fzgjkepcgn.jpeg?q=70'
WHERE product_id = 'aa1cc61f-c6ed-4a9e-98c6-c87b1e74f4ee' AND sort_order = 1;

-- Opium Men Aviator Gold Sunglasses
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/o/g/m/m-3026-brown-gold-piraso-original-imahfffqtnhteury.jpeg?q=70'
WHERE product_id = '42bc439f-577a-48a5-a24d-f21974e81926' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sunglass/j/z/v/m-aircrafts-gold-brown-dc-resist-original-imahgve7xsxvv8dp.jpeg?q=70'
WHERE product_id = '42bc439f-577a-48a5-a24d-f21974e81926' AND sort_order = 1;

-- ---- DRESSES ----

-- Femella Women Red Dress
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/d/u/g/xxl-emz02311-emeros-original-imahn79wjgefpgjy.jpeg?q=70'
WHERE product_id = '5cb1550a-d8f7-45c1-a2a2-73a2f5d3fc02' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/u/j/v/-resized-2-original-imahffafjazkhane.jpeg?q=70'
WHERE product_id = '5cb1550a-d8f7-45c1-a2a2-73a2f5d3fc02' AND sort_order = 1;

-- Femella Women Brown Dress
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/0/7/e/xl-mmy-md258-pd4-moomaya-original-imagtyzrzafvh8mh.jpeg?q=70'
WHERE product_id = '70f84fbe-d946-4984-8d3a-ca46758be9be' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/j/v/y/m-w25drsa2825-kami-kubi-original-imahhpnwyba7mvde.jpeg?q=70'
WHERE product_id = '70f84fbe-d946-4984-8d3a-ca46758be9be' AND sort_order = 1;

-- Mineral Women Orange Dress
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/q/6/j/l-pa-123-orange-one-pecie-priyankit-original-imahhynwjhrqbvvx.jpeg?q=70'
WHERE product_id = '1e3add62-2890-48d6-a895-19c12640ad57' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/q/h/a/xxl-rcmarnty-3006-rudraaksha-original-imah6vkdjhjzg73e.jpeg?q=70'
WHERE product_id = '1e3add62-2890-48d6-a895-19c12640ad57' AND sort_order = 1;

-- ONLY Women Toronto Grey Printed Dress
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/f/p/0/l-bhz-middr-025-behruz-original-imahmpb29dhzzefd.jpeg?q=70'
WHERE product_id = '84b7bccb-7165-40f4-8fda-2ec3aa419fee' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/dress/e/5/e/xxl-dc-1449-grey-denim-crafter-original-imahn3ynj2yqeyfp.jpeg?q=70'
WHERE product_id = '84b7bccb-7165-40f4-8fda-2ec3aa419fee' AND sort_order = 1;

-- Doodle Kids Girl Printed White Dress
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/k/b/g/10-11-years-boho-white-xapic-original-imahmy7nuxrj3ryh.jpeg?q=70'
WHERE product_id = '36e9e800-7c3d-475f-bb7d-fe9df81e4e1a' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/z/t/m/10-11-years-white-rose-mensbit-original-imahkr55ghbjx6zh.jpeg?q=70'
WHERE product_id = '36e9e800-7c3d-475f-bb7d-fe9df81e4e1a' AND sort_order = 1;

-- ---- TOPS ----

-- Doodle Girl Little Princess Pink Tops
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/j/m/x/4-5-years-group24-miss-chief-original-imahfv4d847f9h5q.jpeg?q=70'
WHERE product_id = '3efbf18b-c9ca-421a-a583-fe7c8dbb6b74' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-dress/h/g/k/10-11-years-d-w-051-flora-original-imah2ynyfaqbzth8.jpeg?q=70'
WHERE product_id = '3efbf18b-c9ca-421a-a583-fe7c8dbb6b74' AND sort_order = 1;

-- Jealous 21 Women Pink Top
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/i/v/e/s-1-b1-firstbloom-original-imahna8bzt6dffsu.jpeg?q=70'
WHERE product_id = 'b442e96f-c1d9-460c-9676-cccb59dc5829' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/7/x/7/xxl-1-kbftp031-xxl-kekabu-original-imahgk2m9hgwffkn.jpeg?q=70'
WHERE product_id = 'b442e96f-c1d9-460c-9676-cccb59dc5829' AND sort_order = 1;

-- ONLY Women Yellow Top
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/o/v/c/5xl-1-4993-go-4-it-original-imah8wkazxgkwycw.jpeg?q=70'
WHERE product_id = '7df128f2-5ad0-44de-ba8d-87909b7100f6' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/l/c/u/l-peech-solid-himanc-original-imah2m3mmdbtygw3.jpeg?q=70'
WHERE product_id = '7df128f2-5ad0-44de-ba8d-87909b7100f6' AND sort_order = 1;

-- s.Oliver Women Solid Black Top
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/q/i/9/xs-1-clb705-b-clobug-original-imahmmxehgcejvhg.jpeg?q=70'
WHERE product_id = '90d3dfb7-634e-4616-8001-e4aa10197d48' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/c/l/n/xs-1-nav-top-49-thar-black-navyankaa-original-imahgftthwgaghhz.jpeg?q=70'
WHERE product_id = '90d3dfb7-634e-4616-8001-e4aa10197d48' AND sort_order = 1;

-- Wrangler Women Long Polka Top
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/z/c/g/m-1-n-ria1598-blue-kalakaari-original-imahdg2cw9va439q.jpeg?q=70'
WHERE product_id = 'c605d007-c5ca-42a7-aa06-a832f339d09c' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/top/o/m/g/m-1-fs-t-002-blue-fashoraa-original-imahgptd3udcgwtk.jpeg?q=70'
WHERE product_id = 'c605d007-c5ca-42a7-aa06-a832f339d09c' AND sort_order = 1;

-- ---- SHORTS ----

-- Fila Men Navy Blue Shorts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/l/1/c/m-rmsrta0389-reebok-original-imahf56mwkwnh2qu.jpeg?q=70'
WHERE product_id = 'd7be45f2-d367-4b14-b56f-9a29dd5c2f1d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/u/p/e/s-mn-sht-101-navy-featous-original-imahh2mztxhmfz6q.jpeg?q=70'
WHERE product_id = 'd7be45f2-d367-4b14-b56f-9a29dd5c2f1d' AND sort_order = 1;

-- Myntra Men Green Check Shorts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/c/f/u/m-mn-sht-101-olive-featous-original-imahh2mzhnhmrkme.jpeg?q=70'
WHERE product_id = '472edc0d-684b-4069-b30e-88751bdbd18f' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/3/b/q/38-cotton-boxer-shorts-solid-men-boxer-tiptoun-original-imaggtmvzbgywtuq.jpeg?q=70'
WHERE product_id = '472edc0d-684b-4069-b30e-88751bdbd18f' AND sort_order = 1;

-- Quiksilver Men Printed Blue Shorts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/j/y/w/m-self-design-shorts-for-men-wereko-original-imahkrbvpcdtvznt.jpeg?q=70'
WHERE product_id = '0d4b2cc4-429e-4a2a-bb0b-2ea602605394' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/short/u/p/e/s-mn-sht-101-navy-featous-original-imahh2mztxhmfz6q.jpeg?q=70'
WHERE product_id = '0d4b2cc4-429e-4a2a-bb0b-2ea602605394' AND sort_order = 1;

-- ---- TSHIRTS ----

-- Fila Men White Polo T-shirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/f/e/g/l-ss26mapgplo00122white-peregrine-by-pantaloons-original-imahm24gdmzdwfeg.jpeg?q=70'
WHERE product_id = '9f28e109-6bbd-465f-8503-adcb147bb14b' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/2/o/n/xl-shop-pl-002-shopholik-original-imahn5be5m82hfas.jpeg?q=70'
WHERE product_id = '9f28e109-6bbd-465f-8503-adcb147bb14b' AND sort_order = 1;

-- Manchester United Men Printed Red Tshirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/l/s/r/l-hg10-fcred-united2024-plainjer-manchester-rjm-original-imahh4kuzpcee2b4.jpeg?q=70'
WHERE product_id = '3a85521f-7d04-43dc-85e9-e836148ff123' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/4/t/m/l-t-r208-manchester-united-the-print-platter-original-imahfs6y4zgnvuac.jpeg?q=70'
WHERE product_id = '3a85521f-7d04-43dc-85e9-e836148ff123' AND sort_order = 1;

-- Regent Polo Club Men Solid Blue Tshirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/r/s/n/s-ts110-vebnor-original-imahhfunnn7hujrh.jpeg?q=70'
WHERE product_id = '671709ff-dfe2-45b2-8623-fc278ff75d44' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/t-shirt/f/i/g/m-t-314-plain-royal-blue-ruhe-original-imahhmhhmezz8b4x.jpeg?q=70'
WHERE product_id = '671709ff-dfe2-45b2-8623-fc278ff75d44' AND sort_order = 1;

-- ---- TROUSERS ----

-- Highlander Men Classic Chinos Cream Trousers
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/y/q/r/34-epnchino-18-cream-urbano-fashion-original-imahgjzs7xvgfwjw.jpeg?q=70'
WHERE product_id = '51c157e8-2e35-4c37-978b-62e82bf7b132' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/t/k/7/34-kctr-linen-222-crm-fubar-original-imah3nphn2rgkfuq.jpeg?q=70'
WHERE product_id = '51c157e8-2e35-4c37-978b-62e82bf7b132' AND sort_order = 1;

-- Indigo Nation Men Printed Beige Trousers
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/1/3/q/28-tr1-cream-flicfol-original-imahftremxfbyaza.jpeg?q=70'
WHERE product_id = '1ab1947e-609a-4a08-afb0-5b7b87c189dd' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/p/t/v/30-dnrmnoostr-denro-original-imahhvgjkdeqsbgz.jpeg?q=70'
WHERE product_id = '1ab1947e-609a-4a08-afb0-5b7b87c189dd' AND sort_order = 1;

-- Indigo Nation Men TR Yarn Dyed Grey Trousers
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/i/g/n/32-pmtx07529-g8-park-avenue-original-imagwfvyaxanshbb.jpeg?q=70'
WHERE product_id = '8824764f-ab12-48e3-89cc-4ac89d75c358' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/h/0/4/36-0224-rgfltr02-15-13-the-indian-garage-co-original-imah6nf4y3qkzdjm.jpeg?q=70'
WHERE product_id = '8824764f-ab12-48e3-89cc-4ac89d75c358' AND sort_order = 1;

-- Indigo Nation Men Black Trouser
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/1/e/z/32-rmts05274-k8-raymond-original-imaguhxakazn8hgr.jpeg?q=70'
WHERE product_id = 'b4c12160-317d-46dc-ae27-83754edd44d4' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/w/b/q/32-pmtx07553-k8-park-avenue-original-imagwhgqbj34naup.jpeg?q=70'
WHERE product_id = 'b4c12160-317d-46dc-ae27-83754edd44d4' AND sort_order = 1;

-- Scullers Men Black Checked Trousers
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/b/2/9/38-6968-mchenry-original-imahehjtzgusnum4.jpeg?q=70'
WHERE product_id = '1bdb26b8-6608-46c5-80f5-cde8603b0f43' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/trouser/1/e/z/32-rmts05274-k8-raymond-original-imaguhxakazn8hgr.jpeg?q=70'
WHERE product_id = '1bdb26b8-6608-46c5-80f5-cde8603b0f43' AND sort_order = 1;

-- ---- JEANS ----

-- Jealous 21 Women Washed Blue Jeans
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/2/1/h/30-womjeanstrttwl-iceblue-urbano-fashion-original-imahhkz8wedaedhz.jpeg?q=70'
WHERE product_id = '6606011d-993a-474c-a391-14bd86a86f2d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/k/g/3/30-jeans-blue2-1-zayla-resized-2-original-imagcpy7rpfgwa2b.jpeg?q=70'
WHERE product_id = '6606011d-993a-474c-a391-14bd86a86f2d' AND sort_order = 1;

-- Jealous 21 Women Washed Black Jeggings
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/k/a/d/30-mcaw25den64-98-71-miss-chase-original-imahmqh6hheawwft.jpeg?q=70'
WHERE product_id = 'a66e642c-2344-448e-9c1b-8aca31c2f5b1' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/0/k/b/-original-imah898gwbhceqpj.jpeg?q=70'
WHERE product_id = 'a66e642c-2344-448e-9c1b-8aca31c2f5b1' AND sort_order = 1;

-- Locomotive Men Cal Grey Jeans
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/v/c/t/28-r-e084-rasso-original-imahdj6dqmt4ujfe.jpeg?q=70'
WHERE product_id = '4bca391e-f6a2-4d2b-9eb3-fa2103b2306d' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/w/9/j/36-mx1001s-marsh-x-original-imagwgrbybz2zbsr.jpeg?q=70'
WHERE product_id = '4bca391e-f6a2-4d2b-9eb3-fa2103b2306d' AND sort_order = 1;

-- SPYKAR Men Slim Fit Blue Jeans
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/b/0/k/30-wmjn007360-wrangler-original-imagyjgffnjrfepr.jpeg?q=70'
WHERE product_id = '57316c93-c386-4912-9544-4039750f2413' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/9/g/k/30-wmjn005855-wrangler-original-imagpw46xqgfte2a.jpeg?q=70'
WHERE product_id = '57316c93-c386-4912-9544-4039750f2413' AND sort_order = 1;

-- Wrangler Men Blue Floyd Jeans
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/c/z/d/38-wmjn005913-wrangler-original-imagpw9nfahgny9u.jpeg?q=70'
WHERE product_id = '4980ab7b-1cd5-4243-8eea-097b11397c4b' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/t/4/k/32-wmjn103534-wrangler-original-imahgkhvntzrjkyw.jpeg?q=70'
WHERE product_id = '4980ab7b-1cd5-4243-8eea-097b11397c4b' AND sort_order = 1;

-- ---- CAPRIS ----

-- Gini and Jony Girl Tamira Blue Kidswear Capris
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/o/s/8/3-4-years-craft026-hulu-lulu-original-imahmhmhawhsafhd.jpeg?q=70'
WHERE product_id = 'f88e2b3b-1d11-4b02-8b80-d123f11d8934' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/x/s/y/3-6-months-cpby0078-carrydreams-original-imahephm8mbseysq.jpeg?q=70'
WHERE product_id = 'f88e2b3b-1d11-4b02-8b80-d123f11d8934' AND sort_order = 1;

-- Jealous 21 Women Light Blue Capris
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/i/i/z/30-gutiwomensjeans105-guti-original-imahmfvmurwqhn8z.jpeg?q=70'
WHERE product_id = '9d3f71b2-13cf-42ff-aa5b-e1df109df2dc' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/jean/v/m/p/38-apss23den12-52-158-miss-chase-original-imahy3x88hzz9ufy.jpeg?q=70'
WHERE product_id = '9d3f71b2-13cf-42ff-aa5b-e1df109df2dc' AND sort_order = 1;

-- Jockey Women Grey Melange Knit Capris 1300
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/x/v/8/xxl-yoga-pant-navy-blue-xxl-poojaran-original-imah2pehd7ghuypp.jpeg?q=70'
WHERE product_id = '4091db8b-0eee-42e2-b8d4-28020442ca1f' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/i/c/b/xxl-af-9-cosvos-original-imah7ry6avzne8mg.jpeg?q=70'
WHERE product_id = '4091db8b-0eee-42e2-b8d4-28020442ca1f' AND sort_order = 1;

-- ---- KIDS SHORTS / SWEATSHIRTS ----

-- Gini and Jony Kids Boys Solid White Shorts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/r/t/3/5-6-years-rbset001-runstars-original-imahgysrh8vqy2te.jpeg?q=70'
WHERE product_id = '25b5235a-5d51-41df-b687-b04cc8519e47' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/x/s/y/3-6-months-cpby0078-carrydreams-original-imahephm8mbseysq.jpeg?q=70'
WHERE product_id = '25b5235a-5d51-41df-b687-b04cc8519e47' AND sort_order = 1;

-- Gini and Jony Boy Kimon Black Bermuda Infant
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/o/s/8/3-4-years-craft026-hulu-lulu-original-imahmhmhawhsafhd.jpeg?q=70'
WHERE product_id = 'd76c7705-51dc-4ac3-8b53-6bd35557393c' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/kids-apparel-combo/r/t/3/5-6-years-rbset001-runstars-original-imahgysrh8vqy2te.jpeg?q=70'
WHERE product_id = 'd76c7705-51dc-4ac3-8b53-6bd35557393c' AND sort_order = 1;

-- Gini and Jony Kids Boys Printed Grey Sweatshirts
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweatshirt/3/p/i/2-3-years-801-strive-grey-2-3-yr-lilbits-original-imahme84uqp44dv7.jpeg?q=70'
WHERE product_id = '82a529a2-c214-4602-bc79-b50c641c9b72' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweatshirt/d/v/7/14-15-years-in25-kprinthoody-l-grey-ni-fashion-original-imahhp2jbhy6ggux.jpeg?q=70'
WHERE product_id = '82a529a2-c214-4602-bc79-b50c641c9b72' AND sort_order = 1;

-- ---- TIGHTS ----

-- Happy Socks Women Striped Tights
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/ktrk13k0/tight/1/5/h/free-ppsdpty-005-kony-original-imag7f8rnhwggwe2.jpeg?q=70'
WHERE product_id = '11c21366-b89a-4935-9886-76dfd2d6bb45' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/1/r/l/5xl-5550-yellow-blinkin-original-imahmuva6gmtjqbh.jpeg?q=70'
WHERE product_id = '11c21366-b89a-4935-9886-76dfd2d6bb45' AND sort_order = 1;

-- Happy Socks Women Black & Grey Tights
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/jtltw280/tight/z/d/6/free-pappaa-jogger-black-navy-2pcs-just-live-fashion-original-imafew8fvzvy6dhw.jpeg?q=70'
WHERE product_id = 'af73dc89-42c9-48ec-a80b-20a2f5c9d9f5' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/jrmdvgw0/tight/w/t/q/free-dgray-navy-2pcs-eazy-trendz-original-imafddxgpdj3tmzp.jpeg?q=70'
WHERE product_id = 'af73dc89-42c9-48ec-a80b-20a2f5c9d9f5' AND sort_order = 1;

-- United Colors of Benetton Women Olive Tights
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/l4fxh8w0/tight/v/l/1/m-ab0042b17-clovia-original-imagfcfypxyg2z5h.jpeg?q=70'
WHERE product_id = 'fffeba91-f821-485b-a2f1-f79ebc0f5678' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/tight/g/h/f/xs-25564680-hrx-by-hrithik-roshan-original-imah4zkasfpqugpq.jpeg?q=70'
WHERE product_id = 'fffeba91-f821-485b-a2f1-f79ebc0f5678' AND sort_order = 1;

-- ---- SWEATSHIRTS ----

-- United Colors of Benetton Women Solid Blue Sweatshirt
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweatshirt/a/y/p/xxl-9005-navy-tojar-original-imahgmzdhrajnkyr.jpeg?q=70'
WHERE product_id = '18465c93-5628-4370-b531-7a26ea967fc2' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sweatshirt/c/p/t/-original-imahh43fvhnbem6z.jpeg?q=70'
WHERE product_id = '18465c93-5628-4370-b531-7a26ea967fc2' AND sort_order = 1;

-- ---- CAPS ----

-- Manchester United Men Solid Red Cap
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/cap/0/5/j/m-bbj-red-basbeall-alamos-original-imahg3rv29tzvgws.jpeg?q=70'
WHERE product_id = 'c56f61f8-b7ba-4e96-b3e2-c3247052e6cc' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/cap/e/d/g/free-cp-ny-flat-red-2565-selloria-original-imahgvhujyyhxswy.jpeg?q=70'
WHERE product_id = 'c56f61f8-b7ba-4e96-b3e2-c3247052e6cc' AND sort_order = 1;

-- Wrangler Men Light Blue Canvas Cap
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/cap/7/d/q/free-afni-dakine-jack-original-imahj7yjfqbdad2j.jpeg?q=70'
WHERE product_id = '14d0482c-02e5-4642-a792-8e95a2b56f1a' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/jpfsnm80/cap/t/p/h/free-cp-03-m-sbrd-stylos-original-imafbm4az4nhvs6r.jpeg?q=70'
WHERE product_id = '14d0482c-02e5-4642-a792-8e95a2b56f1a' AND sort_order = 1;

-- ---- SOCKS ----

-- Playboy Men Black and White Socks
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/l/b/8/free-1-sports-5-pairs-bahuzo-original-imahgvnfssbsvgwg.jpeg?q=70'
WHERE product_id = '9b9cb72d-99ef-44b5-a20b-04ba8e4a8f16' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/kjx6tu80/sock/n/b/e/free-6-0215-2020-pizzro-original-imafzdx6ugppte7v.jpeg?q=70'
WHERE product_id = '9b9cb72d-99ef-44b5-a20b-04ba8e4a8f16' AND sort_order = 1;

-- Playboy Men White & Red Socks
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/t/1/n/free-1-fk-moq-ankle-99-mje-original-imahf4gagyqzftpz.jpeg?q=70'
WHERE product_id = 'cb7e5fb2-b47d-4740-be25-7d9822eca1c6' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/l/d/k/free-1-10-pair-ankle-jaali-bahuzo-original-imahe6r6fmym6zzb.jpeg?q=70'
WHERE product_id = 'cb7e5fb2-b47d-4740-be25-7d9822eca1c6' AND sort_order = 1;

-- Reid & Taylor Men Solid Red Socks
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/l/d/y/free-3-men-cotton-ankle-length-red-socks-mukhaksh-original-imahffhzfa6yqqtf.jpeg?q=70'
WHERE product_id = '4903e73a-623a-4a11-a80e-2578f6463289' AND sort_order = 0;
UPDATE product_media
SET url = 'https://rukminim2.flixcart.com/image/612/612/xif0q/sock/4/w/l/free-1-3-4th-red-captain-original-imah3xw68ujpzeyh.jpeg?q=70'
WHERE product_id = '4903e73a-623a-4a11-a80e-2578f6463289' AND sort_order = 1;

-- ---- VERIFY RESULT ----
SELECT
  SUM(url LIKE '%loremflickr%') AS remaining_placeholders,
  COUNT(*) AS total_rows
FROM product_media;
