# Hướng dẫn Test Postman - Inventory Service

## 1. Kiểm tra Service đã chạy chưa

### Test Health Check (Kiểm tra service hoạt động)
- **Method**: GET
- **URL**: `http://localhost:8082/actuator/health`
- **Kết quả mong đợi**: Status 200 OK
```json
{
  "status": "UP"
}
```

---

## 2. Test kết nối Database

### A. Kiểm tra tất cả stocks (Nên trống ban đầu)
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/stocks`
- **Headers**: 
  - `Content-Type: application/json`
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Nếu database kết nối thành công, sẽ trả về danh sách (có thể rỗng)
```json
{
  "success": true,
  "data": [],
  "message": null,
  "validationErrors": null
}
```

---

## 3. Test CRUD Operations

### B. Tạo stock entry mới (CREATE)
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks`
- **Headers**: 
  - `Content-Type: application/json`
- **Body** (raw JSON):
```json
{
  "skuCode": "LAPTOP-DELL-001",
  "productName": "Dell XPS 13",
  "quantity": 50
}
```
- **Kết quả mong đợi**: 
  - Status: 201 CREATED
  - Response:
```json
{
  "success": true,
  "data": {
    "id": 1,
    "skuCode": "LAPTOP-DELL-001",
    "productName": "Dell XPS 13",
    "quantity": 50
  },
  "message": "Stock entry created successfully",
  "validationErrors": null
}
```

### C. Tạo thêm một vài stock entries khác
**Stock 2:**
```json
{
  "skuCode": "PHONE-IP-14",
  "productName": "iPhone 14 Pro",
  "quantity": 30
}
```

**Stock 3:**
```json
{
  "skuCode": "TABLET-IPAD-AIR",
  "productName": "iPad Air M1",
  "quantity": 20
}
```

### D. Lấy thông tin stock theo SKU Code (READ)
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/stocks/LAPTOP-DELL-001`
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Trả về thông tin stock đã tạo

### E. Lấy tất cả stocks (READ ALL)
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/stocks`
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Danh sách tất cả stocks đã tạo

---

## 4. Test Stock Operations (Thao tác tồn kho)

### F. Thêm stock (IN Operation - Nhập hàng)
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks/LAPTOP-DELL-001/add`
- **Headers**: 
  - `Content-Type: application/json`
- **Body**:
```json
{
  "quantityChange": 25,
  "referenceId": "PO-2026-001",
  "reason": "Nhập hàng từ nhà cung cấp"
}
```
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Quantity tăng từ 50 lên 75

### G. Giảm stock (OUT Operation - Xuất hàng/Bán)
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks/LAPTOP-DELL-001/deduct`
- **Headers**: 
  - `Content-Type: application/json`
- **Body**:
```json
{
  "quantityChange": 10,
  "referenceId": "ORDER-2026-100",
  "reason": "Bán hàng cho khách"
}
```
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Quantity giảm từ 75 xuống 65

### H. Điều chỉnh stock (ADJUSTMENT Operation)
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks/LAPTOP-DELL-001/adjust`
- **Headers**: 
  - `Content-Type: application/json`
- **Body**:
```json
{
  "quantityChange": 5,
  "referenceId": "ADJ-2026-001",
  "reason": "Kiểm kê phát hiện thừa 5 sản phẩm"
}
```
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Quantity tăng thêm 5

---

## 5. Test Inventory Logs (Audit Trail)

### I. Xem tất cả logs (Lịch sử giao dịch tồn kho)
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/inventory-logs`
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Danh sách tất cả các thao tác (IN/OUT/ADJUSTMENT)

### J. Xem logs theo SKU Code
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/inventory-logs/LAPTOP-DELL-001`
- **Kết quả mong đợi**: 
  - Status: 200 OK
  - Danh sách tất cả logs của SKU này (mới nhất trước)

---

## 6. Test Validation (Kiểm tra xác thực dữ liệu)

### K. Test tạo stock với dữ liệu không hợp lệ
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks`
- **Body** (thiếu skuCode):
```json
{
  "productName": "Test Product",
  "quantity": 10
}
```
- **Kết quả mong đợi**: 
  - Status: 400 Bad Request
  - Validation error message

### L. Test deduct với số lượng quá lớn
- **Method**: POST
- **URL**: `http://localhost:8082/api/v1/stocks/PHONE-IP-14/deduct`
- **Body**:
```json
{
  "quantityChange": 1000,
  "reason": "Test insufficient stock"
}
```
- **Kết quả mong đợi**: 
  - Status: 422 Unprocessable Entity
  - Error message về không đủ stock

### M. Test lấy SKU không tồn tại
- **Method**: GET
- **URL**: `http://localhost:8082/api/v1/stocks/NOT-EXIST-SKU`
- **Kết quả mong đợi**: 
  - Status: 404 Not Found

---

## 7. Kiểm tra Database trực tiếp

Sau khi test các API trên, bạn có thể kiểm tra database bằng MySQL:

```sql
-- Kết nối MySQL
mysql -u root -p
-- Nhập password: 08102004

-- Chọn database
USE inventory_service;

-- Xem tất cả tables
SHOW TABLES;

-- Xem dữ liệu stocks
SELECT * FROM stocks;

-- Xem dữ liệu inventory_log
SELECT * FROM inventory_log ORDER BY created_at DESC;

-- Kiểm tra cấu trúc table
DESCRIBE stocks;
DESCRIBE inventory_log;
```

---

## 8. Sử dụng Swagger UI (Cách dễ hơn)

Thay vì dùng Postman, bạn có thể dùng Swagger UI đã tích hợp:

**URL**: `http://localhost:8082/swagger-ui.html`

Swagger UI cung cấp giao diện web để:
- Xem tất cả API endpoints
- Test trực tiếp trên trình duyệt
- Xem request/response schema
- Có nút "Try it out" để test ngay

---

## Checklist Kiểm tra

- [ ] Service khởi động thành công (port 8082)
- [ ] Kết nối database thành công (GET /api/v1/stocks trả về 200)
- [ ] Tạo stock mới thành công
- [ ] Lấy danh sách stocks
- [ ] Lấy stock theo SKU code
- [ ] Thêm stock (add operation)
- [ ] Giảm stock (deduct operation)
- [ ] Điều chỉnh stock (adjust operation)
- [ ] Xem inventory logs
- [ ] Validation hoạt động đúng
- [ ] Database lưu dữ liệu chính xác

---

## Lưu ý quan trọng

1. **Đảm bảo MySQL đang chạy**: Kiểm tra MySQL service
2. **Database phải tồn tại**: `inventory_service` database
3. **Port 8082 không bị chiếm**: Kiểm tra port trước khi start
4. **Eureka Service**: Nếu Eureka chưa chạy, service vẫn hoạt động nhưng sẽ có warning

## Troubleshooting

### Nếu gặp lỗi 500:
- Kiểm tra log console của service
- Kiểm tra MySQL có đang chạy không
- Kiểm tra username/password MySQL

### Nếu không kết nối được:
- Kiểm tra service đã start chưa
- Kiểm tra port 8082
- Xem log để tìm lỗi cụ thể

