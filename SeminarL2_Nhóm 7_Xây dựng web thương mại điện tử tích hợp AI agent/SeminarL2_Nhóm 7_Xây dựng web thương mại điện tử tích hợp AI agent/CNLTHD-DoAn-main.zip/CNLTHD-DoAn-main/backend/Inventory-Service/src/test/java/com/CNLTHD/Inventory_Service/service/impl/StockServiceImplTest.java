package com.CNLTHD.Inventory_Service.service.impl;

import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import com.CNLTHD.Inventory_Service.entity.Stock;
import com.CNLTHD.Inventory_Service.entity.enums.OperationType;
import com.CNLTHD.Inventory_Service.exception.BusinessException;
import com.CNLTHD.Inventory_Service.exception.InsufficientStockException;
import com.CNLTHD.Inventory_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Inventory_Service.mapper.StockMapper;
import com.CNLTHD.Inventory_Service.repository.InventoryLogRepository;
import com.CNLTHD.Inventory_Service.repository.StockRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit test (Function Test) cho StockServiceImpl.
 * Tất cả dependencies được mock - không cần database hay Spring context.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("StockServiceImpl - Function Tests")
class StockServiceImplTest {

    @Mock private StockRepository stockRepository;
    @Mock private InventoryLogRepository inventoryLogRepository;
    @Mock private StockMapper stockMapper;

    @InjectMocks
    private StockServiceImpl stockService;

    private Stock stock;
    private StockResponseDto stockResponse;

    @BeforeEach
    void setUp() {
        stock = new Stock();
        stock.setId(1L);
        stock.setSkuCode("NIKE-AF1-M-WHITE");
        stock.setProductName("Nike Air Force 1");
        stock.setQuantity(50);
        stock.setVersion(0L);

        stockResponse = new StockResponseDto(1L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 50);
    }

    // =========================================================
    //  createStock()
    // =========================================================

    @Nested
    @DisplayName("createStock()")
    class CreateStock {

        @Test
        @DisplayName("Thành công: tạo stock mới và trả về DTO")
        void createStock_success() {
            StockRequestDto req = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", 50);

            when(stockRepository.existsBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(false);
            when(stockMapper.toEntity(req)).thenReturn(stock);
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            StockResponseDto result = stockService.createStock(req);

            assertThat(result).isNotNull();
            assertThat(result.getSkuCode()).isEqualTo("NIKE-AF1-M-WHITE");
            assertThat(result.getQuantity()).isEqualTo(50);
            verify(stockRepository).save(stock);
        }

        @Test
        @DisplayName("Thành công: tạo stock với số lượng ban đầu là 0")
        void createStock_zeroQuantity() {
            StockRequestDto req = new StockRequestDto("NEW-SKU-001", "New Product", 0);
            Stock zeroStock = new Stock(2L, "NEW-SKU-001", "New Product", 0, 0L);
            StockResponseDto zeroResp = new StockResponseDto(2L, "NEW-SKU-001", "New Product", 0);

            when(stockRepository.existsBySkuCode("NEW-SKU-001")).thenReturn(false);
            when(stockMapper.toEntity(req)).thenReturn(zeroStock);
            when(stockRepository.save(zeroStock)).thenReturn(zeroStock);
            when(stockMapper.toResponseDto(zeroStock)).thenReturn(zeroResp);

            StockResponseDto result = stockService.createStock(req);

            assertThat(result.getQuantity()).isEqualTo(0);
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi SKU đã tồn tại")
        void createStock_duplicateSku() {
            StockRequestDto req = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", 50);
            when(stockRepository.existsBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(true);

            assertThatThrownBy(() -> stockService.createStock(req))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("NIKE-AF1-M-WHITE");

            verify(stockRepository, never()).save(any());
        }
    }

    // =========================================================
    //  getBySkuCode()
    // =========================================================

    @Nested
    @DisplayName("getBySkuCode()")
    class GetBySkuCode {

        @Test
        @DisplayName("Thành công: trả về DTO khi SKU tồn tại")
        void getBySkuCode_success() {
            when(stockRepository.findBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            StockResponseDto result = stockService.getBySkuCode("NIKE-AF1-M-WHITE");

            assertThat(result).isNotNull();
            assertThat(result.getSkuCode()).isEqualTo("NIKE-AF1-M-WHITE");
            assertThat(result.getQuantity()).isEqualTo(50);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi SKU không tồn tại")
        void getBySkuCode_notFound() {
            when(stockRepository.findBySkuCode("NOT-EXIST")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> stockService.getBySkuCode("NOT-EXIST"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("NOT-EXIST");
        }
    }

    // =========================================================
    //  getAll()
    // =========================================================

    @Nested
    @DisplayName("getAll()")
    class GetAll {

        @Test
        @DisplayName("Trả về danh sách tất cả stock entries")
        void getAll_returnsList() {
            Stock stock2 = new Stock(2L, "ADIDAS-NMD-L-BLACK", "Adidas NMD", 30, 0L);
            StockResponseDto resp2 = new StockResponseDto(2L, "ADIDAS-NMD-L-BLACK", "Adidas NMD", 30);

            when(stockRepository.findAll()).thenReturn(List.of(stock, stock2));
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);
            when(stockMapper.toResponseDto(stock2)).thenReturn(resp2);

            List<StockResponseDto> result = stockService.getAll();

            assertThat(result).hasSize(2);
        }

        @Test
        @DisplayName("Trả về rỗng khi không có stock nào")
        void getAll_empty() {
            when(stockRepository.findAll()).thenReturn(List.of());

            List<StockResponseDto> result = stockService.getAll();

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  addStock()
    // =========================================================

    @Nested
    @DisplayName("addStock()")
    class AddStock {

        @Test
        @DisplayName("Thành công: cộng thêm số lượng và tạo InventoryLog kiểu IN")
        void addStock_success() {
            StockAdjustmentDto dto = new StockAdjustmentDto(20, "ORDER-001", "Nhập hàng");
            StockResponseDto updatedResp = new StockResponseDto(1L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 70);

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(updatedResp);
            when(inventoryLogRepository.save(any(InventoryLog.class))).thenAnswer(inv -> inv.getArgument(0));

            StockResponseDto result = stockService.addStock("NIKE-AF1-M-WHITE", dto);

            assertThat(stock.getQuantity()).isEqualTo(70);  // 50 + 20
            assertThat(result.getQuantity()).isEqualTo(70);
        }

        @Test
        @DisplayName("InventoryLog được tạo với OperationType.IN và balanceAfter đúng")
        void addStock_createsInventoryLog_withCorrectFields() {
            StockAdjustmentDto dto = new StockAdjustmentDto(20, "ORDER-001", "Nhập hàng");

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            ArgumentCaptor<InventoryLog> logCaptor = ArgumentCaptor.forClass(InventoryLog.class);
            when(inventoryLogRepository.save(logCaptor.capture())).thenReturn(new InventoryLog());

            stockService.addStock("NIKE-AF1-M-WHITE", dto);

            InventoryLog log = logCaptor.getValue();
            assertThat(log.getOperationType()).isEqualTo(OperationType.IN);
            assertThat(log.getQuantityChange()).isEqualTo(20);
            assertThat(log.getBalanceAfter()).isEqualTo(70);  // balanceAfter == stock.quantity sau update
            assertThat(log.getReferenceId()).isEqualTo("ORDER-001");
            assertThat(log.getReason()).isEqualTo("Nhập hàng");
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi SKU không tồn tại")
        void addStock_skuNotFound() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NOT-EXIST")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> stockService.addStock("NOT-EXIST", dto))
                    .isInstanceOf(ResourceNotFoundException.class);

            verify(stockRepository, never()).save(any());
            verify(inventoryLogRepository, never()).save(any());
        }

        @Test
        @DisplayName("Cộng nhiều lần liên tiếp số lượng tăng đúng")
        void addStock_multipleAdds_quantityAccumulates() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, null);

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenAnswer(inv -> new StockResponseDto(
                    stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
            when(inventoryLogRepository.save(any())).thenReturn(new InventoryLog());

            stockService.addStock("NIKE-AF1-M-WHITE", dto);  // 50 + 10 = 60
            stockService.addStock("NIKE-AF1-M-WHITE", dto);  // 60 + 10 = 70
            stockService.addStock("NIKE-AF1-M-WHITE", dto);  // 70 + 10 = 80

            assertThat(stock.getQuantity()).isEqualTo(80);
        }
    }

    // =========================================================
    //  deductStock()
    // =========================================================

    @Nested
    @DisplayName("deductStock()")
    class DeductStock {

        @Test
        @DisplayName("Thành công: trừ số lượng và tạo InventoryLog kiểu OUT")
        void deductStock_success() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, "ORDER-002", "Xuất kho");
            StockResponseDto updatedResp = new StockResponseDto(1L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 40);

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(updatedResp);
            when(inventoryLogRepository.save(any(InventoryLog.class))).thenReturn(new InventoryLog());

            StockResponseDto result = stockService.deductStock("NIKE-AF1-M-WHITE", dto);

            assertThat(stock.getQuantity()).isEqualTo(40);  // 50 - 10
            assertThat(result.getQuantity()).isEqualTo(40);
        }

        @Test
        @DisplayName("InventoryLog được tạo với OperationType.OUT")
        void deductStock_createsInventoryLog_typeOUT() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, "ORDER-002", "Xuất kho");

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            ArgumentCaptor<InventoryLog> logCaptor = ArgumentCaptor.forClass(InventoryLog.class);
            when(inventoryLogRepository.save(logCaptor.capture())).thenReturn(new InventoryLog());

            stockService.deductStock("NIKE-AF1-M-WHITE", dto);

            InventoryLog log = logCaptor.getValue();
            assertThat(log.getOperationType()).isEqualTo(OperationType.OUT);
            assertThat(log.getQuantityChange()).isEqualTo(10);
            assertThat(log.getBalanceAfter()).isEqualTo(40);  // 50 - 10
        }

        @Test
        @DisplayName("Thất bại: ném InsufficientStockException khi số lượng yêu cầu > tồn kho")
        void deductStock_insufficientStock() {
            StockAdjustmentDto dto = new StockAdjustmentDto(100, null, null);  // yêu cầu 100, chỉ có 50
            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));

            assertThatThrownBy(() -> stockService.deductStock("NIKE-AF1-M-WHITE", dto))
                    .isInstanceOf(InsufficientStockException.class)
                    .hasMessageContaining("NIKE-AF1-M-WHITE")
                    .hasMessageContaining("available=50")
                    .hasMessageContaining("requested=100");

            verify(stockRepository, never()).save(any());
            verify(inventoryLogRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném InsufficientStockException khi tồn kho = 0")
        void deductStock_zeroStock_insufficientException() {
            stock.setQuantity(0);
            StockAdjustmentDto dto = new StockAdjustmentDto(1, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));

            assertThatThrownBy(() -> stockService.deductStock("NIKE-AF1-M-WHITE", dto))
                    .isInstanceOf(InsufficientStockException.class);
        }

        @Test
        @DisplayName("Thành công: trừ đúng bằng số lượng tồn kho (quantity về 0)")
        void deductStock_exactAmount_quantityBecomesZero() {
            StockAdjustmentDto dto = new StockAdjustmentDto(50, null, null);  // trừ đúng 50

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenAnswer(inv ->
                    new StockResponseDto(stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
            when(inventoryLogRepository.save(any())).thenReturn(new InventoryLog());

            StockResponseDto result = stockService.deductStock("NIKE-AF1-M-WHITE", dto);

            assertThat(stock.getQuantity()).isEqualTo(0);
            assertThat(result.getQuantity()).isEqualTo(0);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi SKU không tồn tại")
        void deductStock_skuNotFound() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NOT-EXIST")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> stockService.deductStock("NOT-EXIST", dto))
                    .isInstanceOf(ResourceNotFoundException.class);
        }
    }

    // =========================================================
    //  adjustStock()
    // =========================================================

    @Nested
    @DisplayName("adjustStock()")
    class AdjustStock {

        @Test
        @DisplayName("Thành công: điều chỉnh tăng số lượng và tạo log ADJUSTMENT")
        void adjustStock_increase_success() {
            StockAdjustmentDto dto = new StockAdjustmentDto(15, "ADJ-001", "Kiểm kho");

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenAnswer(inv ->
                    new StockResponseDto(stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
            when(inventoryLogRepository.save(any(InventoryLog.class))).thenReturn(new InventoryLog());

            StockResponseDto result = stockService.adjustStock("NIKE-AF1-M-WHITE", dto);

            assertThat(stock.getQuantity()).isEqualTo(65);  // 50 + 15
            assertThat(result.getQuantity()).isEqualTo(65);
        }

        @Test
        @DisplayName("InventoryLog được tạo với OperationType.ADJUSTMENT")
        void adjustStock_createsInventoryLog_typeADJUSTMENT() {
            StockAdjustmentDto dto = new StockAdjustmentDto(15, "ADJ-001", "Kiểm kho");

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            ArgumentCaptor<InventoryLog> logCaptor = ArgumentCaptor.forClass(InventoryLog.class);
            when(inventoryLogRepository.save(logCaptor.capture())).thenReturn(new InventoryLog());

            stockService.adjustStock("NIKE-AF1-M-WHITE", dto);

            InventoryLog log = logCaptor.getValue();
            assertThat(log.getOperationType()).isEqualTo(OperationType.ADJUSTMENT);
            assertThat(log.getQuantityChange()).isEqualTo(15);
        }

        @Test
        @DisplayName("Bất biến: balanceAfter trong log luôn bằng stock.quantity sau khi cập nhật")
        void adjustStock_invariant_balanceAfterEqualsStockQuantity() {
            StockAdjustmentDto dto = new StockAdjustmentDto(15, null, null);

            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            ArgumentCaptor<InventoryLog> logCaptor = ArgumentCaptor.forClass(InventoryLog.class);
            when(inventoryLogRepository.save(logCaptor.capture())).thenReturn(new InventoryLog());

            stockService.adjustStock("NIKE-AF1-M-WHITE", dto);

            InventoryLog log = logCaptor.getValue();
            // Invariant: balanceAfter phải bằng số lượng stock sau khi cập nhật
            assertThat(log.getBalanceAfter()).isEqualTo(stock.getQuantity());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi SKU không tồn tại")
        void adjustStock_skuNotFound() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NOT-EXIST")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> stockService.adjustStock("NOT-EXIST", dto))
                    .isInstanceOf(ResourceNotFoundException.class);
        }
    }

    // =========================================================
    //  Kiểm tra tính nhất quán dữ liệu (Data Integrity)
    // =========================================================

    @Nested
    @DisplayName("Tính nhất quán dữ liệu")
    class DataIntegrity {

        @Test
        @DisplayName("addStock: skuCode trong log phải khớp với stock.skuCode")
        void addStock_logSkuCodeMatchesStock() {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

            ArgumentCaptor<InventoryLog> logCaptor = ArgumentCaptor.forClass(InventoryLog.class);
            when(inventoryLogRepository.save(logCaptor.capture())).thenReturn(new InventoryLog());

            stockService.addStock("NIKE-AF1-M-WHITE", dto);

            assertThat(logCaptor.getValue().getSkuCode()).isEqualTo(stock.getSkuCode());
        }

        @Test
        @DisplayName("deductStock: mỗi thao tác tạo đúng 1 bản ghi InventoryLog")
        void deductStock_createsExactlyOneLog() {
            StockAdjustmentDto dto = new StockAdjustmentDto(5, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);
            when(inventoryLogRepository.save(any())).thenReturn(new InventoryLog());

            stockService.deductStock("NIKE-AF1-M-WHITE", dto);

            verify(inventoryLogRepository, times(1)).save(any(InventoryLog.class));
        }

        @Test
        @DisplayName("Mỗi thao tác ghi (add/deduct/adjust) đều lưu stock và log trong cùng transaction")
        void writeOperations_alwaysSaveBothStockAndLog() {
            StockAdjustmentDto dto = new StockAdjustmentDto(5, null, null);
            when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
            when(stockRepository.save(stock)).thenReturn(stock);
            when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);
            when(inventoryLogRepository.save(any())).thenReturn(new InventoryLog());

            stockService.addStock("NIKE-AF1-M-WHITE", dto);

            verify(stockRepository, times(1)).save(stock);
            verify(inventoryLogRepository, times(1)).save(any(InventoryLog.class));
        }
    }
}
