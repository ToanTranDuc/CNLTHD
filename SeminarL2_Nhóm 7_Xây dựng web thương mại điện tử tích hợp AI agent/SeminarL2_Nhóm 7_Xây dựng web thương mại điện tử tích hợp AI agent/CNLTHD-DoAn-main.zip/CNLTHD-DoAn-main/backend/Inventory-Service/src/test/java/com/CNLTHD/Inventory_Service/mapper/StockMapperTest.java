package com.CNLTHD.Inventory_Service.mapper;

import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.entity.Stock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit test (Function Test) cho StockMapper.
 * Không cần mock hay Spring context - test trực tiếp instance.
 */
@DisplayName("StockMapper - Function Tests")
class StockMapperTest {

    private StockMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new StockMapper();
    }

    // =========================================================
    //  toEntity()
    // =========================================================

    @Nested
    @DisplayName("toEntity(StockRequestDto)")
    class ToEntity {

        @Test
        @DisplayName("Map đúng skuCode từ DTO sang entity")
        void toEntity_mapsSkuCode() {
            StockRequestDto dto = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", 50);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getSkuCode()).isEqualTo("NIKE-AF1-M-WHITE");
        }

        @Test
        @DisplayName("Map đúng productName từ DTO sang entity")
        void toEntity_mapsProductName() {
            StockRequestDto dto = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", 50);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getProductName()).isEqualTo("Nike Air Force 1");
        }

        @Test
        @DisplayName("Map đúng quantity từ DTO sang entity")
        void toEntity_mapsQuantity() {
            StockRequestDto dto = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", 100);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getQuantity()).isEqualTo(100);
        }

        @Test
        @DisplayName("Khi quantity là null, entity được set về 0")
        void toEntity_nullQuantity_defaultsToZero() {
            StockRequestDto dto = new StockRequestDto("NIKE-AF1-M-WHITE", "Nike Air Force 1", null);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getQuantity()).isEqualTo(0);
        }

        @Test
        @DisplayName("Map đúng khi quantity = 0")
        void toEntity_zeroQuantity() {
            StockRequestDto dto = new StockRequestDto("SKU-ZERO", "Zero Product", 0);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getQuantity()).isEqualTo(0);
        }

        @Test
        @DisplayName("id và version không được set bởi mapper (JPA tự quản lý)")
        void toEntity_idAndVersionNotSet() {
            StockRequestDto dto = new StockRequestDto("SKU-001", "Product", 10);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getId()).isNull();
            assertThat(result.getVersion()).isNull();
        }

        @Test
        @DisplayName("Map đúng SKU có ký tự đặc biệt (gạch ngang, gạch dưới)")
        void toEntity_skuWithSpecialChars() {
            StockRequestDto dto = new StockRequestDto("BRAND_PROD-001_XL-RED", "Product Name", 25);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getSkuCode()).isEqualTo("BRAND_PROD-001_XL-RED");
        }

        @Test
        @DisplayName("Map đúng số lượng lớn (edge case)")
        void toEntity_largeQuantity() {
            StockRequestDto dto = new StockRequestDto("BULK-SKU", "Bulk Product", 999999);

            Stock result = mapper.toEntity(dto);

            assertThat(result.getQuantity()).isEqualTo(999999);
        }
    }

    // =========================================================
    //  toResponseDto()
    // =========================================================

    @Nested
    @DisplayName("toResponseDto(Stock)")
    class ToResponseDto {

        @Test
        @DisplayName("Map đúng id từ entity sang DTO")
        void toResponseDto_mapsId() {
            Stock stock = new Stock(42L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 50, 1L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getId()).isEqualTo(42L);
        }

        @Test
        @DisplayName("Map đúng skuCode từ entity sang DTO")
        void toResponseDto_mapsSkuCode() {
            Stock stock = new Stock(1L, "ADIDAS-NMD-L-BLACK", "Adidas NMD", 30, 0L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getSkuCode()).isEqualTo("ADIDAS-NMD-L-BLACK");
        }

        @Test
        @DisplayName("Map đúng productName từ entity sang DTO")
        void toResponseDto_mapsProductName() {
            Stock stock = new Stock(1L, "SKU-001", "My Product Name", 10, 0L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getProductName()).isEqualTo("My Product Name");
        }

        @Test
        @DisplayName("Map đúng quantity từ entity sang DTO")
        void toResponseDto_mapsQuantity() {
            Stock stock = new Stock(1L, "SKU-001", "Product", 75, 0L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getQuantity()).isEqualTo(75);
        }

        @Test
        @DisplayName("Map đúng tất cả field trong một lần gọi")
        void toResponseDto_mapsAllFields() {
            Stock stock = new Stock(99L, "COMPLETE-SKU", "Complete Product", 123, 5L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getId()).isEqualTo(99L);
            assertThat(result.getSkuCode()).isEqualTo("COMPLETE-SKU");
            assertThat(result.getProductName()).isEqualTo("Complete Product");
            assertThat(result.getQuantity()).isEqualTo(123);
        }

        @Test
        @DisplayName("Map đúng khi quantity = 0")
        void toResponseDto_zeroQuantity() {
            Stock stock = new Stock(1L, "EMPTY-SKU", "Empty Product", 0, 0L);

            StockResponseDto result = mapper.toResponseDto(stock);

            assertThat(result.getQuantity()).isEqualTo(0);
        }
    }

    // =========================================================
    //  Round-trip: toEntity → toResponseDto
    // =========================================================

    @Nested
    @DisplayName("Round-trip mapping")
    class RoundTrip {

        @Test
        @DisplayName("toEntity rồi toResponseDto giữ nguyên skuCode và productName")
        void roundTrip_preservesSkuAndName() {
            StockRequestDto req = new StockRequestDto("RT-SKU-001", "Round Trip Product", 55);

            Stock entity = mapper.toEntity(req);
            entity.setId(10L);  // Giả lập JPA tự gán ID
            StockResponseDto response = mapper.toResponseDto(entity);

            assertThat(response.getSkuCode()).isEqualTo(req.getSkuCode());
            assertThat(response.getProductName()).isEqualTo(req.getProductName());
            assertThat(response.getQuantity()).isEqualTo(req.getQuantity());
        }
    }
}
