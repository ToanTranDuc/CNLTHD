package com.CNLTHD.Inventory_Service.performance;

import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import com.CNLTHD.Inventory_Service.entity.Stock;
import com.CNLTHD.Inventory_Service.exception.InsufficientStockException;
import com.CNLTHD.Inventory_Service.mapper.StockMapper;
import com.CNLTHD.Inventory_Service.repository.InventoryLogRepository;
import com.CNLTHD.Inventory_Service.repository.StockRepository;
import com.CNLTHD.Inventory_Service.service.impl.StockServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Unit Performance Test – đo thời gian thực thi từng method của StockService
 * với dependencies được mock (không có I/O thực).
 * Mục tiêu: phát hiện logic chậm trong các thao tác stock mutation.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("StockService - Performance Tests (Unit)")
class StockServicePerformanceTest {

    private static final int ITERATIONS = 200;
    private static final long MAX_TOTAL_MS = 500;
    private static final long MAX_SINGLE_MS = 50;

    @Mock private StockRepository stockRepository;
    @Mock private InventoryLogRepository inventoryLogRepository;
    @Mock private StockMapper stockMapper;

    @InjectMocks
    private StockServiceImpl stockService;

    private Stock stock;
    private StockResponseDto stockResponse;

    @BeforeEach
    void setUp() {
        stock = new Stock(1L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 10000, 0L);
        stockResponse = new StockResponseDto(1L, "NIKE-AF1-M-WHITE", "Nike Air Force 1", 10000);
    }

    @Test
    @DisplayName("getBySkuCode(): " + ITERATIONS + " lần truy vấn hoàn thành trong " + MAX_TOTAL_MS + "ms")
    void getBySkuCode_performanceProfile() {
        when(stockRepository.findBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
        when(stockMapper.toResponseDto(stock)).thenReturn(stockResponse);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            stockService.getBySkuCode("NIKE-AF1-M-WHITE");
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("getBySkuCode() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("getAll(): " + ITERATIONS + " lần với 100 entries mỗi lần")
    void getAll_performanceProfile() {
        List<Stock> stocks = buildStockList(100);
        when(stockRepository.findAll()).thenReturn(stocks);
        when(stockMapper.toResponseDto(any(Stock.class))).thenReturn(stockResponse);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            stockService.getAll();
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("getAll() %d lần (100 items/lần) phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("addStock(): " + ITERATIONS + " lần nhập hàng hoàn thành nhanh")
    void addStock_performanceProfile() {
        stock.setQuantity(1_000_000);  // số lớn để không bao giờ âm
        StockAdjustmentDto dto = new StockAdjustmentDto(1, null, null);

        when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
        when(stockRepository.save(stock)).thenReturn(stock);
        when(stockMapper.toResponseDto(stock)).thenAnswer(inv ->
                new StockResponseDto(stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
        when(inventoryLogRepository.save(any(InventoryLog.class))).thenReturn(new InventoryLog());

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            stockService.addStock("NIKE-AF1-M-WHITE", dto);
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("addStock() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("deductStock(): " + ITERATIONS + " lần xuất kho hoàn thành nhanh")
    void deductStock_performanceProfile() {
        stock.setQuantity(1_000_000);
        StockAdjustmentDto dto = new StockAdjustmentDto(1, null, null);

        when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
        when(stockRepository.save(stock)).thenReturn(stock);
        when(stockMapper.toResponseDto(stock)).thenAnswer(inv ->
                new StockResponseDto(stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
        when(inventoryLogRepository.save(any(InventoryLog.class))).thenReturn(new InventoryLog());

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            stockService.deductStock("NIKE-AF1-M-WHITE", dto);
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("deductStock() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("adjustStock(): " + ITERATIONS + " lần điều chỉnh kho hoàn thành nhanh")
    void adjustStock_performanceProfile() {
        StockAdjustmentDto dto = new StockAdjustmentDto(1, null, null);

        when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));
        when(stockRepository.save(stock)).thenReturn(stock);
        when(stockMapper.toResponseDto(stock)).thenAnswer(inv ->
                new StockResponseDto(stock.getId(), stock.getSkuCode(), stock.getProductName(), stock.getQuantity()));
        when(inventoryLogRepository.save(any(InventoryLog.class))).thenReturn(new InventoryLog());

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            stockService.adjustStock("NIKE-AF1-M-WHITE", dto);
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("adjustStock() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("createStock(): mỗi lần tạo stock không vượt quá " + MAX_SINGLE_MS + "ms")
    void createStock_singleCallPerformance() {
        StockRequestDto req = new StockRequestDto("PERF-SKU-001", "Perf Product", 100);
        Stock s = new Stock(99L, "PERF-SKU-001", "Perf Product", 100, 0L);
        StockResponseDto resp = new StockResponseDto(99L, "PERF-SKU-001", "Perf Product", 100);

        when(stockRepository.existsBySkuCode("PERF-SKU-001")).thenReturn(false);
        when(stockMapper.toEntity(req)).thenReturn(s);
        when(stockRepository.save(s)).thenReturn(s);
        when(stockMapper.toResponseDto(s)).thenReturn(resp);

        long start = System.currentTimeMillis();
        stockService.createStock(req);
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("createStock() một lần không được vượt quá %dms, thực tế: %dms",
                        MAX_SINGLE_MS, elapsed)
                .isLessThan(MAX_SINGLE_MS);
    }

    @Test
    @DisplayName("deductStock() exception path: xử lý InsufficientStock không làm chậm hệ thống")
    void deductStock_insufficientStock_exceptionPathPerformance() {
        stock.setQuantity(0);
        StockAdjustmentDto dto = new StockAdjustmentDto(1, null, null);

        when(stockRepository.findBySkuCodeForUpdate("NIKE-AF1-M-WHITE")).thenReturn(Optional.of(stock));

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            try {
                stockService.deductStock("NIKE-AF1-M-WHITE", dto);
            } catch (InsufficientStockException ignored) {
            }
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("deductStock() exception path %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    // ── helper ──────────────────────────────────────────────────────────────

    private List<Stock> buildStockList(int count) {
        List<Stock> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            list.add(new Stock((long) i, "SKU-" + i, "Product " + i, 100, 0L));
        }
        return list;
    }
}
