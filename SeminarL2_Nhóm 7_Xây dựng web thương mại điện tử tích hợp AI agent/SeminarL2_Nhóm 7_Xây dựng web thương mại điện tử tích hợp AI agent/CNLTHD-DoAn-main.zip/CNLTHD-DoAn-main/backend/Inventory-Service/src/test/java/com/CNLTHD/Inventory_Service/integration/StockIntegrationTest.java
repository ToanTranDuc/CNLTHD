package com.CNLTHD.Inventory_Service.integration;

import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import com.CNLTHD.Inventory_Service.entity.Stock;
import com.CNLTHD.Inventory_Service.entity.enums.OperationType;
import com.CNLTHD.Inventory_Service.repository.InventoryLogRepository;
import com.CNLTHD.Inventory_Service.repository.StockRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for Inventory Service.
 *
 * Covers:
 *   - Function Test  : kiểm thử chức năng từng endpoint qua HTTP (MockMvc)
 *   - Data Integrity : kiểm thử ràng buộc DB và bất biến nghiệp vụ
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@DisplayName("Inventory Service – Integration Tests")
class StockIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private InventoryLogRepository inventoryLogRepository;

    private MockMvc mockMvc;

    // =========================================================================
    // Setup
    // =========================================================================

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
        inventoryLogRepository.deleteAll();
        stockRepository.deleteAll();
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private void createStock(String skuCode, String productName, int quantity) throws Exception {
        StockRequestDto dto = new StockRequestDto(skuCode, productName, quantity);
        mockMvc.perform(post("/api/stocks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated());
    }

    private void addStock(String skuCode, int qty) throws Exception {
        StockAdjustmentDto dto = new StockAdjustmentDto(qty, null, "setup");
        mockMvc.perform(post("/api/stocks/" + skuCode + "/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk());
    }

    // =========================================================================
    // FUNCTION TESTS – kiểm thử chức năng
    // =========================================================================

    @Nested
    @DisplayName("Function Tests – Kiểm thử chức năng")
    class FunctionTests {

        @Test
        @DisplayName("FT-01: Tạo stock mới – trả về 201 và dữ liệu chính xác")
        void createStock_validRequest_returns201WithCorrectData() throws Exception {
            StockRequestDto dto = new StockRequestDto("SKU-FT-01", "Áo phông trắng", 100);

            mockMvc.perform(post("/api/stocks")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.data.skuCode").value("SKU-FT-01"))
                    .andExpect(jsonPath("$.data.productName").value("Áo phông trắng"))
                    .andExpect(jsonPath("$.data.quantity").value(100));
        }

        @Test
        @DisplayName("FT-02: Lấy stock theo SKU tồn tại – trả về 200 và đúng dữ liệu")
        void getBySkuCode_existingSku_returns200() throws Exception {
            createStock("SKU-FT-02", "Quần jean", 50);

            mockMvc.perform(get("/api/stocks/SKU-FT-02"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.skuCode").value("SKU-FT-02"))
                    .andExpect(jsonPath("$.data.quantity").value(50));
        }

        @Test
        @DisplayName("FT-03: Lấy stock theo SKU không tồn tại – trả về 404")
        void getBySkuCode_nonExistentSku_returns404() throws Exception {
            mockMvc.perform(get("/api/stocks/SKU-DOES-NOT-EXIST"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.status").value(404));
        }

        @Test
        @DisplayName("FT-04: Lấy tất cả stock – trả về danh sách đầy đủ")
        void getAllStocks_returnsAllEntries() throws Exception {
            createStock("SKU-FT-04A", "Áo khoác", 30);
            createStock("SKU-FT-04B", "Váy liền", 20);

            mockMvc.perform(get("/api/stocks"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(2));
        }

        @Test
        @DisplayName("FT-05: Thêm stock (IN) – số lượng tăng đúng giá trị")
        void addStock_increasesQuantityByExactAmount() throws Exception {
            createStock("SKU-FT-05", "Giày sneaker", 50);
            StockAdjustmentDto dto = new StockAdjustmentDto(30, "PO-001", "Nhập hàng");

            mockMvc.perform(post("/api/stocks/SKU-FT-05/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.quantity").value(80));
        }

        @Test
        @DisplayName("FT-06: Trừ stock (OUT) – số lượng giảm đúng giá trị")
        void deductStock_decreasesQuantityByExactAmount() throws Exception {
            createStock("SKU-FT-06", "Túi xách", 100);
            StockAdjustmentDto dto = new StockAdjustmentDto(40, "ORDER-001", "Đơn hàng khách");

            mockMvc.perform(post("/api/stocks/SKU-FT-06/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.quantity").value(60));
        }

        @Test
        @DisplayName("FT-07: Điều chỉnh stock (ADJUSTMENT) – số lượng thay đổi đúng")
        void adjustStock_changesQuantityCorrectly() throws Exception {
            createStock("SKU-FT-07", "Thắt lưng", 200);
            StockAdjustmentDto dto = new StockAdjustmentDto(50, null, "Điều chỉnh thủ công");

            mockMvc.perform(post("/api/stocks/SKU-FT-07/adjust")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.quantity").value(250));
        }

        @Test
        @DisplayName("FT-08: Trừ quá số lượng có sẵn – trả về 422 Unprocessable Entity")
        void deductStock_exceedsAvailableQuantity_returns422() throws Exception {
            createStock("SKU-FT-08", "Mũ lưỡi trai", 10);
            StockAdjustmentDto dto = new StockAdjustmentDto(50, "ORDER-999", "Vượt tồn kho");

            mockMvc.perform(post("/api/stocks/SKU-FT-08/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().is(422))
                    .andExpect(jsonPath("$.status").value(422));
        }

        @Test
        @DisplayName("FT-09: Thêm stock cho SKU không tồn tại – trả về 404")
        void addStock_nonExistentSku_returns404() throws Exception {
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, "Test");

            mockMvc.perform(post("/api/stocks/SKU-GHOST/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isNotFound());
        }

        @Test
        @DisplayName("FT-10: Tạo stock với dữ liệu thiếu/sai – trả về 400 Bad Request")
        void createStock_missingRequiredField_returns400() throws Exception {
            // quantity là null → vi phạm @NotNull
            String invalidJson = "{\"skuCode\": \"SKU-INVALID\", \"productName\": \"Test\"}";

            mockMvc.perform(post("/api/stocks")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(invalidJson))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.status").value(400));
        }

        @Test
        @DisplayName("FT-11: Trừ stock về đúng 0 – cho phép và trả về 200")
        void deductStock_toExactlyZero_isAllowed() throws Exception {
            createStock("SKU-FT-11", "Kính mắt", 25);
            StockAdjustmentDto dto = new StockAdjustmentDto(25, "ORDER-ZERO", "Hết hàng");

            mockMvc.perform(post("/api/stocks/SKU-FT-11/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.quantity").value(0));
        }
    }

    // =========================================================================
    // DATA INTEGRITY TESTS – kiểm thử tính toàn vẹn dữ liệu
    // =========================================================================

    @Nested
    @DisplayName("Data Integrity Tests – Kiểm thử tính toàn vẹn dữ liệu")
    class DataIntegrityTests {

        @Test
        @DisplayName("DI-01: Tạo stock với SKU trùng lặp – trả về 409 Conflict (unique constraint)")
        void createStock_duplicateSku_returns409() throws Exception {
            createStock("SKU-DUP-001", "Sản phẩm gốc", 100);

            StockRequestDto dto = new StockRequestDto("SKU-DUP-001", "Sản phẩm khác", 50);
            mockMvc.perform(post("/api/stocks")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.status").value(409));
        }

        @Test
        @DisplayName("DI-02: Bất biến addStock – balanceAfter trong log == quantity trong Stock")
        void addStock_balanceAfterInLogEqualsStockQuantity() throws Exception {
            createStock("SKU-DI-02", "Áo polo", 100);
            StockAdjustmentDto dto = new StockAdjustmentDto(25, "PO-DI", "Kiểm tra bất biến");

            mockMvc.perform(post("/api/stocks/SKU-DI-02/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk());

            Stock stock = stockRepository.findBySkuCode("SKU-DI-02").orElseThrow();
            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-02");

            assertThat(logs).hasSize(1);
            assertThat(logs.get(0).getBalanceAfter())
                    .as("balanceAfter trong log phải bằng quantity hiện tại của Stock")
                    .isEqualTo(stock.getQuantity());
            assertThat(stock.getQuantity()).isEqualTo(125);
        }

        @Test
        @DisplayName("DI-03: Bất biến deductStock – balanceAfter trong log == quantity trong Stock")
        void deductStock_balanceAfterInLogEqualsStockQuantity() throws Exception {
            createStock("SKU-DI-03", "Quần kaki", 200);
            StockAdjustmentDto dto = new StockAdjustmentDto(70, "ORD-DI", "Kiểm tra bất biến OUT");

            mockMvc.perform(post("/api/stocks/SKU-DI-03/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk());

            Stock stock = stockRepository.findBySkuCode("SKU-DI-03").orElseThrow();
            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-03");

            assertThat(logs).hasSize(1);
            assertThat(logs.get(0).getBalanceAfter()).isEqualTo(stock.getQuantity());
            assertThat(stock.getQuantity()).isEqualTo(130);
        }

        @Test
        @DisplayName("DI-04: Bất biến adjustStock – balanceAfter trong log == quantity trong Stock")
        void adjustStock_balanceAfterInLogEqualsStockQuantity() throws Exception {
            createStock("SKU-DI-04", "Dép thể thao", 50);
            StockAdjustmentDto dto = new StockAdjustmentDto(15, null, "Điều chỉnh test");

            mockMvc.perform(post("/api/stocks/SKU-DI-04/adjust")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk());

            Stock stock = stockRepository.findBySkuCode("SKU-DI-04").orElseThrow();
            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-04");

            assertThat(logs).hasSize(1);
            assertThat(logs.get(0).getBalanceAfter()).isEqualTo(stock.getQuantity());
            assertThat(stock.getQuantity()).isEqualTo(65);
        }

        @Test
        @DisplayName("DI-05: Nhiều thao tác liên tiếp – tất cả log được lưu, bất biến cuối giữ")
        void multipleOperations_allLogsPersistedAndFinalInvariantHolds() throws Exception {
            createStock("SKU-DI-05", "Vớ thể thao", 100);

            // IN +50 → 150
            mockMvc.perform(post("/api/stocks/SKU-DI-05/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(50, "REF-A", "Nhập thêm"))))
                    .andExpect(status().isOk());

            // OUT -30 → 120
            mockMvc.perform(post("/api/stocks/SKU-DI-05/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(30, "REF-B", "Xuất hàng"))))
                    .andExpect(status().isOk());

            // ADJUSTMENT +20 → 140
            mockMvc.perform(post("/api/stocks/SKU-DI-05/adjust")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(20, null, "Cân bằng kho"))))
                    .andExpect(status().isOk());

            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-05");
            Stock stock = stockRepository.findBySkuCode("SKU-DI-05").orElseThrow();

            assertThat(logs).hasSize(3);
            assertThat(stock.getQuantity()).isEqualTo(140);
            // Log mới nhất (index 0) phải khớp với số lượng hiện tại
            assertThat(logs.get(0).getBalanceAfter()).isEqualTo(stock.getQuantity());
        }

        @Test
        @DisplayName("DI-06: InventoryLog ghi đúng OperationType cho từng thao tác")
        void inventoryLog_operationTypeMatchesAction() throws Exception {
            createStock("SKU-DI-06", "Nón lưỡi trai", 100);

            mockMvc.perform(post("/api/stocks/SKU-DI-06/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(10, null, null))))
                    .andExpect(status().isOk());

            mockMvc.perform(post("/api/stocks/SKU-DI-06/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(5, null, null))))
                    .andExpect(status().isOk());

            mockMvc.perform(post("/api/stocks/SKU-DI-06/adjust")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(
                                    new StockAdjustmentDto(3, null, null))))
                    .andExpect(status().isOk());

            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-06");

            assertThat(logs).hasSize(3);
            assertThat(logs.get(0).getOperationType()).isEqualTo(OperationType.ADJUSTMENT);
            assertThat(logs.get(1).getOperationType()).isEqualTo(OperationType.OUT);
            assertThat(logs.get(2).getOperationType()).isEqualTo(OperationType.IN);
        }

        @Test
        @DisplayName("DI-07: InventoryLog tự động điền createdBy và createdAt (JPA Auditing)")
        void inventoryLog_auditFieldsAutoPopulated() throws Exception {
            createStock("SKU-DI-07", "Quần short", 80);
            StockAdjustmentDto dto = new StockAdjustmentDto(10, null, "Kiểm tra audit");

            mockMvc.perform(post("/api/stocks/SKU-DI-07/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isOk());

            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-07");

            assertThat(logs).hasSize(1);
            assertThat(logs.get(0).getCreatedBy())
                    .as("createdBy phải được tự động điền (không null)")
                    .isNotNull().isNotBlank();
            assertThat(logs.get(0).getCreatedAt())
                    .as("createdAt phải được tự động điền")
                    .isNotNull();
        }

        @Test
        @DisplayName("DI-08: quantityChange phải >= 1 – giá trị 0 bị từ chối (validation constraint)")
        void stockAdjustment_zeroQuantityChange_returns400() throws Exception {
            createStock("SKU-DI-08", "Áo ba lỗ", 50);
            String invalidJson = "{\"quantityChange\": 0}";

            mockMvc.perform(post("/api/stocks/SKU-DI-08/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(invalidJson))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("DI-09: @Version tăng sau mỗi lần cập nhật Stock (optimistic locking)")
        void stock_versionFieldIncrementsOnUpdate() throws Exception {
            createStock("SKU-DI-09", "Khăn choàng", 60);

            Stock before = stockRepository.findBySkuCode("SKU-DI-09").orElseThrow();
            long versionBefore = before.getVersion();

            addStock("SKU-DI-09", 10);

            Stock after = stockRepository.findBySkuCode("SKU-DI-09").orElseThrow();
            assertThat(after.getVersion())
                    .as("@Version phải tăng sau mỗi lần lưu")
                    .isGreaterThan(versionBefore);
        }

        @Test
        @DisplayName("DI-10: Log ghi quantityChange dương, operationType OUT khi deduct")
        void inventoryLog_deductRecordsPositiveQuantityChangeWithOutType() throws Exception {
            createStock("SKU-DI-10", "Balo du lịch", 100);

            StockAdjustmentDto deductDto = new StockAdjustmentDto(35, "REF-D", "Test deduct log");
            mockMvc.perform(post("/api/stocks/SKU-DI-10/deduct")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(deductDto)))
                    .andExpect(status().isOk());

            List<InventoryLog> logs = inventoryLogRepository
                    .findAllBySkuCodeOrderByCreatedAtDesc("SKU-DI-10");

            assertThat(logs).hasSize(1);
            // Service lưu quantityChange là giá trị dương (35), không phải -35
            assertThat(logs.get(0).getQuantityChange()).isEqualTo(35);
            assertThat(logs.get(0).getOperationType()).isEqualTo(OperationType.OUT);
        }
    }
}
