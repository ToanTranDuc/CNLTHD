package com.CNLTHD.Inventory_Service.service.impl;

import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import com.CNLTHD.Inventory_Service.entity.Stock;
import com.CNLTHD.Inventory_Service.entity.enums.OperationType;
import com.CNLTHD.Inventory_Service.exception.BusinessException;
import com.CNLTHD.Inventory_Service.exception.InsufficientStockException;
import com.CNLTHD.Inventory_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Inventory_Service.mapper.StockMapper;
import com.CNLTHD.Inventory_Service.repository.InventoryLogRepository;
import com.CNLTHD.Inventory_Service.repository.StockRepository;
import com.CNLTHD.Inventory_Service.service.StockService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Stateless implementation of {@link StockService}.
 *
 * <p>
 * <b>Atomicity guarantee:</b> Every method that mutates quantity acquires a
 * pessimistic write-lock on the {@link Stock} row before modification, then
 * inserts a new {@link InventoryLog} record in the same transaction.
 * If either operation fails, the entire transaction is rolled back.
 *
 * <p>
 * <b>Invariant:</b> After every operation,
 * {@code inventoryLog.balanceAfter == stock.quantity}.
 */
@Service
@Transactional(readOnly = true)
public class StockServiceImpl implements StockService {

    private static final Logger log = LoggerFactory.getLogger(StockServiceImpl.class);

    private final StockRepository stockRepository;
    private final InventoryLogRepository inventoryLogRepository;
    private final StockMapper stockMapper;

    public StockServiceImpl(StockRepository stockRepository,
            InventoryLogRepository inventoryLogRepository,
            StockMapper stockMapper) {
        this.stockRepository = stockRepository;
        this.inventoryLogRepository = inventoryLogRepository;
        this.stockMapper = stockMapper;
    }

    // =========================================================================
    // Read operations
    // =========================================================================

    @Override
    public StockResponseDto getBySkuCode(String skuCode) {
        Stock stock = stockRepository.findBySkuCode(skuCode)
                .orElseThrow(() -> new ResourceNotFoundException("Stock", "skuCode", skuCode));
        return stockMapper.toResponseDto(stock);
    }

    @Override
    public List<StockResponseDto> getAll() {
        return stockRepository.findAll().stream()
                .map(stockMapper::toResponseDto)
                .toList();
    }

    // =========================================================================
    // Write operations – all @Transactional(readOnly = false)
    // =========================================================================

    @Override
    @Transactional
    public StockResponseDto createStock(StockRequestDto dto) {
        if (stockRepository.existsBySkuCode(dto.getSkuCode())) {
            throw new BusinessException("Stock",
                    "A stock entry for SKU '" + dto.getSkuCode() + "' already exists.");
        }
        Stock saved = stockRepository.save(stockMapper.toEntity(dto));
        log.info("Created stock entry for SKU '{}' with initial quantity={}", saved.getSkuCode(), saved.getQuantity());
        return stockMapper.toResponseDto(saved);
    }

    @Override
    @Transactional
    public StockResponseDto addStock(String skuCode, StockAdjustmentDto dto) {
        Stock stock = lockStock(skuCode);
        int prevQty = stock.getQuantity();
        stock.setQuantity(prevQty + dto.getQuantityChange());
        stockRepository.save(stock);

        insertLog(stock, OperationType.IN, dto.getQuantityChange(), dto.getReferenceId(), dto.getReason());

        log.info("IN  SKU='{}' +{} → quantity={}", skuCode, dto.getQuantityChange(), stock.getQuantity());
        return stockMapper.toResponseDto(stock);
    }

    @Override
    @Transactional
    public StockResponseDto deductStock(String skuCode, StockAdjustmentDto dto) {
        Stock stock = lockStock(skuCode);
        int available = stock.getQuantity();
        int requested = dto.getQuantityChange();

        if (available < requested) {
            throw new InsufficientStockException(skuCode, available, requested);
        }

        stock.setQuantity(available - requested);
        stockRepository.save(stock);

        insertLog(stock, OperationType.OUT, dto.getQuantityChange(), dto.getReferenceId(), dto.getReason());

        log.info("OUT SKU='{}' -{} → quantity={}", skuCode, requested, stock.getQuantity());
        return stockMapper.toResponseDto(stock);
    }

    @Override
    @Transactional
    public StockResponseDto adjustStock(String skuCode, StockAdjustmentDto dto) {
        Stock stock = lockStock(skuCode);
        int current = stock.getQuantity();
        int delta = dto.getQuantityChange();

        // For ADJUSTMENT the caller supplies an absolute positive delta;
        // the service adds it on top of the current quantity.
        // Negative-correction adjustments should be performed via deductStock.
        int newQty = current + delta;
        if (newQty < 0) {
            throw new BusinessException("Stock",
                    "Adjustment would result in negative quantity for SKU '" + skuCode + "'.");
        }

        stock.setQuantity(newQty);
        stockRepository.save(stock);

        insertLog(stock, OperationType.ADJUSTMENT, delta, dto.getReferenceId(), dto.getReason());

        log.info("ADJ SKU='{}' +{} → quantity={}", skuCode, delta, stock.getQuantity());
        return stockMapper.toResponseDto(stock);
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private Stock lockStock(String skuCode) {
        return stockRepository.findBySkuCodeForUpdate(skuCode)
                .orElseThrow(() -> new ResourceNotFoundException("Stock", "skuCode", skuCode));
    }

    /**
     * Creates and persists a new {@link InventoryLog} record.
     * <p>
     * <b>Invariant:</b> {@code balanceAfter} is read from
     * {@code stock.getQuantity()}
     * <em>after</em> the quantity has already been updated and saved, ensuring
     * exact
     * consistency between the two tables.
     */
    private void insertLog(Stock stock, OperationType type,
            int quantityChange, String referenceId, String reason) {
        InventoryLog entry = new InventoryLog();
        entry.setSkuCode(stock.getSkuCode());
        entry.setOperationType(type);
        entry.setQuantityChange(quantityChange);
        entry.setBalanceAfter(stock.getQuantity()); // must equal stock.quantity post-update
        entry.setReferenceId(referenceId);
        entry.setReason(reason);
        inventoryLogRepository.save(entry);
    }
}
