package com.CNLTHD.Inventory_Service.controller;

import com.CNLTHD.Inventory_Service.common.ApiResponse;
import com.CNLTHD.Inventory_Service.common.AppConstants;
import com.CNLTHD.Inventory_Service.dto.response.InventoryLogResponseDto;
import com.CNLTHD.Inventory_Service.service.InventoryLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Read-only REST endpoints for browsing the inventory audit log.
 */
@RestController
@RequestMapping(AppConstants.INV_LOG_BASE)
@Tag(name = "Inventory Logs", description = "Read-only access to inventory movement audit logs")
public class InventoryLogController {

    private final InventoryLogService inventoryLogService;

    public InventoryLogController(InventoryLogService inventoryLogService) {
        this.inventoryLogService = inventoryLogService;
    }

    @GetMapping
    @Operation(summary = "Get all inventory log entries across all SKUs")
    public ResponseEntity<ApiResponse<List<InventoryLogResponseDto>>> getAllLogs() {
        return ResponseEntity.ok(ApiResponse.success(inventoryLogService.getAllLogs()));
    }

    @GetMapping("/{skuCode}")
    @Operation(summary = "Get all inventory log entries for a specific SKU (newest first)")
    public ResponseEntity<ApiResponse<List<InventoryLogResponseDto>>> getLogsBySkuCode(
            @PathVariable String skuCode) {
        return ResponseEntity.ok(ApiResponse.success(inventoryLogService.getLogsBySkuCode(skuCode)));
    }
}
