package com.CNLTHD.Inventory_Service.repository;

import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for {@link InventoryLog} entities.
 */
@Repository
public interface InventoryLogRepository extends JpaRepository<InventoryLog, Long> {

    List<InventoryLog> findAllBySkuCodeOrderByCreatedAtDesc(String skuCode);
}
