package com.CNLTHD.Inventory_Service.repository;

import com.CNLTHD.Inventory_Service.entity.Stock;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for {@link Stock} entities.
 *
 * <p>
 * Provides two lookup methods by {@code skuCode}:
 * <ul>
 * <li>{@link #findBySkuCode} – standard read (no lock) for GET endpoints.</li>
 * <li>{@link #findBySkuCodeForUpdate} – acquires a pessimistic write-lock for
 * mutation
 * operations (add/deduct/adjust) to prevent concurrent updates from
 * overlapping.</li>
 * </ul>
 */
@Repository
public interface StockRepository extends JpaRepository<Stock, Long> {

    Optional<Stock> findBySkuCode(String skuCode);

    boolean existsBySkuCode(String skuCode);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM Stock s WHERE s.skuCode = :skuCode")
    Optional<Stock> findBySkuCodeForUpdate(@Param("skuCode") String skuCode);
}
