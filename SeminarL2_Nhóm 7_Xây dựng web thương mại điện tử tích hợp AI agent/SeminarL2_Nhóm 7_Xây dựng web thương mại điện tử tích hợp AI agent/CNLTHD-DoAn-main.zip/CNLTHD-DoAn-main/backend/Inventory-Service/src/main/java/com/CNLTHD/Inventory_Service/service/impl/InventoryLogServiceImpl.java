package com.CNLTHD.Inventory_Service.service.impl;

import com.CNLTHD.Inventory_Service.dto.response.InventoryLogResponseDto;
import com.CNLTHD.Inventory_Service.mapper.InventoryLogMapper;
import com.CNLTHD.Inventory_Service.repository.InventoryLogRepository;
import com.CNLTHD.Inventory_Service.service.InventoryLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Read-only implementation of {@link InventoryLogService}.
 */
@Service
@Transactional(readOnly = true)
public class InventoryLogServiceImpl implements InventoryLogService {

    private final InventoryLogRepository inventoryLogRepository;
    private final InventoryLogMapper inventoryLogMapper;

    public InventoryLogServiceImpl(InventoryLogRepository inventoryLogRepository,
            InventoryLogMapper inventoryLogMapper) {
        this.inventoryLogRepository = inventoryLogRepository;
        this.inventoryLogMapper = inventoryLogMapper;
    }

    @Override
    public List<InventoryLogResponseDto> getLogsBySkuCode(String skuCode) {
        return inventoryLogRepository.findAllBySkuCodeOrderByCreatedAtDesc(skuCode)
                .stream()
                .map(inventoryLogMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<InventoryLogResponseDto> getAllLogs() {
        return inventoryLogRepository.findAll().stream()
                .map(inventoryLogMapper::toResponseDto)
                .toList();
    }
}
