package com.CNLTHD.Inventory_Service.mapper;

import com.CNLTHD.Inventory_Service.dto.response.InventoryLogResponseDto;
import com.CNLTHD.Inventory_Service.entity.InventoryLog;
import org.springframework.stereotype.Component;

/**
 * Manual mapper between {@link InventoryLog} entity and its response DTO.
 */
@Component

public class InventoryLogMapper {

    public InventoryLogResponseDto toResponseDto(InventoryLog log) {
        InventoryLogResponseDto dto = new InventoryLogResponseDto();
        dto.setId(log.getId());
        dto.setSkuCode(log.getSkuCode());
        dto.setOperationType(log.getOperationType());
        dto.setQuantityChange(log.getQuantityChange());
        dto.setBalanceAfter(log.getBalanceAfter());
        dto.setReferenceId(log.getReferenceId());
        dto.setReason(log.getReason());
        dto.setCreatedBy(log.getCreatedBy());
        dto.setCreatedAt(log.getCreatedAt());
        return dto;
    }
}
