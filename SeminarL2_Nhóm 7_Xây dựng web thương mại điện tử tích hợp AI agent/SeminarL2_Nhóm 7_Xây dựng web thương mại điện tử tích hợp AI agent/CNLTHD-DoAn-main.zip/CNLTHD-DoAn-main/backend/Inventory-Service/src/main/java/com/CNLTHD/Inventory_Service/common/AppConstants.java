package com.CNLTHD.Inventory_Service.common;

/**
 * Shared constants for API base paths.
 */
public final class AppConstants {

    private AppConstants() {
    }

    public static final String STOCKS_BASE = "/api/stocks";
    public static final String INV_LOG_BASE = "/api/inventory-logs";
}
