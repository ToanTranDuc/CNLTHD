package com.CNLTHD.Inventory_Service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request payload for creating a new stock entry.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockRequestDto {

    @NotBlank(message = "skuCode must not be blank")
    private String skuCode;

    @NotBlank(message = "productName must not be blank")
    private String productName;

    @NotNull(message = "quantity must not be null")
    @Min(value = 0, message = "quantity must be 0 or greater")
    private Integer quantity;

}
