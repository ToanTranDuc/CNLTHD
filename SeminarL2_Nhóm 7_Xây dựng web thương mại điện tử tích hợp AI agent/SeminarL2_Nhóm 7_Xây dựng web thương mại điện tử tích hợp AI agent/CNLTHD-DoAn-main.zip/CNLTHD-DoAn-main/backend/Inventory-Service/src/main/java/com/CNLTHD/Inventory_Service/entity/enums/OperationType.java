package com.CNLTHD.Inventory_Service.entity.enums;

/**
 * Represents the direction of an inventory movement.
 * <ul>
 * <li>IN – stock received / added</li>
 * <li>OUT – stock dispatched / deducted</li>
 * <li>ADJUSTMENT – manual correction (positive or negative delta)</li>
 * </ul>
 */
public enum OperationType {
    IN,
    OUT,
    ADJUSTMENT
}
