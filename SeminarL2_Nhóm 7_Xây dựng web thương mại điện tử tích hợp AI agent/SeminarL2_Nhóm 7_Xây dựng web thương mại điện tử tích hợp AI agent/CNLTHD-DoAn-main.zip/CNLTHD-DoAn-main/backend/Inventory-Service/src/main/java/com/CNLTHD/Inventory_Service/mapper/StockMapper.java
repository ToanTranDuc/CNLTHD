package com.CNLTHD.Inventory_Service.mapper;

import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.entity.Stock;
import org.springframework.stereotype.Component;

/**
 * Manual mapper between {@link Stock} entity and its DTOs.
 */
@Component
public class StockMapper {

    public Stock toEntity(StockRequestDto dto) {
        Stock stock = new Stock();
        stock.setSkuCode(dto.getSkuCode());
        stock.setProductName(dto.getProductName());
        stock.setQuantity(dto.getQuantity() != null ? dto.getQuantity() : 0);
        return stock;
    }

    public StockResponseDto toResponseDto(Stock stock) {
        return new StockResponseDto(
                stock.getId(),
                stock.getSkuCode(),
                stock.getProductName(),
                stock.getQuantity());
    }
}
