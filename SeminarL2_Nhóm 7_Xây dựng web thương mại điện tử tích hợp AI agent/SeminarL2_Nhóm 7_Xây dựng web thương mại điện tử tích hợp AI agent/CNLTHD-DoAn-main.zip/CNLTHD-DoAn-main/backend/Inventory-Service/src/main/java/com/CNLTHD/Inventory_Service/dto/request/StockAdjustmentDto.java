package com.CNLTHD.Inventory_Service.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Request payload for stock mutation operations (add / deduct / adjust).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockAdjustmentDto {

    @NotNull(message = "quantityChange must not be null")
    @Min(value = 1, message = "quantityChange must be at least 1")
    private Integer quantityChange;

    /** Optional – links this movement to an external order / purchase-order ID. */
    private String referenceId;

    /** Optional – human-readable reason for this movement. */
    private String reason;

}
