package com.CNLTHD.Inventory_Service.common;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Standard error response returned by GlobalExceptionHandler.
 */
public class ApiError {

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private final LocalDateTime timestamp;
    private final int status;
    private final String error;
    private final String message;
    private final String path;
    private final List<FieldError> validationErrors;

    private ApiError(Builder builder) {
        this.timestamp = builder.timestamp;
        this.status = builder.status;
        this.error = builder.error;
        this.message = builder.message;
        this.path = builder.path;
        this.validationErrors = builder.validationErrors;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public int getStatus() {
        return status;
    }

    public String getError() {
        return error;
    }

    public String getMessage() {
        return message;
    }

    public String getPath() {
        return path;
    }

    public List<FieldError> getValidationErrors() {
        return validationErrors;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private LocalDateTime timestamp;
        private int status;
        private String error;
        private String message;
        private String path;
        private List<FieldError> validationErrors;

        public Builder timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder status(int status) {
            this.status = status;
            return this;
        }

        public Builder error(String error) {
            this.error = error;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder path(String path) {
            this.path = path;
            return this;
        }

        public Builder validationErrors(List<FieldError> validationErrors) {
            this.validationErrors = validationErrors;
            return this;
        }

        public ApiError build() {
            return new ApiError(this);
        }
    }

    /** Populated only for 400 validation errors; otherwise null. */
    public static class FieldError {
        private final String field;
        private final String rejectedValue;
        private final String message;

        private FieldError(FieldErrorBuilder builder) {
            this.field = builder.field;
            this.rejectedValue = builder.rejectedValue;
            this.message = builder.message;
        }

        public String getField() {
            return field;
        }

        public String getRejectedValue() {
            return rejectedValue;
        }

        public String getMessage() {
            return message;
        }

        public static FieldErrorBuilder builder() {
            return new FieldErrorBuilder();
        }

        public static class FieldErrorBuilder {
            private String field;
            private String rejectedValue;
            private String message;

            public FieldErrorBuilder field(String field) {
                this.field = field;
                return this;
            }

            public FieldErrorBuilder rejectedValue(String rejectedValue) {
                this.rejectedValue = rejectedValue;
                return this;
            }

            public FieldErrorBuilder message(String message) {
                this.message = message;
                return this;
            }

            public FieldError build() {
                return new FieldError(this);
            }
        }
    }
}
