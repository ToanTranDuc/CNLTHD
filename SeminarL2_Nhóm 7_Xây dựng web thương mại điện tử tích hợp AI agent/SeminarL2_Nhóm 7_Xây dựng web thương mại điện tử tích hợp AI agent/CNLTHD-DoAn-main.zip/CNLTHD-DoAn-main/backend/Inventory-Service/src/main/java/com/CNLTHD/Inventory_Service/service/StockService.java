package com.CNLTHD.Inventory_Service.service;

import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;

import java.util.List;

/**
 * Core inventory operations for managing stock levels.
 * Every mutation method atomically updates the {@code stocks} table
 * and inserts a corresponding record into {@code inventory_log}.
 */
public interface StockService {

    /** Register a new SKU with an initial quantity. */
    StockResponseDto createStock(StockRequestDto dto);

    /** Retrieve current stock level for a SKU (read-only). */
    StockResponseDto getBySkuCode(String skuCode);

    /** Retrieve all stock entries. */
    List<StockResponseDto> getAll();

    /**
     * Add stock (IN operation).
     * Increments {@code quantity} and records an {@code IN} log entry.
     */
    StockResponseDto addStock(String skuCode, StockAdjustmentDto dto);

    /**
     * Deduct stock (OUT operation).
     * Decrements {@code quantity} and records an {@code OUT} log entry.
     * Throws
     * {@link com.CNLTHD.Inventory_Service.exception.InsufficientStockException}
     * if available stock is less than requested.
     */
    StockResponseDto deductStock(String skuCode, StockAdjustmentDto dto);

    /**
     * Apply a manual adjustment (ADJUSTMENT operation).
     * The {@code quantityChange} is treated as an absolute positive delta that
     * can either be added or subtracted based on whether the result would be
     * negative.
     * Throws {@link com.CNLTHD.Inventory_Service.exception.BusinessException}
     * if the adjustment would bring quantity below zero.
     */
    StockResponseDto adjustStock(String skuCode, StockAdjustmentDto dto);
}
