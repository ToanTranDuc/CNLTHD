package com.CNLTHD.Inventory_Service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response payload representing the current state of a stock entry.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StockResponseDto {

    private Long id;
    private String skuCode;
    private String productName;
    private Integer quantity;


}
