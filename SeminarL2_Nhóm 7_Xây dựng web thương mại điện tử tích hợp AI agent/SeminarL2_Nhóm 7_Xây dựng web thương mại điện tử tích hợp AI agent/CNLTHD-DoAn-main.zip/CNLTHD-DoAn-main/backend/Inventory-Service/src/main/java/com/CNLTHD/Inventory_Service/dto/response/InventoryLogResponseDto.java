package com.CNLTHD.Inventory_Service.dto.response;

import com.CNLTHD.Inventory_Service.entity.enums.OperationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response payload for a single inventory log entry.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryLogResponseDto {

    private Long id;
    private String skuCode;
    private OperationType operationType;
    private Integer quantityChange;
    private Integer balanceAfter;
    private String referenceId;
    private String reason;
    private String createdBy;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

}
