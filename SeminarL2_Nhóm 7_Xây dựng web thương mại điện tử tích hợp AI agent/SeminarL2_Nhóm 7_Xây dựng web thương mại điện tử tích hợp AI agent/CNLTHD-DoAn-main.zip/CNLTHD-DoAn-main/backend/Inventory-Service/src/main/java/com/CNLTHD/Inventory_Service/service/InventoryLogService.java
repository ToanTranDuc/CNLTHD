package com.CNLTHD.Inventory_Service.service;

import com.CNLTHD.Inventory_Service.dto.response.InventoryLogResponseDto;

import java.util.List;

/**
 * Read-only access to the inventory audit log.
 */
public interface InventoryLogService {

    /** Retrieve all log entries for a given SKU, newest first. */
    List<InventoryLogResponseDto> getLogsBySkuCode(String skuCode);

    /** Retrieve all log entries across all SKUs, newest first. */
    List<InventoryLogResponseDto> getAllLogs();
}
