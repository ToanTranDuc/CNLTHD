package com.CNLTHD.Inventory_Service.controller;

import com.CNLTHD.Inventory_Service.common.ApiResponse;
import com.CNLTHD.Inventory_Service.common.AppConstants;
import com.CNLTHD.Inventory_Service.dto.request.StockAdjustmentDto;
import com.CNLTHD.Inventory_Service.dto.request.StockRequestDto;
import com.CNLTHD.Inventory_Service.dto.response.StockResponseDto;
import com.CNLTHD.Inventory_Service.service.StockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST endpoints for managing SKU stock levels.
 *
 * <p>
 * Use {@code skuCode} as the identifier for all inter-service operations.
 * Internal database IDs are intentionally not exposed in URLs.
 */
@RestController
@RequestMapping(AppConstants.STOCKS_BASE)
@Tag(name = "Stocks", description = "Manage inventory stock levels by SKU")
public class StockController {

    private static final Logger log = LoggerFactory.getLogger(StockController.class);

    private final StockService stockService;

    public StockController(StockService stockService) {
        this.stockService = stockService;
    }

    @GetMapping
    @Operation(summary = "Get all stock entries")
    public ResponseEntity<ApiResponse<List<StockResponseDto>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(stockService.getAll()));
    }

    @GetMapping("/{skuCode}")
    @Operation(summary = "Get stock level for a specific SKU")
    public ResponseEntity<ApiResponse<StockResponseDto>> getBySkuCode(@PathVariable String skuCode) {
        return ResponseEntity.ok(ApiResponse.success(stockService.getBySkuCode(skuCode)));
    }

    @PostMapping
    @Operation(summary = "Register a new SKU with an initial stock quantity")
    public ResponseEntity<ApiResponse<StockResponseDto>> createStock(
            @Valid @RequestBody StockRequestDto dto) {
        StockResponseDto created = stockService.createStock(dto);
        log.info("Registered new stock: SKU='{}'", created.getSkuCode());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(created, "Stock entry created successfully"));
    }

    @PostMapping("/{skuCode}/add")
    @Operation(summary = "Add stock for a SKU (IN operation)", description = "Increments the quantity and records an IN log entry atomically.")
    public ResponseEntity<ApiResponse<StockResponseDto>> addStock(
            @PathVariable String skuCode,
            @Valid @RequestBody StockAdjustmentDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(stockService.addStock(skuCode, dto), "Stock added successfully"));
    }

    @PostMapping("/{skuCode}/deduct")
    @Operation(summary = "Deduct stock for a SKU (OUT operation)", description = "Decrements the quantity and records an OUT log entry atomically. "
            +
            "Returns HTTP 422 if available stock is insufficient.")
    public ResponseEntity<ApiResponse<StockResponseDto>> deductStock(
            @PathVariable String skuCode,
            @Valid @RequestBody StockAdjustmentDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(stockService.deductStock(skuCode, dto), "Stock deducted successfully"));
    }

    @PostMapping("/{skuCode}/adjust")
    @Operation(summary = "Apply a manual adjustment to a SKU (ADJUSTMENT operation)", description = "Adds the given delta to the current quantity and records an ADJUSTMENT log entry atomically.")
    public ResponseEntity<ApiResponse<StockResponseDto>> adjustStock(
            @PathVariable String skuCode,
            @Valid @RequestBody StockAdjustmentDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(stockService.adjustStock(skuCode, dto), "Stock adjusted successfully"));
    }
}
