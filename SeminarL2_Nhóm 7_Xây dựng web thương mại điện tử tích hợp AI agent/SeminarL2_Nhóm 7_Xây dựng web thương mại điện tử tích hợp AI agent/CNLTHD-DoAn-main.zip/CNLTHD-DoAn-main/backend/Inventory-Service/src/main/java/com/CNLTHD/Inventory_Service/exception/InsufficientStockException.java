package com.CNLTHD.Inventory_Service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when an OUT (deduct) operation is requested but the available stock
 * is less than the requested quantity.
 * Maps to HTTP 422 Unprocessable Entity.
 */
@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class InsufficientStockException extends RuntimeException {

    public InsufficientStockException(String skuCode, int available, int requested) {
        super(String.format(
                "Insufficient stock for SKU '%s': available=%d, requested=%d",
                skuCode, available, requested));
    }
}
