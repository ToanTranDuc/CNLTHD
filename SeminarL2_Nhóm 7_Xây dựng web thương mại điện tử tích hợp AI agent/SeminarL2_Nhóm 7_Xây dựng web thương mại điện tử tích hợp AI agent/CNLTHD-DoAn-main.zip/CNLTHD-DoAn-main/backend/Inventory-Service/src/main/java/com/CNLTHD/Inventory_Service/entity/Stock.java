package com.CNLTHD.Inventory_Service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents the current inventory level for a single SKU.
 *
 * <p>
 * Mapped to the {@code stocks} table.
 * {@code skuCode} is the integration key used when communicating with other
 * services.
 * {@code @Version} enables optimistic locking to prevent lost-update anomalies
 * under concurrency.
 * For mutation operations that require strict isolation, use the
 * pessimistic-write
 * query in {@link com.CNLTHD.Inventory_Service.repository.StockRepository}.
 */
@Entity
@Table(name = "stocks", uniqueConstraints = {
        @UniqueConstraint(name = "uq_stocks_sku_code", columnNames = "sku_code")
})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Stock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sku_code", nullable = false, unique = true, length = 100)
    private String skuCode;

    @Column(name = "product_name", nullable = false, length = 255)
    private String productName;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Version
    @Column(name = "version")
    private Long version;
}
