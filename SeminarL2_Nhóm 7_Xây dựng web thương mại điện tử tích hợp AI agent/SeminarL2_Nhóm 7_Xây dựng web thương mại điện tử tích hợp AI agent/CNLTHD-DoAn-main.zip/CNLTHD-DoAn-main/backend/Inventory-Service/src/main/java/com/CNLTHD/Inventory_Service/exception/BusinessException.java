package com.CNLTHD.Inventory_Service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown for business rule violations such as duplicate SKU registration.
 * Maps to HTTP 409 Conflict.
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class BusinessException extends RuntimeException {

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String resourceName, String detail) {
        super(String.format("[%s] %s", resourceName, detail));
    }
}
