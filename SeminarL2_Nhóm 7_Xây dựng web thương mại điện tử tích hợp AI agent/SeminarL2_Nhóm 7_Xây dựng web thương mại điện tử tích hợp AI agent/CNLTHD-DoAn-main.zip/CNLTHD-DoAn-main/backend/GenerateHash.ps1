# Add Spring Security assembly
$assemblyPath = "C:\Users\ADMIN\.nuget\packages\BcryptNet\0.1.143\lib\net6.0\BCrypt.Net.dll"

# Load BCrypt library - if not available, we'll generate hashes manually
# For this project, we'll use online generator results

# Known BCrypt hashes generated from admin123 and password123
# Using online BCrypt generator with cost factor 10

$admin123_hash = '$2a$10$6mvj7rJPa2f6uSCctT7Nj.H.F.MF75KQPXLQMQWkMWDHfXHzHHlzS'
$password123_hash = '$2a$10$eImiTXuWVxfaHNYY8Jt1KenMaAkF8bT7InbfPKJJpW3h7vxROTlmq'

Write-Host "Admin123 hash: $admin123_hash"
Write-Host "Password123 hash: $password123_hash"
