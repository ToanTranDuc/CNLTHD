package com.cnlthd.user.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateUserAdminRequest {

  @Size(min = 2, max = 100, message = "Họ tên phải từ 2-100 ký tự")
  private String fullname;

  @Email(message = "Email không hợp lệ")
  private String email;

  @Pattern(regexp = "^0\\d{9}$", message = "Số điện thoại phải có 10 chữ số và bắt đầu bằng 0")
  private String sdt;

  @Size(min = 10, message = "Mật khẩu phải có ít nhất 10 ký tự")
  private String password;

  @Pattern(regexp = "^(admin|customer)$", message = "Vai trò không hợp lệ")
  private String role;
}
