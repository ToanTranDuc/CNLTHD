package com.cnlthd.user.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignupRequest {

  @NotBlank(message = "Email không được để trống")
  @Pattern(regexp = "^[^@]+@gmail\\.com$", message = "Email phải có định dạng @gmail.com")
  private String email;

  @NotBlank(message = "Mật khẩu không được để trống")
  // Validation chi tiết sẽ được kiểm tra trong service
  private String password;

  @NotBlank(message = "Tên không được để trống")
  private String fullname;

  @NotBlank(message = "Số điện thoại không được để trống")
  @Pattern(regexp = "^0[0-9]{9}$", message = "Số điện thoại phải bắt đầu bằng 0 và có đúng 10 chữ số")
  private String sdt;
}
