package com.cnlthd.user.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

@Component
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

  private final JwtTokenProvider jwtTokenProvider;

  public JwtAuthenticationFilter(JwtTokenProvider jwtTokenProvider) {
    this.jwtTokenProvider = jwtTokenProvider;
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {
    try {
      String authHeader = request.getHeader("Authorization");
      String requestUri = request.getRequestURI();
      String method = request.getMethod();
      
      log.debug("=== JWT Filter Debug ===");
      log.debug("URI: {} {}", method, requestUri);
      log.debug("Authorization Header: {}", authHeader);
      
      if (authHeader != null && authHeader.startsWith("Bearer ")) {
        String token = authHeader.substring(7);
        
        if (jwtTokenProvider.validateToken(token)) {
          String userId = jwtTokenProvider.getUserIdFromToken(token);
          String role = jwtTokenProvider.getRoleFromToken(token);
          String email = jwtTokenProvider.getEmailFromToken(token);
          
          log.debug("Token Valid - UserId: {}, Email: {}, Role: {}", userId, email, role);
          
          // Create authorities from role
          Collection<GrantedAuthority> authorities = new ArrayList<>();
          authorities.add(new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()));
          
          // Create authentication token
          UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
              userId, null, authorities);
          
          // Set authentication in security context
          SecurityContextHolder.getContext().setAuthentication(authentication);
          
          log.debug("JWT Token validated for user: {} with authorities: {}", userId, authorities);
        } else {
          log.warn("Invalid JWT Token");
        }
      } else {
        log.warn("No Authorization header found or invalid format");
      }
    } catch (Exception e) {
      log.error("Error processing JWT Token: {}", e.getMessage(), e);
    }
    
    filterChain.doFilter(request, response);
  }
}
