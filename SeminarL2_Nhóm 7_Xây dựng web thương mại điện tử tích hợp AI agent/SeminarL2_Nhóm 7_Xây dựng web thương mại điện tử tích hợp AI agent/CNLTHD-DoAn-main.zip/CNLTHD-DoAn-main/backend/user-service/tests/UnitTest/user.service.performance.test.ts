import request from 'supertest';
import nock from 'nock';
import { performance } from 'perf_hooks';

const BASE_URL = 'http://localhost:8081';

describe('User Service Performance Tests (Mocked)', () => {
  const customerToken = 'mock-customer-token';

  beforeEach(() => {
    nock.cleanAll();
  });

  afterAll(() => {
    nock.restore();
  });

  test('Single Request Latency - POST /api/auth/login', async () => {
    nock(BASE_URL)
      .post('/api/auth/login')
      .delay(50) // Simulate 50ms network/processing delay
      .reply(200, {
        success: true,
        message: 'Đăng nhập thành công',
        data: { accessToken: 'token', user: {} },
      });

    const start = performance.now();
    await request(BASE_URL)
      .post('/api/auth/login')
      .send({ email: 'test@example.com', password: 'password' });
    const end = performance.now();

    const duration = end - start;
    console.log(`Login Latency: ${duration.toFixed(2)}ms`);
    expect(duration).toBeLessThan(500); // Should be well under 500ms even with mock delay
  });

  test('Concurrent Requests Throughput - GET /api/users/profile', async () => {
    const concurrentRequests = 50;
    
    // Setup nock to handle multiple calls
    nock(BASE_URL)
      .get('/api/users/profile')
      .times(concurrentRequests)
      .delay(20) // Simulate 20ms delay per request
      .reply(200, {
        success: true,
        data: { id: 'user-001', email: 'test@example.com' },
      });

    const start = performance.now();
    
    const requests = Array.from({ length: concurrentRequests }).map(() => 
      request(BASE_URL)
        .get('/api/users/profile')
        .set('Authorization', `Bearer ${customerToken}`)
    );

    const responses = await Promise.all(requests);
    const end = performance.now();

    const totalDuration = end - start;
    const avgDuration = totalDuration / concurrentRequests;

    console.log(`Total duration for ${concurrentRequests} requests: ${totalDuration.toFixed(2)}ms`);
    console.log(`Average duration per request: ${avgDuration.toFixed(2)}ms`);

    responses.forEach(res => {
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    // Verification of performance goals
    expect(avgDuration).toBeLessThan(100); 
  });

  test('Batch Signup Performance', async () => {
    const batchSize = 10;
    
    nock(BASE_URL)
      .post('/api/auth/signup')
      .times(batchSize)
      .delay(100) // Signup is usually slower (hashing, etc.)
      .reply(201, { success: true });

    const start = performance.now();
    
    for (let i = 0; i < batchSize; i++) {
      await request(BASE_URL)
        .post('/api/auth/signup')
        .send({
          email: `user${i}@example.com`,
          password: 'Password@123',
          fullname: 'Test User',
          sdt: '0123456789'
        });
    }
    
    const end = performance.now();
    const totalDuration = end - start;
    
    console.log(`Batch Signup Duration (Sequential): ${totalDuration.toFixed(2)}ms`);
    expect(totalDuration).toBeLessThan(2000); // 10 * 100ms + overhead
  });
});
