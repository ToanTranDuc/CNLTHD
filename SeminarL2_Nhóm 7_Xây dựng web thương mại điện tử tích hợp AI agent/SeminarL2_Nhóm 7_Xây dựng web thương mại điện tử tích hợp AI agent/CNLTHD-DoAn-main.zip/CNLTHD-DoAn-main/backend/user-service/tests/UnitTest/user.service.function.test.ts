import request from 'supertest';
import nock from 'nock';
import { v4 as uuidv4 } from 'uuid';

const BASE_URL = 'http://localhost:8081';

describe('User Service Functional Tests (Mocked)', () => {
  // Mock "Database" State
  let mockUsers: any[] = [];
  const adminToken = 'mock-admin-token';
  const customerToken = 'mock-customer-token';

  beforeEach(() => {
    // Reset state before each test
    mockUsers = [
      {
        id: 'admin-001',
        fullname: 'Admin User',
        email: 'admin@example.com',
        password: 'admin123',
        sdt: '0123456789',
        role: 'admin',
        isActive: true,
      },
      {
        id: 'customer-001',
        fullname: 'John Doe',
        email: 'john@example.com',
        password: 'password123',
        sdt: '0987654321',
        role: 'customer',
        isActive: true,
      },
    ];
    nock.cleanAll();
  });

  afterAll(() => {
    nock.restore();
  });

  describe('Authentication Endpoints', () => {
    test('POST /api/auth/signup - Success', async () => {
      const signupData = {
        fullname: 'New User',
        email: 'newuser@gmail.com',
        password: 'Password@123',
        sdt: '0912345678',
      };

      nock(BASE_URL)
        .post('/api/auth/signup', (body) => body.email === signupData.email)
        .reply(201, {
          success: true,
          message: 'Đăng ký thành công. Vui lòng kiểm tra email để xác thực tài khoản',
          data: {
            id: uuidv4(),
            ...signupData,
            role: 'customer',
            isActive: true,
          },
        });

      const response = await request(BASE_URL)
        .post('/api/auth/signup')
        .send(signupData);

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.email).toBe(signupData.email);
    });

    test('POST /api/auth/login - Success (Admin)', async () => {
      const loginData = {
        email: 'admin@example.com',
        password: 'admin123',
      };

      nock(BASE_URL)
        .post('/api/auth/login')
        .reply(200, {
          success: true,
          message: 'Đăng nhập thành công',
          data: {
            accessToken: adminToken,
            refreshToken: 'mock-refresh-token',
            user: mockUsers[0],
          },
        });

      const response = await request(BASE_URL)
        .post('/api/auth/login')
        .send(loginData);

      expect(response.status).toBe(200);
      expect(response.body.data.accessToken).toBe(adminToken);
      expect(response.body.data.user.role).toBe('admin');
    });

    test('POST /api/auth/login - Failure (Invalid Credentials)', async () => {
      const loginData = {
        email: 'admin@example.com',
        password: 'wrongpassword',
      };

      nock(BASE_URL)
        .post('/api/auth/login')
        .reply(401, {
          success: false,
          message: 'Email hoặc mật khẩu không chính xác',
        });

      const response = await request(BASE_URL)
        .post('/api/auth/login')
        .send(loginData);

      expect(response.status).toBe(401);
      expect(response.body.success).toBe(false);
    });

    test('POST /api/auth/refresh-token - Success', async () => {
      nock(BASE_URL)
        .post('/api/auth/refresh-token')
        .reply(200, {
          success: true,
          message: 'Token làm mới thành công',
          data: {
            accessToken: 'new-access-token',
            refreshToken: 'new-refresh-token',
          },
        });

      const response = await request(BASE_URL)
        .post('/api/auth/refresh-token')
        .set('Authorization', 'Bearer mock-refresh-token');

      expect(response.status).toBe(200);
      expect(response.body.data.accessToken).toBe('new-access-token');
    });

    test('POST /api/auth/logout - Success', async () => {
      nock(BASE_URL)
        .post('/api/auth/logout')
        .reply(200, {
          success: true,
          message: 'Đăng xuất thành công',
        });

      const response = await request(BASE_URL)
        .post('/api/auth/logout')
        .set('Authorization', `Bearer ${customerToken}`);

      expect(response.status).toBe(200);
      expect(response.body.message).toContain('thành công');
    });
  });

  describe('User Profile Endpoints', () => {
    test('GET /api/users/profile - Success', async () => {
      nock(BASE_URL)
        .get('/api/users/profile')
        .reply(200, {
          success: true,
          message: 'Lấy thông tin thành công',
          data: mockUsers[1],
        });

      const response = await request(BASE_URL)
        .get('/api/users/profile')
        .set('Authorization', `Bearer ${customerToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.id).toBe('customer-001');
    });

    test('PUT /api/users/profile - Success', async () => {
      const updateData = {
        fullname: 'John Updated',
        sdt: '0111111111',
      };

      nock(BASE_URL)
        .put('/api/users/profile')
        .reply(200, {
          success: true,
          message: 'Cập nhật thông tin thành công',
          data: { ...mockUsers[1], ...updateData },
        });

      const response = await request(BASE_URL)
        .put('/api/users/profile')
        .set('Authorization', `Bearer ${customerToken}`)
        .send(updateData);

      expect(response.status).toBe(200);
      expect(response.body.data.fullname).toBe('John Updated');
    });

    test('POST /api/users/change-password - Success', async () => {
      const passwordData = {
        oldPassword: 'password123',
        newPassword: 'NewPassword@123',
        confirmPassword: 'NewPassword@123',
      };

      nock(BASE_URL)
        .post('/api/users/change-password')
        .reply(200, {
          success: true,
          message: 'Đổi mật khẩu thành công',
        });

      const response = await request(BASE_URL)
        .post('/api/users/change-password')
        .set('Authorization', `Bearer ${customerToken}`)
        .send(passwordData);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });

  describe('Admin Endpoints', () => {
    test('GET /api/admin/users - Success (Admin Access)', async () => {
      nock(BASE_URL)
        .get('/api/admin/users')
        .query({ page: '0', size: '10' })
        .reply(200, {
          success: true,
          message: 'Danh sách người dùng',
          data: {
            content: mockUsers,
            totalElements: 2,
            totalPages: 1,
          },
        });

      const response = await request(BASE_URL)
        .get('/api/admin/users')
        .query({ page: 0, size: 10 })
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.content.length).toBe(2);
    });

    test('GET /api/admin/users - Forbidden (Customer Access)', async () => {
      nock(BASE_URL)
        .get('/api/admin/users')
        .reply(403, {
          success: false,
          message: 'Access Denied',
        });

      const response = await request(BASE_URL)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${customerToken}`);

      expect(response.status).toBe(403);
      expect(response.body.success).toBe(false);
    });

    test('PUT /api/admin/users/:id/deactivate - Success', async () => {
      const targetId = 'customer-001';
      nock(BASE_URL)
        .put(`/api/admin/users/${targetId}/deactivate`)
        .reply(200, {
          success: true,
          message: 'Vô hiệu hóa người dùng thành công',
          data: { ...mockUsers[1], isActive: false },
        });

      const response = await request(BASE_URL)
        .put(`/api/admin/users/${targetId}/deactivate`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.isActive).toBe(false);
    });

    test('DELETE /api/admin/users/:id - Success', async () => {
      const targetId = 'customer-001';
      nock(BASE_URL)
        .delete(`/api/admin/users/${targetId}`)
        .reply(200, {
          success: true,
          message: 'Xóa người dùng thành công',
        });

      const response = await request(BASE_URL)
        .delete(`/api/admin/users/${targetId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });
});
