const { createDefaultPreset } = require("ts-jest");
const tsJestTransformCfg = createDefaultPreset().transform;

/** @type {import("jest").Config} **/
module.exports = {
  testEnvironment: "node",
  // 1. Cho phép Jest nhận diện cả file .ts và .js
  moduleFileExtensions: ['ts', 'js', 'json', 'node'],
  
  transform: {
    // 2. Dùng ts-jest để xử lý file .ts
    ...tsJestTransformCfg,
  },
  
  // 3. Sửa lại đường dẫn tìm file test để bao gồm cả .js
  testMatch: ["**/tests/**/*.test.(ts|js)"], 
  collectCoverage: true,
  collectCoverageFrom: ["tests/**/*.ts"],
};