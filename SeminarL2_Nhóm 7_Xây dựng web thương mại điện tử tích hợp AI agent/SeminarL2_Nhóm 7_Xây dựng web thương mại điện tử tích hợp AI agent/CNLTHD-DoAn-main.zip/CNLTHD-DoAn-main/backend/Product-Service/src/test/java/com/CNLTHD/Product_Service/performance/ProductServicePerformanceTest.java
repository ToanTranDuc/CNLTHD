package com.CNLTHD.Product_Service.performance;

import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.ProductMapper;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import com.CNLTHD.Product_Service.repository.ProductMediaRepository;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import com.CNLTHD.Product_Service.service.impl.ProductServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

/**
 * Unit Performance Test – đo thời gian thực thi từng method của ProductService
 * với dependencies được mock (không có I/O thực).
 * Mục tiêu: phát hiện logic chậm (vòng lặp nặng, xử lý không hiệu quả).
 */
@SuppressWarnings("unchecked")
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductService - Performance Tests (Unit)")
class ProductServicePerformanceTest {

    private static final int ITERATIONS = 200;
    private static final long MAX_TOTAL_MS = 500;   // 200 lần gọi phải xong trong 500ms
    private static final long MAX_SINGLE_MS = 50;   // mỗi lần không quá 50ms

    @Mock private ProductRepository productRepository;
    @Mock private ProductVariantRepository productVariantRepository;
    @Mock private ProductMediaRepository productMediaRepository;
    @Mock private CategoryRepository categoryRepository;
    @Mock private ProductMapper productMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    private Category category;
    private Product product;
    private ProductRequestDto request;
    private ProductResponseDto response;

    @BeforeEach
    void setUp() {
        category = new Category();
        category.setId("cat-1");
        category.setName("Clothing");

        product = new Product();
        product.setId("prod-1");
        product.setName("Nike Air Force 1");
        product.setBrand("Nike");
        product.setBasePrice(new BigDecimal("1500000"));
        product.setSlug("nike-air-force-1");
        product.setCategory(category);
        product.setStatus(EntityStatus.ACTIVE);
        product.setGender(GenderType.UNISEX);

        request = new ProductRequestDto(
                "Nike Air Force 1", "Classic sneaker", "Nike", "USA",
                new BigDecimal("1500000"), "cat-1", EntityStatus.ACTIVE, GenderType.UNISEX, null
        );

        response = new ProductResponseDto();
        response.setId("prod-1");
        response.setName("Nike Air Force 1");
    }

    @Test
    @DisplayName("findById(): " + ITERATIONS + " lần gọi hoàn thành trong " + MAX_TOTAL_MS + "ms")
    void findById_performanceProfile() {
        when(productRepository.findByIdWithCategory("prod-1")).thenReturn(Optional.of(product));
        when(productVariantRepository.findByProductId("prod-1")).thenReturn(List.of());
        when(productMediaRepository.findByProductIdOrderBySortOrderAsc("prod-1")).thenReturn(List.of());
        when(productMapper.toResponseDto(product)).thenReturn(response);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            productService.findById("prod-1");
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("findById() %d lần phải hoàn thành trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("findAll(): " + ITERATIONS + " lần gọi với danh sách 50 sản phẩm")
    void findAll_performanceProfile() {
        List<Product> products = buildProductList(50);
        when(productRepository.findAll()).thenReturn(products);
        when(productMapper.toResponseDto(any(Product.class))).thenReturn(response);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            productService.findAll();
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("findAll() %d lần (50 items/lần) phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("findByCategory(): " + ITERATIONS + " lần gọi hoàn thành nhanh")
    void findByCategory_performanceProfile() {
        when(categoryRepository.existsById("cat-1")).thenReturn(true);
        when(productRepository.findByCategoryId("cat-1")).thenReturn(List.of(product));
        when(productMapper.toResponseDto(product)).thenReturn(response);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            productService.findByCategory("cat-1");
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("findByCategory() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("searchByKeyword(): " + ITERATIONS + " lần tìm kiếm với Specification")
    void searchByKeyword_performanceProfile() {
        when(productRepository.findAll(any(Specification.class))).thenReturn(List.of(product));
        when(productMapper.toResponseDto(product)).thenReturn(response);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            productService.searchByKeyword("nike");
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("searchByKeyword() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("findByGender(): " + ITERATIONS + " lần lọc theo giới tính")
    void findByGender_performanceProfile() {
        when(productRepository.findAll(any(Specification.class))).thenReturn(List.of(product));
        when(productMapper.toResponseDto(product)).thenReturn(response);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            productService.findByGender(GenderType.MEN);
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("findByGender() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("create(): mỗi lần tạo mới không vượt quá " + MAX_SINGLE_MS + "ms")
    void create_singleCallPerformance() {
        when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
        when(productMapper.toEntity(request)).thenReturn(product);
        when(productRepository.existsBySlug(any())).thenReturn(false);
        when(productRepository.save(product)).thenReturn(product);
        when(productMapper.toResponseDto(product)).thenReturn(response);

        long start = System.currentTimeMillis();
        productService.create(request);
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("create() một lần không được vượt quá %dms, thực tế: %dms",
                        MAX_SINGLE_MS, elapsed)
                .isLessThan(MAX_SINGLE_MS);
    }

    @Test
    @DisplayName("delete(): " + ITERATIONS + " lần soft-delete hoàn thành nhanh")
    void delete_performanceProfile() {
        when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
        when(productRepository.save(product)).thenReturn(product);

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            product.setStatus(EntityStatus.ACTIVE);  // reset lại để không ảnh hưởng lần sau
            productService.delete("prod-1");
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("delete() %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    @Test
    @DisplayName("findById() ném exception: overhead exception handling không đáng kể")
    void findById_exceptionPath_performanceProfile() {
        when(productRepository.findByIdWithCategory("not-exist")).thenReturn(Optional.empty());

        long start = System.currentTimeMillis();
        for (int i = 0; i < ITERATIONS; i++) {
            try {
                productService.findById("not-exist");
            } catch (ResourceNotFoundException ignored) {
            }
        }
        long elapsed = System.currentTimeMillis() - start;

        assertThat(elapsed)
                .as("findById() exception path %d lần phải xong trong %dms, thực tế: %dms",
                        ITERATIONS, MAX_TOTAL_MS, elapsed)
                .isLessThan(MAX_TOTAL_MS);
    }

    // ── helper ──────────────────────────────────────────────────────────────

    private List<Product> buildProductList(int count) {
        List<Product> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Product p = new Product();
            p.setId("prod-" + i);
            p.setName("Product " + i);
            p.setBrand("Brand");
            p.setSlug("product-" + i);
            p.setStatus(EntityStatus.ACTIVE);
            list.add(p);
        }
        return list;
    }
}
