package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.response.CategoryResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.CategoryMapper;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit test (Function Test) cho CategoryServiceImpl.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("CategoryServiceImpl - Function Tests")
class CategoryServiceImplTest {

    @Mock private CategoryRepository categoryRepository;
    @Mock private CategoryMapper categoryMapper;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    private Category category;
    private Category parentCategory;
    private CategoryRequestDto request;
    private CategoryResponseDto response;

    @BeforeEach
    void setUp() {
        parentCategory = new Category();
        parentCategory.setId("parent-1");
        parentCategory.setName("Fashion");
        parentCategory.setSlug("fashion");
        parentCategory.setStatus(EntityStatus.ACTIVE);

        category = new Category();
        category.setId("cat-1");
        category.setName("Clothing");
        category.setSlug("clothing");
        category.setStatus(EntityStatus.ACTIVE);
        category.setParent(parentCategory);

        request = new CategoryRequestDto("Clothing", "Men and women clothing", "parent-1", EntityStatus.ACTIVE);

        response = new CategoryResponseDto();
        response.setId("cat-1");
        response.setName("Clothing");
        response.setSlug("clothing");
        response.setParentId("parent-1");
        response.setStatus(EntityStatus.ACTIVE);
    }

    // =========================================================
    //  create()
    // =========================================================

    @Nested
    @DisplayName("create()")
    class Create {

        @Test
        @DisplayName("Thành công: tạo category mới và trả về DTO")
        void create_success() {
            when(categoryMapper.toEntity(request)).thenReturn(category);
            when(categoryRepository.existsBySlug("clothing")).thenReturn(false);
            when(categoryRepository.findById("parent-1")).thenReturn(Optional.of(parentCategory));
            when(categoryRepository.save(category)).thenReturn(category);
            when(categoryMapper.toResponseDto(category)).thenReturn(response);

            CategoryResponseDto result = categoryService.create(request);

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo("cat-1");
            assertThat(result.getName()).isEqualTo("Clothing");
            verify(categoryRepository).save(category);
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi slug đã tồn tại")
        void create_duplicateSlug() {
            when(categoryMapper.toEntity(request)).thenReturn(category);
            when(categoryRepository.existsBySlug("clothing")).thenReturn(true);

            assertThatThrownBy(() -> categoryService.create(request))
                    .isInstanceOf(BusinessException.class);

            verify(categoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi parent không tồn tại")
        void create_parentNotFound() {
            when(categoryMapper.toEntity(request)).thenReturn(category);
            when(categoryRepository.existsBySlug("clothing")).thenReturn(false);
            when(categoryRepository.findById("parent-1")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> categoryService.create(request))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");

            verify(categoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thành công: tạo root category (không có parent)")
        void create_rootCategory_noParent() {
            CategoryRequestDto rootReq = new CategoryRequestDto("Shoes", null, null, EntityStatus.ACTIVE);
            Category rootCat = new Category();
            rootCat.setId("cat-2");
            rootCat.setName("Shoes");
            rootCat.setSlug("shoes");

            when(categoryMapper.toEntity(rootReq)).thenReturn(rootCat);
            when(categoryRepository.existsBySlug("shoes")).thenReturn(false);
            when(categoryRepository.save(rootCat)).thenReturn(rootCat);
            CategoryResponseDto rootResp = new CategoryResponseDto();
            rootResp.setId("cat-2");
            when(categoryMapper.toResponseDto(rootCat)).thenReturn(rootResp);

            CategoryResponseDto result = categoryService.create(rootReq);

            assertThat(result).isNotNull();
            assertThat(rootCat.getParent()).isNull();
            verify(categoryRepository, never()).findById(any());
        }

        @Test
        @DisplayName("Status mặc định ACTIVE khi request không có status")
        void create_noStatus_defaultsToActive() {
            CategoryRequestDto reqNoStatus = new CategoryRequestDto("Bags", null, null, null);
            Category cat = new Category();
            cat.setName("Bags");
            cat.setSlug("bags");

            when(categoryMapper.toEntity(reqNoStatus)).thenReturn(cat);
            when(categoryRepository.existsBySlug("bags")).thenReturn(false);
            when(categoryRepository.save(cat)).thenReturn(cat);
            when(categoryMapper.toResponseDto(cat)).thenReturn(response);

            categoryService.create(reqNoStatus);

            assertThat(cat.getStatus()).isEqualTo(EntityStatus.ACTIVE);
        }

        @Test
        @DisplayName("Slug sinh tự động từ tên (lowercase, dấu cách → dấu gạch)")
        void create_slugGeneratedCorrectly() {
            CategoryRequestDto req = new CategoryRequestDto("Men Clothing", null, null, EntityStatus.ACTIVE);
            Category cat = new Category();
            cat.setName("Men Clothing");

            when(categoryMapper.toEntity(req)).thenReturn(cat);
            when(categoryRepository.existsBySlug("men-clothing")).thenReturn(false);
            when(categoryRepository.save(cat)).thenReturn(cat);
            when(categoryMapper.toResponseDto(cat)).thenReturn(response);

            categoryService.create(req);

            assertThat(cat.getSlug()).isEqualTo("men-clothing");
        }
    }

    // =========================================================
    //  findById()
    // =========================================================

    @Nested
    @DisplayName("findById()")
    class FindById {

        @Test
        @DisplayName("Thành công: trả về DTO khi category tồn tại")
        void findById_success() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(categoryMapper.toResponseDto(category)).thenReturn(response);

            CategoryResponseDto result = categoryService.findById("cat-1");

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo("cat-1");
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi không tìm thấy")
        void findById_notFound() {
            when(categoryRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> categoryService.findById("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");
        }
    }

    // =========================================================
    //  findAll()
    // =========================================================

    @Nested
    @DisplayName("findAll()")
    class FindAll {

        @Test
        @DisplayName("Trả về danh sách tất cả categories")
        void findAll_returnsList() {
            when(categoryRepository.findAll()).thenReturn(List.of(category, parentCategory));
            when(categoryMapper.toResponseDto(category)).thenReturn(response);
            CategoryResponseDto parentResp = new CategoryResponseDto();
            parentResp.setId("parent-1");
            when(categoryMapper.toResponseDto(parentCategory)).thenReturn(parentResp);

            List<CategoryResponseDto> result = categoryService.findAll();

            assertThat(result).hasSize(2);
        }

        @Test
        @DisplayName("Trả về rỗng khi không có category nào")
        void findAll_empty() {
            when(categoryRepository.findAll()).thenReturn(List.of());

            List<CategoryResponseDto> result = categoryService.findAll();

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  findRootCategories()
    // =========================================================

    @Nested
    @DisplayName("findRootCategories()")
    class FindRootCategories {

        @Test
        @DisplayName("Chỉ trả về categories không có parent")
        void findRootCategories_success() {
            when(categoryRepository.findByParentIsNull()).thenReturn(List.of(parentCategory));
            CategoryResponseDto parentResp = new CategoryResponseDto();
            parentResp.setId("parent-1");
            when(categoryMapper.toResponseDto(parentCategory)).thenReturn(parentResp);

            List<CategoryResponseDto> result = categoryService.findRootCategories();

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getId()).isEqualTo("parent-1");
        }

        @Test
        @DisplayName("Trả về rỗng khi không có root category")
        void findRootCategories_empty() {
            when(categoryRepository.findByParentIsNull()).thenReturn(List.of());

            List<CategoryResponseDto> result = categoryService.findRootCategories();

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  findChildren()
    // =========================================================

    @Nested
    @DisplayName("findChildren()")
    class FindChildren {

        @Test
        @DisplayName("Thành công: trả về danh sách category con")
        void findChildren_success() {
            when(categoryRepository.existsById("parent-1")).thenReturn(true);
            when(categoryRepository.findByParentId("parent-1")).thenReturn(List.of(category));
            when(categoryMapper.toResponseDto(category)).thenReturn(response);

            List<CategoryResponseDto> result = categoryService.findChildren("parent-1");

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getId()).isEqualTo("cat-1");
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi parent không tồn tại")
        void findChildren_parentNotFound() {
            when(categoryRepository.existsById("not-exist")).thenReturn(false);

            assertThatThrownBy(() -> categoryService.findChildren("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");
        }

        @Test
        @DisplayName("Trả về rỗng khi parent không có category con nào")
        void findChildren_noChildren() {
            when(categoryRepository.existsById("parent-1")).thenReturn(true);
            when(categoryRepository.findByParentId("parent-1")).thenReturn(List.of());

            List<CategoryResponseDto> result = categoryService.findChildren("parent-1");

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  update()
    // =========================================================

    @Nested
    @DisplayName("update()")
    class Update {

        @Test
        @DisplayName("Thành công: cập nhật tên và sinh slug mới")
        void update_newName_slugUpdated() {
            CategoryRequestDto updateReq = new CategoryRequestDto(
                    "Men Clothing", "Updated desc", "parent-1", EntityStatus.ACTIVE
            );

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(categoryRepository.existsBySlug("men-clothing")).thenReturn(false);
            when(categoryRepository.findById("parent-1")).thenReturn(Optional.of(parentCategory));
            when(categoryRepository.save(category)).thenReturn(category);
            when(categoryMapper.toResponseDto(category)).thenReturn(response);

            categoryService.update("cat-1", updateReq);

            assertThat(category.getSlug()).isEqualTo("men-clothing");
            verify(categoryRepository).save(category);
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi category tự tham chiếu chính nó làm parent")
        void update_selfParent_throwsBusinessException() {
            CategoryRequestDto selfParentReq = new CategoryRequestDto(
                    "Clothing", null, "cat-1", EntityStatus.ACTIVE
            );

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));

            assertThatThrownBy(() -> categoryService.update("cat-1", selfParentReq))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("cannot be its own parent");

            verify(categoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi category không tồn tại")
        void update_notFound() {
            when(categoryRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> categoryService.update("not-exist", request))
                    .isInstanceOf(ResourceNotFoundException.class);
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi tên mới tạo slug đã tồn tại")
        void update_duplicateSlugOnRename() {
            CategoryRequestDto updateReq = new CategoryRequestDto(
                    "Shoes", null, null, null
            );

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(categoryRepository.existsBySlug("shoes")).thenReturn(true);

            assertThatThrownBy(() -> categoryService.update("cat-1", updateReq))
                    .isInstanceOf(BusinessException.class);

            verify(categoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Cập nhật thành root category khi parentId là null")
        void update_removeParent_becomesRootCategory() {
            CategoryRequestDto rootReq = new CategoryRequestDto(
                    "Clothing", null, null, EntityStatus.ACTIVE
            );

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(categoryRepository.save(category)).thenReturn(category);
            when(categoryMapper.toResponseDto(category)).thenReturn(response);

            categoryService.update("cat-1", rootReq);

            assertThat(category.getParent()).isNull();
        }
    }

    // =========================================================
    //  delete()
    // =========================================================

    @Nested
    @DisplayName("delete()")
    class Delete {

        @Test
        @DisplayName("Soft-delete: đặt status = INACTIVE")
        void delete_setsStatusInactive() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));

            categoryService.delete("cat-1");

            assertThat(category.getStatus()).isEqualTo(EntityStatus.INACTIVE);
            verify(categoryRepository).save(category);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi không tìm thấy")
        void delete_notFound() {
            when(categoryRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> categoryService.delete("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class);

            verify(categoryRepository, never()).save(any());
        }

        @Test
        @DisplayName("Không xóa vật lý: delete() của repository không được gọi")
        void delete_neverCallsRepositoryDelete() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));

            categoryService.delete("cat-1");

            verify(categoryRepository, never()).delete(any(Category.class));
            verify(categoryRepository, never()).deleteById(any());
        }
    }
}
