package com.CNLTHD.Product_Service.integration;

import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import com.CNLTHD.Product_Service.entity.enums.Size;
import com.CNLTHD.Product_Service.external.client.InventoryClient;
import com.CNLTHD.Product_Service.external.dto.InventoryApiResponse;
import com.CNLTHD.Product_Service.external.dto.InventoryResponse;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for Product Service.
 *
 * Covers:
 *   - Function Test  : kiểm thử chức năng CRUD qua HTTP (MockMvc)
 *   - Data Integrity : kiểm thử ràng buộc DB (unique slug, FK, enum)
 *
 * InventoryClient được mock để test không phụ thuộc vào Inventory Service.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@DisplayName("Product Service – Integration Tests")
class ProductServiceIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductVariantRepository productVariantRepository;

    @MockitoBean
    private InventoryClient inventoryClient;

    private MockMvc mockMvc;

    // =========================================================================
    // Setup
    // =========================================================================

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        productVariantRepository.deleteAll();
        productRepository.deleteAll();
        categoryRepository.deleteAll();

        // Mock InventoryClient: giả lập SKU chưa tồn tại → createStock thành công
        InventoryResponse inventoryData = new InventoryResponse(1L, "Product", "SKU", 100);
        InventoryApiResponse<InventoryResponse> apiResp =
                new InventoryApiResponse<>(true, "OK", inventoryData, LocalDateTime.now());

        when(inventoryClient.createStock(any()))
                .thenReturn(ResponseEntity.ok(apiResp));
        when(inventoryClient.addStock(anyString(), any()))
                .thenReturn(ResponseEntity.ok(apiResp));
        when(inventoryClient.deductStock(anyString(), any()))
                .thenReturn(ResponseEntity.ok(apiResp));
        // getBySkuCode ném NotFound để syncInventory biết SKU chưa tồn tại → gọi createStock
        when(inventoryClient.getBySkuCode(anyString()))
                .thenThrow(FeignException.NotFound.class);
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private String createCategory(String name) throws Exception {
        CategoryRequestDto dto = new CategoryRequestDto(name, null, null, EntityStatus.ACTIVE);
        MvcResult result = mockMvc.perform(post("/api/v1/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated())
                .andReturn();

        String body = result.getResponse().getContentAsString();
        return objectMapper.readTree(body).path("data").path("id").asText();
    }

    private String createProduct(String name, String categoryId, GenderType gender)
            throws Exception {
        ProductRequestDto dto = new ProductRequestDto(
                name, "Mô tả sản phẩm", "BrandX", "Vietnam",
                BigDecimal.valueOf(299000), categoryId, EntityStatus.ACTIVE, gender, null);

        MvcResult result = mockMvc.perform(post("/api/v1/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated())
                .andReturn();

        String body = result.getResponse().getContentAsString();
        return objectMapper.readTree(body).path("data").path("id").asText();
    }

    // =========================================================================
    // FUNCTION TESTS – kiểm thử chức năng
    // =========================================================================

    @Nested
    @DisplayName("Function Tests – Kiểm thử chức năng")
    class FunctionTests {

        // ── Category ──────────────────────────────────────────────────────────

        @Test
        @DisplayName("FT-01: Tạo category root – trả về 201 và id không null")
        void createRootCategory_returns201WithId() throws Exception {
            CategoryRequestDto dto = new CategoryRequestDto("Thời trang nam", "Danh mục gốc", null, EntityStatus.ACTIVE);

            mockMvc.perform(post("/api/v1/categories")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.data.id").isNotEmpty())
                    .andExpect(jsonPath("$.data.name").value("Thời trang nam"));
        }

        @Test
        @DisplayName("FT-02: Tạo category con với parentId – liên kết đúng parent")
        void createChildCategory_linksToParent() throws Exception {
            String parentId = createCategory("Thời trang");

            CategoryRequestDto childDto = new CategoryRequestDto("Áo", null, parentId, EntityStatus.ACTIVE);
            MvcResult result = mockMvc.perform(post("/api/v1/categories")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(childDto)))
                    .andExpect(status().isCreated())
                    .andReturn();

            String body = result.getResponse().getContentAsString();
            String parentIdInResponse = objectMapper.readTree(body)
                    .path("data").path("parentId").asText();
            assertThat(parentIdInResponse).isEqualTo(parentId);
        }

        @Test
        @DisplayName("FT-03: Lấy category theo ID – trả về đúng dữ liệu")
        void getCategoryById_returnsCorrectData() throws Exception {
            String id = createCategory("Quần");

            mockMvc.perform(get("/api/v1/categories/" + id))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.id").value(id))
                    .andExpect(jsonPath("$.data.name").value("Quần"));
        }

        @Test
        @DisplayName("FT-04: Cập nhật category – dữ liệu được thay đổi")
        void updateCategory_persistsChanges() throws Exception {
            String id = createCategory("Giày cũ");

            CategoryRequestDto updateDto = new CategoryRequestDto("Giày mới", "Cập nhật tên", null, EntityStatus.ACTIVE);
            mockMvc.perform(put("/api/v1/categories/" + id)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(updateDto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.name").value("Giày mới"));
        }

        @Test
        @DisplayName("FT-05: Soft-delete category – status chuyển sang INACTIVE")
        void deleteCategory_setsStatusInactive() throws Exception {
            String id = createCategory("Phụ kiện tạm thời");

            mockMvc.perform(delete("/api/v1/categories/" + id))
                    .andExpect(status().isOk());

            Category cat = categoryRepository.findById(id).orElseThrow();
            assertThat(cat.getStatus()).isEqualTo(EntityStatus.INACTIVE);
        }

        @Test
        @DisplayName("FT-06: Lấy danh sách category root – không chứa category con")
        void getRootCategories_excludesChildCategories() throws Exception {
            String parentId = createCategory("Root Cat");
            CategoryRequestDto childDto = new CategoryRequestDto("Child Cat", null, parentId, EntityStatus.ACTIVE);
            mockMvc.perform(post("/api/v1/categories")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(childDto)));

            mockMvc.perform(get("/api/v1/categories/roots"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(1))
                    .andExpect(jsonPath("$.data[0].name").value("Root Cat"));
        }

        // ── Product ───────────────────────────────────────────────────────────

        @Test
        @DisplayName("FT-07: Tạo product với category hợp lệ – trả về 201")
        void createProduct_validCategory_returns201() throws Exception {
            String catId = createCategory("Áo thun");

            ProductRequestDto dto = new ProductRequestDto(
                    "Áo thun basic", "Mô tả", "BrandA", "Vietnam",
                    BigDecimal.valueOf(199000), catId, EntityStatus.ACTIVE, GenderType.UNISEX, null);

            mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.data.id").isNotEmpty())
                    .andExpect(jsonPath("$.data.name").value("Áo thun basic"))
                    .andExpect(jsonPath("$.data.slug").value("o-thun-basic"));
        }

        @Test
        @DisplayName("FT-08: Tạo product với category không tồn tại – trả về 404")
        void createProduct_nonExistentCategory_returns404() throws Exception {
            ProductRequestDto dto = new ProductRequestDto(
                    "Sản phẩm X", "Mô tả", "BrandB", "Vietnam",
                    BigDecimal.valueOf(100000), "non-existent-cat-id",
                    EntityStatus.ACTIVE, GenderType.MEN, null);

            mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isNotFound());
        }

        @Test
        @DisplayName("FT-09: Lấy product theo ID – trả về đầy đủ thông tin")
        void getProductById_returnsFullDetails() throws Exception {
            String catId = createCategory("Váy");
            String productId = createProduct("Váy hoa mùa hè", catId, GenderType.WOMEN);

            mockMvc.perform(get("/api/v1/products/" + productId))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.id").value(productId))
                    .andExpect(jsonPath("$.data.name").value("Váy hoa mùa hè"));
        }

        @Test
        @DisplayName("FT-10: Tìm product theo category – trả về đúng danh sách")
        void getProductsByCategory_returnsFilteredList() throws Exception {
            String catId = createCategory("Quần jeans");
            createProduct("Quần jeans slim", catId, GenderType.MEN);
            createProduct("Quần jeans rộng", catId, GenderType.WOMEN);

            String catId2 = createCategory("Áo sơ mi");
            createProduct("Áo sơ mi trắng", catId2, GenderType.MEN);

            mockMvc.perform(get("/api/v1/products/category/" + catId))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(2));
        }

        @Test
        @DisplayName("FT-11: Tìm kiếm product theo keyword – trả về kết quả khớp")
        void searchByKeyword_returnsMatchingProducts() throws Exception {
            String catId = createCategory("Giày dép");
            createProduct("Giày sneaker Nike", catId, GenderType.UNISEX);
            createProduct("Giày boot da", catId, GenderType.MEN);
            createProduct("Dép cao su", catId, GenderType.WOMEN);

            mockMvc.perform(get("/api/v1/products/search?keyword=sneaker"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(1))
                    .andExpect(jsonPath("$.data[0].name").value("Giày sneaker Nike"));
        }

        @Test
        @DisplayName("FT-12: Lọc product theo gender – trả về đúng giới tính")
        void getProductsByGender_returnsCorrectGender() throws Exception {
            String catId = createCategory("Thời trang");
            createProduct("Áo nam", catId, GenderType.MEN);
            createProduct("Áo nữ", catId, GenderType.WOMEN);
            createProduct("Áo unisex", catId, GenderType.UNISEX);

            mockMvc.perform(get("/api/v1/products/gender/MEN"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(1))
                    .andExpect(jsonPath("$.data[0].name").value("Áo nam"));
        }

        @Test
        @DisplayName("FT-13: Cập nhật product – thay đổi được lưu vào DB")
        void updateProduct_persistsChanges() throws Exception {
            String catId = createCategory("Mũ");
            String productId = createProduct("Mũ cũ", catId, GenderType.UNISEX);

            ProductRequestDto updateDto = new ProductRequestDto(
                    "Mũ lưỡi trai mới", "Cập nhật mô tả", "BrandX", "Vietnam",
                    BigDecimal.valueOf(150000), catId, EntityStatus.ACTIVE, GenderType.UNISEX, null);

            mockMvc.perform(put("/api/v1/products/" + productId)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(updateDto)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.name").value("Mũ lưỡi trai mới"));
        }

        @Test
        @DisplayName("FT-14: Soft-delete product – status chuyển sang INACTIVE")
        void deleteProduct_setsStatusInactive() throws Exception {
            String catId = createCategory("Thắt lưng");
            String productId = createProduct("Thắt lưng da", catId, GenderType.MEN);

            mockMvc.perform(delete("/api/v1/products/" + productId))
                    .andExpect(status().isOk());

            var product = productRepository.findById(productId).orElseThrow();
            assertThat(product.getStatus()).isEqualTo(EntityStatus.INACTIVE);
        }

        @Test
        @DisplayName("FT-15: Tạo variant cho product – gọi mock inventory và trả về 201")
        void createProductVariant_callsInventoryAndReturns201() throws Exception {
            String catId = createCategory("Áo polo");
            String productId = createProduct("Polo classic", catId, GenderType.MEN);

            ProductVariantRequestDto variantDto = new ProductVariantRequestDto(
                    productId, Size.M, Color.WHITE,
                    BigDecimal.valueOf(250000), "POLO-M-WHITE", 50, EntityStatus.ACTIVE);

            mockMvc.perform(post("/api/v1/products/variants")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(variantDto)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.data.sku").value("POLO-M-WHITE"))
                    .andExpect(jsonPath("$.data.size").value("M"))
                    .andExpect(jsonPath("$.data.color").value("WHITE"));
        }

        @Test
        @DisplayName("FT-16: Lấy variants của product – trả về danh sách đúng")
        void getVariantsByProduct_returnsAllVariants() throws Exception {
            String catId = createCategory("Quần short");
            String productId = createProduct("Short thể thao", catId, GenderType.UNISEX);

            ProductVariantRequestDto v1 = new ProductVariantRequestDto(
                    productId, Size.S, Color.BLACK, null, "SHORT-S-BLACK", 30, EntityStatus.ACTIVE);
            ProductVariantRequestDto v2 = new ProductVariantRequestDto(
                    productId, Size.L, Color.BLUE, null, "SHORT-L-BLUE", 20, EntityStatus.ACTIVE);

            mockMvc.perform(post("/api/v1/products/variants")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(v1)));
            mockMvc.perform(post("/api/v1/products/variants")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(v2)));

            mockMvc.perform(get("/api/v1/products/" + productId + "/variants"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(2));
        }
    }

    // =========================================================================
    // DATA INTEGRITY TESTS – kiểm thử tính toàn vẹn dữ liệu
    // =========================================================================

    @Nested
    @DisplayName("Data Integrity Tests – Kiểm thử tính toàn vẹn dữ liệu")
    class DataIntegrityTests {

        @Test
        @DisplayName("DI-01: Tạo category với tên trùng nhau – slug trùng → 409 Conflict")
        void createCategory_duplicateName_returns409() throws Exception {
            createCategory("Áo khoác");

            CategoryRequestDto dto = new CategoryRequestDto("Áo khoác", null, null, EntityStatus.ACTIVE);
            mockMvc.perform(post("/api/v1/categories")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.status").value(409));
        }

        @Test
        @DisplayName("DI-02: Tạo product với tên trùng nhau – slug trùng → 409 Conflict")
        void createProduct_duplicateName_returns409() throws Exception {
            String catId = createCategory("Balo");
            createProduct("Balo thể thao", catId, GenderType.UNISEX);

            ProductRequestDto dto = new ProductRequestDto(
                    "Balo thể thao", "Sản phẩm trùng tên", "BrandZ", "Vietnam",
                    BigDecimal.valueOf(500000), catId, EntityStatus.ACTIVE, GenderType.UNISEX, null);

            mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.status").value(409));
        }

        @Test
        @DisplayName("DI-03: Tạo variant với SKU trùng lặp – 409 Conflict (unique constraint)")
        void createVariant_duplicateSku_returns409() throws Exception {
            String catId = createCategory("Sandal");
            String productId = createProduct("Sandal da", catId, GenderType.WOMEN);

            ProductVariantRequestDto v1 = new ProductVariantRequestDto(
                    productId, Size.M, Color.BEIGE, null, "SANDAL-M-BEIGE", 10, EntityStatus.ACTIVE);
            mockMvc.perform(post("/api/v1/products/variants")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(v1)));

            // SKU giống hệt v1
            ProductVariantRequestDto v2 = new ProductVariantRequestDto(
                    productId, Size.L, Color.BROWN, null, "SANDAL-M-BEIGE", 5, EntityStatus.ACTIVE);
            mockMvc.perform(post("/api/v1/products/variants")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(v2)))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.status").value(409));
        }

        @Test
        @DisplayName("DI-04: Slug product được tạo tự động từ tên (lowercase, no special chars)")
        void createProduct_slugGeneratedFromName() throws Exception {
            String catId = createCategory("Đồng hồ");

            ProductRequestDto dto = new ProductRequestDto(
                    "Đồng Hồ Đẹp", "Mô tả", "BrandW", "Vietnam",
                    BigDecimal.valueOf(1000000), catId, EntityStatus.ACTIVE, GenderType.UNISEX, null);

            MvcResult result = mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isCreated())
                    .andReturn();

            String slug = objectMapper.readTree(result.getResponse().getContentAsString())
                    .path("data").path("slug").asText();
            assertThat(slug).matches("[a-z0-9\\-]+")
                    .as("Slug chỉ được chứa chữ thường, số và dấu gạch ngang");
        }

        @Test
        @DisplayName("DI-05: Category với parentId không tồn tại – trả về 404")
        void createCategory_invalidParentId_returns404() throws Exception {
            CategoryRequestDto dto = new CategoryRequestDto(
                    "Con orphan", null, "parent-id-khong-ton-tai", EntityStatus.ACTIVE);

            mockMvc.perform(post("/api/v1/categories")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isNotFound());
        }

        @Test
        @DisplayName("DI-06: Product không có tên – 400 Bad Request (validation)")
        void createProduct_blankName_returns400() throws Exception {
            String catId = createCategory("Test");
            ProductRequestDto dto = new ProductRequestDto(
                    "", "Mô tả", "Brand", "Vietnam",
                    BigDecimal.valueOf(100000), catId, EntityStatus.ACTIVE, GenderType.MEN, null);

            mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("DI-07: Product không có basePrice – 400 Bad Request (validation)")
        void createProduct_nullBasePrice_returns400() throws Exception {
            String catId = createCategory("Túi test");
            ProductRequestDto dto = new ProductRequestDto(
                    "Túi valid", "Mô tả", "Brand", "Vietnam",
                    null, catId, EntityStatus.ACTIVE, GenderType.WOMEN, null);

            mockMvc.perform(post("/api/v1/products")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isBadRequest());
        }

        @Test
        @DisplayName("DI-08: Tính toàn vẹn tham chiếu – product bị xoá vẫn ở DB (soft delete)")
        void deleteProduct_recordRemainsInDatabaseWithInactiveStatus() throws Exception {
            String catId = createCategory("Kính mắt");
            String productId = createProduct("Kính râm", catId, GenderType.UNISEX);

            mockMvc.perform(delete("/api/v1/products/" + productId))
                    .andExpect(status().isOk());

            assertThat(productRepository.existsById(productId))
                    .as("Soft-delete không xoá bản ghi khỏi DB")
                    .isTrue();
        }

        @Test
        @DisplayName("DI-09: Category status mặc định ACTIVE khi không truyền")
        void createCategory_withoutStatus_defaultsToActive() throws Exception {
            CategoryRequestDto dto = new CategoryRequestDto("Phụ kiện", null, null, null);

            MvcResult result = mockMvc.perform(post("/api/v1/categories")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isCreated())
                    .andReturn();

            String id = objectMapper.readTree(result.getResponse().getContentAsString())
                    .path("data").path("id").asText();
            Category cat = categoryRepository.findById(id).orElseThrow();
            assertThat(cat.getStatus()).isEqualTo(EntityStatus.ACTIVE);
        }

        @Test
        @DisplayName("DI-10: Variant với SKU không hợp lệ (chữ thường) – 400 Bad Request")
        void createVariant_invalidSkuFormat_returns400() throws Exception {
            String catId = createCategory("Áo vest");
            String productId = createProduct("Vest classic", catId, GenderType.MEN);

            ProductVariantRequestDto dto = new ProductVariantRequestDto(
                    productId, Size.L, Color.BLACK,
                    BigDecimal.valueOf(1500000),
                    "vest-lowercase-sku",  // SKU chứa chữ thường → vi phạm @Pattern
                    10, EntityStatus.ACTIVE);

            mockMvc.perform(post("/api/v1/products/variants")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(dto)))
                    .andExpect(status().isBadRequest());
        }
    }
}
