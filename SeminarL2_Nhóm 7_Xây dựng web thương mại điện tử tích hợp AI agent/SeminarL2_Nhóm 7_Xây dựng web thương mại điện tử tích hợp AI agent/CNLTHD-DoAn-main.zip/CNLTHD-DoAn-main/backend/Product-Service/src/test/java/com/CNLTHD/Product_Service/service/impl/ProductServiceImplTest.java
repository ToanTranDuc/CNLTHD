
package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.ProductMapper;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import com.CNLTHD.Product_Service.repository.ProductMediaRepository;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit test (Function Test) cho ProductServiceImpl.
 * Tất cả dependencies được mock - không cần database hay Spring context.
 */
@SuppressWarnings({"unchecked", "rawtypes"})
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductServiceImpl - Function Tests")
class ProductServiceImplTest {

    @Mock private ProductRepository productRepository;
    @Mock private ProductVariantRepository productVariantRepository;
    @Mock private ProductMediaRepository productMediaRepository;
    @Mock private CategoryRepository categoryRepository;
    @Mock private ProductMapper productMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    private Category category;
    private Product product;
    private ProductRequestDto request;
    private ProductResponseDto response;

    @BeforeEach
    void setUp() {
        category = new Category();
        category.setId("cat-1");
        category.setName("Clothing");
        category.setSlug("clothing");
        category.setStatus(EntityStatus.ACTIVE);

        product = new Product();
        product.setId("prod-1");
        product.setName("Nike Air Force 1");
        product.setBrand("Nike");
        product.setBasePrice(new BigDecimal("1500000"));
        product.setSlug("nike-air-force-1");
        product.setCategory(category);
        product.setStatus(EntityStatus.ACTIVE);
        product.setGender(GenderType.UNISEX);

        request = new ProductRequestDto(
                "Nike Air Force 1", "Classic sneaker", "Nike", "USA",
                new BigDecimal("1500000"), "cat-1", EntityStatus.ACTIVE, GenderType.UNISEX, null
        );

        response = new ProductResponseDto();
        response.setId("prod-1");
        response.setName("Nike Air Force 1");
        response.setBrand("Nike");
        response.setBasePrice(new BigDecimal("1500000"));
        response.setStatus(EntityStatus.ACTIVE);
        response.setGender(GenderType.UNISEX);
    }

    // =========================================================
    //  create()
    // =========================================================

    @Nested
    @DisplayName("create()")
    class Create {

        @Test
        @DisplayName("Thành công: lưu sản phẩm mới và trả về DTO")
        void create_success() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(productMapper.toEntity(request)).thenReturn(product);
            when(productRepository.existsBySlug("nike-air-force-1")).thenReturn(false);
            when(productRepository.save(product)).thenReturn(product);
            when(productMapper.toResponseDto(product)).thenReturn(response);

            ProductResponseDto result = productService.create(request);

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo("prod-1");
            assertThat(result.getName()).isEqualTo("Nike Air Force 1");
            verify(productRepository).save(product);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi category không tồn tại")
        void create_categoryNotFound() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> productService.create(request))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");

            verify(productRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi slug đã tồn tại (tên sản phẩm trùng)")
        void create_duplicateSlug() {
            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(productMapper.toEntity(request)).thenReturn(product);
            when(productRepository.existsBySlug("nike-air-force-1")).thenReturn(true);

            assertThatThrownBy(() -> productService.create(request))
                    .isInstanceOf(BusinessException.class);

            verify(productRepository, never()).save(any());
        }

        @Test
        @DisplayName("Status mặc định ACTIVE khi request không có status")
        void create_noStatus_defaultsToActive() {
            ProductRequestDto reqNoStatus = new ProductRequestDto(
                    "Test Product", null, "Brand", null,
                    new BigDecimal("100000"), "cat-1", null, GenderType.UNISEX, null
            );
            Product p = new Product();
            p.setName("Test Product");
            p.setSlug("test-product");

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(productMapper.toEntity(reqNoStatus)).thenReturn(p);
            when(productRepository.existsBySlug("test-product")).thenReturn(false);
            when(productRepository.save(p)).thenReturn(p);
            when(productMapper.toResponseDto(p)).thenReturn(response);

            productService.create(reqNoStatus);

            assertThat(p.getStatus()).isEqualTo(EntityStatus.ACTIVE);
        }

        @Test
        @DisplayName("Slug được sinh tự động từ tên sản phẩm (lowercase, dấu cách → dấu gạch)")
        void create_slugGeneratedCorrectly() {
            ProductRequestDto req = new ProductRequestDto(
                    "Adidas Ultra Boost", null, "Adidas", null,
                    new BigDecimal("2500000"), "cat-1", EntityStatus.ACTIVE, GenderType.MEN, null
            );
            Product p = new Product();
            p.setName("Adidas Ultra Boost");

            when(categoryRepository.findById("cat-1")).thenReturn(Optional.of(category));
            when(productMapper.toEntity(req)).thenReturn(p);
            when(productRepository.existsBySlug("adidas-ultra-boost")).thenReturn(false);
            when(productRepository.save(p)).thenReturn(p);
            when(productMapper.toResponseDto(p)).thenReturn(response);

            productService.create(req);

            assertThat(p.getSlug()).isEqualTo("adidas-ultra-boost");
        }
    }

    // =========================================================
    //  findById()
    // =========================================================

    @Nested
    @DisplayName("findById()")
    class FindById {

        @Test
        @DisplayName("Thành công: trả về DTO kèm theo variants và media đã hydrate")
        void findById_success() {
            when(productRepository.findByIdWithCategory("prod-1")).thenReturn(Optional.of(product));
            when(productVariantRepository.findByProductId("prod-1")).thenReturn(List.of());
            when(productMediaRepository.findByProductIdOrderBySortOrderAsc("prod-1")).thenReturn(List.of());
            when(productMapper.toResponseDto(product)).thenReturn(response);

            ProductResponseDto result = productService.findById("prod-1");

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo("prod-1");
            verify(productVariantRepository).findByProductId("prod-1");
            verify(productMediaRepository).findByProductIdOrderBySortOrderAsc("prod-1");
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi không tìm thấy sản phẩm")
        void findById_notFound() {
            when(productRepository.findByIdWithCategory("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> productService.findById("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Product");
        }
    }

    // =========================================================
    //  findAll()
    // =========================================================

    @Nested
    @DisplayName("findAll()")
    class FindAll {

        @Test
        @DisplayName("Trả về danh sách tất cả sản phẩm")
        void findAll_returnsList() {
            when(productRepository.findAll()).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findAll();

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getId()).isEqualTo("prod-1");
        }

        @Test
        @DisplayName("Trả về danh sách rỗng khi không có sản phẩm")
        void findAll_empty() {
            when(productRepository.findAll()).thenReturn(List.of());

            List<ProductResponseDto> result = productService.findAll();

            assertThat(result).isEmpty();
        }

        @Test
        @DisplayName("Trả về nhiều sản phẩm đúng số lượng")
        void findAll_multipleProducts() {
            Product p2 = new Product();
            p2.setId("prod-2");
            p2.setName("Adidas NMD");
            ProductResponseDto resp2 = new ProductResponseDto();
            resp2.setId("prod-2");

            when(productRepository.findAll()).thenReturn(List.of(product, p2));
            when(productMapper.toResponseDto(product)).thenReturn(response);
            when(productMapper.toResponseDto(p2)).thenReturn(resp2);

            List<ProductResponseDto> result = productService.findAll();

            assertThat(result).hasSize(2);
        }
    }

    // =========================================================
    //  findByCategory()
    // =========================================================

    @Nested
    @DisplayName("findByCategory()")
    class FindByCategory {

        @Test
        @DisplayName("Thành công: trả về sản phẩm trong category")
        void findByCategory_success() {
            when(categoryRepository.existsById("cat-1")).thenReturn(true);
            when(productRepository.findByCategoryId("cat-1")).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findByCategory("cat-1");

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi category không tồn tại")
        void findByCategory_categoryNotFound() {
            when(categoryRepository.existsById("not-exist")).thenReturn(false);

            assertThatThrownBy(() -> productService.findByCategory("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");
        }

        @Test
        @DisplayName("Trả về rỗng khi category không có sản phẩm nào")
        void findByCategory_noProducts() {
            when(categoryRepository.existsById("cat-1")).thenReturn(true);
            when(productRepository.findByCategoryId("cat-1")).thenReturn(List.of());

            List<ProductResponseDto> result = productService.findByCategory("cat-1");

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  findByBrand()
    // =========================================================

    @Nested
    @DisplayName("findByBrand()")
    class FindByBrand {

        @Test
        @DisplayName("Thành công: trả về sản phẩm theo thương hiệu")
        void findByBrand_success() {
            when(productRepository.findByBrandIgnoreCase("nike")).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findByBrand("nike");

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Không phân biệt hoa thường khi tìm theo thương hiệu")
        void findByBrand_caseInsensitive() {
            when(productRepository.findByBrandIgnoreCase("NIKE")).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findByBrand("NIKE");

            assertThat(result).hasSize(1);
            verify(productRepository).findByBrandIgnoreCase("NIKE");
        }

        @Test
        @DisplayName("Trả về rỗng khi không có sản phẩm thuộc thương hiệu")
        void findByBrand_noResults() {
            when(productRepository.findByBrandIgnoreCase("unknownbrand")).thenReturn(List.of());

            List<ProductResponseDto> result = productService.findByBrand("unknownbrand");

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  searchByKeyword()
    // =========================================================

    @Nested
    @DisplayName("searchByKeyword()")
    class SearchByKeyword {

        @Test
        @DisplayName("Trả về tất cả sản phẩm khi keyword là null")
        void searchByKeyword_nullKeyword_returnsAll() {
            when(productRepository.findAll()).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.searchByKeyword(null);

            assertThat(result).hasSize(1);
            verify(productRepository).findAll();
            verify(productRepository, never()).findAll(any(Specification.class));
        }

        @Test
        @DisplayName("Trả về tất cả sản phẩm khi keyword là chuỗi trắng")
        void searchByKeyword_blankKeyword_returnsAll() {
            when(productRepository.findAll()).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.searchByKeyword("   ");

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Tìm kiếm với keyword hợp lệ sử dụng Specification")
        void searchByKeyword_withKeyword_usesSpecification() {
            when(productRepository.findAll(any(Specification.class))).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.searchByKeyword("nike");

            assertThat(result).hasSize(1);
            verify(productRepository).findAll(any(Specification.class));
            verify(productRepository, never()).findAll();
        }

        @Test
        @DisplayName("Trả về rỗng khi không tìm thấy sản phẩm khớp keyword")
        void searchByKeyword_noMatch() {
            when(productRepository.findAll(any(Specification.class))).thenReturn(List.of());

            List<ProductResponseDto> result = productService.searchByKeyword("xyz123");

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  findByGender()
    // =========================================================

    @Nested
    @DisplayName("findByGender()")
    class FindByGender {

        @Test
        @DisplayName("Trả về sản phẩm theo giới tính MEN")
        void findByGender_men() {
            when(productRepository.findAll(any(Specification.class))).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findByGender(GenderType.MEN);

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Trả về sản phẩm theo giới tính WOMEN")
        void findByGender_women() {
            when(productRepository.findAll(any(Specification.class))).thenReturn(List.of(product));
            when(productMapper.toResponseDto(product)).thenReturn(response);

            List<ProductResponseDto> result = productService.findByGender(GenderType.WOMEN);

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Trả về rỗng khi không có sản phẩm phù hợp giới tính")
        void findByGender_noResults() {
            when(productRepository.findAll(any(Specification.class))).thenReturn(List.of());

            List<ProductResponseDto> result = productService.findByGender(GenderType.UNISEX);

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  update()
    // =========================================================

    @Nested
    @DisplayName("update()")
    class Update {

        @Test
        @DisplayName("Thành công: cập nhật sản phẩm khi tên thay đổi tạo slug mới")
        void update_newName_slugUpdated() {
            ProductRequestDto updateReq = new ProductRequestDto(
                    "Nike Air Max", "Updated desc", "Nike", "USA",
                    new BigDecimal("2000000"), "cat-1", EntityStatus.ACTIVE, GenderType.MEN, null
            );

            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(productRepository.existsBySlug("nike-air-max")).thenReturn(false);
            when(productRepository.save(product)).thenReturn(product);
            when(productMapper.toResponseDto(product)).thenReturn(response);

            productService.update("prod-1", updateReq);

            assertThat(product.getSlug()).isEqualTo("nike-air-max");
            verify(productRepository).save(product);
        }

        @Test
        @DisplayName("Thành công: tên không đổi thì không kiểm tra slug trùng")
        void update_sameName_noSlugCheck() {
            ProductRequestDto sameNameReq = new ProductRequestDto(
                    "Nike Air Force 1", "Updated desc", "Nike", "USA",
                    new BigDecimal("1800000"), "cat-1", EntityStatus.ACTIVE, GenderType.UNISEX, null
            );

            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(productRepository.save(product)).thenReturn(product);
            when(productMapper.toResponseDto(product)).thenReturn(response);

            productService.update("prod-1", sameNameReq);

            verify(productRepository, never()).existsBySlug(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi sản phẩm không tồn tại")
        void update_notFound() {
            when(productRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> productService.update("not-exist", request))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Product");
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi tên mới tạo slug đã tồn tại")
        void update_duplicateSlugOnRename() {
            ProductRequestDto updateReq = new ProductRequestDto(
                    "Adidas Ultraboost", null, "Adidas", null,
                    new BigDecimal("2500000"), "cat-1", null, null, null
            );
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(productRepository.existsBySlug("adidas-ultraboost")).thenReturn(true);

            assertThatThrownBy(() -> productService.update("prod-1", updateReq))
                    .isInstanceOf(BusinessException.class);

            verify(productRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi category mới không tồn tại")
        void update_newCategoryNotFound() {
            ProductRequestDto updateReq = new ProductRequestDto(
                    "Nike Air Force 1", null, "Nike", null,
                    new BigDecimal("1500000"), "cat-new", null, null, null
            );
            product.setCategory(category);

            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(categoryRepository.findById("cat-new")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> productService.update("prod-1", updateReq))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Category");
        }
    }

    // =========================================================
    //  delete()
    // =========================================================

    @Nested
    @DisplayName("delete()")
    class Delete {

        @Test
        @DisplayName("Soft-delete: đặt status = INACTIVE thay vì xóa vật lý")
        void delete_setsStatusInactive() {
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));

            productService.delete("prod-1");

            assertThat(product.getStatus()).isEqualTo(EntityStatus.INACTIVE);
            verify(productRepository).save(product);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi sản phẩm không tồn tại")
        void delete_notFound() {
            when(productRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> productService.delete("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class);

            verify(productRepository, never()).save(any());
        }

        @Test
        @DisplayName("Không xóa vật lý: productRepository.delete() không được gọi")
        void delete_neverCallsRepositoryDelete() {
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));

            productService.delete("prod-1");

            verify(productRepository, never()).delete(any(Product.class));
            verify(productRepository, never()).deleteById(any());
        }
    }
}
