package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantResponseDto;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.ProductVariant;
import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.Size;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.external.client.InventoryClient;
import com.CNLTHD.Product_Service.external.dto.InventoryApiResponse;
import com.CNLTHD.Product_Service.external.dto.InventoryRequest;
import com.CNLTHD.Product_Service.external.dto.InventoryResponse;
import com.CNLTHD.Product_Service.mapper.ProductVariantMapper;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import feign.FeignException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit test (Function Test) cho ProductVariantServiceImpl.
 * InventoryClient (Feign) được mock hoàn toàn.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("ProductVariantServiceImpl - Function Tests")
class ProductVariantServiceImplTest {

    @Mock private ProductVariantRepository variantRepository;
    @Mock private ProductRepository productRepository;
    @Mock private ProductVariantMapper variantMapper;
    @Mock private InventoryClient inventoryClient;

    @InjectMocks
    private ProductVariantServiceImpl variantService;

    private Product product;
    private ProductVariant variant;
    private ProductVariantRequestDto request;
    private ProductVariantResponseDto response;

    @BeforeEach
    void setUp() {
        product = new Product();
        product.setId("prod-1");
        product.setName("Nike Air Force 1");

        variant = new ProductVariant();
        variant.setId("var-1");
        variant.setSku("NIKE-AF1-M-WHITE");
        variant.setSize(Size.M);
        variant.setColor(Color.WHITE);
        variant.setPrice(new BigDecimal("1500000"));
        variant.setStatus(EntityStatus.ACTIVE);
        variant.setProduct(product);

        request = new ProductVariantRequestDto(
                "prod-1", Size.M, Color.WHITE,
                new BigDecimal("1500000"), "NIKE-AF1-M-WHITE", 10, EntityStatus.ACTIVE
        );

        response = new ProductVariantResponseDto();
        response.setId("var-1");
        response.setSku("NIKE-AF1-M-WHITE");
        response.setSize(Size.M);
        response.setColor(Color.WHITE);
        response.setQuantity(10);
        response.setStatus(EntityStatus.ACTIVE);
    }

    // helper: build inventory response mock
    private ResponseEntity<InventoryApiResponse<InventoryResponse>> buildInventoryResponse(int quantity) {
        InventoryResponse invData = new InventoryResponse(1L, "Nike Air Force 1", "NIKE-AF1-M-WHITE", quantity);
        InventoryApiResponse<InventoryResponse> body = new InventoryApiResponse<>(true, "OK", invData, null);
        return ResponseEntity.ok(body);
    }

    // =========================================================
    //  create()
    // =========================================================

    @Nested
    @DisplayName("create()")
    class Create {

        @Test
        @DisplayName("Thành công: tạo variant mới, inventory chưa tồn tại → gọi createStock")
        void create_success_inventoryNotExist() {
            when(variantRepository.existsBySku("NIKE-AF1-M-WHITE")).thenReturn(false);
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(variantMapper.toEntity(request)).thenReturn(variant);
            when(variantRepository.save(variant)).thenReturn(variant);
            when(variantMapper.toResponseDto(variant)).thenReturn(response);

            // Inventory không tồn tại → FeignException.NotFound
            FeignException.NotFound notFound = mock(FeignException.NotFound.class);
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenThrow(notFound);
            when(inventoryClient.createStock(any(InventoryRequest.class)))
                    .thenReturn(buildInventoryResponse(10));

            ProductVariantResponseDto result = variantService.create(request);

            assertThat(result).isNotNull();
            assertThat(result.getSku()).isEqualTo("NIKE-AF1-M-WHITE");
            verify(inventoryClient).createStock(any(InventoryRequest.class));
        }

        @Test
        @DisplayName("Thành công: tạo variant, inventory đã tồn tại với số lượng thấp hơn → gọi addStock")
        void create_success_inventoryExistsLower() {
            when(variantRepository.existsBySku("NIKE-AF1-M-WHITE")).thenReturn(false);
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(variantMapper.toEntity(request)).thenReturn(variant);
            when(variantRepository.save(variant)).thenReturn(variant);
            when(variantMapper.toResponseDto(variant)).thenReturn(response);

            // Inventory có sẵn 5, request muốn 10 → delta=5 > 0 → addStock
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(5));
            when(inventoryClient.addStock(eq("NIKE-AF1-M-WHITE"), any()))
                    .thenReturn(buildInventoryResponse(10));

            variantService.create(request);

            verify(inventoryClient).addStock(eq("NIKE-AF1-M-WHITE"), any());
        }

        @Test
        @DisplayName("Thành công: inventory đã tồn tại và bằng target → không gọi addStock/deductStock")
        void create_success_inventoryAlreadyAtTarget() {
            when(variantRepository.existsBySku("NIKE-AF1-M-WHITE")).thenReturn(false);
            when(productRepository.findById("prod-1")).thenReturn(Optional.of(product));
            when(variantMapper.toEntity(request)).thenReturn(variant);
            when(variantRepository.save(variant)).thenReturn(variant);
            when(variantMapper.toResponseDto(variant)).thenReturn(response);

            // Inventory đúng 10 = target → delta=0 → không cần gọi gì
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(10));

            variantService.create(request);

            verify(inventoryClient, never()).addStock(any(), any());
            verify(inventoryClient, never()).deductStock(any(), any());
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi SKU đã tồn tại")
        void create_duplicateSku() {
            when(variantRepository.existsBySku("NIKE-AF1-M-WHITE")).thenReturn(true);

            assertThatThrownBy(() -> variantService.create(request))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("NIKE-AF1-M-WHITE");

            verify(variantRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi product không tồn tại")
        void create_productNotFound() {
            when(variantRepository.existsBySku("NIKE-AF1-M-WHITE")).thenReturn(false);
            when(productRepository.findById("prod-1")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> variantService.create(request))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Product");

            verify(variantRepository, never()).save(any());
        }
    }

    // =========================================================
    //  findById()
    // =========================================================

    @Nested
    @DisplayName("findById()")
    class FindById {

        @Test
        @DisplayName("Thành công: trả về DTO kèm quantity từ Inventory Service")
        void findById_success() {
            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));
            when(variantMapper.toResponseDto(variant)).thenReturn(response);
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(10));

            ProductVariantResponseDto result = variantService.findById("var-1");

            assertThat(result).isNotNull();
            assertThat(result.getSku()).isEqualTo("NIKE-AF1-M-WHITE");
            assertThat(result.getQuantity()).isEqualTo(10);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi variant không tồn tại")
        void findById_notFound() {
            when(variantRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> variantService.findById("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("ProductVariant");
        }
    }

    // =========================================================
    //  findByProduct()
    // =========================================================

    @Nested
    @DisplayName("findByProduct()")
    class FindByProduct {

        @Test
        @DisplayName("Thành công: trả về danh sách variant của product")
        void findByProduct_success() {
            when(productRepository.existsById("prod-1")).thenReturn(true);
            when(variantRepository.findByProductId("prod-1")).thenReturn(List.of(variant));
            when(variantMapper.toResponseDto(variant)).thenReturn(response);
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(10));

            List<ProductVariantResponseDto> result = variantService.findByProduct("prod-1");

            assertThat(result).hasSize(1);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi product không tồn tại")
        void findByProduct_productNotFound() {
            when(productRepository.existsById("not-exist")).thenReturn(false);

            assertThatThrownBy(() -> variantService.findByProduct("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("Product");
        }

        @Test
        @DisplayName("Trả về rỗng khi product không có variant nào")
        void findByProduct_noVariants() {
            when(productRepository.existsById("prod-1")).thenReturn(true);
            when(variantRepository.findByProductId("prod-1")).thenReturn(List.of());

            List<ProductVariantResponseDto> result = variantService.findByProduct("prod-1");

            assertThat(result).isEmpty();
        }
    }

    // =========================================================
    //  update()
    // =========================================================

    @Nested
    @DisplayName("update()")
    class Update {

        @Test
        @DisplayName("Thành công: cập nhật variant và đồng bộ inventory")
        void update_success() {
            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));
            when(variantRepository.save(variant)).thenReturn(variant);
            when(variantMapper.toResponseDto(variant)).thenReturn(response);
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(10));

            ProductVariantResponseDto result = variantService.update("var-1", request);

            assertThat(result).isNotNull();
            verify(variantRepository).save(variant);
        }

        @Test
        @DisplayName("Thất bại: ném BusinessException khi SKU mới đã tồn tại ở variant khác")
        void update_duplicateSkuOnChange() {
            ProductVariantRequestDto updateReq = new ProductVariantRequestDto(
                    "prod-1", Size.L, Color.BLACK,
                    new BigDecimal("1500000"), "NIKE-AF1-L-BLACK", 10, EntityStatus.ACTIVE
            );

            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));
            when(variantRepository.existsBySku("NIKE-AF1-L-BLACK")).thenReturn(true);

            assertThatThrownBy(() -> variantService.update("var-1", updateReq))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("NIKE-AF1-L-BLACK");

            verify(variantRepository, never()).save(any());
        }

        @Test
        @DisplayName("Thành công: giữ nguyên SKU cũ thì không kiểm tra trùng SKU")
        void update_sameSku_noSkuUniquenessCheck() {
            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));
            when(variantRepository.save(variant)).thenReturn(variant);
            when(variantMapper.toResponseDto(variant)).thenReturn(response);
            when(inventoryClient.getBySkuCode("NIKE-AF1-M-WHITE")).thenReturn(buildInventoryResponse(10));

            variantService.update("var-1", request);

            verify(variantRepository, never()).existsBySku(any());
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi variant không tồn tại")
        void update_notFound() {
            when(variantRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> variantService.update("not-exist", request))
                    .isInstanceOf(ResourceNotFoundException.class);
        }
    }

    // =========================================================
    //  delete()
    // =========================================================

    @Nested
    @DisplayName("delete()")
    class Delete {

        @Test
        @DisplayName("Soft-delete: đặt status = INACTIVE")
        void delete_setsStatusInactive() {
            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));

            variantService.delete("var-1");

            assertThat(variant.getStatus()).isEqualTo(EntityStatus.INACTIVE);
            verify(variantRepository).save(variant);
        }

        @Test
        @DisplayName("Thất bại: ném ResourceNotFoundException khi variant không tồn tại")
        void delete_notFound() {
            when(variantRepository.findById("not-exist")).thenReturn(Optional.empty());

            assertThatThrownBy(() -> variantService.delete("not-exist"))
                    .isInstanceOf(ResourceNotFoundException.class);

            verify(variantRepository, never()).save(any());
        }

        @Test
        @DisplayName("Không xóa vật lý: delete() của repository không được gọi")
        void delete_neverCallsRepositoryDelete() {
            when(variantRepository.findById("var-1")).thenReturn(Optional.of(variant));

            variantService.delete("var-1");

            verify(variantRepository, never()).delete(any(ProductVariant.class));
        }
    }
}
