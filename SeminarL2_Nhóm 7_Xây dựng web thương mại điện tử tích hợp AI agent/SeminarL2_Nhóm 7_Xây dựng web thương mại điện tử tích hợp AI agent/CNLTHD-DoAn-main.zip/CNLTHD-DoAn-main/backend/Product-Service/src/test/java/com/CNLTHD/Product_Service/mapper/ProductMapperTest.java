package com.CNLTHD.Product_Service.mapper;

import com.CNLTHD.Product_Service.dto.response.ProductColorOptionDto;
import com.CNLTHD.Product_Service.dto.response.ProductDetailsDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantOptionDto;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.ProductMedia;
import com.CNLTHD.Product_Service.entity.ProductVariant;
import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.MediaType;
import com.CNLTHD.Product_Service.entity.enums.Size;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit test (Function Test) cho các default method của ProductMapper.
 * Không cần Spring context - test trực tiếp logic helper.
 */
@DisplayName("ProductMapper - Function Tests (Default Methods)")
class ProductMapperTest {

    // Tạo anonymous implementation để test default methods
    private final ProductMapper mapper = new ProductMapper() {
        @Override
        public com.CNLTHD.Product_Service.dto.response.ProductResponseDto toResponseDto(Product product) {
            throw new UnsupportedOperationException("Use Spring-managed bean for full mapping");
        }

        @Override
        public Product toEntity(com.CNLTHD.Product_Service.dto.request.ProductRequestDto dto) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void updateEntityFromDto(
                com.CNLTHD.Product_Service.dto.request.ProductRequestDto dto,
                Product product) {
            throw new UnsupportedOperationException();
        }
    };

    private Product product;
    private ProductVariant variantWhiteM;
    private ProductVariant variantBlackL;
    private ProductMedia media1;
    private ProductMedia media2;

    @BeforeEach
    void setUp() {
        product = new Product();
        product.setId("prod-1");
        product.setName("Nike Air Force 1");
        product.setBrand("Nike");
        product.setSlug("nike-air-force-1");
        product.setBasePrice(new BigDecimal("1500000"));
        product.setCountry("USA");

        variantWhiteM = new ProductVariant();
        variantWhiteM.setId("var-1");
        variantWhiteM.setSku("NIKE-AF1-M-WHITE");
        variantWhiteM.setSize(Size.M);
        variantWhiteM.setColor(Color.WHITE);
        variantWhiteM.setPrice(new BigDecimal("1500000"));

        variantBlackL = new ProductVariant();
        variantBlackL.setId("var-2");
        variantBlackL.setSku("NIKE-AF1-L-BLACK");
        variantBlackL.setSize(Size.L);
        variantBlackL.setColor(Color.BLACK);

        media1 = new ProductMedia();
        media1.setId("media-1");
        media1.setUrl("https://example.com/img1.jpg");
        media1.setSortOrder(1);
        media1.setMediaType(MediaType.IMAGE);

        media2 = new ProductMedia();
        media2.setId("media-2");
        media2.setUrl("https://example.com/img2.jpg");
        media2.setSortOrder(2);
        media2.setMediaType(MediaType.IMAGE);
    }

    // =========================================================
    //  resolvePrimaryImage()
    // =========================================================

    @Nested
    @DisplayName("resolvePrimaryImage()")
    class ResolvePrimaryImage {

        @Test
        @DisplayName("Trả về URL của media có sortOrder nhỏ nhất")
        void resolvePrimaryImage_returnsFirst() {
            product.setMediaItems(new ArrayList<>(List.of(media2, media1)));

            String primaryImage = mapper.resolvePrimaryImage(product);

            assertThat(primaryImage).isEqualTo("https://example.com/img1.jpg");
        }

        @Test
        @DisplayName("Trả về null khi không có media")
        void resolvePrimaryImage_noMedia_returnsNull() {
            product.setMediaItems(new ArrayList<>());

            String primaryImage = mapper.resolvePrimaryImage(product);

            assertThat(primaryImage).isNull();
        }

        @Test
        @DisplayName("Trả về null khi mediaItems là null")
        void resolvePrimaryImage_nullMedia_returnsNull() {
            product.setMediaItems(null);

            String primaryImage = mapper.resolvePrimaryImage(product);

            assertThat(primaryImage).isNull();
        }
    }

    // =========================================================
    //  resolveImages()
    // =========================================================

    @Nested
    @DisplayName("resolveImages()")
    class ResolveImages {

        @Test
        @DisplayName("Trả về danh sách URL theo thứ tự sortOrder tăng dần")
        void resolveImages_sortedBySortOrder() {
            product.setMediaItems(new ArrayList<>(List.of(media2, media1)));

            List<String> images = mapper.resolveImages(product);

            assertThat(images).containsExactly(
                    "https://example.com/img1.jpg",
                    "https://example.com/img2.jpg"
            );
        }

        @Test
        @DisplayName("Trả về danh sách rỗng khi không có media")
        void resolveImages_noMedia_returnsEmpty() {
            product.setMediaItems(new ArrayList<>());

            List<String> images = mapper.resolveImages(product);

            assertThat(images).isEmpty();
        }

        @Test
        @DisplayName("Trả về danh sách rỗng khi mediaItems là null")
        void resolveImages_nullMedia_returnsEmpty() {
            product.setMediaItems(null);

            List<String> images = mapper.resolveImages(product);

            assertThat(images).isEmpty();
        }
    }

    // =========================================================
    //  mapVariantOptions()
    // =========================================================

    @Nested
    @DisplayName("mapVariantOptions()")
    class MapVariantOptions {

        @Test
        @DisplayName("Map đúng thông tin size, color, sku của mỗi variant")
        void mapVariantOptions_correctMapping() {
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            List<ProductVariantOptionDto> options = mapper.mapVariantOptions(product);

            assertThat(options).hasSize(1);
            ProductVariantOptionDto opt = options.get(0);
            assertThat(opt.getId()).isEqualTo("var-1");
            assertThat(opt.getSize()).isEqualTo("M");
            assertThat(opt.getColor()).isEqualTo("WHITE");
            assertThat(opt.getSku()).isEqualTo("NIKE-AF1-M-WHITE");
        }

        @Test
        @DisplayName("Variant không có price riêng thì dùng basePrice của product")
        void mapVariantOptions_usesProductBasePriceWhenVariantPriceNull() {
            variantWhiteM.setPrice(null);
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            List<ProductVariantOptionDto> options = mapper.mapVariantOptions(product);

            assertThat(options.get(0).getPrice()).isEqualTo(new BigDecimal("1500000"));
        }

        @Test
        @DisplayName("Trả về danh sách rỗng khi không có variant")
        void mapVariantOptions_noVariants_returnsEmpty() {
            product.setVariants(new ArrayList<>());

            List<ProductVariantOptionDto> options = mapper.mapVariantOptions(product);

            assertThat(options).isEmpty();
        }

        @Test
        @DisplayName("Trả về danh sách rỗng khi variants là null")
        void mapVariantOptions_nullVariants_returnsEmpty() {
            product.setVariants(null);

            List<ProductVariantOptionDto> options = mapper.mapVariantOptions(product);

            assertThat(options).isEmpty();
        }
    }

    // =========================================================
    //  mapColorOptions()
    // =========================================================

    @Nested
    @DisplayName("mapColorOptions()")
    class MapColorOptions {

        @Test
        @DisplayName("Trả về danh sách màu không trùng lặp")
        void mapColorOptions_uniqueColors() {
            // Thêm 2 variant cùng màu WHITE
            ProductVariant variantWhiteL = new ProductVariant();
            variantWhiteL.setColor(Color.WHITE);
            product.setVariants(new ArrayList<>(List.of(variantWhiteM, variantBlackL, variantWhiteL)));

            List<ProductColorOptionDto> colors = mapper.mapColorOptions(product);

            assertThat(colors).hasSize(2);
            assertThat(colors).extracting(ProductColorOptionDto::getCode)
                    .containsExactlyInAnyOrder("WHITE", "BLACK");
        }

        @Test
        @DisplayName("Mỗi màu có đủ displayName và hexCode")
        void mapColorOptions_colorHasDisplayNameAndHexCode() {
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            List<ProductColorOptionDto> colors = mapper.mapColorOptions(product);

            assertThat(colors).hasSize(1);
            ProductColorOptionDto whiteColor = colors.get(0);
            assertThat(whiteColor.getCode()).isEqualTo("WHITE");
            assertThat(whiteColor.getName()).isEqualTo("White");
            assertThat(whiteColor.getHex()).isEqualTo("#FFFFFF");
        }

        @Test
        @DisplayName("Trả về rỗng khi variants là null")
        void mapColorOptions_nullVariants_returnsEmpty() {
            product.setVariants(null);

            List<ProductColorOptionDto> colors = mapper.mapColorOptions(product);

            assertThat(colors).isEmpty();
        }
    }

    // =========================================================
    //  mapSizeOptions()
    // =========================================================

    @Nested
    @DisplayName("mapSizeOptions()")
    class MapSizeOptions {

        @Test
        @DisplayName("Trả về danh sách size không trùng lặp")
        void mapSizeOptions_uniqueSizes() {
            ProductVariant variantWhiteM2 = new ProductVariant();
            variantWhiteM2.setSize(Size.M);  // trùng với variantWhiteM
            product.setVariants(new ArrayList<>(List.of(variantWhiteM, variantBlackL, variantWhiteM2)));

            List<String> sizes = mapper.mapSizeOptions(product);

            assertThat(sizes).containsExactlyInAnyOrder("M", "L");
            assertThat(sizes).hasSize(2);
        }

        @Test
        @DisplayName("Trả về rỗng khi không có variant")
        void mapSizeOptions_noVariants_returnsEmpty() {
            product.setVariants(new ArrayList<>());

            List<String> sizes = mapper.mapSizeOptions(product);

            assertThat(sizes).isEmpty();
        }
    }

    // =========================================================
    //  resolveIsNew()
    // =========================================================

    @Nested
    @DisplayName("resolveIsNew()")
    class ResolveIsNew {

        @Test
        @DisplayName("Trả về true khi sản phẩm được tạo trong vòng 30 ngày")
        void resolveIsNew_recentProduct_returnsTrue() {
            product.setCreatedAt(LocalDateTime.now().minusDays(5));

            Boolean isNew = mapper.resolveIsNew(product);

            assertThat(isNew).isTrue();
        }

        @Test
        @DisplayName("Trả về false khi sản phẩm được tạo hơn 30 ngày trước")
        void resolveIsNew_oldProduct_returnsFalse() {
            product.setCreatedAt(LocalDateTime.now().minusDays(31));

            Boolean isNew = mapper.resolveIsNew(product);

            assertThat(isNew).isFalse();
        }

        @Test
        @DisplayName("Trả về false khi createdAt là null")
        void resolveIsNew_nullCreatedAt_returnsFalse() {
            product.setCreatedAt(null);

            Boolean isNew = mapper.resolveIsNew(product);

            assertThat(isNew).isFalse();
        }

        @Test
        @DisplayName("Trả về true cho sản phẩm vừa tạo (0 ngày)")
        void resolveIsNew_justCreated_returnsTrue() {
            product.setCreatedAt(LocalDateTime.now());

            Boolean isNew = mapper.resolveIsNew(product);

            assertThat(isNew).isTrue();
        }
    }

    // =========================================================
    //  resolveDetails()
    // =========================================================

    @Nested
    @DisplayName("resolveDetails()")
    class ResolveDetails {

        @Test
        @DisplayName("Trả về country từ product entity")
        void resolveDetails_hasCountry() {
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            ProductDetailsDto details = mapper.resolveDetails(product);

            assertThat(details.getCountry()).isEqualTo("USA");
        }

        @Test
        @DisplayName("Country = 'Unknown' khi product không có country")
        void resolveDetails_noCountry_returnsUnknown() {
            product.setCountry(null);
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            ProductDetailsDto details = mapper.resolveDetails(product);

            assertThat(details.getCountry()).isEqualTo("Unknown");
        }

        @Test
        @DisplayName("colorShown lấy từ variant đầu tiên có màu")
        void resolveDetails_colorShownFromFirstVariant() {
            product.setVariants(new ArrayList<>(List.of(variantWhiteM)));

            ProductDetailsDto details = mapper.resolveDetails(product);

            assertThat(details.getColorShown()).isEqualTo("White");
        }

        @Test
        @DisplayName("colorShown = 'N/A' khi không có variant")
        void resolveDetails_noVariants_colorShownNA() {
            product.setVariants(new ArrayList<>());

            ProductDetailsDto details = mapper.resolveDetails(product);

            assertThat(details.getColorShown()).isEqualTo("N/A");
        }

        @Test
        @DisplayName("style lấy từ slug của product")
        void resolveDetails_styleFromSlug() {
            product.setVariants(new ArrayList<>());
            product.setSlug("nike-air-force-1");

            ProductDetailsDto details = mapper.resolveDetails(product);

            assertThat(details.getStyle()).isEqualTo("nike-air-force-1");
        }
    }
}
