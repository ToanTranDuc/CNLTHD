package com.CNLTHD.Product_Service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductColorOptionDto {
    private String code;
    private String name;
    private String hex;
}
