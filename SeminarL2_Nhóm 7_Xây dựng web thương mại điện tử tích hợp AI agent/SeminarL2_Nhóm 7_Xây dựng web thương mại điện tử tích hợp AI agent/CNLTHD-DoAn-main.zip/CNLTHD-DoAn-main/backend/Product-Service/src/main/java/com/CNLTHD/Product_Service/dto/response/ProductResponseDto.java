package com.CNLTHD.Product_Service.dto.response;

import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductResponseDto {
    private String id;
    private String name;
    private String description;
    private String brand;
    private String country;
    private String slug;
    private BigDecimal basePrice;
    private String categoryId;
    private String categoryName;

    // Product detail data for frontend display
    private String image;
    private List<String> images;
    private List<ProductVariantOptionDto> variants;
    private List<ProductColorOptionDto> colors;
    private List<String> sizes;
    private Boolean isNew;
    private ProductDetailsDto details;

    private GenderType gender;
    private EntityStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
