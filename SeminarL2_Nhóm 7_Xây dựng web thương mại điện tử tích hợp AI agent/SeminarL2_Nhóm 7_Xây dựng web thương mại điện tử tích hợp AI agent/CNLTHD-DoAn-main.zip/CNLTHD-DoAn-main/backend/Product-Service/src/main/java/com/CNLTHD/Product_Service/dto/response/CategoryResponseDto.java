package com.CNLTHD.Product_Service.dto.response;

import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryResponseDto {
    private String id;
    private String name;
    private String description;
    private String slug;
    private String parentId;
    private String parentName;
    private EntityStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

}
