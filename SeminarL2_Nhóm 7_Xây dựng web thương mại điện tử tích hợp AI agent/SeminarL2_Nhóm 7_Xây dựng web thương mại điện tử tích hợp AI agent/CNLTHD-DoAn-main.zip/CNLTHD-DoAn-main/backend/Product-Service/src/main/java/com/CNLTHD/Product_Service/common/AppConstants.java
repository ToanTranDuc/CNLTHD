package com.CNLTHD.Product_Service.common;

/**
 * Centralised API path constants.
 * Use these in {@code @RequestMapping} on controllers and in tests.
 */
public final class AppConstants {

    private AppConstants() { /* utility class */ }

    public static final String API_VERSION = "/api/v1";

    public static final String CATEGORIES_BASE = API_VERSION + "/categories";
    public static final String PRODUCTS_BASE    = API_VERSION + "/products";
    public static final String VARIANTS_BASE    = API_VERSION + "/products/{productId}/variants";

    /** Common path variable names */
    public static final String PATH_ID         = "/{id}";
    public static final String PATH_PRODUCT_ID = "/{productId}";
}
