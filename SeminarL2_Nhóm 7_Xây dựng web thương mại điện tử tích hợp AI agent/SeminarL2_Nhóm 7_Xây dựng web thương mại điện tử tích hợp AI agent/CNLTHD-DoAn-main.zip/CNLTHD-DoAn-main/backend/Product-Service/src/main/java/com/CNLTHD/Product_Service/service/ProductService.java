package com.CNLTHD.Product_Service.service;

import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public interface ProductService {

    ProductResponseDto create(ProductRequestDto dto);

    ProductResponseDto findById(String id);

    List<ProductResponseDto> findAll();

    List<ProductResponseDto> findByCategory(String categoryId);

    List<ProductResponseDto> findByBrand(String brand);

    /**
     * Dynamic search using JPA Specification.
     * Callers (controllers) can compose filter criteria before passing here.
     */
    Page<ProductResponseDto> search(Specification<Product> spec, Pageable pageable);

    List<ProductResponseDto> searchByKeyword(String keyword);

    List<ProductResponseDto> findByGender(GenderType gender);

    ProductResponseDto update(String id, ProductRequestDto dto);

    void delete(String id);
}
