package com.CNLTHD.Product_Service.controller;

import com.CNLTHD.Product_Service.common.ApiResponse;
import com.CNLTHD.Product_Service.common.AppConstants;
import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantResponseDto;
import com.CNLTHD.Product_Service.service.ProductVariantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(AppConstants.PRODUCTS_BASE)
@Tag(name = "Product Variants", description = "Manage Size + Color variants (SKUs) of products")
public class ProductVariantController {

    private static final Logger log = LoggerFactory.getLogger(ProductVariantController.class);

    private final ProductVariantService variantService;

    public ProductVariantController(ProductVariantService variantService) {
        this.variantService = variantService;
    }

    @GetMapping("/{productId}/variants")
    @Operation(summary = "Get all variants of a product")
    public ResponseEntity<ApiResponse<List<ProductVariantResponseDto>>> getByProduct(
            @PathVariable String productId) {
        return ResponseEntity.ok(ApiResponse.success(variantService.findByProduct(productId)));
    }

    @GetMapping("/variants/{id}")
    @Operation(summary = "Get a variant by its ID")
    public ResponseEntity<ApiResponse<ProductVariantResponseDto>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(variantService.findById(id)));
    }

    @PostMapping("/variants")
    @Operation(summary = "Create a new product variant")
    public ResponseEntity<ApiResponse<ProductVariantResponseDto>> create(
            @Valid @RequestBody ProductVariantRequestDto dto) {
        ProductVariantResponseDto created = variantService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(created, "Variant created successfully"));
    }

    @PutMapping("/variants/{id}")
    @Operation(summary = "Update an existing variant")
    public ResponseEntity<ApiResponse<ProductVariantResponseDto>> update(
            @PathVariable String id, @Valid @RequestBody ProductVariantRequestDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(variantService.update(id, dto), "Variant updated successfully"));
    }

    @DeleteMapping("/variants/{id}")
    @Operation(summary = "Soft-delete a variant")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable String id) {
        variantService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Variant deactivated successfully"));
    }
}
