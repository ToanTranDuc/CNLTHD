package com.CNLTHD.Product_Service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Hierarchical product category supporting unlimited parent-child depth.
 * Example tree: Clothing → Men's Clothing → T-Shirts
 */
@Entity
@Data
@Table(name = "categories")
@AllArgsConstructor
@NoArgsConstructor
public class Category extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /** URL-friendly slug, e.g. "mens-clothing". Must be unique across all categories. */
    @Column(name = "slug", unique = true, length = 150)
    private String slug;

    /** Null means this is a root category. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Category parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Category> children = new ArrayList<>();


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Category)) return false;
        Category that = (Category) o;
        return java.util.Objects.equals(id, that.id);
    }

//    @Override
//    public String toString() {
//        return "Category{id='" + id + "', name='" + name + "', slug='" + slug + "'}";
//    }
}
