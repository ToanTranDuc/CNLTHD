package com.CNLTHD.Product_Service.dto.request;

import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.Size;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductVariantRequestDto {

    @NotBlank(message = "Product ID is required")
    private String productId;

    @NotNull(message = "Size is required")
    private Size size;

    @NotNull(message = "Color is required")
    private Color color;

    /** Optional: if null, the parent product's basePrice applies. */
    @Positive(message = "Price must be a positive number")
    @Digits(integer = 10, fraction = 2, message = "Price format is invalid")
    private BigDecimal price;

    @NotBlank(message = "SKU is required")
    @jakarta.validation.constraints.Size(max = 100, message = "SKU must not exceed 100 characters")
    @Pattern(
        regexp = "^[A-Z0-9_\\-]+$",
        message = "SKU must only contain uppercase letters, numbers, underscores, or hyphens"
    )
    private String sku;
    private int quantity;

    private EntityStatus status;

}
