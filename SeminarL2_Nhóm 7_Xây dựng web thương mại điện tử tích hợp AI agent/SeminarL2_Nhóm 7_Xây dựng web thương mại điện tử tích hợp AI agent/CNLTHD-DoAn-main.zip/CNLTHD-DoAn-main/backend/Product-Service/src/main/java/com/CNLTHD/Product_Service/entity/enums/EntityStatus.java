package com.CNLTHD.Product_Service.entity.enums;

/**
 * Shared lifecycle status for all entities (Product, Category, ProductVariant, etc.).
 * Replaces the old ProductStatus enum in the models package.
 */
public enum EntityStatus {
    ACTIVE,
    INACTIVE
}
