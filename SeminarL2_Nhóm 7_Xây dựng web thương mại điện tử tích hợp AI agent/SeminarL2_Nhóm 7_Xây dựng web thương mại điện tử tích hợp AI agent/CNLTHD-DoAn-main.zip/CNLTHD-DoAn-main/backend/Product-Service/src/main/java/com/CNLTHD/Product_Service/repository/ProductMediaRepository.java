package com.CNLTHD.Product_Service.repository;

import com.CNLTHD.Product_Service.entity.ProductMedia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductMediaRepository extends JpaRepository<ProductMedia, String> {

    List<ProductMedia> findByProductIdOrderBySortOrderAsc(String productId);
}
