package com.CNLTHD.Product_Service.external.client;

import com.CNLTHD.Product_Service.external.dto.InventoryAdjustmentRequest;
import com.CNLTHD.Product_Service.external.dto.InventoryApiResponse;
import com.CNLTHD.Product_Service.external.dto.InventoryRequest;
import com.CNLTHD.Product_Service.external.dto.InventoryResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "inventory-service")
public interface InventoryClient {

    @PostMapping("/api/stocks")
    ResponseEntity<InventoryApiResponse<InventoryResponse>> createStock(@RequestBody InventoryRequest request);

    @PostMapping("/api/stocks/{skuCode}/add")
    ResponseEntity<InventoryApiResponse<InventoryResponse>> addStock(@PathVariable("skuCode") String skuCode,
            @RequestBody InventoryAdjustmentRequest request);

    @PostMapping("/api/stocks/{skuCode}/deduct")
    ResponseEntity<InventoryApiResponse<InventoryResponse>> deductStock(@PathVariable("skuCode") String skuCode,
            @RequestBody InventoryAdjustmentRequest request);

    @GetMapping("/api/stocks/{skuCode}")
    ResponseEntity<InventoryApiResponse<InventoryResponse>> getBySkuCode(@PathVariable("skuCode") String skuCode);
}
