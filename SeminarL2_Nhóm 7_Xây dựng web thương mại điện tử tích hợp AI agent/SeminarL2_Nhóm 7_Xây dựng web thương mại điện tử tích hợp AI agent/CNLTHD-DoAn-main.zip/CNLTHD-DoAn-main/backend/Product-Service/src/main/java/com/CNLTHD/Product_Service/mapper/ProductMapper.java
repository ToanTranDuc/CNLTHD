package com.CNLTHD.Product_Service.mapper;

import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductColorOptionDto;
import com.CNLTHD.Product_Service.dto.response.ProductDetailsDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantOptionDto;
import com.CNLTHD.Product_Service.entity.ProductMedia;
import com.CNLTHD.Product_Service.entity.ProductVariant;
import com.CNLTHD.Product_Service.entity.Product;
import org.mapstruct.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Mapper(componentModel = "spring")
public interface ProductMapper {

    @Mapping(target = "categoryId", source = "category.id")
    @Mapping(target = "categoryName", source = "category.name")
    @Mapping(target = "image", expression = "java(resolvePrimaryImage(product))")
    @Mapping(target = "images", expression = "java(resolveImages(product))")
    @Mapping(target = "variants", expression = "java(mapVariantOptions(product))")
    @Mapping(target = "colors", expression = "java(mapColorOptions(product))")
    @Mapping(target = "sizes", expression = "java(mapSizeOptions(product))")
    @Mapping(target = "isNew", expression = "java(resolveIsNew(product))")
    @Mapping(target = "details", expression = "java(resolveDetails(product))")
    ProductResponseDto toResponseDto(Product product);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "category", ignore = true)
    @Mapping(target = "variants", ignore = true)
    @Mapping(target = "mediaItems", ignore = true)
    @Mapping(target = "slug", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "status", defaultExpression = "java(com.CNLTHD.Product_Service.entity.enums.EntityStatus.ACTIVE)")
    @Mapping(target = "gender", defaultExpression = "java(com.CNLTHD.Product_Service.entity.enums.GenderType.UNISEX)")
    Product toEntity(ProductRequestDto dto);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "category", ignore = true)
    @Mapping(target = "variants", ignore = true)
    @Mapping(target = "mediaItems", ignore = true)
    @Mapping(target = "slug", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateEntityFromDto(ProductRequestDto dto, @MappingTarget Product product);

    default String resolvePrimaryImage(Product product) {
        return product.getMediaItems() == null ? null
                : product.getMediaItems().stream()
                        .filter(Objects::nonNull)
                        .sorted(Comparator.comparing(ProductMedia::getSortOrder,
                                Comparator.nullsLast(Integer::compareTo)))
                        .map(ProductMedia::getUrl)
                        .filter(Objects::nonNull)
                        .findFirst()
                        .orElse(null);
    }

    default List<String> resolveImages(Product product) {
        if (product.getMediaItems() == null) {
            return List.of();
        }
        return product.getMediaItems().stream()
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(ProductMedia::getSortOrder, Comparator.nullsLast(Integer::compareTo)))
                .map(ProductMedia::getUrl)
                .filter(Objects::nonNull)
                .toList();
    }

    default List<ProductVariantOptionDto> mapVariantOptions(Product product) {
        if (product.getVariants() == null) {
            return List.of();
        }
        return product.getVariants().stream()
                .filter(Objects::nonNull)
                .map(v -> new ProductVariantOptionDto(
                        v.getId(),
                        v.getSize() != null ? v.getSize().name() : null,
                        v.getSize() != null ? v.getSize().getDisplayName() : null,
                        v.getColor() != null ? v.getColor().name() : null,
                        v.getColor() != null ? v.getColor().getDisplayName() : null,
                        v.getColor() != null ? v.getColor().getHexCode() : null,
                        v.getPrice() != null ? v.getPrice() : product.getBasePrice(),
                        v.getSku(),
                        Boolean.TRUE))
                .toList();
    }

    default List<ProductColorOptionDto> mapColorOptions(Product product) {
        if (product.getVariants() == null) {
            return List.of();
        }

        Map<String, ProductColorOptionDto> uniqueColors = new LinkedHashMap<>();
        for (ProductVariant variant : product.getVariants()) {
            if (variant == null || variant.getColor() == null) {
                continue;
            }
            String code = variant.getColor().name();
            uniqueColors.putIfAbsent(code, new ProductColorOptionDto(
                    code,
                    variant.getColor().getDisplayName(),
                    variant.getColor().getHexCode()));
        }
        return new ArrayList<>(uniqueColors.values());
    }

    default List<String> mapSizeOptions(Product product) {
        if (product.getVariants() == null) {
            return List.of();
        }

        List<String> sizes = new ArrayList<>();
        for (ProductVariant variant : product.getVariants()) {
            if (variant == null || variant.getSize() == null) {
                continue;
            }
            String sizeCode = variant.getSize().name();
            if (!sizes.contains(sizeCode)) {
                sizes.add(sizeCode);
            }
        }
        return sizes;
    }

    default Boolean resolveIsNew(Product product) {
        LocalDateTime createdAt = product.getCreatedAt();
        if (createdAt == null) {
            return Boolean.FALSE;
        }
        return createdAt.isAfter(LocalDateTime.now().minusDays(30));
    }

    default ProductDetailsDto resolveDetails(Product product) {
        String colorShown = "N/A";
        String style = product.getSlug();

        if (product.getVariants() != null) {
            for (ProductVariant variant : product.getVariants()) {
                if (variant == null) {
                    continue;
                }
                if ("N/A".equals(colorShown) && variant.getColor() != null) {
                    colorShown = variant.getColor().getDisplayName();
                }
                if ((style == null || style.isBlank()) && variant.getSku() != null && !variant.getSku().isBlank()) {
                    style = variant.getSku();
                }
            }
        }

        if (style == null || style.isBlank()) {
            style = "N/A";
        }

        String country = (product.getCountry() == null || product.getCountry().isBlank())
                ? "Unknown"
                : product.getCountry();

        return new ProductDetailsDto(colorShown, style, country);
    }
}
