package com.CNLTHD.Product_Service.entity.enums;

/**
 * Common fashion color palette for ProductVariants.
 * Each constant carries a display name and a hex code for frontend rendering.
 */
public enum Color {
    BLACK("Black", "#000000"),
    WHITE("White", "#FFFFFF"),
    RED("Red", "#FF0000"),
    BLUE("Blue", "#0000FF"),
    NAVY("Navy", "#001F5B"),
    GREEN("Green", "#008000"),
    OLIVE("Olive", "#808000"),
    YELLOW("Yellow", "#FFFF00"),
    PINK("Pink", "#FFC0CB"),
    PURPLE("Purple", "#800080"),
    GRAY("Gray", "#808080"),
    BEIGE("Beige", "#F5F5DC"),
    BROWN("Brown", "#A52A2A"),
    ORANGE("Orange", "#FFA500"),
    CREAM("Cream", "#FFFDD0"),
    KHAKI("Khaki", "#C3B091");

    private final String displayName;
    private final String hexCode;

    Color(String displayName, String hexCode) {
        this.displayName = displayName;
        this.hexCode = hexCode;
    }

    public String getDisplayName() { return displayName; }
    public String getHexCode() { return hexCode; }
}
