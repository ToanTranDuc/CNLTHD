package com.CNLTHD.Product_Service.dto.response;

import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductVariantResponseDto {
    private String id;
    private String productId;
    private String productName;
    private Size size;
    private Color color;
    private BigDecimal price;
    private String sku;
    private int quantity;
    private EntityStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


}
