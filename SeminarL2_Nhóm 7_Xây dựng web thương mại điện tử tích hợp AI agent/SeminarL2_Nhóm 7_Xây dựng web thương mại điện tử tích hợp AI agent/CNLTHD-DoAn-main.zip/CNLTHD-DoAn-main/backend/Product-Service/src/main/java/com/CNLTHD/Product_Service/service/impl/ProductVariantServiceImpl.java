package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantResponseDto;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.ProductVariant;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.external.client.InventoryClient;
import com.CNLTHD.Product_Service.external.dto.InventoryAdjustmentRequest;
import com.CNLTHD.Product_Service.external.dto.InventoryApiResponse;
import com.CNLTHD.Product_Service.external.dto.InventoryRequest;
import com.CNLTHD.Product_Service.external.dto.InventoryResponse;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.ProductVariantMapper;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import feign.FeignException;
import com.CNLTHD.Product_Service.service.ProductVariantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class ProductVariantServiceImpl implements ProductVariantService {

    private static final Logger log = LoggerFactory.getLogger(ProductVariantServiceImpl.class);

    private final ProductVariantRepository variantRepository;
    private final ProductRepository productRepository;
    private final ProductVariantMapper variantMapper;
    private final InventoryClient inventoryClient;

    public ProductVariantServiceImpl(ProductVariantRepository variantRepository,
            ProductRepository productRepository,
            ProductVariantMapper variantMapper,
            InventoryClient inventoryClient) {
        this.variantRepository = variantRepository;
        this.productRepository = productRepository;
        this.variantMapper = variantMapper;
        this.inventoryClient = inventoryClient;
    }

    @Override
    @Transactional
    public ProductVariantResponseDto create(ProductVariantRequestDto dto) {
        log.info("Creating variant SKU: {} for product: {}", dto.getSku(), dto.getProductId());

        if (variantRepository.existsBySku(dto.getSku())) {
            throw new BusinessException("ProductVariant", "SKU '" + dto.getSku() + "' is already in use");
        }

        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", dto.getProductId()));

        ProductVariant variant = variantMapper.toEntity(dto);
        variant.setProduct(product);
        variant.setStatus(Optional.ofNullable(dto.getStatus()).orElse(EntityStatus.ACTIVE));
        ProductVariant saved = variantRepository.save(variant);

        int syncedQty = syncInventoryToTarget(saved.getSku(), product.getName(), dto.getQuantity(), "create-variant");
        ProductVariantResponseDto response = variantMapper.toResponseDto(saved);
        response.setQuantity(syncedQty);
        return response;
    }

    @Override
    public ProductVariantResponseDto findById(String id) {
        return variantRepository.findById(id)
                .map(this::toResponseWithInventoryQuantity)
                .orElseThrow(() -> new ResourceNotFoundException("ProductVariant", "id", id));
    }

    @Override
    public List<ProductVariantResponseDto> findByProduct(String productId) {
        if (!productRepository.existsById(productId)) {
            throw new ResourceNotFoundException("Product", "id", productId);
        }
        return variantRepository.findByProductId(productId).stream()
                .map(this::toResponseWithInventoryQuantity)
                .toList();
    }

    @Override
    @Transactional
    public ProductVariantResponseDto update(String id, ProductVariantRequestDto dto) {
        log.info("Updating variant id: {}", id);

        ProductVariant existing = variantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProductVariant", "id", id));

        // SKU uniqueness check only if SKU is actually changing
        if (!existing.getSku().equals(dto.getSku()) && variantRepository.existsBySku(dto.getSku())) {
            throw new BusinessException("ProductVariant", "SKU '" + dto.getSku() + "' is already in use");
        }

        variantMapper.updateEntityFromDto(dto, existing);
        ProductVariant saved = variantRepository.save(existing);

        String productName = saved.getProduct() != null ? saved.getProduct().getName() : "Unknown Product";
        int syncedQty = syncInventoryToTarget(saved.getSku(), productName, dto.getQuantity(), "update-variant");

        ProductVariantResponseDto response = variantMapper.toResponseDto(saved);
        response.setQuantity(syncedQty);
        return response;
    }

    @Override
    @Transactional
    public void delete(String id) {
        log.info("Soft-deleting variant id: {}", id);
        ProductVariant variant = variantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProductVariant", "id", id));

        variant.setStatus(EntityStatus.INACTIVE);
        variantRepository.save(variant);
    }

    private ProductVariantResponseDto toResponseWithInventoryQuantity(ProductVariant variant) {
        ProductVariantResponseDto response = variantMapper.toResponseDto(variant);
        response.setQuantity(fetchInventoryQuantity(variant.getSku()));
        return response;
    }

    private int syncInventoryToTarget(String skuCode, String productName, int targetQuantity, String actionTag) {
        Integer current = tryGetInventoryQuantity(skuCode);
        if (current == null) {
            InventoryRequest createRequest = new InventoryRequest(productName, skuCode, targetQuantity);
            callInventory(() -> inventoryClient.createStock(createRequest),
                    "Cannot create inventory stock for SKU '" + skuCode + "'");
            return targetQuantity;
        }

        int delta = targetQuantity - current;
        if (delta > 0) {
            InventoryAdjustmentRequest addRequest = new InventoryAdjustmentRequest(
                    delta,
                    skuCode,
                    "Sync from Product Service: " + actionTag);
            callInventory(() -> inventoryClient.addStock(skuCode, addRequest),
                    "Cannot add inventory stock for SKU '" + skuCode + "'");
        } else if (delta < 0) {
            InventoryAdjustmentRequest deductRequest = new InventoryAdjustmentRequest(
                    Math.abs(delta),
                    skuCode,
                    "Sync from Product Service: " + actionTag);
            callInventory(() -> inventoryClient.deductStock(skuCode, deductRequest),
                    "Cannot deduct inventory stock for SKU '" + skuCode + "'");
        }
        return targetQuantity;
    }

    private int fetchInventoryQuantity(String skuCode) {
        ResponseEntity<InventoryApiResponse<InventoryResponse>> response = callInventory(
                () -> inventoryClient.getBySkuCode(skuCode),
                "Cannot fetch inventory quantity for SKU '" + skuCode + "'");
        InventoryResponse data = extractData(response, "Inventory response is empty for SKU '" + skuCode + "'");
        Integer quantity = data.getQuantity();
        return quantity == null ? 0 : quantity;
    }

    private Integer tryGetInventoryQuantity(String skuCode) {
        try {
            ResponseEntity<InventoryApiResponse<InventoryResponse>> response = inventoryClient.getBySkuCode(skuCode);
            InventoryResponse data = extractData(response,
                    "Inventory response is empty while syncing SKU '" + skuCode + "'");
            return data.getQuantity() == null ? 0 : data.getQuantity();
        } catch (FeignException.NotFound ex) {
            return null;
        } catch (FeignException ex) {
            throw new BusinessException("Inventory",
                    "Cannot fetch inventory quantity for SKU '" + skuCode + "' (status=" + ex.status() + ")");
        }
    }

    private <T> ResponseEntity<T> callInventory(InventoryCall<T> call, String errorMessage) {
        try {
            return call.execute();
        } catch (FeignException ex) {
            throw new BusinessException("Inventory", errorMessage + " (status=" + ex.status() + ")");
        } catch (Exception ex) {
            throw new BusinessException("Inventory", errorMessage);
        }
    }

    private InventoryResponse extractData(ResponseEntity<InventoryApiResponse<InventoryResponse>> response,
            String message) {
        InventoryApiResponse<InventoryResponse> body = response.getBody();
        if (body == null || body.getData() == null) {
            throw new BusinessException("Inventory", message);
        }
        return body.getData();
    }

    @FunctionalInterface
    private interface InventoryCall<T> {
        ResponseEntity<T> execute();
    }
}
