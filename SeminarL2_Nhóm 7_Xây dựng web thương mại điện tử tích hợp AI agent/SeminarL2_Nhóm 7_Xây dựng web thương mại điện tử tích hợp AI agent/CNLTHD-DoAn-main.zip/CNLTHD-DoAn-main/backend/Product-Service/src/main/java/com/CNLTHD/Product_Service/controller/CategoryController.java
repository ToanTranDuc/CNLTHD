package com.CNLTHD.Product_Service.controller;

import com.CNLTHD.Product_Service.common.ApiResponse;
import com.CNLTHD.Product_Service.common.AppConstants;
import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.response.CategoryResponseDto;
import com.CNLTHD.Product_Service.service.CategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(AppConstants.CATEGORIES_BASE)
@Tag(name = "Categories", description = "Manage hierarchical product categories")
public class CategoryController {

    private static final Logger log = LoggerFactory.getLogger(CategoryController.class);

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping
    @Operation(summary = "Get all categories")
    public ResponseEntity<ApiResponse<List<CategoryResponseDto>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(categoryService.findAll()));
    }

    @GetMapping("/roots")
    @Operation(summary = "Get root categories (without a parent)")
    public ResponseEntity<ApiResponse<List<CategoryResponseDto>>> getRoots() {
        return ResponseEntity.ok(ApiResponse.success(categoryService.findRootCategories()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get category by ID")
    public ResponseEntity<ApiResponse<CategoryResponseDto>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(categoryService.findById(id)));
    }

    @GetMapping("/{id}/children")
    @Operation(summary = "Get direct children of a category")
    public ResponseEntity<ApiResponse<List<CategoryResponseDto>>> getChildren(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(categoryService.findChildren(id)));
    }

    @PostMapping
    @Operation(summary = "Create a new category")
    public ResponseEntity<ApiResponse<CategoryResponseDto>> create(
            @Valid @RequestBody CategoryRequestDto dto) {
        CategoryResponseDto created = categoryService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(created, "Category created successfully"));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing category")
    public ResponseEntity<ApiResponse<CategoryResponseDto>> update(
            @PathVariable String id, @Valid @RequestBody CategoryRequestDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(categoryService.update(id, dto), "Category updated successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Soft-delete a category (sets status = INACTIVE)")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable String id) {
        categoryService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Category deactivated successfully"));
    }
}
