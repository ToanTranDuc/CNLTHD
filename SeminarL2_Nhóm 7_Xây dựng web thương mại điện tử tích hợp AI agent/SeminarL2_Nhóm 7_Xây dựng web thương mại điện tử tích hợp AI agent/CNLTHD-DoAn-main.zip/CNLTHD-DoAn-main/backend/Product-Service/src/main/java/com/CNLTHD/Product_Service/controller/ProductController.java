package com.CNLTHD.Product_Service.controller;

import com.CNLTHD.Product_Service.common.ApiResponse;
import com.CNLTHD.Product_Service.common.AppConstants;
import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import com.CNLTHD.Product_Service.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(AppConstants.PRODUCTS_BASE)
@Tag(name = "Products", description = "Manage fashion products")
public class ProductController {

    private static final Logger log = LoggerFactory.getLogger(ProductController.class);

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    @Operation(summary = "Get all products")
    public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(productService.findAll()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get product by ID")
    public ResponseEntity<ApiResponse<ProductResponseDto>> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(productService.findById(id)));
    }

    @GetMapping("/category/{categoryId}")
    @Operation(summary = "Get all products in a category")
    public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getByCategory(
            @PathVariable String categoryId) {
        return ResponseEntity.ok(ApiResponse.success(productService.findByCategory(categoryId)));
    }

    @GetMapping("/brand/{brand}")
    @Operation(summary = "Get all products by brand name (case-insensitive)")
    public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getByBrand(
            @PathVariable String brand) {
        return ResponseEntity.ok(ApiResponse.success(productService.findByBrand(brand)));
    }

    @GetMapping("/search")
    @Operation(summary = "Search products by keyword (name, description, or brand)")
    public ResponseEntity<ApiResponse<List<ProductResponseDto>>> search(
            @RequestParam(required = false, defaultValue = "") String keyword) {
        return ResponseEntity.ok(ApiResponse.success(productService.searchByKeyword(keyword)));
    }

    @GetMapping("/gender/{gender}")
    @Operation(summary = "Get products by gender (MEN, WOMEN, UNISEX)")
    public ResponseEntity<ApiResponse<List<ProductResponseDto>>> getByGender(
            @PathVariable GenderType gender) {
        return ResponseEntity.ok(ApiResponse.success(productService.findByGender(gender)));
    }

    @PostMapping
    @Operation(summary = "Create a new product")
    public ResponseEntity<ApiResponse<ProductResponseDto>> create(
            @Valid @RequestBody ProductRequestDto dto) {
        ProductResponseDto created = productService.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(created, "Product created successfully"));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing product")
    public ResponseEntity<ApiResponse<ProductResponseDto>> update(
            @PathVariable String id, @Valid @RequestBody ProductRequestDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(productService.update(id, dto), "Product updated successfully"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Soft-delete a product (sets status = INACTIVE)")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable String id) {
        productService.delete(id);
        return ResponseEntity.ok(ApiResponse.success("Product deactivated successfully"));
    }
}
