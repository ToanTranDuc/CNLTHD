package com.CNLTHD.Product_Service.external.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InventoryAdjustmentRequest {
    private int quantityChange;
    private String referenceId;
    private String reason;
}
