package com.CNLTHD.Product_Service.repository;

import com.CNLTHD.Product_Service.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, String> {

    /** Returns all root categories (those without a parent). */
    List<Category> findByParentIsNull();

    /** Returns direct children of a particular parent category. */
    List<Category> findByParentId(String parentId);

    Optional<Category> findBySlug(String slug);

    boolean existsBySlug(String slug);

    boolean existsByNameAndParentId(String name, String parentId);

    /**
     * Fetches the full category tree in a single query to avoid N+1.
     */
    @Query("SELECT c FROM Category c LEFT JOIN FETCH c.children WHERE c.parent IS NULL")
    List<Category> findRootCategoriesWithChildren();
}
