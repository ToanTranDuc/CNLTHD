package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.ProductRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.ProductMedia;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.MediaType;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.ProductMapper;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import com.CNLTHD.Product_Service.repository.ProductMediaRepository;
import com.CNLTHD.Product_Service.repository.ProductRepository;
import com.CNLTHD.Product_Service.repository.ProductVariantRepository;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import com.CNLTHD.Product_Service.service.ProductService;

import lombok.AllArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductServiceImpl.class);

    private final ProductRepository productRepository;
    private final ProductVariantRepository productVariantRepository;
    private final ProductMediaRepository productMediaRepository;
    private final CategoryRepository categoryRepository;
    private final ProductMapper productMapper;

    
    @Override
    @Transactional
    public ProductResponseDto create(ProductRequestDto dto) {
        log.info("Creating product: {}", dto.getName());

        Category category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getCategoryId()));

        Product product = productMapper.toEntity(dto);
        product.setCategory(category);
        product.setStatus(Optional.ofNullable(dto.getStatus()).orElse(EntityStatus.ACTIVE));
        product.setSlug(generateSlug(dto.getName()));

        if (productRepository.existsBySlug(product.getSlug())) {
            throw new BusinessException("Product", "A product with the name '" + dto.getName() + "' already exists");
        }

        attachMediaItems(product, dto);

        Product saved = productRepository.save(product);
        log.info("Product created with id: {}", saved.getId());

        return productMapper.toResponseDto(saved);
    }

    @Override
    public ProductResponseDto findById(String id) {
        Product product = productRepository.findByIdWithCategory(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));

        hydrateDetailAssociations(product);
        return productMapper.toResponseDto(product);
    }

    @Override
    public List<ProductResponseDto> findAll() {
        return productRepository.findAll().stream()
                .map(productMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<ProductResponseDto> findByCategory(String categoryId) {
        if (!categoryRepository.existsById(categoryId)) {
            throw new ResourceNotFoundException("Category", "id", categoryId);
        }
        return productRepository.findByCategoryId(categoryId).stream()
                .map(productMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<ProductResponseDto> findByBrand(String brand) {
        return productRepository.findByBrandIgnoreCase(brand).stream()
                .map(productMapper::toResponseDto)
                .toList();
    }

    @Override
    public Page<ProductResponseDto> search(Specification<Product> spec, Pageable pageable) {
        return productRepository.findAll(spec, pageable)
                .map(productMapper::toResponseDto);
    }

    @Override
    public List<ProductResponseDto> searchByKeyword(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAll();
        }
        String pattern = "%" + keyword.trim().toLowerCase() + "%";
        Specification<Product> spec = (root, query, cb) -> cb.and(
                cb.equal(root.get("status"), EntityStatus.ACTIVE),
                cb.or(
                        cb.like(cb.lower(root.get("name")), pattern),
                        cb.like(cb.lower(root.get("description")), pattern),
                        cb.like(cb.lower(root.get("brand")), pattern)
                )
        );
        return productRepository.findAll(spec).stream()
                .map(productMapper::toResponseDto)
                .toList();
    }

    @Override
    @Transactional
    public ProductResponseDto update(String id, ProductRequestDto dto) {
        log.info("Updating product id: {}", id);

        Product existing = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));

        if (!existing.getName().equalsIgnoreCase(dto.getName())) {
            String newSlug = generateSlug(dto.getName());
            if (productRepository.existsBySlug(newSlug)) {
                throw new BusinessException("Product",
                        "A product with the name '" + dto.getName() + "' already exists");
            }
            existing.setSlug(newSlug);
        }

        productMapper.updateEntityFromDto(dto, existing);

        if (dto.getCategoryId() != null && !dto.getCategoryId().equals(existing.getCategory().getId())) {
            Category newCategory = categoryRepository.findById(dto.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getCategoryId()));
            existing.setCategory(newCategory);
        }

        if (dto.getImageUrls() != null) {
            existing.getMediaItems().clear();
            attachMediaItems(existing, dto);
        }

        return productMapper.toResponseDto(productRepository.save(existing));
    }

    @Override
    @Transactional
    public void delete(String id) {
        log.info("Soft-deleting product id: {}", id);
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));

        product.setStatus(EntityStatus.INACTIVE);
        productRepository.save(product);
    }

    @Override
    public List<ProductResponseDto> findByGender(GenderType gender) {
        Specification<Product> spec = (root, query, cb) -> cb.and(
                cb.equal(root.get("status"), EntityStatus.ACTIVE),
                cb.equal(root.get("gender"), gender)
        );
        return productRepository.findAll(spec).stream()
                .map(productMapper::toResponseDto)
                .toList();
    }

    // ───────────────────────────── Helpers ─────────────────────────────── //

    private void attachMediaItems(Product product, ProductRequestDto dto) {
        if (dto.getImageUrls() == null) return;
        for (int i = 0; i < dto.getImageUrls().size(); i++) {
            String url = dto.getImageUrls().get(i);
            if (url == null || url.isBlank()) continue;
            ProductMedia media = new ProductMedia();
            media.setProduct(product);
            media.setUrl(url.trim());
            media.setMediaType(MediaType.IMAGE);
            media.setSortOrder(i);
            product.getMediaItems().add(media);
        }
    }

    private String generateSlug(String name) {
        return name.toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .trim()
                .replaceAll("\\s+", "-");
    }

    private void hydrateDetailAssociations(Product product) {
        product.setVariants(productVariantRepository.findByProductId(product.getId()));
        product.setMediaItems(productMediaRepository.findByProductIdOrderBySortOrderAsc(product.getId()));
    }
}
