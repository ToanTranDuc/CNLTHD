package com.CNLTHD.Product_Service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
// @OpenAPIDefinition(
// info = @Info(
// title = "Fashion – Product Service API",
// version = "1.0",
// description = "Manages Products, Categories, and Variants for the Fashion
// Microservices system",
// contact = @Contact(name = "CNLTHD Team")
// )
// )
@EnableFeignClients(basePackages = "com.CNLTHD.Product_Service.external.client")
public class ProductServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductServiceApplication.class, args);
    }
}
