package com.CNLTHD.Product_Service.entity.enums;

/**
 * Standard fashion sizing for ProductVariants.
 */
public enum Size {
    XS("Extra Small"),
    S("Small"),
    M("Medium"),
    L("Large"),
    XL("Extra Large"),
    XXL("Double Extra Large"),
    XXXL("Triple Extra Large"),
    ONE_SIZE("One Size Fits All");

    private final String displayName;

    Size(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
