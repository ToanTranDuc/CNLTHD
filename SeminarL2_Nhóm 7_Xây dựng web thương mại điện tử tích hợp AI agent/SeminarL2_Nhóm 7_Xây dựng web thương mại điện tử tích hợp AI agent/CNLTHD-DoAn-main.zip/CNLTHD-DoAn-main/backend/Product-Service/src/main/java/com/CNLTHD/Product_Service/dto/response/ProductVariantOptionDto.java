package com.CNLTHD.Product_Service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductVariantOptionDto {
    private String id;
    private String size;
    private String sizeDisplayName;
    private String color;
    private String colorDisplayName;
    private String colorHex;
    private BigDecimal price;
    private String sku;
    private Boolean inStock;
}
