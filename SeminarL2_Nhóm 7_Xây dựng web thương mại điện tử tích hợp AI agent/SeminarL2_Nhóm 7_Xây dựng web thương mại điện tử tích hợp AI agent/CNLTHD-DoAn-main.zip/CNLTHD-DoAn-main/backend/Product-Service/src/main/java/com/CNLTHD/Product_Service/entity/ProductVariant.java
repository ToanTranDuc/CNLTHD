package com.CNLTHD.Product_Service.entity;

import com.CNLTHD.Product_Service.entity.enums.Color;
import com.CNLTHD.Product_Service.entity.enums.Size;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * A specific Size + Color combination of a Product (a SKU).
 * Stock levels for each variant are tracked by the Inventory Service — not here.
 */
@Entity
@Table(
    name = "product_variants",
    uniqueConstraints = @UniqueConstraint(name = "uq_variant_sku", columnNames = "sku_code")
)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductVariant extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Enumerated(EnumType.STRING)
    @Column(name = "size", nullable = false, length = 20)
    private Size size;

    @Enumerated(EnumType.STRING)
    @Column(name = "color", nullable = false, length = 30)
    private Color color;

    /** Variant-level price override; if null the parent Product's basePrice applies. */
    @Column(name = "price", precision = 12, scale = 2)
    private BigDecimal price;

    /**
     * Stock Keeping Unit – unique identifier used by the Inventory Service.
     * Recommended format: BRAND-PRODUCT-SIZE-COLOR (e.g. "NIKE-AF1-M-WHITE")
     */
    @Column(name = "sku_code", nullable = false, unique = true, length = 100)
    private String sku;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProductVariant)) return false;
        ProductVariant that = (ProductVariant) o;
        return Objects.equals(id, that.id);
    }
    @Override
    public int hashCode() { return Objects.hashCode(id); }
    @Override
    public String toString() {
        return "ProductVariant{id='" + id + "', sku='" + sku + "'}";
    }
}
