package com.CNLTHD.Product_Service.service;

import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantResponseDto;

import java.util.List;

public interface ProductVariantService {

    ProductVariantResponseDto create(ProductVariantRequestDto dto);

    ProductVariantResponseDto findById(String id);

    List<ProductVariantResponseDto> findByProduct(String productId);

    ProductVariantResponseDto update(String id, ProductVariantRequestDto dto);

    void delete(String id);
}
