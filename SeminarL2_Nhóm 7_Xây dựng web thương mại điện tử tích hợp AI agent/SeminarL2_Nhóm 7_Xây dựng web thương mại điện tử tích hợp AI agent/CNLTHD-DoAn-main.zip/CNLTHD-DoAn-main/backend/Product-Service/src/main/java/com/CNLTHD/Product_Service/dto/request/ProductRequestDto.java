package com.CNLTHD.Product_Service.dto.request;

import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.entity.enums.GenderType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductRequestDto {

    @NotBlank(message = "Product name is required")
    private String name;
    private String description;
    private String brand;
    private String country;

    @NotNull(message = "Base price is required")

    @Positive(message = "Base price must be a positive number")
    private BigDecimal basePrice;

    @NotBlank(message = "Category ID is required")
    private String categoryId;
    private EntityStatus status;
    private GenderType gender;

    /** List of image URLs to attach to this product (order = display order). */
    private List<String> imageUrls;
}
