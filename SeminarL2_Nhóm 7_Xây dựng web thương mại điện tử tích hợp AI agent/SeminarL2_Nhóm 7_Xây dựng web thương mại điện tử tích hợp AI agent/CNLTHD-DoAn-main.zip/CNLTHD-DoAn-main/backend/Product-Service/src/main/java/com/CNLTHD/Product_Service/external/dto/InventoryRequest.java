package com.CNLTHD.Product_Service.external.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InventoryRequest {
    private String productName;
    private String skuCode;
    private int quantity;
}
