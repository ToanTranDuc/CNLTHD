package com.CNLTHD.Product_Service.mapper;

import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.response.CategoryResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface CategoryMapper {

    @Mapping(target = "parentId", source = "parent.id")
    @Mapping(target = "parentName", source = "parent.name")
    CategoryResponseDto toResponseDto(Category category);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "parent", ignore = true)
    @Mapping(target = "children", ignore = true)
    @Mapping(target = "slug", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "status", defaultExpression = "java(com.CNLTHD.Product_Service.entity.enums.EntityStatus.ACTIVE)")
    Category toEntity(CategoryRequestDto dto);

    /**
     * Partial update: only non-null DTO fields overwrite the existing entity.
     * ID, relationships, and audit fields are never touched.
     */
    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "parent", ignore = true)
    @Mapping(target = "children", ignore = true)
    @Mapping(target = "slug", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateEntityFromDto(CategoryRequestDto dto, @MappingTarget Category category);
}
