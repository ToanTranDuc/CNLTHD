package com.CNLTHD.Product_Service.entity;

import com.CNLTHD.Product_Service.entity.enums.MediaType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

/**
 * An image or video asset associated with a Product.
 * Items are ordered by sortOrder (ascending). The item with the lowest sortOrder is the primary/thumbnail.
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "product_media")
public class ProductMedia extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    @Column(name = "url", nullable = false, length = 1000)
    private String url;

    @Enumerated(EnumType.STRING)
    @Column(name = "media_type", nullable = false, length = 10)
    private MediaType mediaType;

    @Column(name = "alt_text", length = 255)
    private String altText;

    /** Display order; lowest value appears first. */
    @Column(name = "sort_order", nullable = false)
    private Integer sortOrder = 0;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProductMedia)) return false;
        ProductMedia that = (ProductMedia) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() { return Objects.hashCode(id); }

    @Override
    public String toString() {
        return "ProductMedia{id='" + id + "', url='" + url + "', mediaType=" + mediaType + "}";
    }
}
