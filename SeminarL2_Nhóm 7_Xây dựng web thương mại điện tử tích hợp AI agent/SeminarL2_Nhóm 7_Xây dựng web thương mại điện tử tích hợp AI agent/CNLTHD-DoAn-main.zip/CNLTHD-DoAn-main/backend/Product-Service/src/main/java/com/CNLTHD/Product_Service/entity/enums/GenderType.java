package com.CNLTHD.Product_Service.entity.enums;

public enum GenderType {
    MEN,
    WOMEN,
    UNISEX
}
