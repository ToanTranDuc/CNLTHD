package com.CNLTHD.Product_Service.service;

import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.response.CategoryResponseDto;

import java.util.List;

public interface CategoryService {

    CategoryResponseDto create(CategoryRequestDto dto);

    CategoryResponseDto findById(String id);

    List<CategoryResponseDto> findAll();

    /** Returns only top-level categories (parent == null). */
    List<CategoryResponseDto> findRootCategories();

    /** Returns direct children of the given parent id. */
    List<CategoryResponseDto> findChildren(String parentId);

    CategoryResponseDto update(String id, CategoryRequestDto dto);

    void delete(String id);
}
