package com.CNLTHD.Product_Service.entity.enums;

/**
 * Media type for ProductMedia entities.
 */
public enum MediaType {
    IMAGE,
    VIDEO
}
