package com.CNLTHD.Product_Service.repository;

import com.CNLTHD.Product_Service.entity.Product;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Extends both {@link JpaRepository} and {@link JpaSpecificationExecutor} to support
 * dynamic search queries via the Specification pattern.
 *
 * <p>Future: migrate plain method queries to Specifications for complex filter combinations.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, String>,
        JpaSpecificationExecutor<Product> {

    @Query("SELECT p FROM Product p JOIN FETCH p.category WHERE p.id = :id")
    Optional<Product> findByIdWithCategory(@Param("id") String id);

    List<Product> findByCategoryId(String categoryId);

    List<Product> findByStatus(EntityStatus status);

    List<Product> findByBrandIgnoreCase(String brand);

    Optional<Product> findBySlug(String slug);

    boolean existsBySlug(String slug);

    /** Eager-fetches category to avoid N+1 on list endpoints. */
    @Query("SELECT p FROM Product p JOIN FETCH p.category WHERE p.status = :status")
    List<Product> findActiveWithCategory(@Param("status") EntityStatus status);
}
