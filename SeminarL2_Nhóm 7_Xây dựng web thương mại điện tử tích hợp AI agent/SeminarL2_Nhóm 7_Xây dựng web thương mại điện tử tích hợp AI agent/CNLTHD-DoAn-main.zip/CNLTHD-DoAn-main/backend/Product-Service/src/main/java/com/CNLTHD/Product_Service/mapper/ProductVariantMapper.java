package com.CNLTHD.Product_Service.mapper;

import com.CNLTHD.Product_Service.dto.request.ProductVariantRequestDto;
import com.CNLTHD.Product_Service.dto.response.ProductVariantResponseDto;
import com.CNLTHD.Product_Service.entity.ProductVariant;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface ProductVariantMapper {

    @Mapping(target = "productId", source = "product.id")
    @Mapping(target = "productName", source = "product.name")
    @Mapping(target = "quantity", ignore = true)
    ProductVariantResponseDto toResponseDto(ProductVariant variant);

    @BeanMapping(ignoreUnmappedSourceProperties = { "quantity" })
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "product", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "status", defaultExpression = "java(com.CNLTHD.Product_Service.entity.enums.EntityStatus.ACTIVE)")
    ProductVariant toEntity(ProductVariantRequestDto dto);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE, ignoreUnmappedSourceProperties = {
            "quantity" })
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "product", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    void updateEntityFromDto(ProductVariantRequestDto dto, @MappingTarget ProductVariant variant);
}
