package com.CNLTHD.Product_Service.external.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryResponse {
    private Long id;
    private String productName;
    private String skuCode;
    private Integer quantity;
}
