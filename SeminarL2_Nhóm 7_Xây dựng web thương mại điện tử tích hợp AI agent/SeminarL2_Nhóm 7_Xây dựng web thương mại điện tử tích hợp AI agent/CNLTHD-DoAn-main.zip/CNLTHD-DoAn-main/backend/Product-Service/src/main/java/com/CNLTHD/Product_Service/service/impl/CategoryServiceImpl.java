package com.CNLTHD.Product_Service.service.impl;

import com.CNLTHD.Product_Service.dto.request.CategoryRequestDto;
import com.CNLTHD.Product_Service.dto.response.CategoryResponseDto;
import com.CNLTHD.Product_Service.entity.Category;
import com.CNLTHD.Product_Service.entity.enums.EntityStatus;
import com.CNLTHD.Product_Service.exception.BusinessException;
import com.CNLTHD.Product_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Product_Service.mapper.CategoryMapper;
import com.CNLTHD.Product_Service.repository.CategoryRepository;
import com.CNLTHD.Product_Service.service.CategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class CategoryServiceImpl implements CategoryService {

    private static final Logger log = LoggerFactory.getLogger(CategoryServiceImpl.class);

    private final CategoryRepository categoryRepository;
    private final CategoryMapper categoryMapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, CategoryMapper categoryMapper) {
        this.categoryRepository = categoryRepository;
        this.categoryMapper = categoryMapper;
    }

    @Override
    @Transactional
    public CategoryResponseDto create(CategoryRequestDto dto) {
        log.info("Creating category: {}", dto.getName());

        Category category = categoryMapper.toEntity(dto);
        category.setStatus(Optional.ofNullable(dto.getStatus()).orElse(EntityStatus.ACTIVE));
        category.setSlug(generateSlug(dto.getName()));

        if (categoryRepository.existsBySlug(category.getSlug())) {
            throw new BusinessException("Category", "A category with the name '" + dto.getName() + "' already exists");
        }

        if (dto.getParentId() != null) {
            Category parent = categoryRepository.findById(dto.getParentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getParentId()));
            category.setParent(parent);
        }

        Category saved = categoryRepository.save(category);
        log.info("Category created with id: {}", saved.getId());
        return categoryMapper.toResponseDto(saved);
    }

    @Override
    public CategoryResponseDto findById(String id) {
        return categoryRepository.findById(id)
                .map(categoryMapper::toResponseDto)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));
    }

    @Override
    public List<CategoryResponseDto> findAll() {
        return categoryRepository.findAll().stream()
                .map(categoryMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<CategoryResponseDto> findRootCategories() {
        return categoryRepository.findByParentIsNull().stream()
                .map(categoryMapper::toResponseDto)
                .toList();
    }

    @Override
    public List<CategoryResponseDto> findChildren(String parentId) {
        // Validate parent exists first
        if (!categoryRepository.existsById(parentId)) {
            throw new ResourceNotFoundException("Category", "id", parentId);
        }
        return categoryRepository.findByParentId(parentId).stream()
                .map(categoryMapper::toResponseDto)
                .toList();
    }

    @Override
    @Transactional
    public CategoryResponseDto update(String id, CategoryRequestDto dto) {
        log.info("Updating category id: {}", id);

        Category existing = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));

        // If name changed, regenerate slug and check uniqueness
        if (!existing.getName().equalsIgnoreCase(dto.getName())) {
            String newSlug = generateSlug(dto.getName());
            if (categoryRepository.existsBySlug(newSlug)) {
                throw new BusinessException("Category", "A category with the name '" + dto.getName() + "' already exists");
            }
            existing.setSlug(newSlug);
        }

        categoryMapper.updateEntityFromDto(dto, existing);

        if (dto.getParentId() != null) {
            if (dto.getParentId().equals(id)) {
                throw new BusinessException("Category", "A category cannot be its own parent");
            }
            Category parent = categoryRepository.findById(dto.getParentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", dto.getParentId()));
            existing.setParent(parent);
        } else {
            existing.setParent(null);
        }

        return categoryMapper.toResponseDto(categoryRepository.save(existing));
    }

    @Override
    @Transactional
    public void delete(String id) {
        log.info("Soft-deleting category id: {}", id);
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));

        // Soft delete by setting status to INACTIVE
        category.setStatus(EntityStatus.INACTIVE);
        categoryRepository.save(category);
    }

    // ───────────────────────────── Helpers ─────────────────────────────── //

    private String generateSlug(String name) {
        return name.toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .trim()
                .replaceAll("\\s+", "-");
    }
}
