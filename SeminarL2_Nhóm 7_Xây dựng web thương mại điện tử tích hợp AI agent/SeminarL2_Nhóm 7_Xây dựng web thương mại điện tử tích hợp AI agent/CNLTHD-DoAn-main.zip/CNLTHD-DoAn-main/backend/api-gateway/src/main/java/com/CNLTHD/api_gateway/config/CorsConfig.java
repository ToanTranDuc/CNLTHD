package com.CNLTHD.api_gateway.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Configuration
public class CorsConfig {

    private static final List<String> ALLOWED_ORIGINS = Arrays.asList(
            "http://localhost:3000",
            "http://localhost:3001"
    );

    @Bean
    public FilterRegistrationBean<OncePerRequestFilter> corsFilter() {
        FilterRegistrationBean<OncePerRequestFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain)
                    throws ServletException, IOException {

                String origin = request.getHeader("Origin");

                if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
                    applyCorsHeaders(response, origin);
                    response.setStatus(HttpServletResponse.SC_OK);
                    return;
                }

                // Set CORS headers on original response BEFORE chain runs
                applyCorsHeaders(response, origin);

                // Wrap response so downstream services cannot overwrite CORS headers
                HttpServletResponseWrapper wrapper = new HttpServletResponseWrapper(response) {
                    @Override
                    public void setHeader(String name, String value) {
                        if (!isCorsHeader(name)) {
                            super.setHeader(name, value);
                        }
                    }

                    @Override
                    public void addHeader(String name, String value) {
                        if (!isCorsHeader(name)) {
                            super.addHeader(name, value);
                        }
                    }

                    private boolean isCorsHeader(String name) {
                        return name != null && name.toLowerCase().startsWith("access-control-");
                    }
                };

                chain.doFilter(request, wrapper);
            }
        });
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        bean.addUrlPatterns("/*");
        return bean;
    }

    private void applyCorsHeaders(HttpServletResponse response, String origin) {
        if (origin != null && ALLOWED_ORIGINS.contains(origin)) {
            response.setHeader("Access-Control-Allow-Origin", origin);
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,PATCH");
            response.setHeader("Access-Control-Allow-Headers", "*");
            response.setHeader("Access-Control-Max-Age", "3600");
        }
    }
}
