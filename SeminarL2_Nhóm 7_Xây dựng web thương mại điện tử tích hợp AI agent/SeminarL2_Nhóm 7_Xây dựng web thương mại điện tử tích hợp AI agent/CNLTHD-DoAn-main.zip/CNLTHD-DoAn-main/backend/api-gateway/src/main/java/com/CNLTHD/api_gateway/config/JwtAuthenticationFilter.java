package com.CNLTHD.api_gateway.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * JWT Authentication Filter for API Gateway
 *
 * TEMPORARILY DISABLED FOR TESTING - All requests are allowed to pass through
 * TODO: Enable JWT validation after implementing authentication service
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    // Tiêm khóa bí mật từ application.yml vào đây
    @Value("${jwt.secret:mySecretKeyForJWTTokenGenerationAndValidation12345}")
    private String jwtSecret;

    // TEMPORARY: Set to true to disable JWT check for testing
    @Value("${jwt.validation.enabled:false}")
    private boolean jwtValidationEnabled;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // TEMPORARY: Skip JWT validation if disabled (for testing)
        if (!jwtValidationEnabled) {
            filterChain.doFilter(request, response);
            return;
        }

        // Bỏ qua xác thực cho các endpoint công khai (ví dụ: login, actuator)
        String uri = request.getRequestURI();
        if (uri.contains("/api/auth") || uri.contains("/actuator")) {
            filterChain.doFilter(request, response);
            return;
        }

        // Kiểm tra Header xem có chứa JWT Token không
        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"Unauthorized\", \"message\": \"Missing or invalid JWT token\"}");
            return;
        }

        // TODO: Implement JWT validation logic here
        String token = authHeader.substring(7);
        // validateToken(token, jwtSecret);

        // Nếu hợp lệ, cho phép Request đi qua Gateway để tới Microservices
        filterChain.doFilter(request, response);
    }
}