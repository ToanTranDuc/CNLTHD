# 🚀 Hướng dẫn Test API Gateway với Postman

## 📋 Mục lục
1. [Chuẩn bị](#chuẩn-bị)
2. [Kiểm tra Services](#kiểm-tra-services)
3. [Test Category APIs](#test-category-apis)
4. [Test Product APIs](#test-product-apis)
5. [Test Product Variant APIs](#test-product-variant-apis)
6. [Test Inventory Stock APIs](#test-inventory-stock-apis)
7. [Test Inventory Log APIs](#test-inventory-log-apis)
8. [Troubleshooting](#troubleshooting)

---

## 🔧 Chuẩn bị

### 1. Khởi động các services theo thứ tự:
```bash
# 1. Eureka Service (port 8761)
cd backend/eureka_service
mvnw spring-boot:run

# 2. Product Service (port 8082)
cd backend/Product-Service
mvnw spring-boot:run

# 3. Inventory Service (port 8083)
cd backend/Inventory-Service
mvnw spring-boot:run

# 4. API Gateway (port 8080)
cd backend/api-gateway
mvnw spring-boot:run
```

### 2. Kiểm tra Eureka Dashboard
- Mở browser: `http://localhost:8761`
- Đảm bảo thấy 3 services: `API-GATEWAY`, `PRODUCT-SERVICE`, `INVENTORY-SERVICE`

### 3. URL Base cho tất cả requests
**⚠️ QUAN TRỌNG**: Tất cả requests phải đi qua API Gateway
```
Base URL: http://localhost:8080
```

**KHÔNG test trực tiếp vào service** (port 8082, 8083) nữa!

---

## ✅ Kiểm tra Services

### Test 1: Kiểm tra API Gateway hoạt động
- **Method**: `GET`
- **URL**: `http://localhost:8080/actuator/health`
- **Expected**: Status 200
```json
{
  "status": "UP"
}
```

---

## 📁 Test Category APIs

### 1. Tạo Root Categories (CREATE)

#### Request 1.1: Tạo category "Thời trang Nam"
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/categories`
- **Headers**: 
  ```
  Content-Type: application/json
  ```
- **Body** (raw JSON):
```json
{
  "name": "Thời trang Nam",
  "description": "Sản phẩm thời trang dành cho nam giới",
  "imageUrl": "https://example.com/men-fashion.jpg",
  "status": "ACTIVE"
}
```
- **Expected**: Status 201
- **Lưu lại**: `categoryId` của "Thời trang Nam" (ví dụ: `cat-001`)

#### Request 1.2: Tạo category "Thời trang Nữ"
```json
{
  "name": "Thời trang Nữ",
  "description": "Sản phẩm thời trang dành cho nữ giới",
  "imageUrl": "https://example.com/women-fashion.jpg",
  "status": "ACTIVE"
}
```
- **Lưu lại**: `categoryId` của "Thời trang Nữ" (ví dụ: `cat-002`)

### 2. Tạo Sub-Categories

#### Request 2.1: Tạo sub-category "Áo Nam" (con của "Thời trang Nam")
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/categories`
- **Body**:
```json
{
  "name": "Áo Nam",
  "description": "Các loại áo dành cho nam",
  "parentId": "cat-001",
  "status": "ACTIVE"
}
```
**⚠️ Thay `cat-001` bằng ID thực tế của "Thời trang Nam"**

#### Request 2.2: Tạo sub-category "Quần Nam"
```json
{
  "name": "Quần Nam",
  "description": "Các loại quần dành cho nam",
  "parentId": "cat-001",
  "status": "ACTIVE"
}
```

### 3. Lấy tất cả Categories (READ)
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/categories`
- **Expected**: Danh sách tất cả categories

### 4. Lấy Root Categories
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/categories/roots`
- **Expected**: Chỉ trả về "Thời trang Nam" và "Thời trang Nữ"

### 5. Lấy Category theo ID
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/categories/{id}`
- **Example**: `http://localhost:8080/api/v1/categories/cat-001`

### 6. Lấy Children của một Category
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/categories/{id}/children`
- **Example**: `http://localhost:8080/api/v1/categories/cat-001/children`
- **Expected**: Trả về "Áo Nam", "Quần Nam"

### 7. Update Category
- **Method**: `PUT`
- **URL**: `http://localhost:8080/api/v1/categories/{id}`
- **Body**:
```json
{
  "name": "Thời trang Nam - Updated",
  "description": "Mô tả đã được cập nhật",
  "status": "ACTIVE"
}
```

### 8. Soft Delete Category
- **Method**: `DELETE`
- **URL**: `http://localhost:8080/api/v1/categories/{id}`
- **Expected**: Status 200, category status chuyển thành INACTIVE

---

## 👕 Test Product APIs

### 1. Tạo Products (CREATE)

#### Request 1.1: Tạo sản phẩm "Áo Polo Nam"
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/products`
- **Headers**: 
  ```
  Content-Type: application/json
  ```
- **Body**:
```json
{
  "name": "Áo Polo Nam Cao Cấp",
  "description": "Áo polo nam chất liệu cotton 100%",
  "brand": "POLO CLASSIC",
  "categoryId": "cat-001",
  "basePrice": 299000,
  "imageUrls": [
    "https://example.com/polo-1.jpg",
    "https://example.com/polo-2.jpg"
  ],
  "status": "ACTIVE"
}
```
**⚠️ Thay `cat-001` bằng categoryId thực tế**
- **Lưu lại**: `productId` (ví dụ: `prod-001`)

#### Request 1.2: Tạo thêm sản phẩm "Quần Jeans"
```json
{
  "name": "Quần Jeans Slim Fit",
  "description": "Quần jeans dáng slim fit, co giãn tốt",
  "brand": "LEVI'S",
  "categoryId": "cat-001",
  "basePrice": 599000,
  "imageUrls": [
    "https://example.com/jeans-1.jpg"
  ],
  "status": "ACTIVE"
}
```
- **Lưu lại**: `productId` (ví dụ: `prod-002`)

### 2. Lấy tất cả Products (READ)
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products`

### 3. Lấy Product theo ID
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products/{id}`
- **Example**: `http://localhost:8080/api/v1/products/prod-001`

### 4. Lấy Products theo Category
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products/category/{categoryId}`
- **Example**: `http://localhost:8080/api/v1/products/category/cat-001`

### 5. Lấy Products theo Brand
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products/brand/{brand}`
- **Example**: `http://localhost:8080/api/v1/products/brand/POLO CLASSIC`

### 6. Update Product
- **Method**: `PUT`
- **URL**: `http://localhost:8080/api/v1/products/{id}`
- **Body**:
```json
{
  "name": "Áo Polo Nam Cao Cấp - Sale",
  "description": "Áo polo nam chất liệu cotton 100%",
  "brand": "POLO CLASSIC",
  "categoryId": "cat-001",
  "basePrice": 249000,
  "status": "ACTIVE"
}
```

### 7. Delete Product
- **Method**: `DELETE`
- **URL**: `http://localhost:8080/api/v1/products/{id}`

---

## 🎨 Test Product Variant APIs

### 1. Tạo Product Variants (CREATE)

#### Request 1.1: Tạo variant "Áo Polo - Size M - Màu Đỏ"
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/products/variants`
- **Body**:
```json
{
  "productId": "prod-001",
  "skuCode": "POLO-M-RED",
  "size": "M",
  "color": "ĐỎ",
  "additionalPrice": 0,
  "imageUrls": [
    "https://example.com/polo-red-m.jpg"
  ],
  "status": "ACTIVE"
}
```
**⚠️ Thay `prod-001` bằng productId thực tế**
- **Lưu lại**: `variantId` và `skuCode` (ví dụ: `var-001` và `POLO-M-RED`)

#### Request 1.2: Tạo variant "Áo Polo - Size L - Màu Xanh"
```json
{
  "productId": "prod-001",
  "skuCode": "POLO-L-BLUE",
  "size": "L",
  "color": "XANH",
  "additionalPrice": 20000,
  "imageUrls": [
    "https://example.com/polo-blue-l.jpg"
  ],
  "status": "ACTIVE"
}
```

#### Request 1.3: Tạo variant "Quần Jeans - Size 30 - Màu Đen"
```json
{
  "productId": "prod-002",
  "skuCode": "JEANS-30-BLACK",
  "size": "30",
  "color": "ĐEN",
  "additionalPrice": 0,
  "status": "ACTIVE"
}
```

### 2. Lấy tất cả Variants của một Product
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products/{productId}/variants`
- **Example**: `http://localhost:8080/api/v1/products/prod-001/variants`

### 3. Lấy Variant theo ID
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/products/variants/{id}`
- **Example**: `http://localhost:8080/api/v1/products/variants/var-001`

### 4. Update Variant
- **Method**: `PUT`
- **URL**: `http://localhost:8080/api/v1/products/variants/{id}`
- **Body**:
```json
{
  "productId": "prod-001",
  "skuCode": "POLO-M-RED",
  "size": "M",
  "color": "ĐỎ",
  "additionalPrice": 10000,
  "status": "ACTIVE"
}
```

### 5. Delete Variant
- **Method**: `DELETE`
- **URL**: `http://localhost:8080/api/v1/products/variants/{id}`

---

## 📦 Test Inventory Stock APIs

### 1. Tạo Stock cho SKU (CREATE)

#### Request 1.1: Tạo stock cho "POLO-M-RED"
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/stocks`
- **Headers**: 
  ```
  Content-Type: application/json
  ```
- **Body**:
```json
{
  "skuCode": "POLO-M-RED",
  "productName": "Áo Polo Nam - M - Đỏ",
  "quantity": 100
}
```
**⚠️ `skuCode` phải trùng với SKU của variant đã tạo**

#### Request 1.2: Tạo stock cho "POLO-L-BLUE"
```json
{
  "skuCode": "POLO-L-BLUE",
  "productName": "Áo Polo Nam - L - Xanh",
  "quantity": 50
}
```

#### Request 1.3: Tạo stock cho "JEANS-30-BLACK"
```json
{
  "skuCode": "JEANS-30-BLACK",
  "productName": "Quần Jeans - 30 - Đen",
  "quantity": 75
}
```

### 2. Lấy tất cả Stock entries (READ)
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/stocks`

### 3. Lấy Stock theo SKU Code
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/stocks/{skuCode}`
- **Example**: `http://localhost:8080/api/v1/stocks/POLO-M-RED`

### 4. Thêm Stock (IN - Nhập hàng)
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/stocks/{skuCode}/add`
- **Example URL**: `http://localhost:8080/api/v1/stocks/POLO-M-RED/add`
- **Body**:
```json
{
  "quantity": 50,
  "note": "Nhập hàng từ nhà cung cấp A"
}
```
**Expected**: Quantity tăng từ 100 lên 150

### 5. Trừ Stock (OUT - Xuất hàng)
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/stocks/{skuCode}/deduct`
- **Example URL**: `http://localhost:8080/api/v1/stocks/POLO-M-RED/deduct`
- **Body**:
```json
{
  "quantity": 10,
  "note": "Bán hàng cho khách hàng #001"
}
```
**Expected**: Quantity giảm từ 150 xuống 140

### 6. Điều chỉnh Stock (ADJUSTMENT - Kiểm kê)
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/stocks/{skuCode}/adjust`
- **Example URL**: `http://localhost:8080/api/v1/stocks/POLO-M-RED/adjust`
- **Body**:
```json
{
  "quantity": -5,
  "note": "Hàng lỗi sau kiểm kê"
}
```
**Note**: Quantity có thể âm (giảm) hoặc dương (tăng)

### 7. Test Insufficient Stock (Lỗi khi hết hàng)
- **Method**: `POST`
- **URL**: `http://localhost:8080/api/v1/stocks/POLO-M-RED/deduct`
- **Body**:
```json
{
  "quantity": 99999,
  "note": "Test lỗi"
}
```
**Expected**: Status 422 (Unprocessable Entity) với message "Insufficient stock"

---

## 📊 Test Inventory Log APIs

### 1. Lấy tất cả Inventory Logs
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/inventory-logs`
- **Expected**: Danh sách tất cả các log entries từ các thao tác IN/OUT/ADJUSTMENT

### 2. Lấy Logs theo SKU Code
- **Method**: `GET`
- **URL**: `http://localhost:8080/api/v1/inventory-logs/{skuCode}`
- **Example**: `http://localhost:8080/api/v1/inventory-logs/POLO-M-RED`
- **Expected**: Danh sách logs của SKU đó (sắp xếp theo thời gian mới nhất)

---

## 🧪 Test Flow hoàn chỉnh (End-to-End)

### Scenario: Tạo một sản phẩm hoàn chỉnh và quản lý tồn kho

```
1. POST /api/v1/categories              → Tạo category "Áo Khoác"
2. POST /api/v1/products                → Tạo product "Áo Khoác Bomber"
3. POST /api/v1/products/variants       → Tạo variant "Size M - Đen" (SKU: BOMBER-M-BLACK)
4. POST /api/v1/products/variants       → Tạo variant "Size L - Đen" (SKU: BOMBER-L-BLACK)
5. POST /api/v1/stocks                  → Tạo stock cho BOMBER-M-BLACK (qty: 100)
6. POST /api/v1/stocks                  → Tạo stock cho BOMBER-L-BLACK (qty: 80)
7. POST /api/v1/stocks/BOMBER-M-BLACK/deduct  → Bán 5 cái (qty: 95)
8. POST /api/v1/stocks/BOMBER-M-BLACK/add     → Nhập thêm 50 cái (qty: 145)
9. GET  /api/v1/inventory-logs/BOMBER-M-BLACK → Xem lịch sử xuất nhập
10. GET /api/v1/products                → Kiểm tra danh sách products
```

---

## ❌ Troubleshooting

### Lỗi 503 Service Unavailable
**Nguyên nhân**: Service chưa register với Eureka
**Giải pháp**: 
1. Kiểm tra Eureka Dashboard: `http://localhost:8761`
2. Đảm bảo tất cả services đã xuất hiện (đợi 30s)
3. Restart API Gateway

### Lỗi 404 Not Found
**Nguyên nhân**: Route không khớp
**Giải pháp**: 
1. Kiểm tra URL có đúng format không
2. Đảm bảo có `/api/v1/` trong path
3. Kiểm tra method (GET/POST/PUT/DELETE)

### CORS Error (khi test từ frontend)
**Nguyên nhân**: CORS config chưa đúng
**Giải pháp**: 
- API Gateway đã config CORS cho `localhost:*`
- Nếu dùng IP khác, thêm vào `allowedOriginPatterns` trong `application.yml`

### Lỗi 400 Bad Request
**Nguyên nhân**: Request body không hợp lệ
**Giải pháp**: 
1. Kiểm tra JSON syntax
2. Đảm bảo có header `Content-Type: application/json`
3. Kiểm tra required fields

### Connection Refused
**Nguyên nhân**: Service chưa chạy
**Giải pháp**: 
1. Kiểm tra service đã start chưa
2. Kiểm tra port có bị chiếm không
3. Xem logs của service

---

## 📝 Notes quan trọng

1. **⚠️ LUÔN test qua API Gateway** (port 8080), KHÔNG test trực tiếp vào service
2. **Lưu lại IDs**: Sau mỗi CREATE request, lưu lại ID để dùng cho các request tiếp theo
3. **SKU Code phải duy nhất**: Mỗi variant cần SKU code riêng biệt
4. **Thứ tự quan trọng**: Category → Product → Variant → Stock
5. **Soft Delete**: DELETE chỉ set status = INACTIVE, không xóa vật lý

---

## 🎯 Checklist Test hoàn chỉnh

- [ ] API Gateway health check
- [ ] Eureka có 3 services
- [ ] Tạo được Category
- [ ] Tạo được Product
- [ ] Tạo được Variant
- [ ] Tạo được Stock
- [ ] Add stock thành công
- [ ] Deduct stock thành công
- [ ] Xem được Inventory Logs
- [ ] Update thành công
- [ ] Delete (soft) thành công
- [ ] Test lỗi (404, 400, 422)

---

## 🚀 Tips cho Postman

### 1. Tạo Environment Variables
```
gateway_url = http://localhost:8080
category_id = {{lưu từ response}}
product_id = {{lưu từ response}}
variant_id = {{lưu từ response}}
sku_code = {{lưu từ response}}
```

### 2. Tạo Collection
- Organize theo service: Categories, Products, Variants, Stocks, Logs
- Sắp xếp theo thứ tự test

### 3. Sử dụng Tests Script
Sau mỗi POST request, tự động lưu ID:
```javascript
pm.test("Status 201", function () {
    pm.response.to.have.status(201);
});

var jsonData = pm.response.json();
pm.environment.set("product_id", jsonData.data.id);
```

---

**✅ Hoàn thành! Bây giờ bạn có thể test toàn bộ hệ thống qua API Gateway.**

