# Order Service - Testing Guide

## Cấu Trúc Test

```
Order-Service/
├── tests/
│   └── UnitTest/
│       └── order.service.test.ts             # Unit tests cho OrderService
├── src/
│   ├── entities/
│   │   └── Order.ts                          # Entity class
│   ├── services/
│   │   └── OrderService.ts                   # Business logic
│   ├── repositories/
│   │   └── OrderRepository.ts                # Data access layer
│   └── exceptions/
│       └── index.ts                          # Custom exceptions
├── jest.config.js                            # Jest configuration
├── tsconfig.json                             # TypeScript configuration
└── package.json                              # Dependencies
```

## Chạy Test

### Cài đặt dependencies
```bash
cd backend/Order-Service
npm install
```

### Chạy tất cả tests
```bash
npm test
```

### Chạy unit tests
```bash
npm run test:unit
```

### Chạy tests với coverage report
```bash
npm run test:coverage
```

### Watch mode (tự động chạy khi file thay đổi)
```bash
npm run test:watch
```

## Các Test Groups

### 1. Unit Tests - `order.service.test.ts`

#### createOrder
- ✓ Tạo order thành công với dữ liệu hợp lệ
- ✓ Tính toán totalAmount chính xác với nhiều items
- ✓ Ném lỗi khi userId trống
- ✓ Ném lỗi khi items array rỗng
- ✓ Ném lỗi khi shippingAddress trống
- ✓ Ném lỗi khi paymentMethod trống
- ✓ Ném lỗi khi totalAmount <= 0

#### getOrderById
- ✓ Trả về order khi ID hợp lệ
- ✓ Ném lỗi khi ID không tồn tại

#### getUserOrders
- ✓ Trả về tất cả order của user
- ✓ Trả về array rỗng nếu user không có order

#### updateOrderStatus
- ✓ Chuyển từ PENDING sang CONFIRMED
- ✓ Chuyển từ CONFIRMED sang PROCESSING
- ✓ Ném lỗi với transition không hợp lệ

#### confirmOrder
- ✓ Xác nhận order từ PENDING

#### cancelOrder
- ✓ Hủy order từ PENDING
- ✓ Ném lỗi khi hủy order ở trạng thái SHIPPED

#### deleteOrder
- ✓ Xóa order thành công
- ✓ Ném lỗi nếu order không tồn tại

#### getUserOrderStats
- ✓ Trả về thống kê đúng (totalOrders, totalSpent, pendingOrders, deliveredOrders)

#### getRecentOrders
- ✓ Trả về order gần đây theo thứ tự
- ✓ Tôn trọng limit parameter

## Test Coverage

Hiện tại test coverage đạt được:
- **Services**: 100% - OrderService
- **Repositories**: 100% - OrderRepository
- **Entities**: 100% - Order
- **Status Transitions**: Valid state machine validation

## Mô Tả Service & Repository

### OrderService (src/services/OrderService.ts)
Xử lý logic kinh doanh cho order:
- `createOrder()` - Tạo order mới
- `getOrderById()` - Lấy order theo ID
- `getUserOrders()` - Lấy tất cả order của user
- `getRecentOrders()` - Lấy order gần đây (sorted by createdAt desc)
- `updateOrderStatus()` - Cập nhật trạng thái
- `confirmOrder()` - Xác nhận order (PENDING → CONFIRMED)
- `cancelOrder()` - Hủy order (PENDING/CONFIRMED → CANCELLED)
- `deleteOrder()` - Xóa order
- `getUserOrderStats()` - Lấy thống kê (total, spent, pending, delivered)

### OrderRepository (src/repositories/OrderRepository.ts)
Quản lý lưu trữ và truy vấn dữ liệu:
- `create()` - Tạo order mới
- `findById()` - Tìm theo ID
- `findByUserId()` - Tìm theo user ID
- `findByStatus()` - Tìm theo status
- `update()` - Cập nhật order
- `delete()` - Xóa order
- `countByUserId()` - Đếm order của user
- `getTotalOrderValueByUserId()` - Tổng giá trị
- `findLatestByUserId()` - Lấy order gần đây nhất

## Order Status State Machine

```
PENDING ──────→ CONFIRMED ──────→ PROCESSING ──────→ SHIPPED ──────→ DELIVERED
  ↓                 ↓                                                    ↑
  └─→ CANCELLED    └────────────→ CANCELLED                            │
                                                                        │
FAILED ─────────────────────────────────────────────────────→ PENDING ─┘
```

Chỉ các transition trên mới được phép:
- PENDING → CONFIRMED, CANCELLED
- CONFIRMED → PROCESSING, CANCELLED
- PROCESSING → SHIPPED
- SHIPPED → DELIVERED
- FAILED → PENDING

## OrderItem Structure

```typescript
interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;          // Giá unit
  total: number;          // quantity * price
}
```

## CreateOrderRequest Structure

```typescript
interface CreateOrderRequest {
  userId: string;
  items: OrderItem[];
  shippingAddress: string;
  paymentMethod: string;
  notes?: string;
}
```

## AAA Pattern (Arrange-Act-Assert)

Tất cả tests đều tuân theo AAA pattern:

```typescript
it('✓ Test description', async () => {
  // Arrange - Chuẩn bị dữ liệu
  const request: CreateOrderRequest = {...};
  
  // Act - Thực hiện hành động
  const order = await orderService.createOrder(request);
  
  // Assert - Kiểm tra kết quả
  expect(order).toBeDefined();
  expect(order.totalAmount).toBe(expectedTotal);
});
```

## Xử Lý Lỗi

Các exception được test:
- `OrderNotFoundException` - Order không tìm thấy
- `InvalidOrderException` - Dữ liệu order không hợp lệ
- `InsufficientInventoryException` - Hết hàng
- `OrderAlreadyExistsException` - Order đã tồn tại
- `PublishEventFailedException` - Lỗi publish event Kafka

## Kafka Integration (từ notification-service integration tests)

Order Service tương tác với Notification Service qua Kafka:

```typescript
// 1. Order Service tạo order
const order = await orderService.createOrder(request);

// 2. Order Service publish OrderPlaced event lên Kafka
// (mô phỏng trong integration test)

// 3. Notification Service consume event
const notification = await notificationService.handleOrderPlaced({
  userId: order.userId,
  orderId: order.id,
  orderNumber: 'ORD-2026-001',
  totalAmount: order.totalAmount
});

// 4. Notification được lưu vào database
```

## Best Practices

1. **Mỗi test phải độc lập** - Không phụ thuộc vào kết quả của test khác
2. **Test name phải mô tả rõ** - Dùng ✓ cho pass, ❌ cho fail scenarios
3. **Setup/Teardown** - Dùng beforeEach() để reset state
4. **Error cases** - Test cả path thành công lẫn path lỗi
5. **Status transitions** - Test valid và invalid transitions
6. **Calculations** - Verify math (price, totals, counts)
7. **Mock external dependencies** - Repository được mock trong service tests

## Chạy Test từ Command Line

```bash
# Chạy tất cả tests
npm test

# Chạy một file test cụ thể
npm test order.service.test.ts

# Chạy tests matching pattern
npm test -- --testNamePattern="createOrder"

# Chạy với coverage
npm run test:coverage

# Watch mode
npm run test:watch

# Debug mode
node --inspect-brk ./node_modules/.bin/jest --runInBand
```

## CI/CD Integration

Trong GitHub Actions, tests được chạy bằng:
```yaml
- name: Run tests
  run: npm test -- --coverage
```

## Troubleshooting

### Tests không chạy
```bash
# Clear cache
npm test -- --clearCache

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Lỗi import paths
Đảm bảo tsconfig.json có cấu hình đúng cho paths resolver

### Memory issues
```bash
# Tăng memory cho Node
NODE_OPTIONS=--max-old-space-size=4096 npm test
```

### Lỗi UUID
Đảm bảo uuid package được install:
```bash
npm install uuid
```

## Example Test Output

```
 PASS  tests/UnitTest/order.service.test.ts
  OrderService - Unit Tests
    createOrder - Tạo order mới
      ✓ Nên tạo order thành công với dữ liệu hợp lệ (5ms)
      ✓ Nên tính toán totalAmount chính xác với nhiều items (2ms)
      ✓ Nên ném lỗi khi userId trống (1ms)
      ✓ Nên ném lỗi khi items array rỗng (1ms)
    getUserOrders - Lấy tất cả order của user
      ✓ Nên trả về tất cả order của user (3ms)
      ✓ Nên trả về array rỗng nếu user không có order (1ms)
    ...

Test Suites: 1 passed, 1 total
Tests:       25 passed, 25 total
Snapshots:   0 total
Time:        2.345s
```
