/**
 * Unit Test cho OrderService
 * 
 * Kiểm thử các chức năng chính của OrderService:
 * - Tạo order
 * - Lấy order
 * - Cập nhật trạng thái order
 * - Xác nhận / Hủy order
 * - Lấy thống kê order
 */

import { OrderService, CreateOrderRequest } from '../../src/services/OrderService';
import { OrderRepository } from '../../src/repositories/OrderRepository';
import { OrderStatus, OrderItem } from '../../src/entities/Order';
import {
  OrderNotFoundException,
  InvalidOrderException
} from '../../src/exceptions';

describe('OrderService - Unit Tests', () => {
  let orderService: OrderService;
  let orderRepository: OrderRepository;

  // Setup trước mỗi test
  beforeEach(() => {
    orderRepository = new OrderRepository();
    orderService = new OrderService(orderRepository);
  });

  // ====== TEST GROUP 1: createOrder ======
  describe('createOrder - Tạo order mới', () => {
    
    it('✓ Nên tạo order thành công với dữ liệu hợp lệ', async () => {
      // Arrange
      const items: OrderItem[] = [
        {
          productId: 'prod-1',
          productName: 'Áo phông',
          quantity: 2,
          price: 150000,
          total: 300000
        }
      ];
      
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items,
        shippingAddress: '123 Main St',
        paymentMethod: 'CREDIT_CARD',
        notes: 'Gift order'
      };

      // Act
      const result = await orderService.createOrder(request);

      // Assert
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
      expect(result.userId).toBe('user-123');
      expect(result.items).toHaveLength(1);
      expect(result.totalAmount).toBe(300000);
      expect(result.status).toBe(OrderStatus.PENDING);
      expect(result.shippingAddress).toBe('123 Main St');
      expect(result.paymentMethod).toBe('CREDIT_CARD');
      expect(result.notes).toBe('Gift order');
    });

    it('✓ Nên tính toán totalAmount chính xác với nhiều items', async () => {
      // Arrange
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item 1', quantity: 2, price: 100000, total: 200000 },
        { productId: 'p2', productName: 'Item 2', quantity: 1, price: 500000, total: 500000 }
      ];
      
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items,
        shippingAddress: '123 Main St',
        paymentMethod: 'BANK_TRANSFER'
      };

      // Act
      const result = await orderService.createOrder(request);

      // Assert
      expect(result.totalAmount).toBe(700000);
    });

    it('✓ Nên ném lỗi khi userId trống', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: '',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };

      // Act & Assert
      await expect(orderService.createOrder(request)).rejects.toThrow(InvalidOrderException);
    });

    it('✓ Nên ném lỗi khi items array rỗng', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };

      // Act & Assert
      await expect(orderService.createOrder(request)).rejects.toThrow(InvalidOrderException);
    });

    it('✓ Nên ném lỗi khi shippingAddress trống', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: '',
        paymentMethod: 'CARD'
      };

      // Act & Assert
      await expect(orderService.createOrder(request)).rejects.toThrow(InvalidOrderException);
    });

    it('✓ Nên ném lỗi khi paymentMethod trống', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: ''
      };

      // Act & Assert
      await expect(orderService.createOrder(request)).rejects.toThrow(InvalidOrderException);
    });

    it('✓ Nên ném lỗi khi totalAmount <= 0', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 0, price: 0, total: 0 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };

      // Act & Assert
      await expect(orderService.createOrder(request)).rejects.toThrow(InvalidOrderException);
    });
  });

  // ====== TEST GROUP 2: getOrderById ======
  describe('getOrderById - Lấy order theo ID', () => {
    
    it('✓ Nên trả về order khi ID hợp lệ', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const created = await orderService.createOrder(request);

      // Act
      const result = await orderService.getOrderById(created.id);

      // Assert
      expect(result).toBeDefined();
      expect(result.id).toBe(created.id);
      expect(result.userId).toBe('user-123');
    });

    it('✓ Nên ném lỗi khi ID không tồn tại', async () => {
      // Act & Assert
      await expect(
        orderService.getOrderById('non-existent-id')
      ).rejects.toThrow(OrderNotFoundException);
    });
  });

  // ====== TEST GROUP 3: getUserOrders ======
  describe('getUserOrders - Lấy tất cả order của user', () => {
    
    it('✓ Nên trả về tất cả order của user', async () => {
      // Arrange
      const userId = 'user-123';
      const items = [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }];
      
      await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr1',
        paymentMethod: 'CARD'
      });
      await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr2',
        paymentMethod: 'CARD'
      });
      await orderService.createOrder({
        userId: 'user-456',
        items,
        shippingAddress: 'Addr3',
        paymentMethod: 'CARD'
      });

      // Act
      const result = await orderService.getUserOrders(userId);

      // Assert
      expect(result).toHaveLength(2);
      expect(result.every(o => o.userId === userId)).toBe(true);
    });

    it('✓ Nên trả về array rỗng nếu user không có order', async () => {
      // Act
      const result = await orderService.getUserOrders('new-user');

      // Assert
      expect(result).toEqual([]);
    });
  });

  // ====== TEST GROUP 4: updateOrderStatus ======
  describe('updateOrderStatus - Cập nhật trạng thái order', () => {
    
    it('✓ Nên chuyển từ PENDING sang CONFIRMED', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);

      // Act
      const result = await orderService.updateOrderStatus(order.id, OrderStatus.CONFIRMED);

      // Assert
      expect(result.status).toBe(OrderStatus.CONFIRMED);
    });

    it('✓ Nên chuyển từ CONFIRMED sang PROCESSING', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);
      await orderService.updateOrderStatus(order.id, OrderStatus.CONFIRMED);

      // Act
      const result = await orderService.updateOrderStatus(order.id, OrderStatus.PROCESSING);

      // Assert
      expect(result.status).toBe(OrderStatus.PROCESSING);
    });

    it('✓ Nên ném lỗi với transition không hợp lệ', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);

      // Act & Assert
      await expect(
        orderService.updateOrderStatus(order.id, OrderStatus.DELIVERED)
      ).rejects.toThrow(InvalidOrderException);
    });
  });

  // ====== TEST GROUP 5: confirmOrder ======
  describe('confirmOrder - Xác nhận order', () => {
    
    it('✓ Nên xác nhận order từ PENDING', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);

      // Act
      const result = await orderService.confirmOrder(order.id);

      // Assert
      expect(result.status).toBe(OrderStatus.CONFIRMED);
    });
  });

  // ====== TEST GROUP 6: cancelOrder ======
  describe('cancelOrder - Hủy order', () => {
    
    it('✓ Nên hủy order từ PENDING', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);

      // Act
      const result = await orderService.cancelOrder(order.id);

      // Assert
      expect(result.status).toBe(OrderStatus.CANCELLED);
    });

    it('✓ Nên ném lỗi khi hủy order ở trạng thái SHIPPED', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);
      await orderService.confirmOrder(order.id);
      await orderService.updateOrderStatus(order.id, OrderStatus.PROCESSING);
      await orderService.updateOrderStatus(order.id, OrderStatus.SHIPPED);

      // Act & Assert
      await expect(
        orderService.cancelOrder(order.id)
      ).rejects.toThrow(InvalidOrderException);
    });
  });

  // ====== TEST GROUP 7: deleteOrder ======
  describe('deleteOrder - Xóa order', () => {
    
    it('✓ Nên xóa order thành công', async () => {
      // Arrange
      const request: CreateOrderRequest = {
        userId: 'user-123',
        items: [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }],
        shippingAddress: 'Address',
        paymentMethod: 'CARD'
      };
      const order = await orderService.createOrder(request);

      // Act
      await orderService.deleteOrder(order.id);

      // Assert
      await expect(
        orderService.getOrderById(order.id)
      ).rejects.toThrow(OrderNotFoundException);
    });

    it('✓ Nên ném lỗi nếu order không tồn tại', async () => {
      // Act & Assert
      await expect(
        orderService.deleteOrder('non-existent-id')
      ).rejects.toThrow(OrderNotFoundException);
    });
  });

  // ====== TEST GROUP 8: getUserOrderStats ======
  describe('getUserOrderStats - Lấy thống kê order của user', () => {
    
    it('✓ Nên trả về thống kê đúng', async () => {
      // Arrange
      const userId = 'user-123';
      const items = [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }];
      
      const order1 = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });
      
      const order2 = await orderService.createOrder({
        userId,
        items: [{ productId: 'p2', productName: 'Item 2', quantity: 2, price: 250000, total: 500000 }],
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      await orderService.confirmOrder(order1.id);
      // Follow valid state transitions: PENDING -> CONFIRMED -> PROCESSING -> SHIPPED -> DELIVERED
      await orderService.confirmOrder(order2.id);
      await orderService.updateOrderStatus(order2.id, OrderStatus.PROCESSING);
      await orderService.updateOrderStatus(order2.id, OrderStatus.SHIPPED);
      await orderService.updateOrderStatus(order2.id, OrderStatus.DELIVERED);

      // Act
      const stats = await orderService.getUserOrderStats(userId);

      // Assert
      expect(stats.totalOrders).toBe(2);
      expect(stats.totalSpent).toBe(600000);
      expect(stats.pendingOrders).toBe(1); // order1 is CONFIRMED (pending)
      expect(stats.deliveredOrders).toBe(1);
    });
  });

  // ====== TEST GROUP 9: getRecentOrders ======
  describe('getRecentOrders - Lấy order gần đây', () => {
    
    it('✓ Nên trả về order gần đây theo thứ tự', async () => {
      // Arrange
      const userId = 'user-123';
      const items = [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }];
      
      const order1 = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });
      
      const order2 = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      // Act
      const result = await orderService.getRecentOrders(userId, 5);

      // Assert
      expect(result).toHaveLength(2);
      expect(result[0].id).toBe(order2.id); // Most recent first
      expect(result[1].id).toBe(order1.id);
    });

    it('✓ Nên tôn trọng limit parameter', async () => {
      // Arrange
      const userId = 'user-123';
      const items = [{ productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }];
      
      for (let i = 0; i < 5; i++) {
        await orderService.createOrder({
          userId,
          items,
          shippingAddress: 'Addr',
          paymentMethod: 'CARD'
        });
      }

      // Act
      const result = await orderService.getRecentOrders(userId, 3);

      // Assert
      expect(result).toHaveLength(3);
    });
  });
});
