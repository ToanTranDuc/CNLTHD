/**
 * OrderService
 * Xử lý logic kinh doanh cho Order
 */

import { Order, OrderStatus, OrderItem } from '../entities/Order';
import { OrderRepository } from '../repositories/OrderRepository';
import {
  OrderNotFoundException,
  InvalidOrderException,
  InsufficientInventoryException
} from '../exceptions';

export interface CreateOrderRequest {
  userId: string;
  items: OrderItem[];
  shippingAddress: string;
  paymentMethod: string;
  notes?: string;
}

export class OrderService {
  constructor(private orderRepository: OrderRepository) {}

  /**
   * Tạo order mới
   */
  async createOrder(request: CreateOrderRequest): Promise<Order> {
    // Validate input
    if (!request.userId || !request.items || request.items.length === 0) {
      throw new InvalidOrderException('Invalid order data: missing userId or items');
    }

    if (!request.shippingAddress || !request.paymentMethod) {
      throw new InvalidOrderException('Missing shipping address or payment method');
    }

    // Calculate total
    const totalAmount = request.items.reduce((sum, item) => sum + item.total, 0);

    if (totalAmount <= 0) {
      throw new InvalidOrderException('Order total must be greater than 0');
    }

    // Create order
    return await this.orderRepository.create({
      userId: request.userId,
      items: request.items,
      totalAmount,
      shippingAddress: request.shippingAddress,
      paymentMethod: request.paymentMethod,
      notes: request.notes,
      status: OrderStatus.PENDING
    });
  }

  /**
   * Lấy order theo ID
   */
  async getOrderById(id: string): Promise<Order> {
    const order = await this.orderRepository.findById(id);
    if (!order) {
      throw new OrderNotFoundException(`Order with ID ${id} not found`);
    }
    return order;
  }

  /**
   * Lấy tất cả order của user
   */
  async getUserOrders(userId: string): Promise<Order[]> {
    return await this.orderRepository.findByUserId(userId);
  }

  /**
   * Lấy order gần đây của user
   */
  async getRecentOrders(userId: string, limit: number = 5): Promise<Order[]> {
    return await this.orderRepository.findLatestByUserId(userId, limit);
  }

  /**
   * Cập nhật trạng thái order
   */
  async updateOrderStatus(id: string, status: OrderStatus): Promise<Order> {
    const order = await this.getOrderById(id);

    // Validate status transition
    const validTransitions: Record<OrderStatus, OrderStatus[]> = {
      [OrderStatus.PENDING]: [OrderStatus.CONFIRMED, OrderStatus.CANCELLED],
      [OrderStatus.CONFIRMED]: [OrderStatus.PROCESSING, OrderStatus.CANCELLED],
      [OrderStatus.PROCESSING]: [OrderStatus.SHIPPED],
      [OrderStatus.SHIPPED]: [OrderStatus.DELIVERED],
      [OrderStatus.DELIVERED]: [],
      [OrderStatus.CANCELLED]: [],
      [OrderStatus.FAILED]: [OrderStatus.PENDING]
    };

    if (!validTransitions[order.status]?.includes(status)) {
      throw new InvalidOrderException(
        `Cannot transition from ${order.status} to ${status}`
      );
    }

    return await this.orderRepository.update(id, { status });
  }

  /**
   * Xác nhận order
   */
  async confirmOrder(id: string): Promise<Order> {
    return await this.updateOrderStatus(id, OrderStatus.CONFIRMED);
  }

  /**
   * Hủy order
   */
  async cancelOrder(id: string): Promise<Order> {
    const order = await this.getOrderById(id);
    if (![OrderStatus.PENDING, OrderStatus.CONFIRMED].includes(order.status)) {
      throw new InvalidOrderException(`Cannot cancel order in ${order.status} status`);
    }
    return await this.updateOrderStatus(id, OrderStatus.CANCELLED);
  }

  /**
   * Xóa order
   */
  async deleteOrder(id: string): Promise<void> {
    await this.getOrderById(id); // Verify exists
    await this.orderRepository.delete(id);
  }

  /**
   * Lấy thống kê order của user
   */
  async getUserOrderStats(userId: string): Promise<{
    totalOrders: number;
    totalSpent: number;
    pendingOrders: number;
    deliveredOrders: number;
  }> {
    const orders = await this.orderRepository.findByUserId(userId);
    const totalSpent = orders.reduce((sum, o) => sum + o.totalAmount, 0);
    const pendingOrders = orders.filter(o => 
      [OrderStatus.PENDING, OrderStatus.CONFIRMED, OrderStatus.PROCESSING].includes(o.status)
    ).length;
    const deliveredOrders = orders.filter(o => o.status === OrderStatus.DELIVERED).length;

    return {
      totalOrders: orders.length,
      totalSpent,
      pendingOrders,
      deliveredOrders
    };
  }
}

export type OrderDto = Omit<Order, 'id' | 'createdAt' | 'updatedAt'>;
