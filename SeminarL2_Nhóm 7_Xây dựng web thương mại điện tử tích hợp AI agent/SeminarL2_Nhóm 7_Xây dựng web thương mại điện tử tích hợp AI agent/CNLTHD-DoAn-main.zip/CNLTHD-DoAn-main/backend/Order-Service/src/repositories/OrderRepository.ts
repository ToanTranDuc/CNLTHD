/**
 * OrderRepository
 * Quản lý lưu trữ và truy vấn dữ liệu Order
 */

import { Order, OrderStatus } from '../entities/Order';
import { v4 as uuidv4 } from 'uuid';

export class OrderRepository {
  private orders: Map<string, Order> = new Map();

  /**
   * Tạo order mới
   */
  async create(order: Partial<Order>): Promise<Order> {
    const id = uuidv4();
    const newOrder = new Order({
      ...order,
      id
    });
    this.orders.set(id, newOrder);
    return newOrder;
  }

  /**
   * Tìm order theo ID
   */
  async findById(id: string): Promise<Order | null> {
    return this.orders.get(id) || null;
  }

  /**
   * Lấy tất cả order của user
   */
  async findByUserId(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.userId === userId);
  }

  /**
   * Lấy order theo status
   */
  async findByStatus(status: OrderStatus): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.status === status);
  }

  /**
   * Cập nhật order
   */
  async update(id: string, data: Partial<Order>): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) {
      throw new Error('Order not found');
    }
    Object.assign(order, data, { updatedAt: new Date() });
    this.orders.set(id, order);
    return order;
  }

  /**
   * Xóa order
   */
  async delete(id: string): Promise<void> {
    this.orders.delete(id);
  }

  /**
   * Lấy tổng số order của user
   */
  async countByUserId(userId: string): Promise<number> {
    return Array.from(this.orders.values()).filter(o => o.userId === userId).length;
  }

  /**
   * Lấy tổng giá trị đơn hàng của user
   */
  async getTotalOrderValueByUserId(userId: string): Promise<number> {
    return Array.from(this.orders.values())
      .filter(o => o.userId === userId)
      .reduce((sum, o) => sum + o.totalAmount, 0);
  }

  /**
   * Lấy order gần đây nhất của user
   */
  async findLatestByUserId(userId: string, limit: number = 5): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(o => o.userId === userId)
      .sort((a, b) => {
        // Primary sort: by createdAt descending
        const timeDiff = b.createdAt.getTime() - a.createdAt.getTime();
        if (timeDiff !== 0) return timeDiff;
        // Secondary sort: by ID descending (for stability when timestamps are equal)
        return b.id.localeCompare(a.id);
      })
      .slice(0, limit);
  }
}
