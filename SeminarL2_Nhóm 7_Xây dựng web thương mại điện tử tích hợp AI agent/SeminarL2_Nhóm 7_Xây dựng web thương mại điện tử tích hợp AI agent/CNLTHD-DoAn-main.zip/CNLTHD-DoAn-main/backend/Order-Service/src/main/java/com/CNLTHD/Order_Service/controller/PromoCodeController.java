package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.dto.request.PromoCodeRequestDto;
import com.CNLTHD.Order_Service.dto.response.PromoApplyResponseDto;
import com.CNLTHD.Order_Service.dto.response.PromoCodeResponseDto;
import com.CNLTHD.Order_Service.service.PromoCodeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/promo-codes")
@Tag(name = "Promo Codes", description = "Discount code management & redemption")
public class PromoCodeController {

    private final PromoCodeService service;

    public PromoCodeController(PromoCodeService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "List all promo codes (admin) or only active (customer)")
    public ResponseEntity<ApiResponse<List<PromoCodeResponseDto>>> list(
            @RequestParam(defaultValue = "false") boolean activeOnly) {
        return ResponseEntity.ok(ApiResponse.success(service.list(activeOnly)));
    }

    @PostMapping
    @Operation(summary = "Create a new promo code (admin)")
    public ResponseEntity<ApiResponse<PromoCodeResponseDto>> create(@Valid @RequestBody PromoCodeRequestDto request) {
        return ResponseEntity.ok(ApiResponse.success(service.create(request), "Promo code created"));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a promo code (admin)")
    public ResponseEntity<ApiResponse<PromoCodeResponseDto>> update(
            @PathVariable String id,
            @Valid @RequestBody PromoCodeRequestDto request) {
        return ResponseEntity.ok(ApiResponse.success(service.update(id, request), "Promo code updated"));
    }

    @PatchMapping("/{id}/toggle")
    @Operation(summary = "Toggle active flag (admin)")
    public ResponseEntity<ApiResponse<PromoCodeResponseDto>> toggle(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(service.toggleActive(id)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a promo code (admin)")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable String id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Promo code deleted"));
    }

    @GetMapping("/validate")
    @Operation(summary = "Validate a code against a subtotal (customer)")
    public ResponseEntity<ApiResponse<PromoApplyResponseDto>> validate(
            @RequestParam String code,
            @RequestParam(required = false, defaultValue = "0") BigDecimal subtotal) {
        return ResponseEntity.ok(ApiResponse.success(service.validate(code, subtotal)));
    }
}
