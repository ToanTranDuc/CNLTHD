package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.Payment;
import com.CNLTHD.Order_Service.entity.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, String> {

    Optional<Payment> findByOrderId(String orderId);

    Optional<Payment> findByTransactionId(String transactionId);

    java.util.List<Payment> findByPaymentStatus(PaymentStatus paymentStatus);
}
