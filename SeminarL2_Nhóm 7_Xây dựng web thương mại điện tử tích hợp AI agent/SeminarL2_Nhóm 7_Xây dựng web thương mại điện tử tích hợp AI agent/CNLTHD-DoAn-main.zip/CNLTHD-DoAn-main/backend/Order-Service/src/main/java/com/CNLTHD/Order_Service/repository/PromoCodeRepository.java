package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.PromoCode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PromoCodeRepository extends JpaRepository<PromoCode, String> {

    Optional<PromoCode> findByCodeIgnoreCase(String code);

    List<PromoCode> findAllByOrderByCreatedAtDesc();

    List<PromoCode> findByActiveTrueOrderByCreatedAtDesc();

    boolean existsByCodeIgnoreCase(String code);
}
