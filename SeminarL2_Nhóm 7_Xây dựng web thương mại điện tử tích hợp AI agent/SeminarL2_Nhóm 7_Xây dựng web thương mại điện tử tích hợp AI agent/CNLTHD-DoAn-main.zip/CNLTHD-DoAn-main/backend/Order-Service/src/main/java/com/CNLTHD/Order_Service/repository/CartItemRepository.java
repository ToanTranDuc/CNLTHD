package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, String> {

    List<CartItem> findByCartId(String cartId);

    Optional<CartItem> findByCartIdAndVariantId(String cartId, String variantId);

    void deleteAllByCartId(String cartId);
}
