package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.dto.request.PlaceOrderRequestDto;
import com.CNLTHD.Order_Service.service.OrderPlacementService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Assignment-compliant endpoint: POST /api/order.
 */
@RestController
@RequestMapping("/api")
public class OrderPlacementController {

    private final OrderPlacementService orderPlacementService;

    public OrderPlacementController(OrderPlacementService orderPlacementService) {
        this.orderPlacementService = orderPlacementService;
    }

    @PostMapping("/order")
    public ResponseEntity<ApiResponse<Void>> placeOrder(@Valid @RequestBody PlaceOrderRequestDto request) {
        orderPlacementService.placeOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Order Placed"));
    }
}
