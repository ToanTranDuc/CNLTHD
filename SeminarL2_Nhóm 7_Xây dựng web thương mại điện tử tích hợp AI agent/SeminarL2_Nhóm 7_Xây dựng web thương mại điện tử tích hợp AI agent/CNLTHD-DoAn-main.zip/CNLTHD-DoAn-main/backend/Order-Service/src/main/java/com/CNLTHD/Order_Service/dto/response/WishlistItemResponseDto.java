package com.CNLTHD.Order_Service.dto.response;

import com.CNLTHD.Order_Service.entity.WishlistItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WishlistItemResponseDto {

    private String id;
    private String userId;
    private String productId;
    private String productName;
    private String imageUrl;
    private BigDecimal price;
    private String category;
    private LocalDateTime createdAt;

    public static WishlistItemResponseDto from(WishlistItem item) {
        return WishlistItemResponseDto.builder()
                .id(item.getId())
                .userId(item.getUserId())
                .productId(item.getProductId())
                .productName(item.getProductName())
                .imageUrl(item.getImageUrl())
                .price(item.getPrice())
                .category(item.getCategory())
                .createdAt(item.getCreatedAt())
                .build();
    }
}
