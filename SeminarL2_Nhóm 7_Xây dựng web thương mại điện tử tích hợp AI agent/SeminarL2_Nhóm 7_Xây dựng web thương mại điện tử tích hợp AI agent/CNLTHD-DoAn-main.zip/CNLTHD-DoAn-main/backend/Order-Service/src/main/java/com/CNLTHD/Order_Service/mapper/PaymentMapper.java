package com.CNLTHD.Order_Service.mapper;

import com.CNLTHD.Order_Service.dto.response.PaymentResponseDto;
import com.CNLTHD.Order_Service.entity.Payment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PaymentMapper {

    @Mapping(target = "orderId", source = "order.id")
    PaymentResponseDto toResponseDto(Payment payment);
}
