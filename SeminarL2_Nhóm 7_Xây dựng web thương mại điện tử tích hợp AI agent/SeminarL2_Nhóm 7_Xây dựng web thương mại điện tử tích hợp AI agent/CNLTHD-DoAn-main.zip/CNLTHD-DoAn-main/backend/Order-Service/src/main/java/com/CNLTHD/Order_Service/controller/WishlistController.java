package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.dto.request.WishlistItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.WishlistItemResponseDto;
import com.CNLTHD.Order_Service.service.WishlistService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/wishlist")
@Tag(name = "Wishlist", description = "Per-customer wishlist of products")
public class WishlistController {

    private final WishlistService wishlistService;

    public WishlistController(WishlistService wishlistService) {
        this.wishlistService = wishlistService;
    }

    @GetMapping
    @Operation(summary = "Get a user's wishlist")
    public ResponseEntity<ApiResponse<List<WishlistItemResponseDto>>> getWishlist(@RequestParam String userId) {
        return ResponseEntity.ok(ApiResponse.success(wishlistService.getWishlist(userId)));
    }

    @GetMapping("/count")
    @Operation(summary = "Count items in a user's wishlist")
    public ResponseEntity<ApiResponse<Map<String, Long>>> count(@RequestParam String userId) {
        return ResponseEntity.ok(ApiResponse.success(Map.of("count", wishlistService.countItems(userId))));
    }

    @PostMapping
    @Operation(summary = "Add a product to wishlist (idempotent — duplicate ignored)")
    public ResponseEntity<ApiResponse<WishlistItemResponseDto>> add(@Valid @RequestBody WishlistItemRequestDto request) {
        return ResponseEntity.ok(ApiResponse.success(wishlistService.addItem(request), "Product added to wishlist"));
    }

    @DeleteMapping("/{productId}")
    @Operation(summary = "Remove a product from wishlist")
    public ResponseEntity<ApiResponse<Void>> remove(@PathVariable String productId, @RequestParam String userId) {
        wishlistService.removeItem(userId, productId);
        return ResponseEntity.ok(ApiResponse.success(null, "Product removed from wishlist"));
    }

    @DeleteMapping
    @Operation(summary = "Clear an entire user's wishlist")
    public ResponseEntity<ApiResponse<Void>> clear(@RequestParam String userId) {
        wishlistService.clearWishlist(userId);
        return ResponseEntity.ok(ApiResponse.success(null, "Wishlist cleared"));
    }
}
