package com.CNLTHD.Order_Service.entity.enums;

/**
 * Lifecycle status for auditable entities.
 */
public enum EntityStatus {
    ACTIVE,
    INACTIVE
}
