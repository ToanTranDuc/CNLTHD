package com.CNLTHD.Order_Service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;

/**
 * Promotion / discount code created by admin. Customers redeem it at checkout.
 */
@Entity
@Table(
        name = "promo_codes",
        indexes = {
                @Index(name = "idx_promo_code", columnList = "code", unique = true),
                @Index(name = "idx_promo_active", columnList = "active")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PromoCode {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    /** Unique uppercase code customers enter (e.g. WELCOME10) */
    @Column(name = "code", nullable = false, unique = true, length = 50)
    private String code;

    @Column(name = "description", length = 255)
    private String description;

    /** Percentage off subtotal (0 = none). */
    @Column(name = "percent_off", nullable = false, precision = 5, scale = 2)
    private BigDecimal percentOff = BigDecimal.ZERO;

    /** Flat amount off (₫). 0 = none. */
    @Column(name = "amount_off", nullable = false, precision = 14, scale = 2)
    private BigDecimal amountOff = BigDecimal.ZERO;

    /** Cap on total discount per use (₫). 0 = uncapped. */
    @Column(name = "max_discount", nullable = false, precision = 14, scale = 2)
    private BigDecimal maxDiscount = BigDecimal.ZERO;

    /** Minimum subtotal to use the code (₫). */
    @Column(name = "min_subtotal", nullable = false, precision = 14, scale = 2)
    private BigDecimal minSubtotal = BigDecimal.ZERO;

    /** If true, grants free shipping. */
    @Column(name = "free_shipping", nullable = false)
    private Boolean freeShipping = false;

    /** Optional expiry timestamp. Null = no expiry. */
    @Column(name = "expires_at")
    private Instant expiresAt;

    /** Max total redemptions. 0 = unlimited. */
    @Column(name = "max_uses", nullable = false)
    private Integer maxUses = 0;

    /** Total times this code has been redeemed. */
    @Column(name = "used_count", nullable = false)
    private Integer usedCount = 0;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        updatedAt = createdAt;
        if (code != null) code = code.toUpperCase();
    }

    @PreUpdate
    void preUpdate() {
        updatedAt = LocalDateTime.now();
        if (code != null) code = code.toUpperCase();
    }
}
