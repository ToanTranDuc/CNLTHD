package com.CNLTHD.Order_Service.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Optional local listener used to verify notification messages in development.
 */
@Component
public class OrderNotificationListener {

    private static final Logger log = LoggerFactory.getLogger(OrderNotificationListener.class);

    @KafkaListener(
            topics = "${app.kafka.topic.notification}",
            groupId = "order-service-listener",
            autoStartup = "${app.kafka.listener.enabled:false}")
    public void onOrderPlaced(String payload) {
        log.info("Received notification topic message: {}", payload);
    }
}
