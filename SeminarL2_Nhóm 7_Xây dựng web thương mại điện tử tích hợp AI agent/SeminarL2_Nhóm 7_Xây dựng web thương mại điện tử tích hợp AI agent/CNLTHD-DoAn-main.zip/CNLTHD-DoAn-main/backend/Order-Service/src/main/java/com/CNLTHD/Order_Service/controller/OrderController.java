package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.common.AppConstants;
import com.CNLTHD.Order_Service.dto.request.CheckoutRequestDto;
import com.CNLTHD.Order_Service.dto.response.OrderResponseDto;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import com.CNLTHD.Order_Service.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(AppConstants.ORDERS_BASE)
@Tag(name = "Orders", description = "Order management")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/checkout")
    @Operation(summary = "Checkout – create order from cart")
    public ResponseEntity<ApiResponse<OrderResponseDto>> checkout(
            @Valid @RequestBody CheckoutRequestDto dto) {
        OrderResponseDto order = orderService.checkout(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(order, "Order placed successfully"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get order by ID")
    public ResponseEntity<ApiResponse<OrderResponseDto>> getById(
            @PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(orderService.findById(id)));
    }

    @GetMapping("/number/{orderNumber}")
    @Operation(summary = "Get order by order number")
    public ResponseEntity<ApiResponse<OrderResponseDto>> getByOrderNumber(
            @PathVariable String orderNumber) {
        return ResponseEntity.ok(ApiResponse.success(orderService.findByOrderNumber(orderNumber)));
    }

    @GetMapping("/customer/{customerId}")
    @Operation(summary = "Get all orders for a customer")
    public ResponseEntity<ApiResponse<List<OrderResponseDto>>> getByCustomer(
            @PathVariable String customerId) {
        return ResponseEntity.ok(ApiResponse.success(orderService.findByCustomerId(customerId)));
    }

    @GetMapping
    @Operation(summary = "Get all orders (admin)")
    public ResponseEntity<ApiResponse<List<OrderResponseDto>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(orderService.findAll()));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update order status")
    public ResponseEntity<ApiResponse<OrderResponseDto>> updateStatus(
            @PathVariable String id,
            @RequestParam OrderStatus status) {
        return ResponseEntity.ok(
                ApiResponse.success(orderService.updateOrderStatus(id, status),
                        "Order status updated"));
    }

    @PatchMapping("/{id}/cancel")
    @Operation(summary = "Cancel an order (optional reason)")
    public ResponseEntity<ApiResponse<OrderResponseDto>> cancel(
            @PathVariable String id,
            @RequestParam(required = false) String reason) {
        return ResponseEntity.ok(
                ApiResponse.success(orderService.cancelOrder(id, reason), "Order cancelled"));
    }
}
