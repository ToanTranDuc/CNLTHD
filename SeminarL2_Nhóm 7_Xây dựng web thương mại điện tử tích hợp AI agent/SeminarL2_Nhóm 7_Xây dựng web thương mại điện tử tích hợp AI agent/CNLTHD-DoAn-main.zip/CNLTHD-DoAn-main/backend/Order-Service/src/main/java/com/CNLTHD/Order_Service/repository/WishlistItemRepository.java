package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.WishlistItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WishlistItemRepository extends JpaRepository<WishlistItem, String> {

    List<WishlistItem> findByUserIdOrderByCreatedAtDesc(String userId);

    Optional<WishlistItem> findByUserIdAndProductId(String userId, String productId);

    long countByUserId(String userId);

    void deleteByUserIdAndProductId(String userId, String productId);

    void deleteByUserId(String userId);
}
