package com.CNLTHD.Order_Service.entity.enums;

/**
 * Order lifecycle statuses.
 */
public enum OrderStatus {
    PENDING,
    CONFIRMED,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    RETURNED
}
