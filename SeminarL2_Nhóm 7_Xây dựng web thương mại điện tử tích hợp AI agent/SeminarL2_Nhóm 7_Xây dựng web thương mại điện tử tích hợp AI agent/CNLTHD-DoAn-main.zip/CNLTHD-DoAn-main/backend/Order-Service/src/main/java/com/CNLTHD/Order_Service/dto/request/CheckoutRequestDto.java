package com.CNLTHD.Order_Service.dto.request;

import com.CNLTHD.Order_Service.entity.enums.PaymentMethod;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Request DTO to create an order from the customer's cart (checkout).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckoutRequestDto {

    @NotBlank(message = "Customer ID is required")
    private String customerId;

    @NotBlank(message = "Recipient email is required")
    private String recipientEmail;

    // ===== Shipping Address =====
    @NotBlank(message = "Recipient name is required")
    private String recipientName;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @NotBlank(message = "Address is required")
    private String addressLine;

    private String ward;
    private String district;
    private String city;
    private String note;

    // ===== Shipping & Discount =====
    private BigDecimal shippingFee;
    private BigDecimal discount;

    // ===== Payment =====
    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod;
}
