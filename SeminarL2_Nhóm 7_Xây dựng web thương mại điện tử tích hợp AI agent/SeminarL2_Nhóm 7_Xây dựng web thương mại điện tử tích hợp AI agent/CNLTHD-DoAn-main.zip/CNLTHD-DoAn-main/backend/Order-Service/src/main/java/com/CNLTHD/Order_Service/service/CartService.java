package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.AddToCartRequestDto;
import com.CNLTHD.Order_Service.dto.request.UpdateCartItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.CartResponseDto;

public interface CartService {

    /** Get or create cart for a customer */
    CartResponseDto getCartByCustomerId(String customerId);

    /** Add item to cart (if same variant exists, increase quantity) */
    CartResponseDto addItemToCart(AddToCartRequestDto dto);

    /** Update quantity of a specific cart item */
    CartResponseDto updateCartItem(String cartItemId, UpdateCartItemRequestDto dto);

    /** Remove a single item from cart */
    CartResponseDto removeCartItem(String customerId, String cartItemId);

    /** Clear all items in a customer's cart */
    void clearCart(String customerId);
}
