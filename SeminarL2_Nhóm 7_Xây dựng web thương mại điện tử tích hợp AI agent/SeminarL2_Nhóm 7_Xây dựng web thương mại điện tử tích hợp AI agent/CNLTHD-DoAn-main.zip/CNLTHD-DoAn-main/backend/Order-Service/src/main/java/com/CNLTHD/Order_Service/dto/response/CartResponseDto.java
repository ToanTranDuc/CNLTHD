package com.CNLTHD.Order_Service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartResponseDto {

    private String id;
    private String customerId;
    private List<CartItemResponseDto> items;
    private BigDecimal totalPrice;
    private int totalItems;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
