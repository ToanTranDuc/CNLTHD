package com.CNLTHD.Order_Service.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Provides the current auditor (user) for JPA Auditing fields (@CreatedBy).
 * Returns "system" during the development phase.
 * TODO: Replace with JWT principal extraction when Auth Service is integrated.
 */
@Component("auditAwareImpl")
public class AuditAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        return Optional.of("system");
    }
}
