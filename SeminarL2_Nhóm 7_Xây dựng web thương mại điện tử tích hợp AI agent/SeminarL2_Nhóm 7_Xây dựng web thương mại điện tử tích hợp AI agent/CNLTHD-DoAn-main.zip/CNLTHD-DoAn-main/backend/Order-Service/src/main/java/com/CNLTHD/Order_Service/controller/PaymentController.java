package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.common.AppConstants;
import com.CNLTHD.Order_Service.dto.request.PaymentRequestDto;
import com.CNLTHD.Order_Service.dto.response.PaymentResponseDto;
import com.CNLTHD.Order_Service.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(AppConstants.PAYMENTS_BASE)
@Tag(name = "Payments", description = "Payment management")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/order/{orderId}")
    @Operation(summary = "Get payment by order ID")
    public ResponseEntity<ApiResponse<PaymentResponseDto>> getByOrderId(
            @PathVariable String orderId) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getPaymentByOrderId(orderId)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get payment by ID")
    public ResponseEntity<ApiResponse<PaymentResponseDto>> getById(
            @PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.findById(id)));
    }

    @PutMapping("/status")
    @Operation(summary = "Update payment status (e.g. from payment gateway callback)")
    public ResponseEntity<ApiResponse<PaymentResponseDto>> updateStatus(
            @Valid @RequestBody PaymentRequestDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(paymentService.updatePaymentStatus(dto),
                        "Payment status updated"));
    }
}
