package com.CNLTHD.Order_Service.mapper;

import com.CNLTHD.Order_Service.dto.response.OrderItemResponseDto;
import com.CNLTHD.Order_Service.dto.response.OrderResponseDto;
import com.CNLTHD.Order_Service.entity.Order;
import com.CNLTHD.Order_Service.entity.OrderItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = {PaymentMapper.class})
public interface OrderMapper {

    @Mapping(target = "items", source = "items")
    @Mapping(target = "payment", source = "payment")
    OrderResponseDto toResponseDto(Order order);

    OrderItemResponseDto toItemResponseDto(OrderItem item);

    List<OrderResponseDto> toResponseDtoList(List<Order> orders);
}
