package com.CNLTHD.Order_Service.service;

public interface NotificationPublisher {
    void publishOrderPlaced(String orderNumber, String customerId, String recipientEmail);

    /** Generic publisher for any order lifecycle change (CANCELLED, CONFIRMED, SHIPPED, DELIVERED, RETURNED). */
    void publishOrderStatusChanged(String action, String orderNumber, String customerId, String recipientEmail);
}
