package com.CNLTHD.Order_Service.service;

import java.util.concurrent.CompletableFuture;

public interface InventoryClient {
    CompletableFuture<Boolean> hasStock(String skuCode, Integer requiredQuantity);
    void deductStock(String skuCode, Integer quantity, String referenceId);
    /** Restock when an order is cancelled — returns inventory units back to the warehouse. */
    void restockStock(String skuCode, Integer quantity, String referenceId);
}
