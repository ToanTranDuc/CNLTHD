package com.CNLTHD.Order_Service.common;

/**
 * Shared constants for API base paths.
 */
public final class AppConstants {

    private AppConstants() { /* utility class */ }

    public static final String API_VERSION = "/api/v1";

    public static final String CART_BASE     = API_VERSION + "/cart";
    public static final String ORDERS_BASE   = API_VERSION + "/orders";
    public static final String PAYMENTS_BASE = API_VERSION + "/payments";

    public static final String PATH_ID = "/{id}";
}
