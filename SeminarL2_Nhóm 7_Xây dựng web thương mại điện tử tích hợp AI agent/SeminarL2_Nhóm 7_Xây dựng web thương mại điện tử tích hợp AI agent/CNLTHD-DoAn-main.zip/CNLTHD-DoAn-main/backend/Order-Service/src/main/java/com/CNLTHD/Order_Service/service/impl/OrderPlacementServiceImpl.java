package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.OrderLineItemsDto;
import com.CNLTHD.Order_Service.dto.request.PlaceOrderRequestDto;
import com.CNLTHD.Order_Service.entity.Order;
import com.CNLTHD.Order_Service.entity.OrderItem;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import com.CNLTHD.Order_Service.exception.BusinessException;
import com.CNLTHD.Order_Service.repository.OrderRepository;
import com.CNLTHD.Order_Service.service.InventoryClient;
import com.CNLTHD.Order_Service.service.NotificationPublisher;
import com.CNLTHD.Order_Service.service.OrderPlacementService;
import com.CNLTHD.Order_Service.service.PromoCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Service
public class OrderPlacementServiceImpl implements OrderPlacementService {

    private static final Logger log = LoggerFactory.getLogger(OrderPlacementServiceImpl.class);

    private final OrderRepository orderRepository;
    private final InventoryClient inventoryClient;
    private final NotificationPublisher notificationPublisher;
    private final PromoCodeService promoCodeService;

    public OrderPlacementServiceImpl(OrderRepository orderRepository,
                                     InventoryClient inventoryClient,
                                     NotificationPublisher notificationPublisher,
                                     PromoCodeService promoCodeService) {
        this.orderRepository = orderRepository;
        this.inventoryClient = inventoryClient;
        this.notificationPublisher = notificationPublisher;
        this.promoCodeService = promoCodeService;
    }

    @Override
    @Transactional
    public void placeOrder(PlaceOrderRequestDto request) {
        for (OrderLineItemsDto item : request.getOrderLineItemsDtoList()) {
            boolean inStock = inventoryClient.hasStock(item.getSkuCode(), item.getQuantity()).join();
            if (!inStock) {
                throw new BusinessException("Order", "Product with SKU '" + item.getSkuCode() + "' is out of stock");
            }
        }

        Order order = new Order();
        order.setOrderNumber(generateOrderNumber());
        order.setCustomerId(defaultIfBlank(request.getCustomerId(), "guest"));
        order.setOrderStatus(OrderStatus.PENDING);

        BigDecimal subtotal = request.getOrderLineItemsDtoList().stream()
                .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal shippingFee = request.getShippingFee() != null ? request.getShippingFee() : BigDecimal.ZERO;
        BigDecimal discount = request.getDiscount() != null ? request.getDiscount() : BigDecimal.ZERO;
        // Clamp discount so it can't exceed subtotal
        if (discount.compareTo(subtotal) > 0) discount = subtotal;
        BigDecimal totalAmount = subtotal.subtract(discount).add(shippingFee);
        if (totalAmount.signum() < 0) totalAmount = BigDecimal.ZERO;

        order.setSubtotal(subtotal);
        order.setShippingFee(shippingFee);
        order.setDiscount(discount);
        order.setTotalAmount(totalAmount);
        // Stash promoCode in note so we can trace it back even though we don't have a dedicated column
        if (request.getPromoCode() != null && !request.getPromoCode().isBlank()) {
            String existing = request.getNote() == null ? "" : request.getNote() + " | ";
            request.setNote(existing + "promo=" + request.getPromoCode());
        }

        order.setRecipientName(defaultIfBlank(request.getRecipientName(), "System Customer"));
        order.setPhone(defaultIfBlank(request.getPhone(), "N/A"));
        order.setAddressLine(defaultIfBlank(request.getAddressLine(), "N/A"));
        order.setWard(request.getWard());
        order.setDistrict(request.getDistrict());
        order.setCity(request.getCity());
        order.setNote(request.getNote());

        for (OrderLineItemsDto dto : request.getOrderLineItemsDtoList()) {
            OrderItem item = new OrderItem();
            item.setProductId(dto.getSkuCode());
            item.setVariantId(dto.getSkuCode());
            item.setSkuCode(dto.getSkuCode());
            item.setProductName(dto.getProductName() != null && !dto.getProductName().isBlank()
                    ? dto.getProductName() : dto.getSkuCode());
            item.setImageUrl(dto.getImageUrl());
            item.setUnitPrice(dto.getPrice());
            item.setQuantity(dto.getQuantity());
            item.setLineTotal(dto.getPrice().multiply(BigDecimal.valueOf(dto.getQuantity())));
            order.addItem(item);
        }

        Order saved = orderRepository.save(order);
        log.info("Order {} placed successfully", saved.getOrderNumber());

        for (OrderLineItemsDto item : request.getOrderLineItemsDtoList()) {
            inventoryClient.deductStock(item.getSkuCode(), item.getQuantity(), saved.getOrderNumber());
        }

        // Record promo redemption (best-effort)
        if (request.getPromoCode() != null && !request.getPromoCode().isBlank()) {
            try {
                promoCodeService.recordRedemption(request.getPromoCode());
            } catch (Exception ex) {
                log.warn("Failed to record promo redemption for {}: {}", request.getPromoCode(), ex.getMessage());
            }
        }

        notificationPublisher.publishOrderPlaced(saved.getOrderNumber(), saved.getCustomerId(), request.getRecipientEmail());
    }

    private String defaultIfBlank(String value, String fallback) {
        if (value == null || value.isBlank()) {
            return fallback;
        }
        return value;
    }

    private String generateOrderNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String uniquePart = UUID.randomUUID().toString().substring(0, 5).toUpperCase();
        return "ORD-" + datePart + "-" + uniquePart;
    }
}
