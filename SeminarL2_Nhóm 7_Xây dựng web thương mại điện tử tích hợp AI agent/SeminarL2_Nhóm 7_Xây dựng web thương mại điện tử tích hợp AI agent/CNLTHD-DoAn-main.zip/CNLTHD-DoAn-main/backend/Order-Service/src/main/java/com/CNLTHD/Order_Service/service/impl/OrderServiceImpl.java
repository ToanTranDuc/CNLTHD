package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.CheckoutRequestDto;
import com.CNLTHD.Order_Service.dto.response.OrderResponseDto;
import com.CNLTHD.Order_Service.entity.*;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import com.CNLTHD.Order_Service.entity.enums.PaymentStatus;
import com.CNLTHD.Order_Service.exception.BusinessException;
import com.CNLTHD.Order_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Order_Service.mapper.OrderMapper;
import com.CNLTHD.Order_Service.repository.CartRepository;
import com.CNLTHD.Order_Service.repository.OrderRepository;
import com.CNLTHD.Order_Service.service.InventoryClient;
import com.CNLTHD.Order_Service.service.NotificationPublisher;
import com.CNLTHD.Order_Service.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional(readOnly = true)
public class OrderServiceImpl implements OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

    private final OrderRepository orderRepository;
    private final CartRepository cartRepository;
    private final OrderMapper orderMapper;
    private final NotificationPublisher notificationPublisher;
    private final InventoryClient inventoryClient;

    public OrderServiceImpl(OrderRepository orderRepository,
                            CartRepository cartRepository,
                            OrderMapper orderMapper,
                            NotificationPublisher notificationPublisher,
                            InventoryClient inventoryClient) {
        this.orderRepository = orderRepository;
        this.cartRepository = cartRepository;
        this.orderMapper = orderMapper;
        this.notificationPublisher = notificationPublisher;
        this.inventoryClient = inventoryClient;
    }

    @Override
    @Transactional
    public OrderResponseDto checkout(CheckoutRequestDto dto) {
        log.info("Processing checkout for customer: {}", dto.getCustomerId());

        // 1. Get customer's cart
        Cart cart = cartRepository.findByCustomerId(dto.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Cart", "customerId", dto.getCustomerId()));

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new BusinessException("Order", "Cannot checkout with an empty cart");
        }

        // 2. Calculate totals
        BigDecimal subtotal = cart.getItems().stream()
                .map(ci -> ci.getUnitPrice().multiply(BigDecimal.valueOf(ci.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal shippingFee = Optional.ofNullable(dto.getShippingFee()).orElse(BigDecimal.ZERO);
        BigDecimal discount = Optional.ofNullable(dto.getDiscount()).orElse(BigDecimal.ZERO);
        BigDecimal totalAmount = subtotal.add(shippingFee).subtract(discount);

        // 3. Create Order
        Order order = new Order();
        order.setOrderNumber(generateOrderNumber());
        order.setCustomerId(dto.getCustomerId());
        order.setOrderStatus(OrderStatus.PENDING);
        order.setSubtotal(subtotal);
        order.setShippingFee(shippingFee);
        order.setDiscount(discount);
        order.setTotalAmount(totalAmount);

        // Shipping address
        order.setRecipientName(dto.getRecipientName());
        order.setPhone(dto.getPhone());
        order.setAddressLine(dto.getAddressLine());
        order.setWard(dto.getWard());
        order.setDistrict(dto.getDistrict());
        order.setCity(dto.getCity());
        order.setNote(dto.getNote());

        // 4. Convert cart items → order items
        for (CartItem ci : cart.getItems()) {
            OrderItem oi = new OrderItem();
            oi.setProductId(ci.getProductId());
            oi.setVariantId(ci.getVariantId());
            oi.setSkuCode(ci.getSkuCode());
            oi.setProductName(ci.getProductName());
            oi.setSize(ci.getSize());
            oi.setColor(ci.getColor());
            oi.setUnitPrice(ci.getUnitPrice());
            oi.setQuantity(ci.getQuantity());
            oi.setLineTotal(ci.getUnitPrice().multiply(BigDecimal.valueOf(ci.getQuantity())));
            oi.setImageUrl(ci.getImageUrl());
            order.addItem(oi);
        }

        // 5. Create Payment record
        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(totalAmount);
        payment.setPaymentMethod(dto.getPaymentMethod());
        payment.setPaymentStatus(PaymentStatus.PENDING);
        order.setPayment(payment);

        // 6. Save order
        Order savedOrder = orderRepository.save(order);
        log.info("Order created: {} for customer: {}", savedOrder.getOrderNumber(), dto.getCustomerId());
        notificationPublisher.publishOrderPlaced(savedOrder.getOrderNumber(), savedOrder.getCustomerId(), dto.getRecipientEmail());

        // 7. Clear the cart after successful checkout
        cart.clearItems();
        cartRepository.save(cart);

        return orderMapper.toResponseDto(savedOrder);
    }

    @Override
    public OrderResponseDto findById(String orderId) {
        return orderRepository.findById(orderId)
                .map(orderMapper::toResponseDto)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
    }

    @Override
    public OrderResponseDto findByOrderNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber)
                .map(orderMapper::toResponseDto)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "orderNumber", orderNumber));
    }

    @Override
    public List<OrderResponseDto> findByCustomerId(String customerId) {
        return orderMapper.toResponseDtoList(
                orderRepository.findByCustomerIdOrderByCreatedAtDesc(customerId));
    }

    @Override
    public List<OrderResponseDto> findAll() {
        return orderMapper.toResponseDtoList(orderRepository.findAll());
    }

    @Override
    @Transactional
    public OrderResponseDto updateOrderStatus(String orderId, OrderStatus newStatus) {
        log.info("Updating order {} status to {}", orderId, newStatus);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        if (order.getOrderStatus() == OrderStatus.CANCELLED) {
            throw new BusinessException("Order", "Cannot update a cancelled order");
        }

        if (order.getOrderStatus() == OrderStatus.DELIVERED) {
            throw new BusinessException("Order", "Cannot update a delivered order");
        }

        OrderStatus previous = order.getOrderStatus();
        order.setOrderStatus(newStatus);

        // If order is confirmed and payment is COD, keep payment PENDING
        // If order is delivered and payment is COD, mark payment as COMPLETED
        if (newStatus == OrderStatus.DELIVERED && order.getPayment() != null
                && order.getPayment().getPaymentStatus() == PaymentStatus.PENDING) {
            order.getPayment().setPaymentStatus(PaymentStatus.COMPLETED);
        }

        Order saved = orderRepository.save(order);
        if (previous != newStatus) {
            notificationPublisher.publishOrderStatusChanged(newStatus.name(), saved.getOrderNumber(),
                    saved.getCustomerId(), null);
        }
        return orderMapper.toResponseDto(saved);
    }

    @Override
    @Transactional
    public OrderResponseDto cancelOrder(String orderId) {
        return cancelOrder(orderId, null);
    }

    @Override
    @Transactional
    public OrderResponseDto cancelOrder(String orderId, String reason) {
        log.info("Cancelling order: {} (reason: {})", orderId, reason);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        if (order.getOrderStatus() == OrderStatus.SHIPPED
                || order.getOrderStatus() == OrderStatus.DELIVERED) {
            throw new BusinessException("Order", "Cannot cancel an order that has been shipped or delivered");
        }

        order.setOrderStatus(OrderStatus.CANCELLED);
        if (reason != null && !reason.isBlank()) {
            order.setCancelReason(reason);
        }

        // Mark payment as refunded if it was completed
        if (order.getPayment() != null
                && order.getPayment().getPaymentStatus() == PaymentStatus.COMPLETED) {
            order.getPayment().setPaymentStatus(PaymentStatus.REFUNDED);
        } else if (order.getPayment() != null) {
            order.getPayment().setPaymentStatus(PaymentStatus.FAILED);
        }

        Order saved = orderRepository.save(order);

        // Restock inventory — return units back to warehouse
        for (OrderItem item : saved.getItems()) {
            try {
                inventoryClient.restockStock(item.getSkuCode(), item.getQuantity(), "CANCEL-" + saved.getOrderNumber());
            } catch (Exception ex) {
                log.warn("Failed to restock {} units of {}: {}", item.getQuantity(), item.getSkuCode(), ex.getMessage());
            }
        }

        notificationPublisher.publishOrderStatusChanged("CANCELLED", saved.getOrderNumber(),
                saved.getCustomerId(), null);
        return orderMapper.toResponseDto(saved);
    }

    // ───────────────────────── Helpers ───────────────────────── //

    private String generateOrderNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String uniquePart = UUID.randomUUID().toString().substring(0, 5).toUpperCase();
        return "ORD-" + datePart + "-" + uniquePart;
    }
}
