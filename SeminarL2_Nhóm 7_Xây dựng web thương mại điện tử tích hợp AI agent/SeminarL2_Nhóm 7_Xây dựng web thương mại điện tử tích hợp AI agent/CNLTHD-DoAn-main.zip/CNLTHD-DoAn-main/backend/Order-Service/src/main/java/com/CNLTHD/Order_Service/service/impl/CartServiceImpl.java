package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.AddToCartRequestDto;
import com.CNLTHD.Order_Service.dto.request.UpdateCartItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.CartResponseDto;
import com.CNLTHD.Order_Service.entity.Cart;
import com.CNLTHD.Order_Service.entity.CartItem;
import com.CNLTHD.Order_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Order_Service.mapper.CartMapper;
import com.CNLTHD.Order_Service.repository.CartItemRepository;
import com.CNLTHD.Order_Service.repository.CartRepository;
import com.CNLTHD.Order_Service.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class CartServiceImpl implements CartService {

    private static final Logger log = LoggerFactory.getLogger(CartServiceImpl.class);

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final CartMapper cartMapper;

    public CartServiceImpl(CartRepository cartRepository,
                           CartItemRepository cartItemRepository,
                           CartMapper cartMapper) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.cartMapper = cartMapper;
    }

    @Override
    public CartResponseDto getCartByCustomerId(String customerId) {
        Cart cart = getOrCreateCart(customerId);
        return cartMapper.toResponseDto(cart);
    }

    @Override
    @Transactional
    public CartResponseDto addItemToCart(AddToCartRequestDto dto) {
        log.info("Adding item to cart for customer: {}", dto.getCustomerId());

        Cart cart = getOrCreateCart(dto.getCustomerId());

        // Check if same variant already exists in cart
        Optional<CartItem> existingItem = cartItemRepository
                .findByCartIdAndVariantId(cart.getId(), dto.getVariantId());

        if (existingItem.isPresent()) {
            // Increase quantity
            CartItem item = existingItem.get();
            item.setQuantity(item.getQuantity() + dto.getQuantity());
            item.setUnitPrice(dto.getUnitPrice()); // update price to latest
            cartItemRepository.save(item);
            log.debug("Updated existing cart item quantity for variant: {}", dto.getVariantId());
        } else {
            // Add new item
            CartItem newItem = new CartItem();
            newItem.setProductId(dto.getProductId());
            newItem.setVariantId(dto.getVariantId());
            newItem.setSkuCode(dto.getSkuCode());
            newItem.setProductName(dto.getProductName());
            newItem.setSize(dto.getSize());
            newItem.setColor(dto.getColor());
            newItem.setUnitPrice(dto.getUnitPrice());
            newItem.setQuantity(dto.getQuantity());
            newItem.setImageUrl(dto.getImageUrl());
            cart.addItem(newItem);
            cartRepository.save(cart);
            log.debug("Added new cart item for variant: {}", dto.getVariantId());
        }

        // Refresh cart to get updated items
        Cart updatedCart = cartRepository.findByCustomerId(dto.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException("Cart", "customerId", dto.getCustomerId()));
        return cartMapper.toResponseDto(updatedCart);
    }

    @Override
    @Transactional
    public CartResponseDto updateCartItem(String cartItemId, UpdateCartItemRequestDto dto) {
        log.info("Updating cart item: {}", cartItemId);

        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("CartItem", "id", cartItemId));

        item.setQuantity(dto.getQuantity());
        cartItemRepository.save(item);

        Cart cart = item.getCart();
        return cartMapper.toResponseDto(cart);
    }

    @Override
    @Transactional
    public CartResponseDto removeCartItem(String customerId, String cartItemId) {
        log.info("Removing cart item: {} for customer: {}", cartItemId, customerId);

        Cart cart = cartRepository.findByCustomerId(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart", "customerId", customerId));

        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new ResourceNotFoundException("CartItem", "id", cartItemId));

        cart.removeItem(item);
        cartItemRepository.delete(item);

        return cartMapper.toResponseDto(cart);
    }

    @Override
    @Transactional
    public void clearCart(String customerId) {
        log.info("Clearing cart for customer: {}", customerId);

        Cart cart = cartRepository.findByCustomerId(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Cart", "customerId", customerId));

        cart.clearItems();
        cartRepository.save(cart);
    }

    // ───────────────────────── Helpers ───────────────────────── //

    @Transactional
    private Cart getOrCreateCart(String customerId) {
        return cartRepository.findByCustomerId(customerId)
                .orElseGet(() -> {
                    log.info("Creating new cart for customer: {}", customerId);
                    Cart newCart = new Cart();
                    newCart.setCustomerId(customerId);
                    return cartRepository.save(newCart);
                });
    }
}
