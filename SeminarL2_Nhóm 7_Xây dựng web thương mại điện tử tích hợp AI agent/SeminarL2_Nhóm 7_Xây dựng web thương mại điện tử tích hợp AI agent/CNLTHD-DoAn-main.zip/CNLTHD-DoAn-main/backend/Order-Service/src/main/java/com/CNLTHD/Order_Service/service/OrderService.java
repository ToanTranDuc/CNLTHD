package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.CheckoutRequestDto;
import com.CNLTHD.Order_Service.dto.response.OrderResponseDto;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;

import java.util.List;

public interface OrderService {

    /** Create order from customer's cart (checkout) */
    OrderResponseDto checkout(CheckoutRequestDto dto);

    /** Get order by ID */
    OrderResponseDto findById(String orderId);

    /** Get order by order number */
    OrderResponseDto findByOrderNumber(String orderNumber);

    /** Get all orders for a customer */
    List<OrderResponseDto> findByCustomerId(String customerId);

    /** Get all orders (admin) */
    List<OrderResponseDto> findAll();

    /** Update order status */
    OrderResponseDto updateOrderStatus(String orderId, OrderStatus newStatus);

    /** Cancel an order */
    OrderResponseDto cancelOrder(String orderId);

    /** Cancel an order with a reason recorded on the order entity. */
    OrderResponseDto cancelOrder(String orderId, String reason);
}
