package com.CNLTHD.Order_Service.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/** Result of validating a promo code against a given subtotal. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromoApplyResponseDto {

    private boolean valid;
    private String message;
    private String code;
    private String description;
    private BigDecimal discountAmount;
    private Boolean freeShipping;
}
