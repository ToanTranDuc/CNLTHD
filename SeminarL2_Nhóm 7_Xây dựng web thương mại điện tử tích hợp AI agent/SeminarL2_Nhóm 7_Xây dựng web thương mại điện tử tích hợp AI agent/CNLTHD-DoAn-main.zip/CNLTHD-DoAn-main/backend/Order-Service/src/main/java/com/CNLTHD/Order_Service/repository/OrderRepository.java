package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.Order;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, String> {

    Optional<Order> findByOrderNumber(String orderNumber);

    List<Order> findByCustomerIdOrderByCreatedAtDesc(String customerId);

    List<Order> findByCustomerIdAndOrderStatus(String customerId, OrderStatus orderStatus);

    List<Order> findByOrderStatus(OrderStatus orderStatus);
}
