package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.event.OrderPlacedEvent;
import com.CNLTHD.Order_Service.event.OrderStatusEvent;
import com.CNLTHD.Order_Service.service.NotificationPublisher;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class KafkaNotificationPublisher implements NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(KafkaNotificationPublisher.class);

    private final ObjectProvider<KafkaTemplate<String, String>> kafkaTemplateProvider;
    private final ObjectMapper objectMapper;

    @Value("${app.kafka.topic.notification}")
    private String notificationTopic;

    public KafkaNotificationPublisher(ObjectProvider<KafkaTemplate<String, String>> kafkaTemplateProvider,
                                      ObjectMapper objectMapper) {
        this.kafkaTemplateProvider = kafkaTemplateProvider;
        this.objectMapper = objectMapper;
    }

    @Override
    public void publishOrderPlaced(String orderNumber, String customerId, String recipientEmail) {
        KafkaTemplate<String, String> kafkaTemplate = kafkaTemplateProvider.getIfAvailable();
        if (kafkaTemplate == null) {
            log.warn("KafkaTemplate is not configured. Skip notification for order {}", orderNumber);
            return;
        }

        try {
            String payload = objectMapper.writeValueAsString(new OrderPlacedEvent(orderNumber, customerId, recipientEmail, Instant.now()));
            kafkaTemplate.send(notificationTopic, orderNumber, payload)
                    .whenComplete((result, ex) -> {
                        if (ex != null) {
                            log.warn("Failed to publish Kafka notification for order {}: {}", orderNumber, ex.getMessage());
                        } else {
                            log.info("Published order notification for {} to topic {}", orderNumber, notificationTopic);
                        }
                    });
        } catch (JsonProcessingException ex) {
            log.warn("Failed to serialize notification payload for order {}: {}", orderNumber, ex.getMessage());
        }
    }

    @Override
    public void publishOrderStatusChanged(String action, String orderNumber, String customerId, String recipientEmail) {
        KafkaTemplate<String, String> kafkaTemplate = kafkaTemplateProvider.getIfAvailable();
        if (kafkaTemplate == null) {
            log.warn("KafkaTemplate is not configured. Skip {} notification for order {}", action, orderNumber);
            return;
        }

        try {
            OrderStatusEvent event = new OrderStatusEvent(action, orderNumber, customerId, recipientEmail, Instant.now());
            String payload = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(notificationTopic, orderNumber, payload)
                    .whenComplete((result, ex) -> {
                        if (ex != null) {
                            log.warn("Failed to publish {} event for order {}: {}", action, orderNumber, ex.getMessage());
                        } else {
                            log.info("Published {} event for order {}", action, orderNumber);
                        }
                    });
        } catch (JsonProcessingException ex) {
            log.warn("Failed to serialize {} payload for order {}: {}", action, orderNumber, ex.getMessage());
        }
    }
}
