package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.PaymentRequestDto;
import com.CNLTHD.Order_Service.dto.response.PaymentResponseDto;

public interface PaymentService {

    /** Get payment by order ID */
    PaymentResponseDto getPaymentByOrderId(String orderId);

    /** Update payment status (e.g. from payment gateway callback) */
    PaymentResponseDto updatePaymentStatus(PaymentRequestDto dto);

    /** Get payment by ID */
    PaymentResponseDto findById(String paymentId);
}
