package com.CNLTHD.Order_Service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * A single line-item inside a Cart.
 * References product/variant from Product-Service via their IDs.
 */
@Entity
@Table(name = "cart_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cart_id", nullable = false)
    private Cart cart;

    /** Product ID from Product-Service */
    @Column(name = "product_id", nullable = false, length = 100)
    private String productId;

    /** Variant ID from Product-Service */
    @Column(name = "variant_id", nullable = false, length = 100)
    private String variantId;

    /** SKU code for inventory lookup */
    @Column(name = "sku_code", nullable = false, length = 100)
    private String skuCode;

    /** Product name snapshot at the time of adding to cart */
    @Column(name = "product_name", nullable = false, length = 255)
    private String productName;

    /** Size label (e.g. "M", "L") */
    @Column(name = "size", length = 20)
    private String size;

    /** Color label (e.g. "BLACK", "WHITE") */
    @Column(name = "color", length = 30)
    private String color;

    /** Unit price at the time of adding to cart */
    @Column(name = "unit_price", nullable = false, precision = 12, scale = 2)
    private BigDecimal unitPrice;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    /** Image URL snapshot */
    @Column(name = "image_url", length = 500)
    private String imageUrl;
}
