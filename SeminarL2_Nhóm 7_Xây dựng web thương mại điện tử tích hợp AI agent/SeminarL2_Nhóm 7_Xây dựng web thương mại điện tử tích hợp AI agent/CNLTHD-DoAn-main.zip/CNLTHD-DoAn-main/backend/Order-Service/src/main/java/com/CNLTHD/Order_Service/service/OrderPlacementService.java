package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.PlaceOrderRequestDto;

public interface OrderPlacementService {
    void placeOrder(PlaceOrderRequestDto request);
}
