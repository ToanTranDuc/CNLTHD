package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.WishlistItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.WishlistItemResponseDto;
import com.CNLTHD.Order_Service.entity.WishlistItem;
import com.CNLTHD.Order_Service.repository.WishlistItemRepository;
import com.CNLTHD.Order_Service.service.WishlistService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class WishlistServiceImpl implements WishlistService {

    private static final Logger log = LoggerFactory.getLogger(WishlistServiceImpl.class);

    private final WishlistItemRepository repository;

    public WishlistServiceImpl(WishlistItemRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<WishlistItemResponseDto> getWishlist(String userId) {
        return repository.findByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(WishlistItemResponseDto::from)
                .toList();
    }

    @Override
    @Transactional
    public WishlistItemResponseDto addItem(WishlistItemRequestDto request) {
        return repository.findByUserIdAndProductId(request.getUserId(), request.getProductId())
                .map(WishlistItemResponseDto::from)
                .orElseGet(() -> {
                    WishlistItem item = WishlistItem.builder()
                            .userId(request.getUserId())
                            .productId(request.getProductId())
                            .productName(request.getProductName())
                            .imageUrl(request.getImageUrl())
                            .price(request.getPrice())
                            .category(request.getCategory())
                            .build();
                    WishlistItem saved = repository.save(item);
                    log.info("Added wishlist item {} for user {}", saved.getProductId(), saved.getUserId());
                    return WishlistItemResponseDto.from(saved);
                });
    }

    @Override
    @Transactional
    public void removeItem(String userId, String productId) {
        repository.deleteByUserIdAndProductId(userId, productId);
        log.info("Removed wishlist item {} for user {}", productId, userId);
    }

    @Override
    @Transactional
    public void clearWishlist(String userId) {
        repository.deleteByUserId(userId);
    }

    @Override
    public long countItems(String userId) {
        return repository.countByUserId(userId);
    }
}
