package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.common.ApiResponse;
import com.CNLTHD.Order_Service.common.AppConstants;
import com.CNLTHD.Order_Service.dto.request.AddToCartRequestDto;
import com.CNLTHD.Order_Service.dto.request.UpdateCartItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.CartResponseDto;
import com.CNLTHD.Order_Service.service.CartService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(AppConstants.CART_BASE)
@Tag(name = "Cart", description = "Shopping cart management")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping("/{customerId}")
    @Operation(summary = "Get cart by customer ID")
    public ResponseEntity<ApiResponse<CartResponseDto>> getCart(
            @PathVariable String customerId) {
        return ResponseEntity.ok(ApiResponse.success(cartService.getCartByCustomerId(customerId)));
    }

    @PostMapping("/items")
    @Operation(summary = "Add item to cart")
    public ResponseEntity<ApiResponse<CartResponseDto>> addItem(
            @Valid @RequestBody AddToCartRequestDto dto) {
        CartResponseDto cart = cartService.addItemToCart(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(cart, "Item added to cart successfully"));
    }

    @PutMapping("/items/{cartItemId}")
    @Operation(summary = "Update cart item quantity")
    public ResponseEntity<ApiResponse<CartResponseDto>> updateItem(
            @PathVariable String cartItemId,
            @Valid @RequestBody UpdateCartItemRequestDto dto) {
        return ResponseEntity.ok(
                ApiResponse.success(cartService.updateCartItem(cartItemId, dto),
                        "Cart item updated successfully"));
    }

    @DeleteMapping("/{customerId}/items/{cartItemId}")
    @Operation(summary = "Remove item from cart")
    public ResponseEntity<ApiResponse<CartResponseDto>> removeItem(
            @PathVariable String customerId,
            @PathVariable String cartItemId) {
        return ResponseEntity.ok(
                ApiResponse.success(cartService.removeCartItem(customerId, cartItemId),
                        "Item removed from cart"));
    }

    @DeleteMapping("/{customerId}/clear")
    @Operation(summary = "Clear all items in a cart")
    public ResponseEntity<ApiResponse<Void>> clearCart(
            @PathVariable String customerId) {
        cartService.clearCart(customerId);
        return ResponseEntity.ok(ApiResponse.success("Cart cleared successfully"));
    }
}
