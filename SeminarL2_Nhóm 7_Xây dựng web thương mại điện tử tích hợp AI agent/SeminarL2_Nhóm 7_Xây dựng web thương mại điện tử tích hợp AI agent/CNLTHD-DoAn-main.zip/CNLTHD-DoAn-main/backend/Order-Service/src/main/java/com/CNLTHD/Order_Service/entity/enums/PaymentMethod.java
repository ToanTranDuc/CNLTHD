package com.CNLTHD.Order_Service.entity.enums;

/**
 * Supported payment methods.
 */
public enum PaymentMethod {
    COD("Cash on Delivery"),
    CREDIT_CARD("Credit Card"),
    BANK_TRANSFER("Bank Transfer"),
    E_WALLET("E-Wallet");

    private final String displayName;

    PaymentMethod(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() { return displayName; }
}
