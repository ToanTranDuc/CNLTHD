package com.CNLTHD.Order_Service.mapper;

import com.CNLTHD.Order_Service.dto.response.CartItemResponseDto;
import com.CNLTHD.Order_Service.dto.response.CartResponseDto;
import com.CNLTHD.Order_Service.entity.Cart;
import com.CNLTHD.Order_Service.entity.CartItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.util.List;

@Mapper(componentModel = "spring")
public interface CartMapper {

    @Mapping(target = "items", source = "items")
    @Mapping(target = "totalPrice", source = "items", qualifiedByName = "calcTotalPrice")
    @Mapping(target = "totalItems", source = "items", qualifiedByName = "calcTotalItems")
    CartResponseDto toResponseDto(Cart cart);

    @Mapping(target = "lineTotal", expression = "java(item.getUnitPrice().multiply(java.math.BigDecimal.valueOf(item.getQuantity())))")
    CartItemResponseDto toItemResponseDto(CartItem item);

    List<CartItemResponseDto> toItemResponseDtoList(List<CartItem> items);

    @Named("calcTotalPrice")
    default BigDecimal calcTotalPrice(List<CartItem> items) {
        if (items == null || items.isEmpty()) return BigDecimal.ZERO;
        return items.stream()
                .map(i -> i.getUnitPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Named("calcTotalItems")
    default int calcTotalItems(List<CartItem> items) {
        if (items == null) return 0;
        return items.stream().mapToInt(CartItem::getQuantity).sum();
    }
}
