package com.CNLTHD.Order_Service.dto.response;

import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponseDto {

    private String id;
    private String orderNumber;
    private String customerId;
    private OrderStatus orderStatus;

    private BigDecimal subtotal;
    private BigDecimal shippingFee;
    private BigDecimal discount;
    private BigDecimal totalAmount;

    // Shipping address
    private String recipientName;
    private String phone;
    private String addressLine;
    private String ward;
    private String district;
    private String city;
    private String note;
    private String cancelReason;

    private List<OrderItemResponseDto> items;
    private PaymentResponseDto payment;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
