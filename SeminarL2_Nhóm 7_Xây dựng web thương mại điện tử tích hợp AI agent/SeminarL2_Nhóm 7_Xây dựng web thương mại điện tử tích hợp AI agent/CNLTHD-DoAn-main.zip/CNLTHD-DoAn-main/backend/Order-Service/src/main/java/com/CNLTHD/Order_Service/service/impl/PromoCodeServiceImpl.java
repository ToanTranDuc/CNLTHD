package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.PromoCodeRequestDto;
import com.CNLTHD.Order_Service.dto.response.PromoApplyResponseDto;
import com.CNLTHD.Order_Service.dto.response.PromoCodeResponseDto;
import com.CNLTHD.Order_Service.entity.PromoCode;
import com.CNLTHD.Order_Service.exception.BusinessException;
import com.CNLTHD.Order_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Order_Service.repository.PromoCodeRepository;
import com.CNLTHD.Order_Service.service.PromoCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class PromoCodeServiceImpl implements PromoCodeService {

    private static final Logger log = LoggerFactory.getLogger(PromoCodeServiceImpl.class);

    private final PromoCodeRepository repository;

    public PromoCodeServiceImpl(PromoCodeRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<PromoCodeResponseDto> list(boolean activeOnly) {
        List<PromoCode> rows = activeOnly
                ? repository.findByActiveTrueOrderByCreatedAtDesc()
                : repository.findAllByOrderByCreatedAtDesc();
        return rows.stream().map(PromoCodeResponseDto::from).toList();
    }

    @Override
    @Transactional
    public PromoCodeResponseDto create(PromoCodeRequestDto request) {
        String code = request.getCode().trim().toUpperCase();
        if (repository.existsByCodeIgnoreCase(code)) {
            throw new BusinessException("PromoCode", "Mã '" + code + "' đã tồn tại");
        }
        PromoCode p = PromoCode.builder()
                .code(code)
                .description(request.getDescription())
                .percentOff(request.getPercentOff() != null ? request.getPercentOff() : BigDecimal.ZERO)
                .amountOff(request.getAmountOff() != null ? request.getAmountOff() : BigDecimal.ZERO)
                .maxDiscount(request.getMaxDiscount() != null ? request.getMaxDiscount() : BigDecimal.ZERO)
                .minSubtotal(request.getMinSubtotal() != null ? request.getMinSubtotal() : BigDecimal.ZERO)
                .freeShipping(Boolean.TRUE.equals(request.getFreeShipping()))
                .expiresAt(request.getExpiresAt())
                .maxUses(request.getMaxUses() != null ? request.getMaxUses() : 0)
                .usedCount(0)
                .active(request.getActive() == null ? Boolean.TRUE : request.getActive())
                .build();
        return PromoCodeResponseDto.from(repository.save(p));
    }

    @Override
    @Transactional
    public PromoCodeResponseDto update(String id, PromoCodeRequestDto request) {
        PromoCode p = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PromoCode", "id", id));
        if (request.getCode() != null && !request.getCode().isBlank()) {
            String newCode = request.getCode().trim().toUpperCase();
            if (!newCode.equalsIgnoreCase(p.getCode()) && repository.existsByCodeIgnoreCase(newCode)) {
                throw new BusinessException("PromoCode", "Mã '" + newCode + "' đã tồn tại");
            }
            p.setCode(newCode);
        }
        if (request.getDescription() != null) p.setDescription(request.getDescription());
        if (request.getPercentOff() != null) p.setPercentOff(request.getPercentOff());
        if (request.getAmountOff() != null) p.setAmountOff(request.getAmountOff());
        if (request.getMaxDiscount() != null) p.setMaxDiscount(request.getMaxDiscount());
        if (request.getMinSubtotal() != null) p.setMinSubtotal(request.getMinSubtotal());
        if (request.getFreeShipping() != null) p.setFreeShipping(request.getFreeShipping());
        if (request.getExpiresAt() != null) p.setExpiresAt(request.getExpiresAt());
        if (request.getMaxUses() != null) p.setMaxUses(request.getMaxUses());
        if (request.getActive() != null) p.setActive(request.getActive());
        return PromoCodeResponseDto.from(repository.save(p));
    }

    @Override
    @Transactional
    public void delete(String id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PromoCode", "id", id);
        }
        repository.deleteById(id);
    }

    @Override
    @Transactional
    public PromoCodeResponseDto toggleActive(String id) {
        PromoCode p = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PromoCode", "id", id));
        p.setActive(!Boolean.TRUE.equals(p.getActive()));
        return PromoCodeResponseDto.from(repository.save(p));
    }

    @Override
    public PromoApplyResponseDto validate(String rawCode, BigDecimal subtotal) {
        if (rawCode == null || rawCode.isBlank()) {
            return PromoApplyResponseDto.builder().valid(false).message("Vui lòng nhập mã").discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }
        if (subtotal == null) subtotal = BigDecimal.ZERO;
        Optional<PromoCode> opt = repository.findByCodeIgnoreCase(rawCode.trim());
        if (opt.isEmpty()) {
            return PromoApplyResponseDto.builder().valid(false).message("Mã không tồn tại").discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }
        PromoCode p = opt.get();
        if (!Boolean.TRUE.equals(p.getActive())) {
            return PromoApplyResponseDto.builder().valid(false).message("Mã đã bị vô hiệu hoá").discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }
        if (p.getExpiresAt() != null && Instant.now().isAfter(p.getExpiresAt())) {
            return PromoApplyResponseDto.builder().valid(false).message("Mã đã hết hạn").discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }
        if (p.getMaxUses() != null && p.getMaxUses() > 0 && p.getUsedCount() >= p.getMaxUses()) {
            return PromoApplyResponseDto.builder().valid(false).message("Mã đã đạt giới hạn sử dụng").discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }
        if (p.getMinSubtotal() != null && subtotal.compareTo(p.getMinSubtotal()) < 0) {
            return PromoApplyResponseDto.builder().valid(false)
                    .message("Đơn tối thiểu " + p.getMinSubtotal().toPlainString() + "đ để dùng mã này")
                    .discountAmount(BigDecimal.ZERO).freeShipping(false).build();
        }

        BigDecimal discount = BigDecimal.ZERO;
        if (p.getPercentOff() != null && p.getPercentOff().signum() > 0) {
            discount = discount.add(subtotal.multiply(p.getPercentOff()).divide(BigDecimal.valueOf(100), 0, RoundingMode.FLOOR));
        }
        if (p.getAmountOff() != null && p.getAmountOff().signum() > 0) {
            discount = discount.add(p.getAmountOff());
        }
        if (p.getMaxDiscount() != null && p.getMaxDiscount().signum() > 0 && discount.compareTo(p.getMaxDiscount()) > 0) {
            discount = p.getMaxDiscount();
        }
        // Clamp at subtotal
        if (discount.compareTo(subtotal) > 0) discount = subtotal;

        return PromoApplyResponseDto.builder()
                .valid(true)
                .code(p.getCode())
                .description(p.getDescription())
                .discountAmount(discount)
                .freeShipping(Boolean.TRUE.equals(p.getFreeShipping()))
                .message("OK")
                .build();
    }

    @Override
    @Transactional
    public void recordRedemption(String code) {
        if (code == null || code.isBlank()) return;
        repository.findByCodeIgnoreCase(code.trim()).ifPresent((p) -> {
            p.setUsedCount(p.getUsedCount() + 1);
            repository.save(p);
            log.info("Promo {} used (total uses: {})", p.getCode(), p.getUsedCount());
        });
    }
}
