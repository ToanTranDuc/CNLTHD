package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.dto.request.PaymentRequestDto;
import com.CNLTHD.Order_Service.dto.response.PaymentResponseDto;
import com.CNLTHD.Order_Service.entity.Order;
import com.CNLTHD.Order_Service.entity.Payment;
import com.CNLTHD.Order_Service.entity.enums.OrderStatus;
import com.CNLTHD.Order_Service.entity.enums.PaymentStatus;
import com.CNLTHD.Order_Service.exception.BusinessException;
import com.CNLTHD.Order_Service.exception.ResourceNotFoundException;
import com.CNLTHD.Order_Service.mapper.PaymentMapper;
import com.CNLTHD.Order_Service.repository.OrderRepository;
import com.CNLTHD.Order_Service.repository.PaymentRepository;
import com.CNLTHD.Order_Service.service.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class PaymentServiceImpl implements PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentServiceImpl.class);

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final PaymentMapper paymentMapper;

    public PaymentServiceImpl(PaymentRepository paymentRepository,
                              OrderRepository orderRepository,
                              PaymentMapper paymentMapper) {
        this.paymentRepository = paymentRepository;
        this.orderRepository = orderRepository;
        this.paymentMapper = paymentMapper;
    }

    @Override
    public PaymentResponseDto getPaymentByOrderId(String orderId) {
        Payment payment = paymentRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "orderId", orderId));
        return paymentMapper.toResponseDto(payment);
    }

    @Override
    @Transactional
    public PaymentResponseDto updatePaymentStatus(PaymentRequestDto dto) {
        log.info("Updating payment for order: {} to status: {}", dto.getOrderId(), dto.getPaymentStatus());

        Payment payment = paymentRepository.findByOrderId(dto.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "orderId", dto.getOrderId()));

        if (payment.getPaymentStatus() == PaymentStatus.COMPLETED) {
            throw new BusinessException("Payment", "Payment is already completed");
        }

        if (payment.getPaymentStatus() == PaymentStatus.REFUNDED) {
            throw new BusinessException("Payment", "Payment has already been refunded");
        }

        payment.setPaymentStatus(dto.getPaymentStatus());
        if (dto.getTransactionId() != null) {
            payment.setTransactionId(dto.getTransactionId());
        }

        // If payment is completed, update order status to CONFIRMED
        if (dto.getPaymentStatus() == PaymentStatus.COMPLETED) {
            Order order = payment.getOrder();
            if (order.getOrderStatus() == OrderStatus.PENDING) {
                order.setOrderStatus(OrderStatus.CONFIRMED);
                orderRepository.save(order);
                log.info("Order {} confirmed after payment completed", order.getOrderNumber());
            }
        }

        return paymentMapper.toResponseDto(paymentRepository.save(payment));
    }

    @Override
    public PaymentResponseDto findById(String paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "id", paymentId));
        return paymentMapper.toResponseDto(payment);
    }
}
