package com.CNLTHD.Order_Service.event;

import java.time.Instant;

/**
 * Generic order lifecycle event published to Kafka.
 * action is one of: PLACED, CONFIRMED, SHIPPED, DELIVERED, CANCELLED, RETURNED.
 */
public record OrderStatusEvent(
        String action,
        String orderNumber,
        String customerId,
        String recipientEmail,
        Instant timestamp
) {}
