package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.PromoCodeRequestDto;
import com.CNLTHD.Order_Service.dto.response.PromoApplyResponseDto;
import com.CNLTHD.Order_Service.dto.response.PromoCodeResponseDto;

import java.math.BigDecimal;
import java.util.List;

public interface PromoCodeService {

    List<PromoCodeResponseDto> list(boolean activeOnly);

    PromoCodeResponseDto create(PromoCodeRequestDto request);

    PromoCodeResponseDto update(String id, PromoCodeRequestDto request);

    void delete(String id);

    PromoCodeResponseDto toggleActive(String id);

    /** Validate a code against a subtotal (does NOT increment usage). */
    PromoApplyResponseDto validate(String code, BigDecimal subtotal);

    /** Increment usedCount after a successful order. */
    void recordRedemption(String code);
}
