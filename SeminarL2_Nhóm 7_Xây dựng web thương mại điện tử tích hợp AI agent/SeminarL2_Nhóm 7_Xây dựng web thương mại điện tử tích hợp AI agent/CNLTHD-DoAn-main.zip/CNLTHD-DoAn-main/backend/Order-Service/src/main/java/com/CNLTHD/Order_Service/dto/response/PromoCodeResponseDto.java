package com.CNLTHD.Order_Service.dto.response;

import com.CNLTHD.Order_Service.entity.PromoCode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromoCodeResponseDto {

    private String id;
    private String code;
    private String description;
    private BigDecimal percentOff;
    private BigDecimal amountOff;
    private BigDecimal maxDiscount;
    private BigDecimal minSubtotal;
    private Boolean freeShipping;
    private Instant expiresAt;
    private Integer maxUses;
    private Integer usedCount;
    private Boolean active;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static PromoCodeResponseDto from(PromoCode p) {
        return PromoCodeResponseDto.builder()
                .id(p.getId())
                .code(p.getCode())
                .description(p.getDescription())
                .percentOff(p.getPercentOff())
                .amountOff(p.getAmountOff())
                .maxDiscount(p.getMaxDiscount())
                .minSubtotal(p.getMinSubtotal())
                .freeShipping(p.getFreeShipping())
                .expiresAt(p.getExpiresAt())
                .maxUses(p.getMaxUses())
                .usedCount(p.getUsedCount())
                .active(p.getActive())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
