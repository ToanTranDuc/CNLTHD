package com.CNLTHD.Order_Service.service.impl;

import com.CNLTHD.Order_Service.service.InventoryClient;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class InventoryClientImpl implements InventoryClient {

    private static final Logger log = LoggerFactory.getLogger(InventoryClientImpl.class);

    private final RestClient restClient;

    @Value("${app.inventory.base-url}")
    private String inventoryBaseUrl;

    public InventoryClientImpl(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    @CircuitBreaker(name = "inventory", fallbackMethod = "hasStockFallback")
    @Retry(name = "inventory")
    @TimeLimiter(name = "inventory")
    public CompletableFuture<Boolean> hasStock(String skuCode, Integer requiredQuantity) {
        return CompletableFuture.supplyAsync(() -> doCheck(skuCode, requiredQuantity));
    }

    @Override
    public void deductStock(String skuCode, Integer quantity, String referenceId) {
        try {
            Map<String, Object> body = Map.of(
                "quantityChange", quantity,
                "referenceId", referenceId != null ? referenceId : "",
                "reason", "Order placement"
            );
            restClient.post()
                    .uri(inventoryBaseUrl + "/api/stocks/{skuCode}/deduct", skuCode)
                    .body(body)
                    .retrieve()
                    .toBodilessEntity();
            log.info("Deducted {} units from stock for sku={}", quantity, skuCode);
        } catch (Exception ex) {
            log.warn("Failed to deduct stock for sku={}: {}", skuCode, ex.getMessage());
        }
    }

    @Override
    public void restockStock(String skuCode, Integer quantity, String referenceId) {
        try {
            // Inventory's /deduct endpoint accepts negative quantityChange to add back stock.
            // Reverse sign to add stock.
            Map<String, Object> body = Map.of(
                "quantityChange", -Math.abs(quantity),
                "referenceId", referenceId != null ? referenceId : "",
                "reason", "Order cancellation - restock"
            );
            restClient.post()
                    .uri(inventoryBaseUrl + "/api/stocks/{skuCode}/deduct", skuCode)
                    .body(body)
                    .retrieve()
                    .toBodilessEntity();
            log.info("Restocked {} units to stock for sku={} (reference={})", quantity, skuCode, referenceId);
        } catch (Exception ex) {
            log.warn("Failed to restock sku={}: {}", skuCode, ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private Boolean doCheck(String skuCode, Integer requiredQuantity) {
        Map<String, Object> response = restClient.get()
                .uri(inventoryBaseUrl + "/api/stocks/{skuCode}", skuCode)
                .retrieve()
                .body(Map.class);

        if (response == null) {
            throw new IllegalStateException("Null stock response for sku " + skuCode);
        }

        Object data = response.get("data");
        if (!(data instanceof Map)) {
            throw new IllegalStateException("Invalid stock response for sku " + skuCode);
        }

        Object qty = ((Map<String, Object>) data).get("quantity");
        int available = qty instanceof Number ? ((Number) qty).intValue() : -1;
        if (available < 0) {
            throw new IllegalStateException("Invalid stock quantity for sku " + skuCode);
        }

        return available >= requiredQuantity;
    }

    private CompletableFuture<Boolean> hasStockFallback(String skuCode, Integer requiredQuantity, Throwable ex) {
        log.warn("Inventory fallback activated for sku={} quantity={}: {}",
                skuCode, requiredQuantity, ex.getMessage());
        return CompletableFuture.completedFuture(false);
    }
}
