package com.CNLTHD.Order_Service.service;

import com.CNLTHD.Order_Service.dto.request.WishlistItemRequestDto;
import com.CNLTHD.Order_Service.dto.response.WishlistItemResponseDto;

import java.util.List;

public interface WishlistService {

    List<WishlistItemResponseDto> getWishlist(String userId);

    WishlistItemResponseDto addItem(WishlistItemRequestDto request);

    void removeItem(String userId, String productId);

    void clearWishlist(String userId);

    long countItems(String userId);
}
