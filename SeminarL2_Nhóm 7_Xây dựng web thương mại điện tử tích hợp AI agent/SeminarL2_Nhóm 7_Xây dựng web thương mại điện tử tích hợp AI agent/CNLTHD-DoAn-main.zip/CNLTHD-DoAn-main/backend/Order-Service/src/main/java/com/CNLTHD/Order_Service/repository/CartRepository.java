package com.CNLTHD.Order_Service.repository;

import com.CNLTHD.Order_Service.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, String> {

    Optional<Cart> findByCustomerId(String customerId);

    boolean existsByCustomerId(String customerId);
}
