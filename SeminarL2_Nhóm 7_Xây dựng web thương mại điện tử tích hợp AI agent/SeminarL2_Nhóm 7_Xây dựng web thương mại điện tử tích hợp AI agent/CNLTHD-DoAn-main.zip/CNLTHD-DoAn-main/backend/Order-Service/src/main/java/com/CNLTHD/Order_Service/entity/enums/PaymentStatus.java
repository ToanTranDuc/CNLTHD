package com.CNLTHD.Order_Service.entity.enums;

/**
 * Payment lifecycle statuses.
 */
public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED,
    REFUNDED
}
