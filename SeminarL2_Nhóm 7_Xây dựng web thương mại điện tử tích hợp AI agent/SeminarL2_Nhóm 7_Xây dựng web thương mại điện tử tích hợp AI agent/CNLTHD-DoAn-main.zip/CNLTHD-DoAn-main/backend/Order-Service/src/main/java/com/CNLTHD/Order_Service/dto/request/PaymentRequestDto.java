package com.CNLTHD.Order_Service.dto.request;

import com.CNLTHD.Order_Service.entity.enums.PaymentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO to update payment status (e.g. from payment gateway callback).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequestDto {

    @NotBlank(message = "Order ID is required")
    private String orderId;

    @NotNull(message = "Payment status is required")
    private PaymentStatus paymentStatus;

    /** External transaction ID from payment gateway */
    private String transactionId;
}
