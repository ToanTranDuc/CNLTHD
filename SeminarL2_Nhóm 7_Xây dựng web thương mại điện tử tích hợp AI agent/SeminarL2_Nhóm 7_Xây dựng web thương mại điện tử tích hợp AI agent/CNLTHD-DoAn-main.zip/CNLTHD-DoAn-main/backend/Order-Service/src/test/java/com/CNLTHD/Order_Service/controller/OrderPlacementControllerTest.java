package com.CNLTHD.Order_Service.controller;

import com.CNLTHD.Order_Service.exception.BusinessException;
import com.CNLTHD.Order_Service.exception.GlobalExceptionHandler;
import com.CNLTHD.Order_Service.service.OrderPlacementService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class OrderPlacementControllerTest {

    private MockMvc mockMvc;

    @Mock
    private OrderPlacementService orderPlacementService;

    @InjectMocks
    private OrderPlacementController orderPlacementController;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(orderPlacementController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void placeOrderSuccess_returnsCreated() throws Exception {
        doNothing().when(orderPlacementService).placeOrder(any());

        String payload = """
                {
                  \"orderLineItemsDtoList\": [
                    {
                      \"skuCode\": \"iphone_13\",
                      \"price\": 1200,
                      \"quantity\": 1
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/order")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(payload))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Order Placed"));
    }

    @Test
    void placeOrderOutOfStock_returnsConflict() throws Exception {
        doThrow(new BusinessException("Order", "Product with SKU 'iphone_13' is out of stock"))
                .when(orderPlacementService)
                .placeOrder(any());

        String payload = """
                {
                  \"orderLineItemsDtoList\": [
                    {
                      \"skuCode\": \"iphone_13\",
                      \"price\": 1200,
                      \"quantity\": 1
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/order")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(payload))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409))
                .andExpect(jsonPath("$.message").value("[Order] Product with SKU 'iphone_13' is out of stock"));
    }
}
