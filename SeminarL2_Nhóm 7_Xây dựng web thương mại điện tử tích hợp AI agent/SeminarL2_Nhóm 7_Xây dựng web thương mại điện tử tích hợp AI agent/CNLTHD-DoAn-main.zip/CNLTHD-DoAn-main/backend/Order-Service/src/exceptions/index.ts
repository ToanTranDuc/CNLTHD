/**
 * Custom Exceptions for Order Service
 */

export class OrderNotFoundException extends Error {
  constructor(message: string = 'Order not found') {
    super(message);
    this.name = 'OrderNotFoundException';
  }
}

export class OrderServiceException extends Error {
  constructor(message: string = 'Order service error') {
    super(message);
    this.name = 'OrderServiceException';
  }
}

export class InvalidOrderException extends Error {
  constructor(message: string = 'Invalid order data') {
    super(message);
    this.name = 'InvalidOrderException';
  }
}

export class OrderAlreadyExistsException extends Error {
  constructor(message: string = 'Order already exists') {
    super(message);
    this.name = 'OrderAlreadyExistsException';
  }
}

export class InsufficientInventoryException extends Error {
  constructor(message: string = 'Insufficient inventory') {
    super(message);
    this.name = 'InsufficientInventoryException';
  }
}

export class PublishEventFailedException extends Error {
  constructor(message: string = 'Failed to publish event to Kafka') {
    super(message);
    this.name = 'PublishEventFailedException';
  }
}
