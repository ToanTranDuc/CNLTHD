package com.cnlthd.chatbotservice.unit;

import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.cnlthd.chatbotservice.controller.ChatbotConfigController;
import com.cnlthd.chatbotservice.service.ChatbotConfigService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@DisplayName("Unit Tests - Chatbot Config Service & Controller")
class ChatbotConfigUnitTest {

    @Nested
    @DisplayName("UT-CHATBOT-01: Service trả webhookUrl mặc định")
    class DefaultUrlTest {
        @Test
        @DisplayName("Should return fallback webhook URL when no property is set")
        void testDefaultWebhookUrl() {
            String defaultUrl = "https://brice-opportune-unacceptably.ngrok-free.dev/webhook/3d84c956-4adf-403d-8895-bfcf35e558e1/chat";
            ChatbotConfigService service = new ChatbotConfigService(defaultUrl);

            String result = service.getWebhookUrl();

            assertEquals(defaultUrl, result);
        }
    }

    @Nested
    @DisplayName("UT-CHATBOT-02: Service trả webhookUrl khi cấu hình custom")
    class CustomUrlTest {
        @Test
        @DisplayName("Should return custom webhook URL when property is set")
        void testCustomWebhookUrl() {
            String customUrl = "http://test-webhook/chat";
            ChatbotConfigService service = new ChatbotConfigService(customUrl);

            String result = service.getWebhookUrl();

            assertEquals(customUrl, result);
        }
    }

    @Nested
    @DisplayName("UT-CHATBOT-03: Controller map JSON config đúng")
    @ExtendWith(MockitoExtension.class)
    class ControllerMockTest {
        @Mock
        private ChatbotConfigService chatbotConfigService;

        @Test
        @DisplayName("Should return JSON with webhookUrl in /api/chatbot/config")
        void testControllerReturnsConfigJson() throws Exception {
            when(chatbotConfigService.getWebhookUrl()).thenReturn("http://mocked-webhook/chat");

            MockMvc mockMvc = MockMvcBuilders
                    .standaloneSetup(new ChatbotConfigController(chatbotConfigService))
                    .build();

            mockMvc.perform(get("/api/chatbot/config"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.webhookUrl", is("http://mocked-webhook/chat")));
        }
    }
}
