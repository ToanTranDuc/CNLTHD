package com.cnlthd.chatbotservice.integration;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@DisplayName("Integration Tests - Chatbot Config")
class ChatbotConfigIntegrationTest {

    @Nested
    @SpringBootTest
    @TestPropertySource(properties = "chatbot.webhook-url=http://integration-test-webhook/chat")
    @DisplayName("IT-CHATBOT-01: Endpoint config chạy full Spring context")
    class FullContextTest {
        @Autowired
        private WebApplicationContext webApplicationContext;

        private MockMvc mockMvc;

        @BeforeEach
        void setUp() {
            mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        }

        @Test
        @DisplayName("Should expose /api/chatbot/config with configured webhook URL")
        void testConfigEndpointWithFullContext() throws Exception {
            mockMvc.perform(get("/api/chatbot/config"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.webhookUrl", is("http://integration-test-webhook/chat")));
        }
    }

    @Nested
    @SpringBootTest
    @TestPropertySource(properties = {
        "chatbot.webhook-url=http://eureka-independent-webhook/chat",
        "eureka.client.enabled=false"
    })
    @DisplayName("IT-CHATBOT-03: Config endpoint không phụ thuộc Eureka")
    class WithoutEurekaTest {
        @Autowired
        private WebApplicationContext webApplicationContext;

        private MockMvc mockMvc;

        @BeforeEach
        void setUp() {
            mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        }

        @Test
        @DisplayName("Should return config JSON even when Eureka is disabled")
        void testConfigEndpointIndependentOfEureka() throws Exception {
            mockMvc.perform(get("/api/chatbot/config"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.webhookUrl", is("http://eureka-independent-webhook/chat")));
        }
    }
}