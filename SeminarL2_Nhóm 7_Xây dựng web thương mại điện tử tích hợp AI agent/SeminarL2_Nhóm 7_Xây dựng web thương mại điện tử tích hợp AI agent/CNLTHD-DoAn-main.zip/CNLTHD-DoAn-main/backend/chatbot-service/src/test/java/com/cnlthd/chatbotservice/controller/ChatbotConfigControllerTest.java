package com.cnlthd.chatbotservice.controller;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.cnlthd.chatbotservice.service.ChatbotConfigService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class ChatbotConfigControllerTest {

    @Mock
    private ChatbotConfigService chatbotConfigService;

    @Test
    void shouldReturnWebhookUrlFromService() throws Exception {
        when(chatbotConfigService.getWebhookUrl()).thenReturn("http://localhost:1234/webhook");

        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new ChatbotConfigController(chatbotConfigService))
                .build();

        mockMvc.perform(get("/api/chatbot/config"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.webhookUrl", is("http://localhost:1234/webhook")));
    }
}