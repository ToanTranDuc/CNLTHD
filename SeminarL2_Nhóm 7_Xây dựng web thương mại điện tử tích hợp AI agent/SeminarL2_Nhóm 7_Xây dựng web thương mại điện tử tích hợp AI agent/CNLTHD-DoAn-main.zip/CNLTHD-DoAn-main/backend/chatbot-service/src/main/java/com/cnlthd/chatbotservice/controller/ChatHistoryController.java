package com.cnlthd.chatbotservice.controller;

import com.cnlthd.chatbotservice.service.ChatHistoryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class ChatHistoryController {

    private final ChatHistoryService chatHistoryService;

    public ChatHistoryController(ChatHistoryService chatHistoryService) {
        this.chatHistoryService = chatHistoryService;
    }

    @GetMapping("/api/chatbot/history")
    public List<Map<String, Object>> getHistory(
            @RequestParam String userId,
            @RequestParam(defaultValue = "20") int limit) {
        return chatHistoryService.getHistory(userId, limit);
    }
}
