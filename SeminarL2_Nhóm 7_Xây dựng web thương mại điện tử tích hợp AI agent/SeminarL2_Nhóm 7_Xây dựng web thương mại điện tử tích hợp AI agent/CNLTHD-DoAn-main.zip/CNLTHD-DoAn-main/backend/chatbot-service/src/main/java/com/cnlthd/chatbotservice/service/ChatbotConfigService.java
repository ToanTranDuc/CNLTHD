package com.cnlthd.chatbotservice.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ChatbotConfigService {

    private final String webhookUrl;

    public ChatbotConfigService(
            @Value("${chatbot.webhook-url:https://brice-opportune-unacceptably.ngrok-free.dev/webhook/3d84c956-4adf-403d-8895-bfcf35e558e1/chat}")
            String webhookUrl) {
        this.webhookUrl = webhookUrl;
    }

    public String getWebhookUrl() {
        return webhookUrl;
    }
}