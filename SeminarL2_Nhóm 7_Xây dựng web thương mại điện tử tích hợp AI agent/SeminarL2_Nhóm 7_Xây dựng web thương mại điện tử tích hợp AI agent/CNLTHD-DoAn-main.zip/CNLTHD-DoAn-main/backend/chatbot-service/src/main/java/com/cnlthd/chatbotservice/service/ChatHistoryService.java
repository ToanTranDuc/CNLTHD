package com.cnlthd.chatbotservice.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class ChatHistoryService {

    private final JdbcTemplate jdbcTemplate;

    public ChatHistoryService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Trả về lịch sử tin nhắn theo userId, sắp xếp cũ → mới.
     * Với anonymous user trả về danh sách rỗng.
     */
    public List<Map<String, Object>> getHistory(String userId, int limit) {
        if (userId == null || userId.isBlank() || "anonymous".equalsIgnoreCase(userId)) {
            return Collections.emptyList();
        }

        int safeLimit = Math.min(Math.max(limit, 1), 50);

        String sql = """
                SELECT role, content, created_at
                FROM chatbot_service.chat_messages
                WHERE user_id = ?
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                """;

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, userId, safeLimit);

        // Đảo ngược để trả về thứ tự chronological (cũ → mới)
        Collections.reverse(rows);
        return rows;
    }
}
