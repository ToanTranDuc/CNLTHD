package com.cnlthd.chatbotservice.controller;

import java.util.Map;

import com.cnlthd.chatbotservice.service.ChatbotConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChatbotConfigController {

    private final ChatbotConfigService chatbotConfigService;

    @Autowired
    public ChatbotConfigController(ChatbotConfigService chatbotConfigService) {
        this.chatbotConfigService = chatbotConfigService;
    }

    @GetMapping("/api/chatbot/config")
    public Map<String, String> getConfig() {
        return Map.of("webhookUrl", chatbotConfigService.getWebhookUrl());
    }
}
