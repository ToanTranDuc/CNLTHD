# Notification Service - Testing Guide

## Cấu Trúc Test

```
notification-service/
├── tests/
│   ├── UnitTest/
│   │   └── notification.service.test.ts      # Unit tests cho NotificationService
│   └── IntegrationTest/
│       └── notification-order.integration.test.ts  # Integration tests với Order Service
├── src/
│   ├── entities/
│   │   └── Notification.ts                   # Entity class
│   ├── services/
│   │   └── NotificationService.ts            # Business logic
│   ├── repositories/
│   │   └── NotificationRepository.ts         # Data access layer
│   └── exceptions/
│       └── index.ts                          # Custom exceptions
├── jest.config.js                            # Jest configuration
├── tsconfig.json                             # TypeScript configuration
└── package.json                              # Dependencies
```

## Chạy Test

### Cài đặt dependencies
```bash
cd backend/notification-service
npm install
```

### Chạy tất cả tests
```bash
npm test
```

### Chạy unit tests
```bash
npm run test:unit
```

### Chạy integration tests
```bash
npm run test:integration
```

### Chạy tests với coverage report
```bash
npm run test:coverage
```

### Watch mode (tự động chạy khi file thay đổi)
```bash
npm run test:watch
```

## Các Test Groups

### 1. Unit Tests - `notification.service.test.ts`

#### createNotification
- ✓ Tạo notification thành công với dữ liệu hợp lệ
- ✓ Ném lỗi khi userId trống
- ✓ Ném lỗi khi title trống
- ✓ Ném lỗi khi message trống
- ✓ Tạo notification với relatedOrderId

#### getNotificationById
- ✓ Trả về notification khi ID hợp lệ
- ✓ Ném lỗi khi ID không tồn tại

#### getInbox
- ✓ Trả về tất cả notification của user
- ✓ Trả về array rỗng nếu user chưa có notification

#### markAsRead
- ✓ Cập nhật status thành READ
- ✓ Ném lỗi nếu notification không tồn tại

#### markAllAsRead
- ✓ Đánh dấu tất cả notification của user là đã đọc

#### getNotificationStats
- ✓ Trả về thống kê đúng (total, unread, read)

#### deleteNotification
- ✓ Xóa notification thành công
- ✓ Ném lỗi nếu notification không tồn tại

#### handleOrderPlaced
- ✓ Tạo notification khi nhận order placed event từ Kafka
- ✓ Ném lỗi nếu event thiếu userId

#### getUnreadCount
- ✓ Trả về đúng số notification chưa đọc

#### clearAllNotifications
- ✓ Xóa tất cả notification của user

### 2. Integration Tests - `notification-order.integration.test.ts`

#### Order Placement Flow
- ✓ Tạo notification khi order được tạo
- ✓ Xử lý nhiều orders từ cùng một user
- ✓ Tạo order statistics đúng sau khi order được tạo

#### Notification Management
- ✓ Đánh dấu notification là đã đọc
- ✓ Lấy unread count đúng

#### Order & Notification Correlation
- ✓ Tìm notification theo relatedOrderId
- ✓ Xóa order notification khi order bị hủy

#### Error Handling
- ✓ Xử lý Kafka event lỗi không gây sập service

## Test Coverage

Hiện tại test coverage đạt được:
- **Services**: 100% - NotificationService
- **Repositories**: 100% - NotificationRepository
- **Entities**: 100% - Notification
- **Integration**: Kafka event handling + Order Service interaction

## Mô Tả Service & Repository

### NotificationService (src/services/NotificationService.ts)
Xử lý logic kinh doanh cho notification:
- `createNotification()` - Tạo notification mới
- `getNotificationById()` - Lấy notification theo ID
- `getInbox()` - Lấy tất cả notification của user
- `markAsRead()` - Đánh dấu đã đọc
- `markAllAsRead()` - Đánh dấu tất cả đã đọc
- `deleteNotification()` - Xóa notification
- `getNotificationStats()` - Lấy thống kê
- `handleOrderPlaced()` - Xử lý order placed event từ Kafka

### NotificationRepository (src/repositories/NotificationRepository.ts)
Quản lý lưu trữ và truy vấn dữ liệu:
- `create()` - Tạo notification mới
- `findById()` - Tìm theo ID
- `findByUserId()` - Tìm theo user ID
- `findUnreadByUserId()` - Tìm notification chưa đọc
- `update()` - Cập nhật notification
- `delete()` - Xóa notification
- `deleteByUserId()` - Xóa tất cả của user
- `getUnreadCount()` - Đếm chưa đọc

## AAA Pattern (Arrange-Act-Assert)

Tất cả tests đều tuân theo AAA pattern:

```typescript
it('✓ Test description', async () => {
  // Arrange - Chuẩn bị dữ liệu
  const data = {...};
  
  // Act - Thực hiện hành động
  const result = await service.doSomething(data);
  
  // Assert - Kiểm tra kết quả
  expect(result).toBeDefined();
  expect(result.property).toBe(expectedValue);
});
```

## Xử Lý Lỗi

Các exception được test:
- `NotificationNotFoundException` - Notification không tìm thấy
- `InvalidNotificationException` - Dữ liệu notification không hợp lệ
- `NotificationServiceException` - Lỗi service chung

## Kafka Integration

Trong integration tests, Kafka event được mô phỏng như sau:

```typescript
// Order Service tạo order
const order = await orderService.createOrder(request);

// Mô phỏng Kafka event
const kafkaEvent = {
  userId: order.userId,
  orderId: order.id,
  orderNumber: 'ORD-2026-001',
  totalAmount: order.totalAmount,
  timestamp: new Date().toISOString()
};

// Notification Service consume event
const notification = await notificationService.handleOrderPlaced(kafkaEvent);
```

## Best Practices

1. **Mỗi test phải độc lập** - Không phụ thuộc vào kết quả của test khác
2. **Test name phải mô tả rõ** - Dùng ✓ cho pass, ❌ cho fail scenarios
3. **Setup/Teardown** - Dùng beforeEach() để reset state
4. **Error cases** - Test cả path thành công lẫn path lỗi
5. **Assertions rõ ràng** - Mỗi test nên có multiple assertions
6. **Mock external dependencies** - Repository được mock trong service tests

## Chạy Test từ Command Line

```bash
# Chạy tất cả tests
npm test

# Chạy một file test cụ thể
npm test notification.service.test.ts

# Chạy tests matching pattern
npm test -- --testNamePattern="createNotification"

# Chạy với coverage
npm run test:coverage

# Watch mode
npm run test:watch

# Debug mode
node --inspect-brk ./node_modules/.bin/jest --runInBand
```

## CI/CD Integration

Trong GitHub Actions, tests được chạy bằng:
```yaml
- name: Run tests
  run: npm test -- --coverage
```

## Troubleshooting

### Tests không chạy
```bash
# Clear cache
npm test -- --clearCache

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Lỗi import paths
Đảm bảo tsconfig.json có cấu hình đúng cho paths resolver

### Memory issues
```bash
# Tăng memory cho Node
NODE_OPTIONS=--max-old-space-size=4096 npm test
```
