const { createDefaultPreset } = require("ts-jest");
const tsJestTransformCfg = createDefaultPreset().transform;

/** @type {import("jest").Config} **/
module.exports = {
  testEnvironment: "node",
  // 1. Cho phép Jest nhận diện cả file .ts và .js
  moduleFileExtensions: ['ts', 'js', 'json', 'node'],
  
  transform: {
    // 2. Dùng ts-jest để xử lý file .ts
    ...tsJestTransformCfg,
    // 3. Nếu bạn có dùng cú pháp ES Modules (import/export) trong file .js, 
    // bạn có thể cần thêm babel-jest, nhưng mặc định thường node sẽ chạy được CommonJS.
  },
  
  // 4. Sửa lại đường dẫn tìm file test để bao gồm cả .js
  testMatch: ["**/tests/UnitTest/**/*.test.(ts|js)"], 
};