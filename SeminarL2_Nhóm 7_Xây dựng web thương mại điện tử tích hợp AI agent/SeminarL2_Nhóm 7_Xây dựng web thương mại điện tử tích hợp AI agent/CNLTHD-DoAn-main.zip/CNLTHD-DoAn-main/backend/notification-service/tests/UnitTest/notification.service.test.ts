/**
 * Unit Test cho NotificationService
 * 
 * Kiểm thử các chức năng chính của NotificationService:
 * - Tạo notification
 * - Lấy notification
 * - Đánh dấu đã đọc
 * - Xóa notification
 * - Xử lý order placed event
 */

import { NotificationService } from '../../src/services/NotificationService';
import { NotificationRepository } from '../../src/repositories/NotificationRepository';
import { NotificationType, NotificationStatus } from '../../src/entities/Notification';
import {
  NotificationNotFoundException,
  InvalidNotificationException
} from '../../src/exceptions';

describe('NotificationService - Unit Tests', () => {
  let notificationService: NotificationService;
  let notificationRepository: NotificationRepository;

  // Setup trước mỗi test
  beforeEach(() => {
    notificationRepository = new NotificationRepository();
    notificationService = new NotificationService(notificationRepository);
  });

  // ====== TEST GROUP 1: createNotification ======
  describe('createNotification - Tạo notification mới', () => {
    
    it('✓ Nên tạo notification thành công với dữ liệu hợp lệ', async () => {
      // Arrange
      const userId = 'user-123';
      const title = 'Đơn hàng mới';
      const message = 'Đơn hàng của bạn đã được tạo thành công';
      const type = NotificationType.ORDER_PLACED;

      // Act
      const result = await notificationService.createNotification(
        userId,
        title,
        message,
        type
      );

      // Assert
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
      expect(result.userId).toBe(userId);
      expect(result.title).toBe(title);
      expect(result.message).toBe(message);
      expect(result.type).toBe(type);
      expect(result.status).toBe(NotificationStatus.UNREAD);
      expect(result.emailSent).toBe(false);
    });

    it('✓ Nên ném lỗi khi userId trống', async () => {
      // Act & Assert
      await expect(
        notificationService.createNotification(
          '',
          'Title',
          'Message',
          NotificationType.SYSTEM
        )
      ).rejects.toThrow(InvalidNotificationException);
    });

    it('✓ Nên ném lỗi khi title trống', async () => {
      // Act & Assert
      await expect(
        notificationService.createNotification(
          'user-123',
          '',
          'Message',
          NotificationType.SYSTEM
        )
      ).rejects.toThrow(InvalidNotificationException);
    });

    it('✓ Nên ném lỗi khi message trống', async () => {
      // Act & Assert
      await expect(
        notificationService.createNotification(
          'user-123',
          'Title',
          '',
          NotificationType.SYSTEM
        )
      ).rejects.toThrow(InvalidNotificationException);
    });

    it('✓ Nên tạo notification với relatedOrderId', async () => {
      // Arrange
      const userId = 'user-123';
      const orderId = 'order-456';

      // Act
      const result = await notificationService.createNotification(
        userId,
        'Order Shipped',
        'Your order is on the way',
        NotificationType.ORDER_SHIPPED,
        orderId
      );

      // Assert
      expect(result.relatedOrderId).toBe(orderId);
    });
  });

  // ====== TEST GROUP 2: getNotificationById ======
  describe('getNotificationById - Lấy notification theo ID', () => {
    
    it('✓ Nên trả về notification khi ID hợp lệ', async () => {
      // Arrange
      const created = await notificationService.createNotification(
        'user-123',
        'Title',
        'Message',
        NotificationType.SYSTEM
      );

      // Act
      const result = await notificationService.getNotificationById(created.id);

      // Assert
      expect(result).toBeDefined();
      expect(result.id).toBe(created.id);
      expect(result.userId).toBe('user-123');
    });

    it('✓ Nên ném lỗi khi ID không tồn tại', async () => {
      // Act & Assert
      await expect(
        notificationService.getNotificationById('non-existent-id')
      ).rejects.toThrow(NotificationNotFoundException);
    });
  });

  // ====== TEST GROUP 3: getInbox ======
  describe('getInbox - Lấy inbox của user', () => {
    
    it('✓ Nên trả về tất cả notification của user', async () => {
      // Arrange
      const userId = 'user-123';
      await notificationService.createNotification(userId, 'Notif 1', 'Message 1', NotificationType.SYSTEM);
      await notificationService.createNotification(userId, 'Notif 2', 'Message 2', NotificationType.PROMOTION);
      await notificationService.createNotification('user-456', 'Notif 3', 'Message 3', NotificationType.SYSTEM);

      // Act
      const result = await notificationService.getInbox(userId);

      // Assert
      expect(result).toHaveLength(2);
      expect(result.every(n => n.userId === userId)).toBe(true);
    });

    it('✓ Nên trả về array rỗng nếu user chưa có notification', async () => {
      // Act
      const result = await notificationService.getInbox('new-user');

      // Assert
      expect(result).toEqual([]);
    });
  });

  // ====== TEST GROUP 4: markAsRead ======
  describe('markAsRead - Đánh dấu notification đã đọc', () => {
    
    it('✓ Nên cập nhật status thành READ', async () => {
      // Arrange
      const created = await notificationService.createNotification(
        'user-123',
        'Title',
        'Message',
        NotificationType.SYSTEM
      );

      // Act
      const result = await notificationService.markAsRead(created.id);

      // Assert
      expect(result.status).toBe(NotificationStatus.READ);
      expect(result.readAt).toBeDefined();
    });

    it('✓ Nên ném lỗi nếu notification không tồn tại', async () => {
      // Act & Assert
      await expect(
        notificationService.markAsRead('non-existent-id')
      ).rejects.toThrow(NotificationNotFoundException);
    });
  });

  // ====== TEST GROUP 5: markAllAsRead ======
  describe('markAllAsRead - Đánh dấu tất cả notification đã đọc', () => {
    
    it('✓ Nên đánh dấu tất cả notification của user là đã đọc', async () => {
      // Arrange
      const userId = 'user-123';
      const n1 = await notificationService.createNotification(userId, 'N1', 'M1', NotificationType.SYSTEM);
      const n2 = await notificationService.createNotification(userId, 'N2', 'M2', NotificationType.SYSTEM);

      // Act
      await notificationService.markAllAsRead(userId);

      // Assert
      const n1Updated = await notificationService.getNotificationById(n1.id);
      const n2Updated = await notificationService.getNotificationById(n2.id);
      expect(n1Updated.status).toBe(NotificationStatus.READ);
      expect(n2Updated.status).toBe(NotificationStatus.READ);
    });
  });

  // ====== TEST GROUP 6: getNotificationStats ======
  describe('getNotificationStats - Lấy thống kê notification', () => {
    
    it('✓ Nên trả về thống kê đúng', async () => {
      // Arrange
      const userId = 'user-123';
      const n1 = await notificationService.createNotification(userId, 'N1', 'M1', NotificationType.SYSTEM);
      const n2 = await notificationService.createNotification(userId, 'N2', 'M2', NotificationType.SYSTEM);
      await notificationService.markAsRead(n1.id);

      // Act
      const stats = await notificationService.getNotificationStats(userId);

      // Assert
      expect(stats.total).toBe(2);
      expect(stats.unread).toBe(1);
      expect(stats.read).toBe(1);
    });
  });

  // ====== TEST GROUP 7: deleteNotification ======
  describe('deleteNotification - Xóa notification', () => {
    
    it('✓ Nên xóa notification thành công', async () => {
      // Arrange
      const created = await notificationService.createNotification(
        'user-123',
        'Title',
        'Message',
        NotificationType.SYSTEM
      );

      // Act
      await notificationService.deleteNotification(created.id);

      // Assert
      await expect(
        notificationService.getNotificationById(created.id)
      ).rejects.toThrow(NotificationNotFoundException);
    });

    it('✓ Nên ném lỗi nếu notification không tồn tại', async () => {
      // Act & Assert
      await expect(
        notificationService.deleteNotification('non-existent-id')
      ).rejects.toThrow(NotificationNotFoundException);
    });
  });

  // ====== TEST GROUP 8: handleOrderPlaced ======
  describe('handleOrderPlaced - Xử lý order placed event từ Kafka', () => {
    
    it('✓ Nên tạo notification khi nhận order placed event', async () => {
      // Arrange
      const orderEvent = {
        userId: 'user-123',
        orderId: 'order-456',
        orderNumber: 'ORD-2026-001',
        totalAmount: 1500000
      };

      // Act
      const result = await notificationService.handleOrderPlaced(orderEvent);

      // Assert
      expect(result).toBeDefined();
      expect(result.userId).toBe('user-123');
      expect(result.relatedOrderId).toBe('order-456');
      expect(result.type).toBe(NotificationType.ORDER_PLACED);
      expect(result.title).toContain('Đơn hàng được tạo thành công');
    });

    it('✓ Nên ném lỗi nếu event thiếu userId', async () => {
      // Arrange
      const orderEvent = {
        orderId: 'order-456',
        orderNumber: 'ORD-2026-001',
        totalAmount: 1500000
      };

      // Act & Assert
      await expect(
        notificationService.handleOrderPlaced(orderEvent)
      ).rejects.toThrow(InvalidNotificationException);
    });
  });

  // ====== TEST GROUP 9: getUnreadCount ======
  describe('getUnreadCount - Lấy tổng số notification chưa đọc', () => {
    
    it('✓ Nên trả về đúng số notification chưa đọc', async () => {
      // Arrange
      const userId = 'user-123';
      const n1 = await notificationService.createNotification(userId, 'N1', 'M1', NotificationType.SYSTEM);
      const n2 = await notificationService.createNotification(userId, 'N2', 'M2', NotificationType.SYSTEM);
      await notificationService.markAsRead(n1.id);

      // Act
      const count = await notificationService.getUnreadCount(userId);

      // Assert
      expect(count).toBe(1);
    });
  });

  // ====== TEST GROUP 10: clearAllNotifications ======
  describe('clearAllNotifications - Xóa tất cả notification', () => {
    
    it('✓ Nên xóa tất cả notification của user', async () => {
      // Arrange
      const userId = 'user-123';
      await notificationService.createNotification(userId, 'N1', 'M1', NotificationType.SYSTEM);
      await notificationService.createNotification(userId, 'N2', 'M2', NotificationType.SYSTEM);

      // Act
      await notificationService.clearAllNotifications(userId);

      // Assert
      const inbox = await notificationService.getInbox(userId);
      expect(inbox).toHaveLength(0);
    });
  });
});
