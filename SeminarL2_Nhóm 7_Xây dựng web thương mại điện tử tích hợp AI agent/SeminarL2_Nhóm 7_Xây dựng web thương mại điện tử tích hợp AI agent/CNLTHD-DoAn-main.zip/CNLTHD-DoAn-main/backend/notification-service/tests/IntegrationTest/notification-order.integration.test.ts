/**
 * Integration Test - Notification Service <-> Order Service
 * 
 * Kiểm thử tương tác giữa notification-service và order-service:
 * - Order Service tạo order
 * - Order Service publish OrderPlaced event lên Kafka
 * - Notification Service consume event từ Kafka
 * - Notification Service tạo notification cho user
 */

import { NotificationService } from '../../src/services/NotificationService';
import { NotificationRepository } from '../../src/repositories/NotificationRepository';
import { OrderService, CreateOrderRequest } from '../../../Order-Service/src/services/OrderService';
import { OrderRepository } from '../../../Order-Service/src/repositories/OrderRepository';
import { NotificationType, NotificationStatus } from '../../src/entities/Notification';
import { OrderStatus, OrderItem } from '../../../Order-Service/src/entities/Order';

describe('Integration Test: Notification <-> Order Service via Kafka', () => {
  let notificationService: NotificationService;
  let notificationRepository: NotificationRepository;
  let orderService: OrderService;
  let orderRepository: OrderRepository;

  beforeEach(() => {
    // Setup notification service
    notificationRepository = new NotificationRepository();
    notificationService = new NotificationService(notificationRepository);

    // Setup order service
    orderRepository = new OrderRepository();
    orderService = new OrderService(orderRepository);
  });

  // ====== TEST GROUP 1: Order Placement Flow ======
  describe('Order Placement Flow - Đơn hàng được tạo và thông báo được gửi', () => {
    
    it('✓ Nên tạo notification khi order được tạo', async () => {
      // Arrange - User tạo order
      const userId = 'user-123';
      const items: OrderItem[] = [
        {
          productId: 'prod-001',
          productName: 'Áo phông nam',
          quantity: 2,
          price: 150000,
          total: 300000
        }
      ];

      const orderRequest: CreateOrderRequest = {
        userId,
        items,
        shippingAddress: '123 Main Street, District 1, HCMC',
        paymentMethod: 'CREDIT_CARD'
      };

      // Act - Order Service tạo order
      const order = await orderService.createOrder(orderRequest);

      // Simulate Kafka event publishing
      const kafkaEvent = {
        userId: order.userId,
        orderId: order.id,
        orderNumber: `ORD-${Date.now()}`,
        totalAmount: order.totalAmount,
        timestamp: new Date().toISOString()
      };

      // Notification Service nhận event từ Kafka listener
      const notification = await notificationService.handleOrderPlaced(kafkaEvent);

      // Assert
      expect(notification).toBeDefined();
      expect(notification.userId).toBe(userId);
      expect(notification.relatedOrderId).toBe(order.id);
      expect(notification.type).toBe(NotificationType.ORDER_PLACED);
      expect(notification.status).toBe(NotificationStatus.UNREAD);

      // Verify notification in repository
      const userNotifications = await notificationService.getInbox(userId);
      expect(userNotifications).toHaveLength(1);
      expect(userNotifications[0].relatedOrderId).toBe(order.id);
    });

    it('✓ Nên xử lý nhiều orders từ cùng một user', async () => {
      // Arrange
      const userId = 'user-456';
      const items: OrderItem[] = [
        {
          productId: 'prod-002',
          productName: 'Quần jeans',
          quantity: 1,
          price: 450000,
          total: 450000
        }
      ];

      const orderRequest: CreateOrderRequest = {
        userId,
        items,
        shippingAddress: 'Address 1',
        paymentMethod: 'BANK_TRANSFER'
      };

      // Act - Tạo order 1
      const order1 = await orderService.createOrder(orderRequest);
      const kafkaEvent1 = {
        userId,
        orderId: order1.id,
        orderNumber: 'ORD-001',
        totalAmount: order1.totalAmount
      };
      const notif1 = await notificationService.handleOrderPlaced(kafkaEvent1);

      // Tạo order 2
      const order2 = await orderService.createOrder(orderRequest);
      const kafkaEvent2 = {
        userId,
        orderId: order2.id,
        orderNumber: 'ORD-002',
        totalAmount: order2.totalAmount
      };
      const notif2 = await notificationService.handleOrderPlaced(kafkaEvent2);

      // Assert
      const userInbox = await notificationService.getInbox(userId);
      expect(userInbox).toHaveLength(2);
      expect(userInbox.every(n => n.userId === userId)).toBe(true);
      expect(userInbox.map(n => n.relatedOrderId)).toEqual([order1.id, order2.id]);
    });

    it('✓ Nên tạo order statistics đúng sau khi order được tạo', async () => {
      // Arrange
      const userId = 'user-789';
      const items1: OrderItem[] = [
        { productId: 'p1', productName: 'Item 1', quantity: 1, price: 100000, total: 100000 }
      ];
      const items2: OrderItem[] = [
        { productId: 'p2', productName: 'Item 2', quantity: 2, price: 250000, total: 500000 }
      ];

      // Act
      const order1 = await orderService.createOrder({
        userId,
        items: items1,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const order2 = await orderService.createOrder({
        userId,
        items: items2,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const stats = await orderService.getUserOrderStats(userId);

      // Assert
      expect(stats.totalOrders).toBe(2);
      expect(stats.totalSpent).toBe(600000);
      expect(stats.pendingOrders).toBe(2);
    });
  });

  // ====== TEST GROUP 2: Notification Management ======
  describe('Notification Management - Quản lý thông báo sau order', () => {
    
    it('✓ Nên đánh dấu notification là đã đọc', async () => {
      // Arrange
      const userId = 'user-abc';
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }
      ];

      const order = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const notification = await notificationService.handleOrderPlaced({
        userId,
        orderId: order.id,
        orderNumber: 'ORD-123',
        totalAmount: order.totalAmount
      });

      // Act
      const marked = await notificationService.markAsRead(notification.id);

      // Assert
      expect(marked.status).toBe(NotificationStatus.READ);
      expect(marked.readAt).toBeDefined();

      // Verify stats
      const stats = await notificationService.getNotificationStats(userId);
      expect(stats.unread).toBe(0);
      expect(stats.read).toBe(1);
    });

    it('✓ Nên lấy unread count đúng', async () => {
      // Arrange
      const userId = 'user-xyz';
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }
      ];

      // Tạo 3 orders
      for (let i = 0; i < 3; i++) {
        const order = await orderService.createOrder({
          userId,
          items,
          shippingAddress: 'Addr',
          paymentMethod: 'CARD'
        });

        await notificationService.handleOrderPlaced({
          userId,
          orderId: order.id,
          orderNumber: `ORD-${i}`,
          totalAmount: order.totalAmount
        });
      }

      // Act & Assert
      let unreadCount = await notificationService.getUnreadCount(userId);
      expect(unreadCount).toBe(3);

      // Mark 1 as read
      const inbox = await notificationService.getInbox(userId);
      await notificationService.markAsRead(inbox[0].id);

      unreadCount = await notificationService.getUnreadCount(userId);
      expect(unreadCount).toBe(2);
    });
  });

  // ====== TEST GROUP 3: Order & Notification Correlation ======
  describe('Order & Notification Correlation - Tương quan giữa order và notification', () => {
    
    it('✓ Nên tìm notification theo relatedOrderId', async () => {
      // Arrange
      const userId = 'user-corr';
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }
      ];

      const order = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const notification = await notificationService.handleOrderPlaced({
        userId,
        orderId: order.id,
        orderNumber: 'ORD-CORR',
        totalAmount: order.totalAmount
      });

      // Act
      const inbox = await notificationService.getInbox(userId);
      const orderNotif = inbox.find(n => n.relatedOrderId === order.id);

      // Assert
      expect(orderNotif).toBeDefined();
      expect(orderNotif?.id).toBe(notification.id);
      expect(orderNotif?.relatedOrderId).toBe(order.id);
    });

    it('✓ Nên xóa order notification khi order bị hủy', async () => {
      // Arrange
      const userId = 'user-del';
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }
      ];

      const order = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const notification = await notificationService.handleOrderPlaced({
        userId,
        orderId: order.id,
        orderNumber: 'ORD-DEL',
        totalAmount: order.totalAmount
      });

      // Act - Cancel order
      await orderService.cancelOrder(order.id);
      
      // Simulate notification deletion (in real scenario, order cancellation event would trigger this)
      await notificationService.deleteNotification(notification.id);

      // Assert
      const inbox = await notificationService.getInbox(userId);
      expect(inbox.length).toBe(0);
    });
  });

  // ====== TEST GROUP 4: Error Handling ======
  describe('Error Handling - Xử lý lỗi', () => {
    
    it('✓ Nên xử lý Kafka event lỗi không gây sập service', async () => {
      // Arrange - Invalid event missing userId
      const invalidEvent = {
        orderId: 'order-123',
        orderNumber: 'ORD-ERR',
        totalAmount: 100000
      };

      // Act & Assert
      try {
        await notificationService.handleOrderPlaced(invalidEvent);
        fail('Should have thrown error');
      } catch (error: any) {
        expect(error.message).toContain('Missing userId');
      }

      // Service should still work for valid events
      const userId = 'user-error-test';
      const items: OrderItem[] = [
        { productId: 'p1', productName: 'Item', quantity: 1, price: 100000, total: 100000 }
      ];

      const order = await orderService.createOrder({
        userId,
        items,
        shippingAddress: 'Addr',
        paymentMethod: 'CARD'
      });

      const validEvent = {
        userId,
        orderId: order.id,
        orderNumber: 'ORD-VALID',
        totalAmount: order.totalAmount
      };

      const notification = await notificationService.handleOrderPlaced(validEvent);
      expect(notification).toBeDefined();
    });
  });
});
