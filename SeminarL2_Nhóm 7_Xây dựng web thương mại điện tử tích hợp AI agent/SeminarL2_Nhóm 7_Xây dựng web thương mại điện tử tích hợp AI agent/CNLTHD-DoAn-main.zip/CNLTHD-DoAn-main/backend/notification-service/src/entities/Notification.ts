/**
 * Notification Entity
 * Đại diện cho một thông báo trong hệ thống
 */
export enum NotificationStatus {
  UNREAD = 'UNREAD',
  READ = 'READ',
  ARCHIVED = 'ARCHIVED'
}

export enum NotificationType {
  ORDER_PLACED = 'ORDER_PLACED',
  ORDER_SHIPPED = 'ORDER_SHIPPED',
  ORDER_DELIVERED = 'ORDER_DELIVERED',
  PAYMENT_CONFIRMED = 'PAYMENT_CONFIRMED',
  SYSTEM = 'SYSTEM',
  PROMOTION = 'PROMOTION'
}

export class Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  status: NotificationStatus;
  relatedOrderId?: string;
  relatedProductId?: string;
  createdAt: Date;
  updatedAt: Date;
  readAt?: Date;
  emailSent: boolean;

  constructor(data: Partial<Notification>) {
    Object.assign(this, data);
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
    this.status = data.status || NotificationStatus.UNREAD;
    this.emailSent = data.emailSent || false;
  }
}
