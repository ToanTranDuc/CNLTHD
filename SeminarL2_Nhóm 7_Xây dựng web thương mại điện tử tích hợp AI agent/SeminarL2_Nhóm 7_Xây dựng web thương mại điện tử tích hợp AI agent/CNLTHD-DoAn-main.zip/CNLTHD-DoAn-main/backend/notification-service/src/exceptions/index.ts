/**
 * Custom Exceptions for Notification Service
 */

export class NotificationNotFoundException extends Error {
  constructor(message: string = 'Notification not found') {
    super(message);
    this.name = 'NotificationNotFoundException';
  }
}

export class NotificationServiceException extends Error {
  constructor(message: string = 'Notification service error') {
    super(message);
    this.name = 'NotificationServiceException';
  }
}

export class InvalidNotificationException extends Error {
  constructor(message: string = 'Invalid notification data') {
    super(message);
    this.name = 'InvalidNotificationException';
  }
}

export class EmailSendFailedException extends Error {
  constructor(message: string = 'Failed to send email') {
    super(message);
    this.name = 'EmailSendFailedException';
  }
}
