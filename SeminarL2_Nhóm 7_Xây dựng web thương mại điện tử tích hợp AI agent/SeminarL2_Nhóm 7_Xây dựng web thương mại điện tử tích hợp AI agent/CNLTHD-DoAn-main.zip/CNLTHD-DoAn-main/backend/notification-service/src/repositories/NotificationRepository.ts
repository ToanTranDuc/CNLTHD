/**
 * NotificationRepository
 * Quản lý lưu trữ và truy vấn dữ liệu Notification
 */

import { Notification, NotificationStatus } from '../entities/Notification';
import { v4 as uuidv4 } from 'uuid';

export class NotificationRepository {
  private notifications: Map<string, Notification> = new Map();

  /**
   * Tạo notification mới
   */
  async create(notification: Partial<Notification>): Promise<Notification> {
    const id = uuidv4();
    const newNotification = new Notification({
      ...notification,
      id
    });
    this.notifications.set(id, newNotification);
    return newNotification;
  }

  /**
   * Tìm notification theo ID
   */
  async findById(id: string): Promise<Notification | null> {
    return this.notifications.get(id) || null;
  }

  /**
   * Lấy tất cả notification của user
   */
  async findByUserId(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(n => n.userId === userId);
  }

  /**
   * Lấy notification chưa đọc của user
   */
  async findUnreadByUserId(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      n => n.userId === userId && n.status === NotificationStatus.UNREAD
    );
  }

  /**
   * Cập nhật notification
   */
  async update(id: string, data: Partial<Notification>): Promise<Notification> {
    const notification = this.notifications.get(id);
    if (!notification) {
      throw new Error('Notification not found');
    }
    Object.assign(notification, data, { updatedAt: new Date() });
    this.notifications.set(id, notification);
    return notification;
  }

  /**
   * Xóa notification
   */
  async delete(id: string): Promise<void> {
    this.notifications.delete(id);
  }

  /**
   * Xóa tất cả notification của user
   */
  async deleteByUserId(userId: string): Promise<void> {
    const idsToDelete = Array.from(this.notifications.entries())
      .filter(([_, n]) => n.userId === userId)
      .map(([id, _]) => id);
    idsToDelete.forEach(id => this.notifications.delete(id));
  }

  /**
   * Lấy tổng số notification chưa đọc
   */
  async getUnreadCount(userId: string): Promise<number> {
    return Array.from(this.notifications.values()).filter(
      n => n.userId === userId && n.status === NotificationStatus.UNREAD
    ).length;
  }
}
