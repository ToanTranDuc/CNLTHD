package com.CNLTHD.Notification_Service.repository;

import com.CNLTHD.Notification_Service.entity.Notification;
import com.CNLTHD.Notification_Service.entity.enums.NotificationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface NotificationRepository extends JpaRepository<Notification, UUID> {

    Page<Notification> findByRecipientUserIdOrderByCreatedAtDesc(String recipientUserId, Pageable pageable);

    Page<Notification> findByRecipientUserIdAndStatusOrderByCreatedAtDesc(String recipientUserId, NotificationStatus status, Pageable pageable);

    long countByRecipientUserIdAndStatusNot(String recipientUserId, NotificationStatus status);

    long countByRecipientUserId(String recipientUserId);

    Optional<Notification> findByIdAndRecipientUserId(UUID id, String recipientUserId);

    Optional<Notification> findByDedupKey(String dedupKey);

    long countByRecipientUserIdAndStatus(String recipientUserId, NotificationStatus status);
}