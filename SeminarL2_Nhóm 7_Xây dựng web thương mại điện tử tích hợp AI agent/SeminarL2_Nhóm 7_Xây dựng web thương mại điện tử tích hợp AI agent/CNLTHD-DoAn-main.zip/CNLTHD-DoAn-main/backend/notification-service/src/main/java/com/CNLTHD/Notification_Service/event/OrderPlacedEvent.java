package com.CNLTHD.Notification_Service.event;

import java.time.Instant;

public record OrderPlacedEvent(String orderNumber, String customerId, String recipientEmail, Instant createdAt) {
}