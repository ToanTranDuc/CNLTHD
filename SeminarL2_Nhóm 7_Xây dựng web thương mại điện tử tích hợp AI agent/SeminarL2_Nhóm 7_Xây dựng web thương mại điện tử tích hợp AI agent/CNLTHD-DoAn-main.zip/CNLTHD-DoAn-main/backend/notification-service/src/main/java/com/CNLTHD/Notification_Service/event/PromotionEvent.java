package com.CNLTHD.Notification_Service.event;

import java.time.Instant;
import java.util.List;

/**
 * Promotion / marketing campaign event.
 * If recipientUserIds is null or empty, the promotion is broadcast to "broadcast".
 */
public record PromotionEvent(
        String promotionId,
        String title,
        String message,
        List<String> recipientUserIds,
        Instant timestamp
) {}
