package com.CNLTHD.Notification_Service.dto;

public record NotificationStatsResponse(long unreadCount, long totalCount) {
}