package com.CNLTHD.Notification_Service.service.impl;

import com.CNLTHD.Notification_Service.entity.Notification;
import com.CNLTHD.Notification_Service.entity.enums.NotificationChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class NotificationEmailSender {

    private static final Logger log = LoggerFactory.getLogger(NotificationEmailSender.class);

    private final ObjectProvider<JavaMailSender> mailSenderProvider;

    @Value("${notification.delivery.email-enabled:false}")
    private boolean emailEnabled;

    @Value("${notification.delivery.from-address:no-reply@cnlthd.local}")
    private String fromAddress;

    public NotificationEmailSender(ObjectProvider<JavaMailSender> mailSenderProvider) {
        this.mailSenderProvider = mailSenderProvider;
    }

    public void sendIfNeeded(Notification notification) {
        if (!emailEnabled) {
            return;
        }

        if (notification.getChannel() == NotificationChannel.IN_APP || notification.getRecipientEmail() == null || notification.getRecipientEmail().isBlank()) {
            return;
        }

        JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
        if (mailSender == null) {
            log.warn("JavaMailSender is not configured. Skip email delivery for notification {}", notification.getId());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromAddress);
            message.setTo(notification.getRecipientEmail());
            message.setSubject(notification.getTitle());
            message.setText(notification.getMessage());
            mailSender.send(message);
            log.info("Email notification sent for {}", notification.getId());
        } catch (Exception ex) {
            log.warn("Failed to send email for notification {}: {}", notification.getId(), ex.getMessage());
        }
    }
}