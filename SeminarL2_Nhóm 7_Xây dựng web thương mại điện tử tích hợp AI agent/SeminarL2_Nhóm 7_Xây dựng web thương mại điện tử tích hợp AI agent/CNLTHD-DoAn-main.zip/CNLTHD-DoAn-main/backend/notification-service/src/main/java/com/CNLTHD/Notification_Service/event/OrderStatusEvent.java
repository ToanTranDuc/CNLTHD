package com.CNLTHD.Notification_Service.event;

import java.time.Instant;

public record OrderStatusEvent(
        String action,
        String orderNumber,
        String customerId,
        String recipientEmail,
        Instant timestamp
) {}
