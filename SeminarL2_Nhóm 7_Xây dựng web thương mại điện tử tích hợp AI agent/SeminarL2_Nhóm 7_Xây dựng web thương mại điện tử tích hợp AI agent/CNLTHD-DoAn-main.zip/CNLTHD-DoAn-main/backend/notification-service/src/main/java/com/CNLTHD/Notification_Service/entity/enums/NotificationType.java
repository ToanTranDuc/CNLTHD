package com.CNLTHD.Notification_Service.entity.enums;

public enum NotificationType {
    SYSTEM,
    ORDER,
    ACCOUNT,
    PROMOTION
}