package com.CNLTHD.Notification_Service.dto;

import com.CNLTHD.Notification_Service.entity.enums.NotificationChannel;
import com.CNLTHD.Notification_Service.entity.enums.NotificationType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record NotificationCreateRequest(
        @NotBlank String recipientUserId,
        String recipientEmail,
        @NotBlank String title,
        @NotBlank String message,
        @NotNull NotificationType type,
        @NotNull NotificationChannel channel) {
}