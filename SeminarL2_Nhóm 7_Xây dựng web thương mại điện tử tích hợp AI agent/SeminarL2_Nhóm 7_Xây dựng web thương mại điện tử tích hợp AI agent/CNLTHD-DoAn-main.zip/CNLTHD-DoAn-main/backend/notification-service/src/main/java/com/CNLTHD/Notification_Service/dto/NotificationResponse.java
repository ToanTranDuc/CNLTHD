package com.CNLTHD.Notification_Service.dto;

import com.CNLTHD.Notification_Service.entity.Notification;
import com.CNLTHD.Notification_Service.entity.enums.NotificationChannel;
import com.CNLTHD.Notification_Service.entity.enums.NotificationStatus;
import com.CNLTHD.Notification_Service.entity.enums.NotificationType;

import java.time.Instant;
import java.util.UUID;

public record NotificationResponse(
        UUID id,
        String recipientUserId,
        String recipientEmail,
        String title,
        String message,
        NotificationType type,
        NotificationStatus status,
        NotificationChannel channel,
        Instant createdAt,
        Instant deliveredAt,
        Instant readAt) {

    public static NotificationResponse from(Notification notification) {
        return new NotificationResponse(
                notification.getId(),
                notification.getRecipientUserId(),
                notification.getRecipientEmail(),
                notification.getTitle(),
                notification.getMessage(),
                notification.getType(),
                notification.getStatus(),
                notification.getChannel(),
                notification.getCreatedAt(),
                notification.getDeliveredAt(),
                notification.getReadAt());
    }
}