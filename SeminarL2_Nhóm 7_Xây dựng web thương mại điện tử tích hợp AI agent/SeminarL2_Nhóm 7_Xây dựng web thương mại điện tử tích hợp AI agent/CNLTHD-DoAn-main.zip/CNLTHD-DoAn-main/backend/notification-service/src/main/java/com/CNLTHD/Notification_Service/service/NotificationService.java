package com.CNLTHD.Notification_Service.service;

import com.CNLTHD.Notification_Service.dto.NotificationCreateRequest;
import com.CNLTHD.Notification_Service.dto.NotificationListResponse;
import com.CNLTHD.Notification_Service.dto.NotificationResponse;
import com.CNLTHD.Notification_Service.dto.NotificationStatsResponse;
import com.CNLTHD.Notification_Service.event.OrderPlacedEvent;
import com.CNLTHD.Notification_Service.event.OrderStatusEvent;
import com.CNLTHD.Notification_Service.event.UserEvent;
import com.CNLTHD.Notification_Service.event.PromotionEvent;

import java.util.UUID;

public interface NotificationService {

    NotificationResponse createNotification(NotificationCreateRequest request);

    NotificationListResponse getInbox(String recipientUserId, String status, int page, int size);

    NotificationStatsResponse getStats(String recipientUserId);

    NotificationResponse markAsRead(UUID id, String recipientUserId);

    NotificationStatsResponse markAllAsRead(String recipientUserId);

    void delete(UUID id, String recipientUserId);

    void handleOrderPlaced(OrderPlacedEvent event);

    void handleOrderStatusChanged(OrderStatusEvent event);

    void handleUserEvent(UserEvent event);

    void handlePromotionEvent(PromotionEvent event);
}