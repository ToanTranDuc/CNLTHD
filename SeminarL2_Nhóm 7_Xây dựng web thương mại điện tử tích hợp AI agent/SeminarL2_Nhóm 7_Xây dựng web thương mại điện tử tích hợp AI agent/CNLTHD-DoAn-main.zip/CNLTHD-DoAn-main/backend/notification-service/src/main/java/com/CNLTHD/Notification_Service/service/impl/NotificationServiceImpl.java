package com.CNLTHD.Notification_Service.service.impl;

import com.CNLTHD.Notification_Service.dto.NotificationCreateRequest;
import com.CNLTHD.Notification_Service.dto.NotificationListResponse;
import com.CNLTHD.Notification_Service.dto.NotificationResponse;
import com.CNLTHD.Notification_Service.dto.NotificationStatsResponse;
import com.CNLTHD.Notification_Service.entity.Notification;
import com.CNLTHD.Notification_Service.entity.enums.NotificationChannel;
import com.CNLTHD.Notification_Service.entity.enums.NotificationStatus;
import com.CNLTHD.Notification_Service.entity.enums.NotificationType;
import com.CNLTHD.Notification_Service.event.OrderPlacedEvent;
import com.CNLTHD.Notification_Service.event.OrderStatusEvent;
import com.CNLTHD.Notification_Service.exception.NotificationNotFoundException;
import com.CNLTHD.Notification_Service.repository.NotificationRepository;
import com.CNLTHD.Notification_Service.service.NotificationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final NotificationEmailSender emailSender;

    public NotificationServiceImpl(NotificationRepository notificationRepository, NotificationEmailSender emailSender) {
        this.notificationRepository = notificationRepository;
        this.emailSender = emailSender;
    }

    @Override
    @Transactional
    public NotificationResponse createNotification(NotificationCreateRequest request) {
        Notification notification = new Notification();
        notification.setRecipientUserId(request.recipientUserId());
        notification.setRecipientEmail(request.recipientEmail());
        notification.setTitle(request.title());
        notification.setMessage(request.message());
        notification.setType(request.type());
        notification.setChannel(request.channel());
        notification.setStatus(NotificationStatus.DELIVERED);
        notification.setDeliveredAt(Instant.now());
        // Ad-hoc REST creates must always insert (no silent dedup) — add timestamp to make key unique.
        notification.setDedupKey(buildDedupKey(request.recipientUserId(), request.title(), request.message(), request.type())
                + ":" + Instant.now().toEpochMilli());

        Notification saved = notificationRepository.save(notification);
        emailSender.sendIfNeeded(saved);
        return NotificationResponse.from(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public NotificationListResponse getInbox(String recipientUserId, String status, int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100));
        Page<Notification> notifications;
        if (status == null || status.isBlank()) {
            notifications = notificationRepository.findByRecipientUserIdOrderByCreatedAtDesc(recipientUserId, pageable);
        } else {
            NotificationStatus notificationStatus = NotificationStatus.valueOf(status.toUpperCase());
            notifications = notificationRepository.findByRecipientUserIdAndStatusOrderByCreatedAtDesc(recipientUserId, notificationStatus, pageable);
        }

        return new NotificationListResponse(
                notifications.map(NotificationResponse::from).getContent(),
                notifications.getNumber(),
                notifications.getSize(),
                notifications.getTotalElements(),
                notifications.getTotalPages(),
                notificationRepository.countByRecipientUserIdAndStatusNot(recipientUserId, NotificationStatus.READ)
        );
    }

    @Override
    @Transactional(readOnly = true)
    public NotificationStatsResponse getStats(String recipientUserId) {
        long unread = notificationRepository.countByRecipientUserIdAndStatusNot(recipientUserId, NotificationStatus.READ);
        long total = notificationRepository.countByRecipientUserId(recipientUserId);
        return new NotificationStatsResponse(unread, total);
    }

    @Override
    @Transactional
    public NotificationResponse markAsRead(UUID id, String recipientUserId) {
        Notification notification = getOwnedNotification(id, recipientUserId);
        notification.setStatus(NotificationStatus.READ);
        notification.setReadAt(Instant.now());
        return NotificationResponse.from(notificationRepository.save(notification));
    }

    @Override
    @Transactional
    public NotificationStatsResponse markAllAsRead(String recipientUserId) {
        Page<Notification> page = notificationRepository.findByRecipientUserIdOrderByCreatedAtDesc(recipientUserId, PageRequest.of(0, 1000));
        page.forEach(notification -> {
            if (notification.getStatus() != NotificationStatus.READ) {
                notification.setStatus(NotificationStatus.READ);
                notification.setReadAt(Instant.now());
            }
        });
        notificationRepository.saveAll(page.getContent());
        return getStats(recipientUserId);
    }

    @Override
    @Transactional
    public void delete(UUID id, String recipientUserId) {
        Notification notification = getOwnedNotification(id, recipientUserId);
        notificationRepository.delete(notification);
    }

    @Override
    @Transactional
    public void handleOrderPlaced(OrderPlacedEvent event) {
        String recipientUserId = event.customerId() == null || event.customerId().isBlank() ? "guest" : event.customerId();
        String dedupKey = "order-placed:" + event.orderNumber() + ":" + recipientUserId;

        if (notificationRepository.findByDedupKey(dedupKey).isPresent()) {
            return;
        }

        Notification notification = new Notification();
        notification.setRecipientUserId(recipientUserId);
        notification.setRecipientEmail(event.recipientEmail());
        notification.setTitle("Đơn hàng đã được tạo");
        notification.setMessage("Đơn hàng " + event.orderNumber() + " đã được tạo thành công lúc " + event.createdAt() + ".");
        notification.setType(NotificationType.ORDER);
        notification.setChannel(event.recipientEmail() == null || event.recipientEmail().isBlank()
            ? NotificationChannel.IN_APP
            : NotificationChannel.BOTH);
        notification.setStatus(NotificationStatus.DELIVERED);
        notification.setDeliveredAt(Instant.now());
        notification.setDedupKey(dedupKey);

        notificationRepository.save(notification);
    }

    @Override
    @Transactional
    public void handleOrderStatusChanged(OrderStatusEvent event) {
        String recipientUserId = event.customerId() == null || event.customerId().isBlank() ? "guest" : event.customerId();
        String dedupKey = "order-" + event.action() + ":" + event.orderNumber() + ":" + recipientUserId;

        if (notificationRepository.findByDedupKey(dedupKey).isPresent()) {
            return;
        }

        Notification notification = new Notification();
        notification.setRecipientUserId(recipientUserId);
        notification.setRecipientEmail(event.recipientEmail());
        notification.setTitle(titleFor(event.action()));
        notification.setMessage(messageFor(event.action(), event.orderNumber()));
        notification.setType(NotificationType.ORDER);
        notification.setChannel(event.recipientEmail() == null || event.recipientEmail().isBlank()
                ? NotificationChannel.IN_APP : NotificationChannel.BOTH);
        notification.setStatus(NotificationStatus.DELIVERED);
        notification.setDeliveredAt(Instant.now());
        notification.setDedupKey(dedupKey);

        notificationRepository.save(notification);
    }

    private String titleFor(String action) {
        return switch (action) {
            case "CONFIRMED" -> "Đơn hàng đã được xác nhận";
            case "PROCESSING" -> "Đơn hàng đang được chuẩn bị";
            case "SHIPPED" -> "Đơn hàng đã được giao cho đơn vị vận chuyển";
            case "DELIVERED" -> "Đơn hàng đã được giao thành công";
            case "CANCELLED" -> "Đơn hàng đã bị huỷ";
            case "RETURNED" -> "Đơn hàng đã được trả lại";
            default -> "Cập nhật trạng thái đơn hàng";
        };
    }

    private String messageFor(String action, String orderNumber) {
        return switch (action) {
            case "CONFIRMED" -> "Đơn hàng " + orderNumber + " đã được xác nhận và sẽ sớm được chuẩn bị.";
            case "PROCESSING" -> "Đơn hàng " + orderNumber + " đang được chuẩn bị để giao.";
            case "SHIPPED" -> "Đơn hàng " + orderNumber + " đã được giao cho đơn vị vận chuyển.";
            case "DELIVERED" -> "Đơn hàng " + orderNumber + " đã được giao đến địa chỉ của bạn.";
            case "CANCELLED" -> "Đơn hàng " + orderNumber + " đã bị huỷ. Tiền sẽ được hoàn lại nếu đã thanh toán.";
            case "RETURNED" -> "Đơn hàng " + orderNumber + " đã được trả lại.";
            default -> "Đơn hàng " + orderNumber + " có cập nhật trạng thái: " + action;
        };
    }

    @Override
    @Transactional
    public void handleUserEvent(com.CNLTHD.Notification_Service.event.UserEvent event) {
        String dedupKey = "user-" + event.action() + ":" + event.userId() + ":" + (event.timestamp() != null ? event.timestamp().toEpochMilli() : 0);
        if (notificationRepository.findByDedupKey(dedupKey).isPresent()) return;

        Notification n = new Notification();
        n.setRecipientUserId(event.userId());
        n.setRecipientEmail(event.email());
        n.setTitle(switch (event.action()) {
            case "REGISTERED" -> "Chào mừng đến với CNLTHD!";
            case "PASSWORD_RESET" -> "Mật khẩu đã được đặt lại";
            case "PASSWORD_RESET_REQUESTED" -> "Yêu cầu đặt lại mật khẩu";
            case "PROFILE_UPDATED" -> "Hồ sơ đã được cập nhật";
            default -> "Thông báo tài khoản";
        });
        n.setMessage(switch (event.action()) {
            case "REGISTERED" -> "Cảm ơn bạn đã đăng ký tài khoản! Hãy khám phá các sản phẩm thời trang mới nhất.";
            case "PASSWORD_RESET" -> "Mật khẩu của tài khoản bạn đã được thay đổi thành công.";
            case "PASSWORD_RESET_REQUESTED" -> "Chúng tôi đã nhận được yêu cầu đặt lại mật khẩu. Vui lòng kiểm tra email.";
            case "PROFILE_UPDATED" -> "Thông tin hồ sơ của bạn đã được cập nhật.";
            default -> "Có cập nhật mới trong tài khoản của bạn.";
        });
        n.setType(NotificationType.ACCOUNT);
        n.setChannel(event.email() == null || event.email().isBlank() ? NotificationChannel.IN_APP : NotificationChannel.BOTH);
        n.setStatus(NotificationStatus.DELIVERED);
        n.setDeliveredAt(Instant.now());
        n.setDedupKey(dedupKey);
        notificationRepository.save(n);
    }

    @Override
    @Transactional
    public void handlePromotionEvent(com.CNLTHD.Notification_Service.event.PromotionEvent event) {
        // Broadcast to all recipients in the list (or 'broadcast' as a marker)
        for (String userId : (event.recipientUserIds() != null ? event.recipientUserIds() : java.util.List.<String>of("broadcast"))) {
            String dedupKey = "promo:" + event.promotionId() + ":" + userId;
            if (notificationRepository.findByDedupKey(dedupKey).isPresent()) continue;

            Notification n = new Notification();
            n.setRecipientUserId(userId);
            n.setRecipientEmail(null);
            n.setTitle(event.title() != null ? event.title() : "Ưu đãi mới đang chờ bạn!");
            n.setMessage(event.message() != null ? event.message() : "Đừng bỏ lỡ ưu đãi mới từ CNLTHD.");
            n.setType(NotificationType.PROMOTION);
            n.setChannel(NotificationChannel.IN_APP);
            n.setStatus(NotificationStatus.DELIVERED);
            n.setDeliveredAt(Instant.now());
            n.setDedupKey(dedupKey);
            notificationRepository.save(n);
        }
    }

    private Notification getOwnedNotification(UUID id, String recipientUserId) {
        return notificationRepository.findByIdAndRecipientUserId(id, recipientUserId)
                .orElseThrow(() -> new NotificationNotFoundException("Notification not found"));
    }

    private String buildDedupKey(String recipientUserId, String title, String message, NotificationType type) {
        return type + ":" + recipientUserId + ":" + Integer.toHexString((title + message).hashCode());
    }
}