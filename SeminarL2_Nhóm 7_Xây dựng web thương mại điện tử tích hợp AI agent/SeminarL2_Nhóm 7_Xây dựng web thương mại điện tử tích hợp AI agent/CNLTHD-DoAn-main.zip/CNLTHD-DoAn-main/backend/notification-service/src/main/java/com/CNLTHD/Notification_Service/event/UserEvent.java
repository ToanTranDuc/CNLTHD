package com.CNLTHD.Notification_Service.event;

import java.time.Instant;

/**
 * Account lifecycle event.
 * action ∈ {REGISTERED, PASSWORD_RESET, PASSWORD_RESET_REQUESTED, PROFILE_UPDATED}
 */
public record UserEvent(
        String action,
        String userId,
        String email,
        String fullName,
        Instant timestamp
) {}
