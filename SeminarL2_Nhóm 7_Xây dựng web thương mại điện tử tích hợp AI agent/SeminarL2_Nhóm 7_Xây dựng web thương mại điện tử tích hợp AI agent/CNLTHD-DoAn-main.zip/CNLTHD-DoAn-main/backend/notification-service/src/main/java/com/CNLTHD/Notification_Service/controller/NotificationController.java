package com.CNLTHD.Notification_Service.controller;

import com.CNLTHD.Notification_Service.dto.ApiResponse;
import com.CNLTHD.Notification_Service.dto.NotificationCreateRequest;
import com.CNLTHD.Notification_Service.dto.NotificationListResponse;
import com.CNLTHD.Notification_Service.dto.NotificationResponse;
import com.CNLTHD.Notification_Service.dto.NotificationStatsResponse;
import com.CNLTHD.Notification_Service.security.JwtTokenResolver;
import com.CNLTHD.Notification_Service.service.NotificationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationController {

    private final NotificationService notificationService;
    private final JwtTokenResolver jwtTokenResolver;

    public NotificationController(NotificationService notificationService, JwtTokenResolver jwtTokenResolver) {
        this.notificationService = notificationService;
        this.jwtTokenResolver = jwtTokenResolver;
    }

    @PostMapping
    public ResponseEntity<ApiResponse<NotificationResponse>> create(@Valid @RequestBody NotificationCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Notification created", notificationService.createNotification(request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<NotificationListResponse>> inbox(
            HttpServletRequest request,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        String recipientUserId = resolveUserId(request, userId);
        return ResponseEntity.ok(ApiResponse.success("Notification inbox", notificationService.getInbox(recipientUserId, status, page, size)));
    }

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<NotificationStatsResponse>> stats(
            HttpServletRequest request,
            @RequestParam(required = false) String userId) {
        String recipientUserId = resolveUserId(request, userId);
        return ResponseEntity.ok(ApiResponse.success("Notification stats", notificationService.getStats(recipientUserId)));
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<ApiResponse<NotificationResponse>> markAsRead(
            HttpServletRequest request,
            @PathVariable UUID id,
            @RequestParam(required = false) String recipientUserId) {
        String ownerId = resolveUserId(request, recipientUserId);
        return ResponseEntity.ok(ApiResponse.success("Notification marked as read", notificationService.markAsRead(id, ownerId)));
    }

    @PatchMapping("/read-all")
    public ResponseEntity<ApiResponse<NotificationStatsResponse>> markAllAsRead(
            HttpServletRequest request,
            @RequestParam(required = false) String userId) {
        String recipientUserId = resolveUserId(request, userId);
        return ResponseEntity.ok(ApiResponse.success("All notifications marked as read", notificationService.markAllAsRead(recipientUserId)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(
            HttpServletRequest request,
            @PathVariable UUID id,
            @RequestParam(required = false) String recipientUserId) {
        String ownerId = resolveUserId(request, recipientUserId);
        notificationService.delete(id, ownerId);
        return ResponseEntity.ok(ApiResponse.success("Notification deleted"));
    }

    private String resolveUserId(HttpServletRequest request, String fallbackUserId) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            if (jwtTokenResolver.validateToken(token)) {
                String fromJwt = jwtTokenResolver.getUserIdFromToken(token);
                org.slf4j.LoggerFactory.getLogger(NotificationController.class)
                        .info("Resolved userId from JWT: {}", fromJwt);
                return fromJwt;
            } else {
                org.slf4j.LoggerFactory.getLogger(NotificationController.class)
                        .warn("JWT validation failed; falling back to query param");
            }
        }

        if (fallbackUserId != null && !fallbackUserId.isBlank()) {
            org.slf4j.LoggerFactory.getLogger(NotificationController.class)
                    .info("Using userId from fallback param: {}", fallbackUserId);
            return fallbackUserId;
        }

        throw new IllegalArgumentException("Missing or invalid JWT token, and no userId provided");
    }
}