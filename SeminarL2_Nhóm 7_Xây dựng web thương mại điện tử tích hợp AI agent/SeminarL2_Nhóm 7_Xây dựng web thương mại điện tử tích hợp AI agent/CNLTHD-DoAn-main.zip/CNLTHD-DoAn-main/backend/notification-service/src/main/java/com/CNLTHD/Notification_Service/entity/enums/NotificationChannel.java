package com.CNLTHD.Notification_Service.entity.enums;

public enum NotificationChannel {
    IN_APP,
    EMAIL,
    BOTH
}