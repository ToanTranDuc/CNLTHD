package com.CNLTHD.Notification_Service.entity.enums;

public enum NotificationStatus {
    CREATED,
    DELIVERED,
    READ,
    FAILED
}