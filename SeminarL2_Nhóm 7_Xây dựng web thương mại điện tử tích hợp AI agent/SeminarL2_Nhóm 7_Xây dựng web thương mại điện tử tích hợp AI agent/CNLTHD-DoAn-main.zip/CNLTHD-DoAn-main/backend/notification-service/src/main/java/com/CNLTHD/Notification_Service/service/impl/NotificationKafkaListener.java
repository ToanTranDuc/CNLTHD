package com.CNLTHD.Notification_Service.service.impl;

import com.CNLTHD.Notification_Service.event.OrderPlacedEvent;
import com.CNLTHD.Notification_Service.event.OrderStatusEvent;
import com.CNLTHD.Notification_Service.event.PromotionEvent;
import com.CNLTHD.Notification_Service.event.UserEvent;
import com.CNLTHD.Notification_Service.service.NotificationService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class NotificationKafkaListener {

    private static final Logger log = LoggerFactory.getLogger(NotificationKafkaListener.class);

    private final ObjectMapper objectMapper;
    private final NotificationService notificationService;

    public NotificationKafkaListener(ObjectMapper objectMapper, NotificationService notificationService) {
        this.objectMapper = objectMapper;
        this.notificationService = notificationService;
    }

    /**
     * Order events come on the main notification topic. Distinguishes by JSON shape:
     *  - has "action" field → OrderStatusEvent
     *  - otherwise → OrderPlacedEvent (legacy)
     */
    @KafkaListener(topics = "${notification.kafka.topics.order-placed}", groupId = "notification-service-group")
    public void onOrderEvent(String payload) throws Exception {
        JsonNode root = objectMapper.readTree(payload);
        if (root.hasNonNull("action")) {
            OrderStatusEvent event = objectMapper.treeToValue(root, OrderStatusEvent.class);
            log.info("Received order status event {} for order {}", event.action(), event.orderNumber());
            notificationService.handleOrderStatusChanged(event);
        } else {
            OrderPlacedEvent event = objectMapper.treeToValue(root, OrderPlacedEvent.class);
            log.info("Received order placed event for order {}", event.orderNumber());
            notificationService.handleOrderPlaced(event);
        }
    }

    /** User account events: registration, password reset, profile update. */
    @KafkaListener(topics = "${notification.kafka.topics.user-events:userEventsTopic}", groupId = "notification-service-user-group")
    public void onUserEvent(String payload) throws Exception {
        UserEvent event = objectMapper.readValue(payload, UserEvent.class);
        log.info("Received user event {} for user {}", event.action(), event.userId());
        notificationService.handleUserEvent(event);
    }

    /** Promotion / marketing campaign events. */
    @KafkaListener(topics = "${notification.kafka.topics.promotion:promotionTopic}", groupId = "notification-service-promo-group")
    public void onPromotionEvent(String payload) throws Exception {
        PromotionEvent event = objectMapper.readValue(payload, PromotionEvent.class);
        log.info("Received promotion event {}", event.promotionId());
        notificationService.handlePromotionEvent(event);
    }
}
