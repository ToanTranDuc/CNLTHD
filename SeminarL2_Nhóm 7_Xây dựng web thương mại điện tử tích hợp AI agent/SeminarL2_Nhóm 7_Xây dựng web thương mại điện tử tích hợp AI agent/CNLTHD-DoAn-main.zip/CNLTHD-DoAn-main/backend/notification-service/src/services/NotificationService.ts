/**
 * NotificationService
 * Xử lý logic kinh doanh cho Notification
 */

import { Notification, NotificationStatus, NotificationType } from '../entities/Notification';
import { NotificationRepository } from '../repositories/NotificationRepository';
import {
  NotificationNotFoundException,
  InvalidNotificationException
} from '../exceptions';

export class NotificationService {
  constructor(private notificationRepository: NotificationRepository) {}

  /**
   * Tạo notification mới cho user
   */
  async createNotification(
    userId: string,
    title: string,
    message: string,
    type: NotificationType,
    relatedOrderId?: string
  ): Promise<Notification> {
    if (!userId || !title || !message) {
      throw new InvalidNotificationException('Missing required notification fields');
    }

    return await this.notificationRepository.create({
      userId,
      title,
      message,
      type,
      relatedOrderId,
      status: NotificationStatus.UNREAD,
      emailSent: false
    });
  }

  /**
   * Lấy notification theo ID
   */
  async getNotificationById(id: string): Promise<Notification> {
    const notification = await this.notificationRepository.findById(id);
    if (!notification) {
      throw new NotificationNotFoundException(`Notification with ID ${id} not found`);
    }
    return notification;
  }

  /**
   * Lấy inbox của user (tất cả notification)
   */
  async getInbox(userId: string): Promise<Notification[]> {
    return await this.notificationRepository.findByUserId(userId);
  }

  /**
   * Lấy thống kê notification
   */
  async getNotificationStats(userId: string): Promise<{
    total: number;
    unread: number;
    read: number;
  }> {
    const all = await this.notificationRepository.findByUserId(userId);
    const unread = all.filter(n => n.status === NotificationStatus.UNREAD).length;
    return {
      total: all.length,
      unread,
      read: all.length - unread
    };
  }

  /**
   * Đánh dấu notification là đã đọc
   */
  async markAsRead(id: string): Promise<Notification> {
    const notification = await this.getNotificationById(id);
    return await this.notificationRepository.update(id, {
      status: NotificationStatus.READ,
      readAt: new Date()
    });
  }

  /**
   * Đánh dấu tất cả notification của user là đã đọc
   */
  async markAllAsRead(userId: string): Promise<void> {
    const unreadNotifications = await this.notificationRepository.findUnreadByUserId(userId);
    for (const notification of unreadNotifications) {
      await this.notificationRepository.update(notification.id, {
        status: NotificationStatus.READ,
        readAt: new Date()
      });
    }
  }

  /**
   * Xóa notification
   */
  async deleteNotification(id: string): Promise<void> {
    await this.getNotificationById(id); // Verify exists
    await this.notificationRepository.delete(id);
  }

  /**
   * Xóa tất cả notification của user
   */
  async clearAllNotifications(userId: string): Promise<void> {
    await this.notificationRepository.deleteByUserId(userId);
  }

  /**
   * Lấy tổng số notification chưa đọc
   */
  async getUnreadCount(userId: string): Promise<number> {
    return await this.notificationRepository.getUnreadCount(userId);
  }

  /**
   * Xử lý order placed event từ Kafka
   */
  async handleOrderPlaced(orderEvent: any): Promise<Notification> {
    const { userId, orderId, orderNumber, totalAmount } = orderEvent;
    
    if (!userId || !orderId) {
      throw new InvalidNotificationException('Missing userId or orderId in order event');
    }

    return await this.createNotification(
      userId,
      'Đơn hàng được tạo thành công',
      `Đơn hàng #${orderNumber} với giá trị ${totalAmount.toLocaleString('vi-VN')} đ đã được tạo. Chúng tôi sẽ xác nhận trong vòng 24 giờ.`,
      NotificationType.ORDER_PLACED,
      orderId
    );
  }
}

export type NotificationDto = Omit<Notification, 'id' | 'createdAt' | 'updatedAt'>;
