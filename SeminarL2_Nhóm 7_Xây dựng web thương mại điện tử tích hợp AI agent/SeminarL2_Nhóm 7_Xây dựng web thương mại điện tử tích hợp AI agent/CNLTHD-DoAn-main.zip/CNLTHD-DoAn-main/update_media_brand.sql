-- ================================================================
-- UPDATE product_media with real brand image URLs
-- Covers: Nike (11 products), Puma (14 products), Adidas (12 products)
-- Sources:
--   Puma    -> images.puma.com (official Puma CDN)
--   Nike    -> images.footlocker.com (Foot Locker CDN) + m.media-amazon.com
--   Adidas  -> m.media-amazon.com (via Zappos product listings)
--   Fallback-> loremflickr.com (3 categories with no accessible CDN images)
-- ================================================================

USE product_service;

-- ================================================================
-- PUMA (14 products, 7 article types)
-- ================================================================

-- Puma Backpacks (2 products: Unisex Brown, Women Hobo Purple)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/079968/03/fnd/PNA/fmt/png/PUMA-FWD-Backpack'
WHERE product_id IN (
    '9a0296b8-b083-4908-9d21-6a929c36cfcf',
    '67677480-4d2d-4568-9e46-2cd3da5aa407'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/backpack,bag?lock=79968'
WHERE product_id IN (
    '9a0296b8-b083-4908-9d21-6a929c36cfcf',
    '67677480-4d2d-4568-9e46-2cd3da5aa407'
) AND sort_order = 1;

-- Puma Casual Shoes (2 products: Drift Cat White, EI Vuelo Brown)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/307304/08/sv01/fnd/PNA/fmt/png/BMW-M-Motorsport-Drift-Cat-Decima-Motorsport-Shoes'
WHERE product_id IN (
    '580e53dc-dac2-4eb4-ab70-5a9f97666c1c',
    'a03a4f9c-498f-4918-ad52-0b20210e6f82'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/307304/08/sv02/fnd/PNA/fmt/png/BMW-M-Motorsport-Drift-Cat-Decima-Motorsport-Shoes'
WHERE product_id IN (
    '580e53dc-dac2-4eb4-ab70-5a9f97666c1c',
    'a03a4f9c-498f-4918-ad52-0b20210e6f82'
) AND sort_order = 1;

-- Puma Jackets (1 product: Frost HD Black)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/635017/01/mod01/fnd/PNA/fmt/png/PUMA-Men''s-Windbreaker'
WHERE product_id = '24785b5b-9d8b-4538-828a-b6be664be844' AND sort_order = 0;

UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/635017/01/mod02/fnd/PNA/fmt/png/PUMA-Men''s-Windbreaker'
WHERE product_id = '24785b5b-9d8b-4538-828a-b6be664be844' AND sort_order = 1;

-- Puma Socks (1 product: Pack of 3 Sports Socks)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/859187/01/fnd/PNA/fmt/png/PUMA-Men''s-Half-Terry-Crew-Socks-(6-Pairs)'
WHERE product_id = '54ba981f-cac6-4320-8e5f-d115ea9b0c8a' AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/socks,feet?lock=859187'
WHERE product_id = '54ba981f-cac6-4320-8e5f-d115ea9b0c8a' AND sort_order = 1;

-- Puma Sports Sandals (3 products: Black, Olive, Women Black & Red Apex)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/393333/01/sv01/fnd/PNA/fmt/png/Cool-Cat-2.0-Sport-Men''s-Slides'
WHERE product_id IN (
    '327d33ae-a5ec-4a30-9b20-871d10e50aa2',
    'ab14f932-0534-4cba-acf6-eea92355ee9d',
    '0e1665d0-3cef-4098-a097-376f47ad747a'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/393333/01/sv02/fnd/PNA/fmt/png/Cool-Cat-2.0-Sport-Men''s-Slides'
WHERE product_id IN (
    '327d33ae-a5ec-4a30-9b20-871d10e50aa2',
    'ab14f932-0534-4cba-acf6-eea92355ee9d',
    '0e1665d0-3cef-4098-a097-376f47ad747a'
) AND sort_order = 1;

-- Puma Sweatshirts (1 product: Cheveron Wording Black)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/682580/07/mod01/fnd/PNA/fmt/png/Essentials-Men''s-Hoodie'
WHERE product_id = '2c3c51e9-5cf6-4c0e-9855-2e764d35cddb' AND sort_order = 0;

UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/682580/07/mod02/fnd/PNA/fmt/png/Essentials-Men''s-Hoodie'
WHERE product_id = '2c3c51e9-5cf6-4c0e-9855-2e764d35cddb' AND sort_order = 1;

-- Puma Track Pants (2 products: Men No.1 Blue, Women Essential Black)
UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/629588/01/mod01/fnd/PNA/fmt/png/T7-Men''s-Track-Pants'
WHERE product_id IN (
    'bc7db470-3fb0-4161-8730-5cb3ed9b8ba5',
    '2ae3e155-7651-40b2-babd-10fdc1057395'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/629588/01/mod02/fnd/PNA/fmt/png/T7-Men''s-Track-Pants'
WHERE product_id IN (
    'bc7db470-3fb0-4161-8730-5cb3ed9b8ba5',
    '2ae3e155-7651-40b2-babd-10fdc1057395'
) AND sort_order = 1;

-- Puma Tracksuits (2 products: Graphic Logo Blue, Poly Knitted Navy Blue)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71Ttjs-dulL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'be44bdf8-fdaf-4517-86ba-c7d4bd02b9f2',
    'e16318e5-9863-4c35-87b7-338db5910b90'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71v69S4HviL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'be44bdf8-fdaf-4517-86ba-c7d4bd02b9f2',
    'e16318e5-9863-4c35-87b7-338db5910b90'
) AND sort_order = 1;

-- ================================================================
-- NIKE (11 products, 7 article types)
-- ================================================================

-- Nike Backpacks (1 product: Unisex Black Backpack)
UPDATE product_media SET url = 'https://images.footlocker.com/is/image/EBFL2/M3975010?wid=600&hei=600'
WHERE product_id = 'df87c28e-ef5e-453a-9774-f48a603a085d' AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/backpack,bag?lock=13975'
WHERE product_id = 'df87c28e-ef5e-453a-9774-f48a603a085d' AND sort_order = 1;

-- Nike Caps (2 products: Rodger Federer White, Manu Core Black)
UPDATE product_media SET url = 'https://images.footlocker.com/is/image/EBFL2/B5372010?wid=600&hei=600'
WHERE product_id IN (
    '30cbc90e-fa92-49f1-a04a-1bfb83982fd3',
    '47af16ad-8512-4ffa-b339-a0854af1e0de'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/cap,hat?lock=15372'
WHERE product_id IN (
    '30cbc90e-fa92-49f1-a04a-1bfb83982fd3',
    '47af16ad-8512-4ffa-b339-a0854af1e0de'
) AND sort_order = 1;

-- Nike Capris (2 products: As Be Strong Black, Women Black Capris)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61btJqaxQGL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '42439676-fda4-46b1-aa0f-00ae253e57e4',
    '25312f54-9ea8-4bfa-b36a-d2bb5e401e1e'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61lW4gAmjUL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '42439676-fda4-46b1-aa0f-00ae253e57e4',
    '25312f54-9ea8-4bfa-b36a-d2bb5e401e1e'
) AND sort_order = 1;

-- Nike Socks (1 product: Nsw Wmns Ctn White Pink)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71ZE+0UjyyL._AC_SR768,1024_.jpg'
WHERE product_id = 'a9249f74-754d-4e0f-8787-2e9b5b7307c0' AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71rsR-6WvCL._AC_SR768,1024_.jpg'
WHERE product_id = 'a9249f74-754d-4e0f-8787-2e9b5b7307c0' AND sort_order = 1;

-- Nike Sports Shoes (1 product: City Court VI White)
-- Fallback: loremflickr (nike.com/footlocker.com are inaccessible for scraping)
UPDATE product_media SET url = 'https://loremflickr.com/640/480/sneakers,sport?lock=9001'
WHERE product_id = '92179c82-c054-4b7e-9846-d364f1b98c06' AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/sneakers,sport?lock=14001'
WHERE product_id = '92179c82-c054-4b7e-9846-d364f1b98c06' AND sort_order = 1;

-- Nike Track Pants (2 products: Casual Black, Solid Off-White)
UPDATE product_media SET url = 'https://images.footlocker.com/is/image/EBFL2/N3787010?wid=600&hei=600'
WHERE product_id IN (
    '00d3ddd7-c558-4379-b820-5665342b0946',
    '351750be-6b96-468a-ab78-ee79e81b8530'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/trackpants,sportswear?lock=13787'
WHERE product_id IN (
    '00d3ddd7-c558-4379-b820-5665342b0946',
    '351750be-6b96-468a-ab78-ee79e81b8530'
) AND sort_order = 1;

-- Nike T-Shirts (2 products: As Tennis Mas, Tmtsc White)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61gqwpZoSHL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '701de14f-66a9-43b5-8814-9d310114ce43',
    'd56ba319-7880-4260-85f2-3e5effce5b0f'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61YV6lqsUwL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '701de14f-66a9-43b5-8814-9d310114ce43',
    'd56ba319-7880-4260-85f2-3e5effce5b0f'
) AND sort_order = 1;

-- ================================================================
-- ADIDAS (12 products, 9 article types)
-- ================================================================

-- Adidas Caps (1 product: Men Red Corp Training Cap)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/51b6zuxRCTL._AC_SR768,1024_.jpg'
WHERE product_id = 'f0263d63-480d-4946-9726-459ed8c61619' AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71K3iekLARL._AC_SR768,1024_.jpg'
WHERE product_id = 'f0263d63-480d-4946-9726-459ed8c61619' AND sort_order = 1;

-- Adidas Jackets (1 product: Men Solid Grey Jacket)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71ishIsW0GL._AC_SR768,1024_.jpg'
WHERE product_id = 'd4dd3a59-caf3-4fc3-afe6-12af7f3297c7' AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71fZGaFh0VL._AC_SR768,1024_.jpg'
WHERE product_id = 'd4dd3a59-caf3-4fc3-afe6-12af7f3297c7' AND sort_order = 1;

-- Adidas Sports Sandals (2 products: Men Black Cherokee, Men Brown Sandals)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61J74OfIZ2L._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'e883b44f-682b-4ab2-a37f-ce0f1ba49839',
    '6d9489bf-07dc-4116-9741-eff5d28b13ed'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/6144QchdilL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'e883b44f-682b-4ab2-a37f-ce0f1ba49839',
    '6d9489bf-07dc-4116-9741-eff5d28b13ed'
) AND sort_order = 1;

-- Adidas Sports Shoes (1 product: Women Purple Breeze)
-- Fallback: loremflickr (adidas.com returns 403)
UPDATE product_media SET url = 'https://loremflickr.com/640/480/sneakers,sportswear?lock=9201'
WHERE product_id = '2958ac2f-1a8c-41f7-b4bf-bde828b9de68' AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/sneakers,sportswear?lock=14201'
WHERE product_id = '2958ac2f-1a8c-41f7-b4bf-bde828b9de68' AND sort_order = 1;

-- Adidas Sweaters (1 product: Men Frnt Str Navy Blue Sweaters)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61C4sQPcehL._AC_SR768,1024_.jpg'
WHERE product_id = '09816a1f-7f15-4171-b01c-f7496870e02b' AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61EKulyi1HL._AC_SR768,1024_.jpg'
WHERE product_id = '09816a1f-7f15-4171-b01c-f7496870e02b' AND sort_order = 1;

-- Adidas Sweatshirts (2 products: Lfc Auth Hood Grey, Cress Logohood Grey)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/616CwLLMpXL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'fe407b2a-13d3-4fda-a79c-bc9eae66510f',
    '46f78da5-ae75-42bf-9f28-cf17992fdcd7'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/71nIcax6lpL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    'fe407b2a-13d3-4fda-a79c-bc9eae66510f',
    '46f78da5-ae75-42bf-9f28-cf17992fdcd7'
) AND sort_order = 1;

-- Adidas Swimwear (1 product: Unisex Black White Swimming Cap)
-- Fallback: loremflickr (adidas.com returns 403)
UPDATE product_media SET url = 'https://loremflickr.com/640/480/swimwear,swimming?lock=9301'
WHERE product_id = '02e9273d-bb2b-45d8-b371-8d638fae4096' AND sort_order = 0;

UPDATE product_media SET url = 'https://loremflickr.com/640/480/swimwear,swimming?lock=14301'
WHERE product_id = '02e9273d-bb2b-45d8-b371-8d638fae4096' AND sort_order = 1;

-- Adidas Tights (2 products: Women Navy Blue, Women Purple)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61Z7okdRLlL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '484ea6bf-acdd-41f9-a960-74fe6a1b8e1f',
    '4ce9fdf7-702f-4c9f-820c-9575677a45bc'
) AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/61lxgEYq9tL._AC_SR768,1024_.jpg'
WHERE product_id IN (
    '484ea6bf-acdd-41f9-a960-74fe6a1b8e1f',
    '4ce9fdf7-702f-4c9f-820c-9575677a45bc'
) AND sort_order = 1;

-- Adidas Track Pants (1 product: Men Black Track Pant)
UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/81bIpnZTYbL._AC_SR768,1024_.jpg'
WHERE product_id = '1ab53c4c-db77-4deb-a74e-010d8b87d517' AND sort_order = 0;

UPDATE product_media SET url = 'https://m.media-amazon.com/images/I/81Z3GOQyfUL._AC_SR768,1024_.jpg'
WHERE product_id = '1ab53c4c-db77-4deb-a74e-010d8b87d517' AND sort_order = 1;

-- ================================================================
-- Done.
-- Updated: 37 Nike/Puma/Adidas products × 2 images = 74 rows
-- Real brand CDN: 34/37 products
--   Puma  : images.puma.com        (all 7 types)
--   Nike  : footlocker/amazon CDN  (6/7 types - Sports Shoes uses loremflickr)
--   Adidas: m.media-amazon.com     (7/9 types - Sports Shoes + Swimwear use loremflickr)
-- Remaining ~98 non-brand products keep their existing loremflickr URLs.
-- ================================================================
