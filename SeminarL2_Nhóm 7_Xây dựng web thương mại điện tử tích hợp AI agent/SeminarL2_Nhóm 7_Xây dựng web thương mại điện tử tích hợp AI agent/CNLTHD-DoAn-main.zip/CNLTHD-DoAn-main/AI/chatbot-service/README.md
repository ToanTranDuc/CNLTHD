# Chatbot Service

Service Spring Boot de phuc vu giao dien chatbot tu file HTML.

## Cau truc
- `src/main/resources/static/chatbot_interface.html`: Ban HTML chatbot (copy tu `AI/chatbot_interface.html`, file goc khong bi sua)
- `src/main/java/.../controller/ChatbotConfigController.java`: API tra ve webhook URL
- `src/main/resources/application.yml`: Cau hinh port va webhook

## Chay local
```bash
mvn spring-boot:run
```

Mac dinh service chay o:
- `http://localhost:8091`
- `http://localhost:8091/chatbot_interface.html`

## Cấu hình webhook
Dat bien moi truong truoc khi chay:
- `CHATBOT_WEBHOOK_URL`

Vi du PowerShell:
```powershell
$env:CHATBOT_WEBHOOK_URL="https://your-ngrok-domain/webhook/xxx/chat"
mvn spring-boot:run
```

## Build Docker
```bash
docker build -t chatbot-service .
docker run -p 8091:8091 -e CHATBOT_WEBHOOK_URL="https://your-ngrok-domain/webhook/xxx/chat" chatbot-service
```
