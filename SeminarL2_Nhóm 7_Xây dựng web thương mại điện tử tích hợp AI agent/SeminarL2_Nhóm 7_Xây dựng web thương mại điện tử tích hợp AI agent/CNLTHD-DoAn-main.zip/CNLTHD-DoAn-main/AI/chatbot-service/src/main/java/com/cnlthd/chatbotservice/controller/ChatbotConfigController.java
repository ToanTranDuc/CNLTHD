package com.cnlthd.chatbotservice.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChatbotConfigController {

    @Value("${chatbot.webhook-url:https://brice-opportune-unacceptably.ngrok-free.dev/webhook/3d84c956-4adf-403d-8895-bfcf35e558e1/chat}")
    private String webhookUrl;

    @GetMapping("/api/chatbot/config")
    public Map<String, String> getConfig() {
        return Map.of("webhookUrl", webhookUrl);
    }
}
