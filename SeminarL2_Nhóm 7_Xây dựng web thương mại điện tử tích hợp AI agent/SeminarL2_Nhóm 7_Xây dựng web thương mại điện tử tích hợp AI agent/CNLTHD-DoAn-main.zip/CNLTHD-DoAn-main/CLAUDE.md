# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Fashion e-commerce platform built with Spring Boot microservices backend, Next.js frontend, and an AI chatbot stack using n8n + Ollama + Qdrant.

---

## Commands

### Backend Services

Start services in this order: Eureka → individual services → API Gateway.

```bash
# Service Discovery (start first)
cd backend/eureka_service && mvnw spring-boot:run        # http://localhost:8761

# Core services
cd backend/Product-Service && mvnw spring-boot:run       # port 8081
cd backend/Inventory-Service && mvnw spring-boot:run     # port 8082
cd backend/Order-Service && mvnw spring-boot:run         # port 8083
cd backend/user-service && mvnw spring-boot:run          # port 8081 (conflicts with Product Service)
cd backend/chatbot-service && mvnw spring-boot:run       # port 8091

# API Gateway (start last)
cd backend/api-gateway && mvnw spring-boot:run           # port 8080

# Build (skip tests)
mvnw clean package -DskipTests
```

Order Service has a Docker Compose that includes MySQL, Zookeeper, Kafka, and Eureka:
```bash
cd backend/Order-Service && docker-compose up -d
```

### Frontend

```bash
cd frontend
npm install
npm run dev        # http://localhost:3000
npm run build
npm run lint
```

### AI Stack

```bash
cd AI
docker-compose up -d   # starts n8n, Ollama, Qdrant, ngrok
docker-compose logs -f
docker-compose down
```

- Ollama API: http://localhost:11434 (model: Qwen 2.5 7B)
- Qdrant: http://localhost:6333
- n8n workflow UI is accessible inside the container

### Database

```bash
mysql -u root -p < AI/ALL_PROJECT_SQL.sql
```

Default DB credentials across services: user `cnlthd_user`, password `jelly1810`.

### API Testing

All requests go through the API Gateway at `http://localhost:8080`. See `backend/api-gateway/POSTMAN_TESTING_GUIDE.md` for the full test flow. Swagger UI is available at:
- Product Service: http://localhost:8081/swagger-ui.html
- Inventory Service: http://localhost:8082/swagger-ui.html
- Order Service: http://localhost:8083/swagger-ui.html

---

## Architecture

### Request Flow

```
Browser (Next.js :3000)
    → API Gateway (:8080, Spring Cloud Gateway WebMvc)
        → Product Service (:8081)   — MySQL: product_service
        → Inventory Service (:8082) — MySQL: inventory_service
        → Order Service (:8083)     — MySQL: order_service
        → User Service (:8081)      — MySQL: user_service_db

All services register with Eureka (:8761); gateway routes via lb:// URLs.
```

### Services

| Service | Port | Purpose |
|---------|------|---------|
| `eureka_service` | 8761 | Service registry — must start first |
| `api-gateway` | 8080 | Single ingress; routes `/api/v1/**`; JWT validation currently disabled |
| `Product-Service` | 8081 | Categories, Products, ProductVariants (SKU/size/color), ProductMedia |
| `Inventory-Service` | 8082 | Stock levels + InventoryLog (IN/OUT/ADJUSTMENT) |
| `Order-Service` | 8083 | Cart, Orders, Payments; publishes to Kafka topic `notificationTopic` |
| `user-service` | 8081 | JWT auth, Spring Security, role-based access (ADMIN/CUSTOMER) |
| `chatbot-service` | 8091 | Serves static chatbot HTML; proxies to n8n via ngrok |

### Inter-Service Communication

- **OpenFeign**: Product Service calls Inventory Service for stock checks; Order Service calls Inventory Service for checkout validation, wrapped with Resilience4j circuit breaker.
- **Kafka** (`localhost:9092`): Order Service publishes order events to `notificationTopic`.
- **Eureka**: Gateway and services discover each other dynamically; gateway uses `lb://service-name` URIs.

### Frontend Structure (`frontend/`)

Next.js 16 App Router. Key areas:
- `app/` — pages: `admin/`, `products/`, `cart/`, `checkout/`, `orders/`, `profile/`, `wishlist/`, `login/`
- `components/` — `admin/`, `chatbot/`, `layout/`, `product/`, `cart/`, `checkout/`
- `context/` — React context providers
- `lib/` — API clients and utilities

### Key Config Files

| File | What to change |
|------|---------------|
| `backend/api-gateway/src/main/resources/application.yml` | Routes, JWT enable/disable |
| `backend/Order-Service/src/main/resources/application.properties` | Kafka, Resilience4j, Zipkin, Inventory base URL |
| `backend/user-service/src/main/resources/application.yml` | JWT secret, mail (SMTP Gmail) |
| `backend/chatbot-service/src/main/resources/application.yml` | n8n webhook URL (also via env `CHATBOT_WEBHOOK_URL`) |
| `AI/docker-compose.yaml` | AI stack services |
| `AI/ALL_PROJECT_SQL.sql` | Full schema for all databases |

### Technology Stack

- **Backend**: Java 21, Spring Boot 3.2/4.0, Spring Cloud 2025.1, Maven
- **Frontend**: Next.js 16, React 19, TypeScript, Tailwind CSS 4
- **Databases**: MySQL 8+ (one per service, isolated schemas)
- **Messaging**: Apache Kafka
- **Observability**: Micrometer + Prometheus, Zipkin, Spring Boot Actuator
- **API Docs**: SpringDoc OpenAPI (Swagger 3)
- **DTO mapping**: MapStruct
- **AI**: n8n, Ollama (Qwen 2.5 7B), Qdrant vector DB, ngrok

### Known Port Conflict

`user-service` and `Product-Service` are both configured to use port 8081. They cannot run simultaneously without changing one service's `server.port`.
