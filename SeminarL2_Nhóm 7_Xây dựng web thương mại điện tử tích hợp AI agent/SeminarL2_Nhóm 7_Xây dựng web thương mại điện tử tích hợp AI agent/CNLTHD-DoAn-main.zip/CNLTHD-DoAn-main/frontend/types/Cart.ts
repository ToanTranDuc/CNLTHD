export interface CartItem {
  id: string;
  name: string;
  category: string;
  color: string;
  size: string;
  price: number;
  quantity: number;
  image: string;
  skuCode?: string;
}

export interface CartContextType {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string, size: string, color: string) => void;
  updateQuantity: (id: string, quantity: number, size: string, color: string) => void;
  getTotalQuantity: () => number;
  getSubtotal: () => number;
  clearCart: () => void;
}
