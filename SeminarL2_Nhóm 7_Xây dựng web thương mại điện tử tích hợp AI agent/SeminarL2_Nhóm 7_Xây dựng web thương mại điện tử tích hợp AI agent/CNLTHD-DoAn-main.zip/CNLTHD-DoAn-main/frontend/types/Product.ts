export interface ProductVariant {
  size: string;
  color: string;
  price: number;
  sku: string;
  inStock: boolean;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  isNew: boolean;
  variants?: ProductVariant[];
  colors: Array<{
    name: string;
    image: string;
    hex?: string;
  }>;
  sizes: Array<{
    size: string;
    inStock: boolean;
  }>;
  description: string;
  details: {
    colorShown: string;
    style: string;
    country: string;
  };
  images: string[];
}

export interface FilterOptions {
  category: string;
  sortBy: string;
}
