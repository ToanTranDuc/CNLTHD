"use client";
import React, { createContext, useContext, useState, useCallback } from 'react';
import { CheckCircle2, XCircle, AlertCircle, Heart } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info' | 'wishlist';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, type: ToastType = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  }, []);

  const iconFor = (type: ToastType) => {
    switch (type) {
      case 'success': return <CheckCircle2 className="w-5 h-5 flex-shrink-0" />;
      case 'error': return <XCircle className="w-5 h-5 flex-shrink-0" />;
      case 'wishlist': return <Heart className="w-5 h-5 flex-shrink-0 fill-current" />;
      default: return <AlertCircle className="w-5 h-5 flex-shrink-0" />;
    }
  };

  const styleFor = (type: ToastType) => {
    switch (type) {
      case 'success': return 'bg-green-50 border-green-300 text-green-800';
      case 'error': return 'bg-red-50 border-red-300 text-red-800';
      case 'wishlist': return 'bg-pink-50 border-pink-300 text-pink-700';
      default: return 'bg-blue-50 border-blue-300 text-blue-800';
    }
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-20 right-4 z-[9999] flex flex-col gap-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto px-4 py-3 rounded-lg shadow-xl flex items-center gap-2 min-w-[260px] max-w-[400px] border-2 ${styleFor(t.type)}`}
            style={{ animation: 'toastSlideIn 0.25s ease-out' }}
          >
            {iconFor(t.type)}
            <span className="text-sm font-medium">{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
};
