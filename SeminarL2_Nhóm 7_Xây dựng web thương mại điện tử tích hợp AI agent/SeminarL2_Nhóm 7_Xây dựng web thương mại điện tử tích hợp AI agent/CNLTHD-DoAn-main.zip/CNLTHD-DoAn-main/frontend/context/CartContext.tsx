"use client";
import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, CartContextType } from '@/types/Cart';

const CART_STORAGE_KEY = 'cnlthd_cart';
const CartContext = createContext<CartContextType | undefined>(undefined);

const generateCartItemId = (productId: string, size: string, color: string): string =>
  `${productId}-${size}-${color}`;

function loadCartFromStorage(): CartItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CART_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as CartItem[]) : [];
  } catch {
    return [];
  }
}

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    setItems(loadCartFromStorage());
    setHydrated(true);
  }, []);

  // Persist on every change
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  // Listen for auth-changed: hard-clear on logout, refresh on login
  useEffect(() => {
    const handler = () => {
      const hasAuth = typeof window !== 'undefined' && !!localStorage.getItem('accessToken');
      if (!hasAuth) {
        // Logged out — force clear regardless of localStorage state
        setItems([]);
        localStorage.removeItem('cnlthd_cart');
      } else {
        setItems(loadCartFromStorage());
      }
    };
    window.addEventListener('storage', handler);
    window.addEventListener('auth-changed', handler);
    return () => {
      window.removeEventListener('storage', handler);
      window.removeEventListener('auth-changed', handler);
    };
  }, []);

  const addItem = (item: CartItem) => {
    setItems((prev) => {
      const cartItemId = generateCartItemId(item.id, item.size, item.color);
      const existing = prev.find((i) => generateCartItemId(i.id, i.size, i.color) === cartItemId);
      if (existing) {
        return prev.map((i) =>
          generateCartItemId(i.id, i.size, i.color) === cartItemId
            ? { ...i, quantity: i.quantity + item.quantity }
            : i
        );
      }
      return [...prev, item];
    });
  };

  const removeItem = (id: string, size: string, color: string) => {
    const cartItemId = generateCartItemId(id, size, color);
    setItems((prev) => prev.filter((item) => generateCartItemId(item.id, item.size, item.color) !== cartItemId));
  };

  const updateQuantity = (id: string, quantity: number, size: string, color: string) => {
    if (quantity <= 0) {
      removeItem(id, size, color);
    } else {
      const cartItemId = generateCartItemId(id, size, color);
      setItems((prev) =>
        prev.map((item) =>
          generateCartItemId(item.id, item.size, item.color) === cartItemId
            ? { ...item, quantity }
            : item
        )
      );
    }
  };

  const getTotalQuantity = () => items.reduce((total, item) => total + item.quantity, 0);
  const getSubtotal = () => items.reduce((total, item) => total + item.price * item.quantity, 0);
  const clearCart = () => setItems([]);

  return (
    <CartContext.Provider
      value={{ items, addItem, removeItem, updateQuantity, getTotalQuantity, getSubtotal, clearCart }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) throw new Error('useCart must be used within a CartProvider');
  return context;
};
