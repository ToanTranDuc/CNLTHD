"use client";
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { fetchWishlist, addToWishlist, removeFromWishlist } from '@/lib/wishlist';

export interface WishlistItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
}

interface WishlistContextType {
  items: WishlistItem[];
  addItem: (item: WishlistItem) => void;
  removeItem: (id: string) => void;
  isInWishlist: (id: string) => boolean;
  toggleItem: (item: WishlistItem) => void;
  count: number;
  loading: boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);
const STORAGE_KEY = 'cnlthd_wishlist';

function loadLocal(): WishlistItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as WishlistItem[]) : [];
  } catch {
    return [];
  }
}

function saveLocal(items: WishlistItem[]) {
  if (typeof window !== 'undefined') localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

function currentUserId(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('userId');
}

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [loading, setLoading] = useState(false);

  // Initial load + merge: when logged in, push local guest items to backend,
  // then fetch consolidated list.
  const syncFromBackend = useCallback(async () => {
    const uid = currentUserId();
    const local = loadLocal();
    if (!uid) {
      setItems(local);
      return;
    }
    setLoading(true);
    try {
      // Push guest items first (backend is idempotent via unique constraint)
      if (local.length > 0) {
        await Promise.all(local.map((item) =>
          addToWishlist({
            userId: uid,
            productId: item.id,
            productName: item.name,
            imageUrl: item.image || undefined,
            price: item.price,
            category: item.category,
          }).catch(() => null)
        ));
      }
      const remote = await fetchWishlist(uid);
      const mapped: WishlistItem[] = remote.map((r) => ({
        id: r.productId,
        name: r.productName,
        price: r.price ?? 0,
        image: r.imageUrl ?? '',
        category: r.category ?? '',
      }));
      setItems(mapped);
      saveLocal(mapped);
    } catch (err) {
      console.warn('Wishlist sync failed, using local cache:', err);
      setItems(local);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    syncFromBackend().finally(() => setHydrated(true));
    const handler = () => {
      const hasAuth = typeof window !== 'undefined' && !!localStorage.getItem('accessToken');
      if (!hasAuth) {
        // Logged out — hard clear so next user doesn't inherit previous wishlist
        setItems([]);
        localStorage.removeItem('cnlthd_wishlist');
      } else {
        syncFromBackend();
      }
    };
    window.addEventListener('storage', handler);
    window.addEventListener('auth-changed', handler);
    return () => {
      window.removeEventListener('storage', handler);
      window.removeEventListener('auth-changed', handler);
    };
  }, [syncFromBackend]);

  // Mirror to localStorage as cache
  useEffect(() => {
    if (!hydrated) return;
    saveLocal(items);
  }, [items, hydrated]);

  const addItem = (item: WishlistItem) => {
    setItems((prev) => (prev.find((i) => i.id === item.id) ? prev : [...prev, item]));
    const uid = currentUserId();
    if (uid) {
      addToWishlist({
        userId: uid,
        productId: item.id,
        productName: item.name,
        imageUrl: item.image || undefined,
        price: item.price,
        category: item.category,
      }).catch((err) => console.warn('Add wishlist failed:', err));
    }
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    const uid = currentUserId();
    if (uid) {
      removeFromWishlist(uid, id).catch((err) => console.warn('Remove wishlist failed:', err));
    }
  };

  const isInWishlist = (id: string) => items.some((i) => i.id === id);

  const toggleItem = (item: WishlistItem) => {
    if (isInWishlist(item.id)) removeItem(item.id);
    else addItem(item);
  };

  return (
    <WishlistContext.Provider value={{ items, addItem, removeItem, isInWishlist, toggleItem, count: items.length, loading }}>
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error('useWishlist must be used within WishlistProvider');
  return ctx;
};
