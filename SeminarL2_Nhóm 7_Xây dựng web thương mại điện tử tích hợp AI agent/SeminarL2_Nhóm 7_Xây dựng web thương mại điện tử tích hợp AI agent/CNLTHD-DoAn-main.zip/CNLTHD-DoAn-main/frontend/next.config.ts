import type { NextConfig } from "next";

const chatbotUrl =
  process.env.CHATBOT_SERVICE_URL || "http://chatbot-service:8091";

const nextConfig: NextConfig = {
  output: "standalone",
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**" },
      { protocol: "http", hostname: "**" },
    ],
  },
  async rewrites() {
    return [
      {
        source: "/chatbot-service/:path*",
        destination: `${chatbotUrl}/:path*`,
      },
      {
        source: "/api/chatbot/:path*",
        destination: `${chatbotUrl}/api/chatbot/:path*`,
      },
    ];
  },
};

export default nextConfig;
