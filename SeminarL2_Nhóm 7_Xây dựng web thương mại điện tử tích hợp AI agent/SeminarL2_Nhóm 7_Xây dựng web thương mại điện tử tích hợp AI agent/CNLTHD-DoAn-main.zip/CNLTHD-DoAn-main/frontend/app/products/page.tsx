import ProductsContent from '@/components/product/ProductsContent';
import { getProducts, getProductsByGender, getProductsByCategory, searchProducts } from '@/lib/products';

interface ProductsPageProps {
  searchParams: Promise<{ category?: string; categoryId?: string; categoryName?: string; search?: string }>;
}

const GENDER_MAP: Record<string, 'MEN' | 'WOMEN' | 'UNISEX'> = {
  men: 'MEN',
  women: 'WOMEN',
};

const ProductsPage = async ({ searchParams }: ProductsPageProps) => {
  const { category = 'featured', categoryId, categoryName, search } = await searchParams;

  let products;
  if (search) {
    products = await searchProducts(search);
  } else if (categoryId) {
    products = await getProductsByCategory(categoryId);
  } else if (GENDER_MAP[category]) {
    products = await getProductsByGender(GENDER_MAP[category]);
  } else {
    products = await getProducts();
  }

  return (
    <div className="min-h-screen bg-white">
      <ProductsContent
        mockProducts={products}
        category={category}
        categoryName={categoryName}
        searchQuery={search}
      />
    </div>
  );
};

export default ProductsPage;
