"use client";
import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { User, ShoppingCart, Heart, Settings, LogOut, Mail, Phone, Package, Clock, CheckCircle } from 'lucide-react';
import Link from 'next/link';
import { fetchUserOrders, getOrderStatusDisplay, getOrderStatusColor, Order } from '@/lib/orders';
import { useWishlist } from '@/context/WishlistContext';
import { useToast } from '@/context/ToastContext';
import { Trash2 } from 'lucide-react';
import BackButton from '@/components/ui/BackButton';

const ProfilePageInner = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [activeMenu, setActiveMenu] = useState(() => searchParams.get('tab') || 'profile');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // User data from API
  const [userData, setUserData] = useState({
    fullname: '',
    email: '',
    sdt: '',
    id: '', // Add user ID for fetching orders
  });

  // Orders data from API
  const [orders, setOrders] = useState<Order[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [ordersError, setOrdersError] = useState('');

  // User role from localStorage
  const [userRole, setUserRole] = useState('');

  // Wishlist
  const { items: wishlistItems, removeItem: removeFromWishlist } = useWishlist();
  const { showToast } = useToast();
  const handleRemoveWishlist = (id: string) => {
    removeFromWishlist(id);
    showToast('Đã xóa khỏi danh sách yêu thích', 'wishlist');
  };

  // Get user role from localStorage on mount
  useEffect(() => {
    const role = localStorage.getItem('userRole');
    if (role) {
      setUserRole(role);
    }
  }, []);

  // Fetch user profile from API
  useEffect(() => {
    const fetchUserProfile = async () => {
      const token = localStorage.getItem('accessToken');
      
      // Redirect to login if no token
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch('http://localhost:8080/api/users/profile', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          if (response.status === 401) {
            // Token expired or invalid
            localStorage.removeItem('accessToken');
            localStorage.removeItem('refreshToken');
            router.push('/login');
            return;
          }
          throw new Error('Failed to fetch user profile');
        }

        const data = await response.json();
        if (data.success && data.data) {
          setUserData({
            fullname: data.data.fullname || '',
            email: data.data.email || '',
            sdt: data.data.sdt || '',
            id: data.data.id || '',
          });
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Lỗi tải thông tin người dùng');
      } finally {
        setLoading(false);
      }
    };

    fetchUserProfile();
  }, [router]);

  // Fetch user orders — use userData.id when available, fallback to localStorage
  useEffect(() => {
    const customerId = userData.id || (typeof window !== 'undefined' ? localStorage.getItem('userId') : null);
    if (!customerId) return;

    const fetchOrders = async () => {
      setOrdersLoading(true);
      setOrdersError('');
      try {
        const data = await fetchUserOrders(customerId);
        setOrders(data || []);
      } catch (err) {
        console.error('Error fetching orders:', err);
        setOrdersError('Lỗi tải lịch sử đơn hàng');
        setOrders([]);
      } finally {
        setOrdersLoading(false);
      }
    };

    fetchOrders();
  }, [userData.id]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'SHIPPED':
        return <Clock className="w-4 h-4" />;
      case 'DELIVERED':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  const menuItems = [
    { id: 'profile', label: 'Thông tin người dùng', icon: User, href: '#' },
    { id: 'orders', label: 'Đơn hàng', icon: ShoppingCart, href: '#' },
    { id: 'wishlist', label: 'Wishlist', icon: Heart, href: '#' },
    { id: 'settings', label: 'Setting', icon: Settings, href: '#' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="container mx-auto px-4 md:px-8 py-8">
        <BackButton className="mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <nav className="space-y-0">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveMenu(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-4 border-b border-gray-200 last:border-b-0 transition-colors ${
                        activeMenu === item.id
                          ? 'bg-black text-white'
                          : 'bg-white text-black hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </nav>

              {/* Logout Button */}
              <button
                onClick={() => {
                  // Clear auth
                  localStorage.removeItem('accessToken');
                  localStorage.removeItem('refreshToken');
                  localStorage.removeItem('userRole');
                  localStorage.removeItem('userId');
                  localStorage.removeItem('userName');
                  localStorage.removeItem('userEmail');
                  // Clear shopping state so next user doesn't inherit previous user's data
                  localStorage.removeItem('cnlthd_cart');
                  localStorage.removeItem('cnlthd_wishlist');
                  localStorage.removeItem('cart_selected_ids');
                  // Notify contexts
                  window.dispatchEvent(new Event('auth-changed'));
                  router.push('/login');
                }}
                className="w-full flex items-center gap-3 px-4 py-4 bg-red-50 text-red-600 hover:bg-red-100 transition-colors border-t border-gray-200 font-medium"
              >
                <LogOut className="w-5 h-5" />
                <span>Logout</span>
              </button>
            </div>
          </div>

          {/* Right Content */}
          <div className="md:col-span-3">
            <div className="bg-white border border-gray-200 rounded-lg p-6 md:p-8">
            {activeMenu === 'profile' && (
                <div>
                  {loading ? (
                    <p className="text-center text-gray-600">Đang tải thông tin...</p>
                  ) : error ? (
                    <p className="text-center text-red-600">{error}</p>
                  ) : (
                    <>
                      <h2 className="text-3xl font-bold text-black mb-2">Hi, {userData.fullname}</h2>

                      <div className="space-y-6">
                        {/* Full Name */}
                        <div className="pb-6 border-b border-gray-200">
                          <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide block mb-2">
                            Tên người dùng
                          </label>
                          <p className="text-lg text-black font-medium">{userData.fullname}</p>
                        </div>

                        {/* Email */}
                        <div className="pb-6 border-b border-gray-200">
                          <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide block mb-2 flex items-center gap-2">
                            <Mail className="w-4 h-4" />
                            Email
                          </label>
                          <p className="text-lg text-black font-medium">{userData.email}</p>
                        </div>

                        {/* Phone */}
                        <div>
                          <label className="text-sm font-semibold text-gray-600 uppercase tracking-wide block mb-2 flex items-center gap-2">
                            <Phone className="w-4 h-4" />
                            Số điện thoại
                          </label>
                          <p className="text-lg text-black font-medium">{userData.sdt}</p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}

              {activeMenu === 'orders' && (
                <div>
                  <h2 className="text-2xl font-bold text-black mb-6">Đơn hàng của tôi</h2>
                  
                  {ordersLoading ? (
                    <p className="text-center text-gray-600">Đang tải lịch sử đơn hàng...</p>
                  ) : ordersError ? (
                    <p className="text-center text-red-600">{ordersError}</p>
                  ) : orders.length === 0 ? (
                    <p className="text-gray-600 text-center py-8">Bạn chưa có đơn hàng nào</p>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div key={order.id} className="border border-gray-200 rounded-lg p-4 md:p-6 hover:shadow-lg transition-shadow">
                          {/* Top row — order # + date */}
                          <div className="flex flex-wrap items-start justify-between gap-3 mb-4 pb-4 border-b border-gray-100">
                            <div className="min-w-0">
                              <h3 className="text-base md:text-lg font-bold text-black mb-1 truncate">{`#${order.orderNumber || order.id}`}</h3>
                              <p className="text-xs md:text-sm text-gray-600">
                                {new Date(order.createdAt || order.date || '').toLocaleDateString('vi-VN')} · {order.items?.length || 0} sản phẩm
                              </p>
                            </div>
                            <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs md:text-sm font-medium ${getOrderStatusColor(order.status)}`}>
                              {getStatusIcon(order.status)}
                              {getOrderStatusDisplay(order.status)}
                            </div>
                          </div>

                          {/* Detail grid — adapts to width */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
                            <div className="min-w-0">
                              <p className="text-xs text-gray-500 mb-1">Địa chỉ giao</p>
                              <p className="text-sm font-medium text-black truncate" title={order.shippingAddress || ''}>
                                {order.shippingAddress || 'N/A'}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Tổng tiền</p>
                              <p className="text-base md:text-lg font-bold text-black">
                                ₫{order.totalAmount.toLocaleString('vi-VN')}
                              </p>
                            </div>
                            <div className="sm:col-span-2 lg:col-span-1 flex justify-end">
                              <button
                                onClick={() => router.push(`/orders/${order.id}`)}
                                className="px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors whitespace-nowrap"
                              >
                                Xem chi tiết
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeMenu === 'wishlist' && (
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <h2 className="text-2xl font-bold text-black">Wishlist</h2>
                    {wishlistItems.length > 0 && (
                      <span className="bg-black text-white text-sm font-semibold px-3 py-1 rounded-full">
                        {wishlistItems.length}
                      </span>
                    )}
                  </div>

                  {wishlistItems.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-gray-500 mb-4">Bạn chưa có sản phẩm yêu thích nào.</p>
                      <Link
                        href="/products"
                        className="inline-block px-6 py-3 bg-black text-white rounded-full font-semibold hover:bg-gray-800 transition-colors"
                      >
                        Khám phá sản phẩm
                      </Link>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {wishlistItems.map((item) => (
                        <div
                          key={item.id}
                          className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow flex"
                        >
                          <Link
                            href={`/products/${item.id}`}
                            className="w-28 h-28 bg-gray-100 flex-shrink-0"
                          >
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-full h-full object-cover"
                              onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/112'; }}
                            />
                          </Link>
                          <div className="flex-1 p-4 flex flex-col justify-between min-w-0">
                            <div>
                              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">{item.category}</p>
                              <Link
                                href={`/products/${item.id}`}
                                className="text-sm font-semibold text-black hover:text-blue-600 transition-colors line-clamp-2"
                              >
                                {item.name}
                              </Link>
                              <p className="text-sm font-bold text-black mt-1">
                                ₫{item.price.toLocaleString('vi-VN')}
                              </p>
                            </div>
                            <div className="flex items-center gap-2 mt-2">
                              <Link
                                href={`/products/${item.id}`}
                                className="flex-1 text-center text-xs font-semibold px-3 py-1.5 border border-black text-black rounded-full hover:bg-black hover:text-white transition-colors"
                              >
                                Chọn size
                              </Link>
                              <button
                                onClick={() => handleRemoveWishlist(item.id)}
                                className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                                title="Xóa"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeMenu === 'settings' && (
                <div>
                  <h2 className="text-2xl font-bold text-black mb-6">Setting</h2>
                  <div className="space-y-4">
                    {(userRole === 'admin' || userRole === 'ADMIN') && (
                      <button
                        onClick={() => router.push('/admin')}
                        className="w-full flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <span className="text-gray-700 font-medium">Go to Admin Panel</span>
                        <span className="text-blue-600 text-sm font-semibold">→</span>
                      </button>
                    )}
                    <p className="text-gray-600">{(userRole === 'admin' || userRole === 'ADMIN') ? 'Admin options available above' : 'More settings coming soon...'}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const ProfilePage = () => (
  <Suspense>
    <ProfilePageInner />
  </Suspense>
);

export default ProfilePage;
