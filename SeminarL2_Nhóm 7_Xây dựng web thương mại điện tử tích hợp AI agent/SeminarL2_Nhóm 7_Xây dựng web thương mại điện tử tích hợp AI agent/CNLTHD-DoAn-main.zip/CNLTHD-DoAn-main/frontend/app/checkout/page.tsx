"use client";
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import CheckoutDelivery from '@/components/checkout/CheckoutDelivery';
import CheckoutShipping from '@/components/checkout/CheckoutShipping';
import CheckoutPayment from '@/components/checkout/CheckoutPayment';
import OrderSummary from '@/components/checkout/OrderSummary';
import { useCart } from '@/context/CartContext';
import { placeOrder } from '@/lib/orders';
import { saveCard as persistCard } from '@/lib/savedCards';
import { useToast } from '@/context/ToastContext';

interface DeliveryFormData {
  email: string;
  firstName: string;
  lastName: string;
  address: string;
  phoneNumber: string;
  billingMatchesShipping: boolean;
}

interface PaymentFormData {
  promoCode: string;
  paymentMethod: 'card' | 'paypal' | 'googlepay';
  cardName: string;
  cardNumber: string;
  expiryDate: string;
  securityCode: string;
  saveCard: boolean;
  setAsDefault: boolean;
}

function validateDelivery(data: DeliveryFormData): string | null {
  if (!data.email?.trim()) return 'Vui lòng nhập email';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return 'Email không hợp lệ';
  if (!data.firstName?.trim()) return 'Vui lòng nhập họ';
  if (!data.lastName?.trim()) return 'Vui lòng nhập tên';
  if (!data.address?.trim()) return 'Vui lòng nhập địa chỉ';
  if (!data.phoneNumber?.trim()) return 'Vui lòng nhập số điện thoại';
  const digits = data.phoneNumber.replace(/\D/g, '');
  if (digits.length !== 10) return 'Số điện thoại phải đúng 10 chữ số';
  if (!digits.startsWith('0')) return 'Số điện thoại phải bắt đầu bằng 0';
  return null;
}

function translateOrderError(msg: string): string {
  if (/out of stock/i.test(msg)) {
    const skuMatch = msg.match(/SKU '([^']+)'/);
    const sku = skuMatch ? ` (${skuMatch[1]})` : '';
    return `Sản phẩm${sku} đã hết hàng. Vui lòng giảm số lượng hoặc chọn sản phẩm khác.`;
  }
  if (/unauthorized/i.test(msg)) return 'Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.';
  if (/failed to fetch|network/i.test(msg)) return 'Lỗi kết nối. Vui lòng kiểm tra mạng và thử lại.';
  return msg;
}

function validatePayment(data: PaymentFormData): string | null {
  if (data.paymentMethod === 'card') {
    if (!data.cardName?.trim()) return 'Vui lòng nhập tên trên thẻ';
    if (!data.cardNumber?.trim()) return 'Vui lòng nhập số thẻ';
    if (data.cardNumber.replace(/\s/g, '').length !== 16) return 'Số thẻ phải có 16 chữ số';
    if (!data.expiryDate?.trim()) return 'Vui lòng nhập ngày hết hạn';
    if (!/^\d{2}\/\d{2}$/.test(data.expiryDate)) return 'Ngày hết hạn không hợp lệ (MM/YY)';
    if (!data.securityCode?.trim()) return 'Vui lòng nhập mã bảo mật';
    if (data.securityCode.length < 3) return 'Mã bảo mật phải có 3-4 chữ số';
  }
  return null;
}

const CheckoutPage = () => {
  const router = useRouter();
  const { items, clearCart, removeItem } = useCart();
  const { showToast } = useToast();
  const [deliveryData, setDeliveryData] = useState<DeliveryFormData | null>(null);
  const [paymentData, setPaymentData] = useState<PaymentFormData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  const handlePlaceOrder = async () => {
    // Check login
    const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
    if (!token) {
      setError('Bạn cần đăng nhập để đặt hàng.');
      setTimeout(() => router.push('/login'), 2000);
      return;
    }
    setError('');

    // Read selected item keys from cart page (if any)
    const selectedRaw = typeof window !== 'undefined' ? localStorage.getItem('cart_selected_ids') : null;
    const selectedIds: string[] | null = selectedRaw ? JSON.parse(selectedRaw) : null;
    const checkoutItems = selectedIds
      ? items.filter((i) => selectedIds.includes(`${i.id}-${i.size}-${i.color}`))
      : items;

    if (checkoutItems.length === 0) {
      setError('Giỏ hàng trống. Vui lòng thêm sản phẩm trước khi đặt hàng.');
      return;
    }

    const itemsWithSku = checkoutItems.filter((i) => i.skuCode);
    if (itemsWithSku.length === 0) {
      setError('SKU_MISSING');
      return;
    }

    if (!deliveryData) {
      setError('Vui lòng điền thông tin giao hàng.');
      return;
    }
    const deliveryError = validateDelivery(deliveryData);
    if (deliveryError) { setError(deliveryError); return; }

    if (!paymentData) {
      setError('Vui lòng điền thông tin thanh toán.');
      return;
    }
    const paymentError = validatePayment(paymentData);
    if (paymentError) { setError(paymentError); return; }

    setIsProcessing(true);
    try {
      const customerId = typeof window !== 'undefined' ? localStorage.getItem('userId') ?? undefined : undefined;
      const userEmail = typeof window !== 'undefined' ? localStorage.getItem('userEmail') ?? deliveryData.email : deliveryData.email;

      // Read applied promo (set by OrderSummary)
      let promoCode: string | undefined;
      let discount = 0;
      let freeShipping = false;
      if (typeof window !== 'undefined') {
        const promoRaw = localStorage.getItem('checkout_promo');
        if (promoRaw) {
          try {
            const p = JSON.parse(promoRaw) as { code?: string; discountAmount?: number; freeShipping?: boolean };
            promoCode = p.code;
            discount = p.discountAmount || 0;
            freeShipping = !!p.freeShipping;
          } catch {}
        }
      }
      // Shipping rule: free if order ≥ 5M OR promo gives free ship
      const subtotal = itemsWithSku.reduce((s, i) => s + i.price * i.quantity, 0);
      const shippingFee = (subtotal >= 5_000_000 || freeShipping) ? 0 : 100_000;

      await placeOrder({
        customerId,
        recipientEmail: userEmail,
        recipientName: `${deliveryData.firstName} ${deliveryData.lastName}`.trim(),
        phone: deliveryData.phoneNumber.replace(/\D/g, ''),
        addressLine: deliveryData.address,
        note: '',
        discount,
        shippingFee,
        promoCode,
        orderLineItemsDtoList: itemsWithSku.map((item) => ({
          skuCode: item.skuCode!,
          price: item.price,
          quantity: item.quantity,
          productName: item.name,
          imageUrl: item.image,
        })),
      });

      // Save card if requested (only for new cards, not masked saved cards)
      if (paymentData.saveCard && paymentData.paymentMethod === 'card' && !paymentData.cardNumber.includes('•')) {
        try {
          persistCard({
            cardName: paymentData.cardName,
            cardNumber: paymentData.cardNumber,
            expiryDate: paymentData.expiryDate,
            setAsDefault: paymentData.setAsDefault,
          });
          showToast(
            paymentData.setAsDefault ? 'Đã lưu thẻ làm mặc định' : 'Đã lưu thẻ cho lần sau',
            'success'
          );
        } catch {
          // Non-fatal — order already placed
        }
      }

      // Remove only the items that were actually checked out, keep the rest in cart
      checkoutItems.forEach((it) => removeItem(it.id, it.size, it.color));
      if (typeof window !== 'undefined') {
        localStorage.removeItem('cart_selected_ids');
        localStorage.removeItem('checkout_promo');
        // Trigger bell to refresh immediately (Kafka → notification-service round-trip
        // takes ~1-2s, so retry a few times)
        const fire = () => window.dispatchEvent(new Event('notifications-refresh'));
        fire();
        setTimeout(fire, 1500);
        setTimeout(fire, 3500);
      }
      router.push('/profile?tab=orders');
    } catch (err: unknown) {
      const raw = err instanceof Error ? err.message : 'Đặt hàng thất bại. Vui lòng thử lại.';
      const message = translateOrderError(raw);
      setError(message);
    } finally {
      setIsProcessing(false);
    }
  };

  const canSubmit = !isProcessing && items.length > 0 && !!deliveryData && !!paymentData;

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-4 md:px-8 py-8">
        <h1 className="text-3xl font-bold text-black mb-8">Checkout</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white">
              <CheckoutDelivery onFormChange={setDeliveryData} />
              <CheckoutShipping />
              <CheckoutPayment onFormChange={setPaymentData} />

              {error && error !== 'SKU_MISSING' && (
                <div className="mt-4 p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 text-sm">
                  {error}
                </div>
              )}
              {error === 'SKU_MISSING' && (
                <div className="mt-4 p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 text-sm">
                  <p className="font-medium mb-2">Sản phẩm trong giỏ hàng cũ không có thông tin kích thước/SKU.</p>
                  <p className="mb-3">Vui lòng xóa giỏ hàng và thêm lại sản phẩm từ trang sản phẩm.</p>
                  <button
                    onClick={() => { clearCart(); router.push('/products'); }}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700"
                  >
                    Xóa giỏ hàng &amp; Tiếp tục mua sắm
                  </button>
                </div>
              )}

              <div className="pt-8 border-t border-gray-200">
                <button
                  onClick={handlePlaceOrder}
                  disabled={!canSubmit}
                  className={`w-full py-4 px-6 rounded-full font-semibold text-lg transition-colors ${
                    !canSubmit
                      ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                      : 'bg-black text-white hover:bg-gray-800'
                  }`}
                >
                  {isProcessing ? 'Đang xử lý...' : 'Place Order'}
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <OrderSummary />
          </div>
        </div>
      </main>
    </div>
  );
};

export default CheckoutPage;
