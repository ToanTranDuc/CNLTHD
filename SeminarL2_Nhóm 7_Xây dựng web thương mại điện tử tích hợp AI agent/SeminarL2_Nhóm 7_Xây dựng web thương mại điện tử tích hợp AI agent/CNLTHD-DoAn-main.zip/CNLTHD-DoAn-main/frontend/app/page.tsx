import Link from "next/link";

export default function Home() {
  const bannerProducts = [
    { id: 1, name: "Áo Thun Basic", price: "250.000đ", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500" },
    { id: 2, name: "Quần Jean Denim", price: "550.000đ", image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500" },
    { id: 3, name: "Áo Khoác Bomber", price: "890.000đ", image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=500" },
  ];

  return (
    <div className="bg-white min-h-screen">
      {/* Banner */}
      <section className="bg-gray-100 py-20 text-center">
        <h2 className="text-5xl font-extrabold mb-4 text-black italic">BỘ SƯU TẬP MÙA HÈ</h2>
        <p className="text-gray-500 mb-8 text-lg">Giảm giá lên đến 50% cho tất cả các mặt hàng mới</p>
        <Link
          href="/products"
          className="inline-block bg-black text-white px-10 py-4 rounded-full font-bold hover:bg-blue-600 transition-all duration-300 shadow-lg"
        >
          Mua ngay
        </Link>
      </section>

      {/* Sản phẩm nổi bật */}
      <main className="max-w-7xl mx-auto py-16 px-4">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h3 className="text-3xl font-bold text-black uppercase tracking-tight">Sản phẩm nổi bật</h3>
            <div className="h-1 w-20 bg-blue-600 mt-2"></div>
          </div>
          <Link href="/products" className="text-blue-600 font-medium hover:underline">Xem tất cả</Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10">
          {bannerProducts.map((product) => (
            <div key={product.id} className="group cursor-pointer">
              <Link href="/products">
                <div className="relative aspect-[3/4] overflow-hidden bg-gray-100 rounded-2xl">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="object-cover w-full h-full group-hover:scale-110 transition duration-500"
                  />
                  <div className="absolute bottom-4 left-4 right-4 translate-y-12 group-hover:translate-y-0 transition duration-300">
                    <span className="block w-full bg-white text-black py-2 rounded-lg font-bold shadow-md text-center">
                      Xem sản phẩm
                    </span>
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900">{product.name}</h4>
                    <p className="text-blue-600 font-bold">{product.price}</p>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
