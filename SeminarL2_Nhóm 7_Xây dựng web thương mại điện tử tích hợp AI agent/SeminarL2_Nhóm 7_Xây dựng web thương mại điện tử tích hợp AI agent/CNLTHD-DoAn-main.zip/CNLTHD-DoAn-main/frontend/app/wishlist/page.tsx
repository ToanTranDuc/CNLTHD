"use client";
import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useWishlist } from '@/context/WishlistContext';
import { useToast } from '@/context/ToastContext';
import BackButton from '@/components/ui/BackButton';

const WishlistPage = () => {
  const router = useRouter();
  const { items, removeItem, count } = useWishlist();
  const { showToast } = useToast();

  const handleRemove = (id: string) => {
    removeItem(id);
    showToast('Đã xóa khỏi danh sách yêu thích', 'wishlist');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="container mx-auto px-4 md:px-8 py-8">
        <BackButton className="mb-4" />
        <div className="flex items-center gap-3 mb-8">
          <Heart className="w-7 h-7 text-red-500 fill-red-500" />
          <h1 className="text-3xl font-bold text-black">Yêu thích</h1>
          {count > 0 && (
            <span className="bg-black text-white text-sm font-semibold px-3 py-1 rounded-full">
              {count}
            </span>
          )}
        </div>

        {items.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-xl p-16 text-center">
            <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">Chưa có sản phẩm yêu thích</h2>
            <p className="text-gray-500 mb-6">Nhấn vào nút &ldquo;Favourite&rdquo; trên trang sản phẩm để lưu vào đây.</p>
            <Link
              href="/products"
              className="inline-flex items-center gap-2 px-6 py-3 bg-black text-white rounded-full font-semibold hover:bg-gray-800 transition-colors"
            >
              Khám phá sản phẩm
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-shadow group"
                >
                  {/* Product image — clickable */}
                  <div className="relative aspect-square bg-gray-100 overflow-hidden">
                    <Link href={`/products/${item.id}`} className="block w-full h-full">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/400x400?text=No+Image';
                        }}
                      />
                    </Link>
                    <button
                      onClick={() => handleRemove(item.id)}
                      className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100 z-10"
                      title="Xóa khỏi yêu thích"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <p className="text-xs text-gray-500 mb-1 uppercase tracking-wide">{item.category}</p>
                    <Link href={`/products/${item.id}`}>
                      <h3 className="font-semibold text-black text-sm mb-2 line-clamp-2 hover:text-blue-600 transition-colors cursor-pointer">{item.name}</h3>
                    </Link>
                    <p className="text-base font-bold text-black mb-4">
                      ₫{item.price.toLocaleString('vi-VN')}
                    </p>

                    <div className="flex gap-2">
                      <Link
                        href={`/products/${item.id}`}
                        className="flex-1 flex items-center justify-center gap-1 px-3 py-2 border-2 border-black text-black text-sm font-semibold rounded-full hover:bg-black hover:text-white transition-colors"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Chọn size
                      </Link>
                      <button
                        onClick={() => handleRemove(item.id)}
                        className="p-2 border border-gray-300 rounded-full hover:border-red-400 hover:text-red-500 transition-colors"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white border border-gray-200 rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-sm text-gray-500">{count} sản phẩm yêu thích</p>
                <p className="text-sm text-gray-600 mt-1">
                  Nhấn &ldquo;Chọn size&rdquo; để vào trang sản phẩm, chọn size và thêm vào giỏ hàng.
                </p>
              </div>
              <button
                onClick={() => router.push('/products')}
                className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-full font-semibold hover:bg-gray-800 transition-colors whitespace-nowrap"
              >
                Tiếp tục mua sắm
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default WishlistPage;
