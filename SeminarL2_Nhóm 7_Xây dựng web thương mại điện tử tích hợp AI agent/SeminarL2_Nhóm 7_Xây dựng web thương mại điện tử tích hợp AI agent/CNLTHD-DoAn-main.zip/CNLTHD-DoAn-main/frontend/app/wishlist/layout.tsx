"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function WishlistLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();

  useEffect(() => {
    // Check authentication
    const token = localStorage.getItem('accessToken');

    // No token - redirect to login
    if (!token) {
      router.push('/login');
      return;
    }

    // User is logged in - allow access
  }, [router]);

  return <>{children}</>;
}
