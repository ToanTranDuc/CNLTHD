"use client";
import React from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import CustomerManagement from '@/components/admin/CustomerManagement';

const AdminCustomerPage = () => {
  return (
    <AdminLayout>
      <CustomerManagement />
    </AdminLayout>
  );
};

export default AdminCustomerPage;
