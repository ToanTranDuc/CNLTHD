"use client";
import React from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import RevenueAnalytics from '@/components/admin/RevenueAnalytics';

const AdminRevenuePage = () => {
  return (
    <AdminLayout>
      <RevenueAnalytics />
    </AdminLayout>
  );
};

export default AdminRevenuePage;
