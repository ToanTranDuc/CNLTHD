"use client";
import React from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import OrderManagement from '@/components/admin/OrderManagement';

const AdminOrderPage = () => {
  return (
    <AdminLayout>
      <OrderManagement />
    </AdminLayout>
  );
};

export default AdminOrderPage;
