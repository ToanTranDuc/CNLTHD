"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check authentication and role
    const token = localStorage.getItem('accessToken');
    const userRole = localStorage.getItem('userRole');

    // No token - redirect to login
    if (!token) {
      router.push('/login');
      setIsLoading(false);
      return;
    }

    // Token exists but role is not admin - redirect to home
    if (userRole !== 'admin' && userRole !== 'ADMIN') {
      router.push('/');
      setIsLoading(false);
      return;
    }

    // User is admin - allow access
    setIsAuthorized(true);
    setIsLoading(false);
  }, [router]);

  // Show nothing while checking
  if (isLoading) {
    return <div className="min-h-screen bg-white" />;
  }

  // Show nothing if not authorized
  if (!isAuthorized) {
    return <div className="min-h-screen bg-white" />;
  }

  // Show content only if authorized
  return <>{children}</>;
}
