"use client";
import React, { useEffect, useState } from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import { fetchAllOrders, fetchAllUsers } from '@/lib/admin';
import { Order, getOrderStatusDisplay, getOrderStatusColor } from '@/lib/orders';
import Link from 'next/link';
import { Package, ShoppingCart, Users, TrendingUp, ArrowRight } from 'lucide-react';

const VND = (n: number) => '₫' + n.toLocaleString('vi-VN');
const REVENUE_STATUSES = new Set(['CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED']);

const AdminDashboard = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [usersCount, setUsersCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [o, u] = await Promise.all([fetchAllOrders(), fetchAllUsers().catch(() => [])]);
        setOrders(o);
        setUsersCount(u.length);
      } catch (e) {
        console.error('Dashboard load failed', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const revenueOrders = orders.filter((o) => REVENUE_STATUSES.has(o.status));
  const totalRevenue = revenueOrders.reduce((s, o) => s + (Number(o.totalAmount) || 0), 0);
  const cancelledCount = orders.filter((o) => o.status === 'CANCELLED').length;
  const pendingCount = orders.filter((o) => o.status === 'PENDING').length;
  const recentOrders = [...orders]
    .sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime())
    .slice(0, 5);

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-black">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Tổng quan toàn bộ hoạt động cửa hàng</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard icon={<TrendingUp className="w-5 h-5" />} label="Tổng doanh thu" value={loading ? '...' : VND(totalRevenue)} accent="green" />
          <StatCard icon={<ShoppingCart className="w-5 h-5" />} label="Tổng đơn hàng" value={loading ? '...' : orders.length.toLocaleString('vi-VN')} accent="blue" sub={`${pendingCount} chờ xử lý`} />
          <StatCard icon={<Package className="w-5 h-5" />} label="Đơn bị huỷ" value={loading ? '...' : cancelledCount.toLocaleString('vi-VN')} accent="red" />
          <StatCard icon={<Users className="w-5 h-5" />} label="Khách hàng" value={loading ? '...' : usersCount.toLocaleString('vi-VN')} accent="purple" />
        </div>

        {/* Recent orders + Quick links */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-black">Đơn hàng gần đây</h3>
              <Link href="/admin/orders" className="text-sm text-blue-600 hover:underline inline-flex items-center gap-1">
                Xem tất cả <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            {loading ? (
              <p className="text-sm text-gray-500">Đang tải...</p>
            ) : recentOrders.length === 0 ? (
              <p className="text-sm text-gray-500">Chưa có đơn hàng nào.</p>
            ) : (
              <div className="space-y-2">
                {recentOrders.map((o) => (
                  <div key={o.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div className="min-w-0 flex-1">
                      <Link href={`/orders/${o.id}`} className="text-sm font-semibold text-black hover:text-blue-600 truncate block">
                        #{o.orderNumber || o.id.substring(0, 8)}
                      </Link>
                      <p className="text-xs text-gray-500 truncate">{o.recipientName || 'N/A'} · {o.items?.length || 0} sản phẩm</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-black">{VND(o.totalAmount)}</p>
                      <span className={`text-[10px] inline-block mt-1 px-2 py-0.5 rounded-full ${getOrderStatusColor(o.status)}`}>
                        {getOrderStatusDisplay(o.status)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-lg font-bold text-black mb-4">Truy cập nhanh</h3>
            <div className="space-y-2">
              <Link href="/admin/orders" className="block p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                <p className="text-sm font-semibold text-black">Quản lý đơn hàng</p>
                <p className="text-xs text-gray-500">Đổi trạng thái, xem chi tiết</p>
              </Link>
              <Link href="/admin/notifications" className="block p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                <p className="text-sm font-semibold text-black">Gửi thông báo</p>
                <p className="text-xs text-gray-500">Broadcast ưu đãi tới khách</p>
              </Link>
              <Link href="/admin/revenue" className="block p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                <p className="text-sm font-semibold text-black">Báo cáo doanh thu</p>
                <p className="text-xs text-gray-500">Biểu đồ 8 tuần, top sản phẩm</p>
              </Link>
              <Link href="/admin/customers" className="block p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                <p className="text-sm font-semibold text-black">Quản lý khách hàng</p>
                <p className="text-xs text-gray-500">Sửa thông tin, khoá tài khoản</p>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string; sub?: string; accent: 'green' | 'blue' | 'red' | 'purple' }> = ({ icon, label, value, sub, accent }) => {
  const colors = {
    green: 'bg-green-100 text-green-700',
    blue: 'bg-blue-100 text-blue-700',
    red: 'bg-red-100 text-red-700',
    purple: 'bg-purple-100 text-purple-700',
  }[accent];
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6">
      <div className={`inline-flex p-2 rounded-lg mb-3 ${colors}`}>{icon}</div>
      <p className="text-gray-600 text-sm font-medium mb-1">{label}</p>
      <h3 className="text-2xl font-bold text-black">{value}</h3>
      {sub && <p className="text-xs text-gray-500 mt-1">{sub}</p>}
    </div>
  );
};

export default AdminDashboard;
