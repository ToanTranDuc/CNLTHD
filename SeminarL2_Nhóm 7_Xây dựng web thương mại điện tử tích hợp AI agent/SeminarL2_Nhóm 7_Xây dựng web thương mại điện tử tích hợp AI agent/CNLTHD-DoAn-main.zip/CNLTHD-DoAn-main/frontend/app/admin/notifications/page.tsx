"use client";
import React from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import NotificationManagement from '@/components/admin/NotificationManagement';

const AdminNotificationsPage = () => {
  return (
    <AdminLayout>
      <NotificationManagement />
    </AdminLayout>
  );
};

export default AdminNotificationsPage;
