"use client";

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { Bell, CheckCheck, Inbox } from 'lucide-react';
import {
  fetchInboxNotifications,
  fetchNotificationStats,
  markAllNotificationsAsRead,
  markNotificationAsRead,
  type NotificationDto,
  type NotificationStatsResponse,
} from '@/lib/notifications';
import { fetchOrderByNumber } from '@/lib/orders';

function formatTime(value: string): string {
  try {
    return new Intl.DateTimeFormat('vi-VN', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function extractOrderNumber(text: string): string | null {
  const m = text.match(/ORD-\d+-[A-Z0-9]+/i);
  return m ? m[0] : null;
}

export default function NotificationsPage() {
  const router = useRouter();
  const [notifications, setNotifications] = useState<NotificationDto[]>([]);
  const [stats, setStats] = useState<NotificationStatsResponse>({ unreadCount: 0, totalCount: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [hasToken, setHasToken] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [inbox, summary] = await Promise.all([
        fetchInboxNotifications(),
        fetchNotificationStats(),
      ]);
      setNotifications(inbox.items);
      setStats(summary);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Không thể tải thông báo');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const token = typeof window === 'undefined' ? null : localStorage.getItem('accessToken');
    setHasToken(Boolean(token));
    if (!token) {
      setLoading(false);
      return;
    }
    load();

    // Re-check auth on auth-changed (so logged-out users don't see leftover data)
    const handler = () => {
      const t = localStorage.getItem('accessToken');
      setHasToken(Boolean(t));
      if (!t) {
        setNotifications([]);
        setStats({ unreadCount: 0, totalCount: 0 });
      } else {
        load();
      }
    };
    window.addEventListener('auth-changed', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('auth-changed', handler);
      window.removeEventListener('storage', handler);
    };
  }, [load]);

  const optimisticMarkRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, status: 'READ' } : n)));
    setStats((s) => ({ ...s, unreadCount: Math.max(0, s.unreadCount - 1) }));
  };

  const handleClick = async (notification: NotificationDto) => {
    // Mark as read (optimistic — update UI first, fire request in background)
    if (notification.status !== 'READ') {
      optimisticMarkRead(notification.id);
      markNotificationAsRead(notification.id).catch((err) => console.warn('Mark read failed', err));
    }

    // Navigate by type
    if (notification.type === 'ORDER') {
      const orderNumber = extractOrderNumber(notification.message) || extractOrderNumber(notification.title);
      if (orderNumber) {
        try {
          const order = await fetchOrderByNumber(orderNumber);
          router.push(`/orders/${order.id}`);
          return;
        } catch {
          // fall through
        }
      }
      router.push('/profile?tab=orders');
    } else if (notification.type === 'ACCOUNT') {
      router.push('/profile');
    } else if (notification.type === 'PROMOTION') {
      router.push('/products');
    }
  };

  const handleMarkAllRead = async () => {
    // Optimistic
    setNotifications((prev) => prev.map((n) => ({ ...n, status: 'READ' })));
    setStats((s) => ({ ...s, unreadCount: 0 }));
    try {
      await markAllNotificationsAsRead();
    } catch (err) {
      console.warn('Mark all read failed', err);
      // Re-fetch authoritative state
      load();
    }
  };

  let inboxContent: React.ReactNode;
  if (loading) {
    inboxContent = <div className="py-16 text-center text-gray-500">Đang tải thông báo...</div>;
  } else if (error) {
    inboxContent = <div className="py-16 text-center text-red-600">{error}</div>;
  } else if (notifications.length === 0) {
    inboxContent = (
      <div className="py-16 text-center text-gray-500">
        <Inbox className="mx-auto h-10 w-10 text-gray-300 mb-3" />
        Chưa có thông báo nào.
      </div>
    );
  } else {
    inboxContent = (
      <ul className="divide-y divide-gray-100">
        {notifications.map((notification) => (
          <li key={notification.id} className="first:pt-0 last:pb-0">
            <button
              type="button"
              onClick={() => handleClick(notification)}
              className="w-full text-left py-5 hover:bg-gray-50 transition-colors px-2 -mx-2 rounded-lg"
            >
              <div className="flex gap-4">
                <div className={`mt-2 h-3 w-3 rounded-full flex-shrink-0 ${notification.status === 'READ' ? 'bg-gray-300' : 'bg-blue-600'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                    <div className="min-w-0">
                      <h2 className={`text-lg ${notification.status === 'READ' ? 'font-medium text-gray-700' : 'font-bold text-black'}`}>
                        {notification.title}
                      </h2>
                      <p className="mt-1 text-sm text-gray-600 line-clamp-2">{notification.message}</p>
                    </div>
                    <span className="text-xs text-gray-400 whitespace-nowrap">{formatTime(notification.createdAt)}</span>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2 items-center">
                    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${
                      notification.type === 'ORDER' ? 'bg-blue-100 text-blue-700'
                      : notification.type === 'ACCOUNT' ? 'bg-purple-100 text-purple-700'
                      : notification.type === 'PROMOTION' ? 'bg-pink-100 text-pink-700'
                      : 'bg-gray-100 text-gray-700'
                    }`}>
                      {notification.type}
                    </span>
                    {notification.status !== 'READ' && (
                      <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700">
                        Mới
                      </span>
                    )}
                    <span className="text-xs text-gray-500 ml-auto">Click để xem chi tiết →</span>
                  </div>
                </div>
              </div>
            </button>
          </li>
        ))}
      </ul>
    );
  }

  if (!hasToken) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="rounded-3xl border border-gray-200 bg-white p-8 shadow-sm">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gray-100 mb-4">
            <Bell className="h-6 w-6 text-black" />
          </div>
          <h1 className="text-3xl font-bold text-black mb-3">Thông báo của bạn</h1>
          <p className="text-gray-600 mb-6">Đăng nhập để xem inbox cá nhân, cập nhật đơn hàng và ưu đãi mới nhất.</p>
          <Link href="/login" className="inline-flex items-center rounded-full bg-black px-5 py-3 text-sm font-semibold text-white hover:bg-gray-800">
            Đăng nhập ngay
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between mb-8">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-gray-500">Inbox</p>
          <h1 className="mt-2 text-4xl font-bold text-black">Thông báo của bạn</h1>
          <p className="mt-3 text-gray-600">Click vào thông báo để xem chi tiết. Đơn hàng → trang đơn, Ưu đãi → sản phẩm.</p>
        </div>

        {stats.unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="inline-flex items-center gap-2 rounded-full border border-gray-200 px-4 py-2 text-sm font-medium text-black hover:bg-gray-50"
          >
            <CheckCheck className="h-4 w-4" />
            Đánh dấu tất cả đã đọc
          </button>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-[260px_1fr]">
        <div className="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm md:sticky md:top-20 md:self-start">
          <p className="text-sm font-semibold text-gray-500 uppercase tracking-[0.2em] mb-4">Tổng quan</p>
          <div className="space-y-4">
            <div className="rounded-2xl bg-gray-50 p-4">
              <p className="text-sm text-gray-500">Chưa đọc</p>
              <p className="mt-1 text-3xl font-bold text-black">{stats.unreadCount}</p>
            </div>
            <div className="rounded-2xl bg-gray-50 p-4">
              <p className="text-sm text-gray-500">Tổng thông báo</p>
              <p className="mt-1 text-3xl font-bold text-black">{stats.totalCount}</p>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm">
          {inboxContent}
        </div>
      </div>
    </div>
  );
}
