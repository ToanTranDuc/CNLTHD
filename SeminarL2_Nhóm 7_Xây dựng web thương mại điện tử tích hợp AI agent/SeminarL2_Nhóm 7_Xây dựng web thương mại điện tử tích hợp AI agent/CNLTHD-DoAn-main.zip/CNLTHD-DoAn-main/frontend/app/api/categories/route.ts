import { NextResponse } from 'next/server';

export async function GET() {
  const apiBase = process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
  try {
    const res = await fetch(`${apiBase}/api/v1/categories`, { cache: 'no-store' });
    const data = await res.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ success: false, data: [] }, { status: 500 });
  }
}
