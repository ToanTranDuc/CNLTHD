"use client";
import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { ArrowLeft, Clock, CheckCircle, Package, XCircle, RotateCcw } from 'lucide-react';
import { fetchOrderById, cancelOrder, getOrderStatusDisplay, getOrderStatusColor, Order } from '@/lib/orders';
import { useToast } from '@/context/ToastContext';
import { useCart } from '@/context/CartContext';
import ConfirmModal from '@/components/ui/ConfirmModal';
import CancelOrderModal from '@/components/ui/CancelOrderModal';

const OrderDetailsPage = () => {
  const router = useRouter();
  const params = useParams();
  const orderId = params.id as string;
  const { showToast } = useToast();
  const { addItem } = useCart();

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);
  const [error, setError] = useState('');
  const [confirmCancelOpen, setConfirmCancelOpen] = useState(false);

  const canCancel = order && (order.status === 'PENDING' || order.status === 'CONFIRMED');
  const canReorder = order && (order.status === 'CANCELLED' || order.status === 'DELIVERED');

  const handleCancelClick = () => setConfirmCancelOpen(true);

  const handleCancelConfirm = async (reason: string) => {
    if (!order) return;
    setCancelling(true);
    try {
      const updated = await cancelOrder(order.id, reason);
      setOrder(updated);
      setConfirmCancelOpen(false);
      showToast('Đã huỷ đơn hàng thành công', 'success');
      // Trigger bell refresh — cancellation publishes a notification via Kafka
      if (typeof window !== 'undefined') {
        const fire = () => window.dispatchEvent(new Event('notifications-refresh'));
        fire();
        setTimeout(fire, 1500);
        setTimeout(fire, 3500);
      }
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Huỷ đơn thất bại', 'error');
    } finally {
      setCancelling(false);
    }
  };

  const handleReorder = () => {
    if (!order || !order.items) return;
    let addedCount = 0;
    for (const item of order.items) {
      if (!item.skuCode) continue;
      addItem({
        id: item.productId || item.skuCode,
        name: item.name,
        category: order.items[0]?.name?.split(' ')[0] || 'Product',
        color: item.color || '',
        size: item.size || '',
        price: item.price,
        quantity: item.quantity,
        image: item.image || '',
        skuCode: item.skuCode,
      });
      addedCount += item.quantity;
    }
    if (addedCount > 0) {
      showToast(`Đã thêm ${addedCount} sản phẩm vào giỏ. Đang chuyển tới giỏ hàng...`, 'success');
      setTimeout(() => router.push('/cart'), 1000);
    } else {
      showToast('Không có sản phẩm nào có thể đặt lại', 'error');
    }
  };

  useEffect(() => {
    const loadOrder = async () => {
      if (!orderId) return;

      setLoading(true);
      setError('');

      try {
        const data = await fetchOrderById(orderId);
        setOrder(data);
      } catch (err) {
        console.error('Error fetching order:', err);
        setError('Không thể tải chi tiết đơn hàng');
      } finally {
        setLoading(false);
      }
    };

    loadOrder();
  }, [orderId]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'SHIPPED':
        return <Clock className="w-4 h-4" />;
      case 'DELIVERED':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Package className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Đang tải...</p>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-black mb-4">
            {error || 'Không tìm thấy đơn hàng'}
          </h2>
          <button
            onClick={() => router.push('/profile?tab=orders')}
            className="px-4 py-2 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Quay lại lịch sử
          </button>
        </div>
      </div>
    );
  }

  // Use real backend values when available; fall back to client computation if absent
  const itemsTotal = order.items?.reduce((sum, item) => sum + (item.price * item.quantity), 0) || 0;
  const subtotal = order.subtotal ?? itemsTotal;
  const shipping = order.shippingFee ?? 0;
  const discount = order.discount ?? 0;
  const total = order.totalAmount ?? Math.max(0, subtotal - discount + shipping);

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="container mx-auto px-4 md:px-8 py-8">
          {/* Header with Back Button */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => router.push('/profile?tab=orders')}
            className="flex items-center gap-2 text-black hover:text-gray-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Quay lại</span>
          </button>
        </div>

        {/* Order Summary */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 md:p-8 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {/* Order ID */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Mã đơn hàng</p>
              <p className="text-xl font-bold text-black">#{order.orderNumber || order.id}</p>
            </div>

            {/* Order Date */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Ngày đặt hàng</p>
              <p className="text-lg font-medium text-black">
                {new Date(order.createdAt || '').toLocaleDateString('vi-VN')}
              </p>
            </div>

            {/* Status */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Trạng thái</p>
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${getOrderStatusColor(order.status)}`}>
                {getStatusIcon(order.status)}
                {getOrderStatusDisplay(order.status)}
              </div>
            </div>

            {/* Shipping Address */}
            <div>
              <p className="text-sm text-gray-600 mb-2">Địa chỉ giao</p>
              <p className="text-sm font-medium text-black">
                {order.shippingAddress}
              </p>
            </div>
          </div>
        </div>

        {/* Order Items */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 md:p-8 mb-6">
          <h2 className="text-2xl font-bold text-black mb-6">Chi tiết đơn hàng</h2>

          <div className="space-y-6">
            {order.items?.map((item, index) => (
              <div key={index} className="flex gap-6 pb-6 border-b border-gray-200 last:border-b-0">
                {/* Product Image */}
                {item.image && (
                  <div className="flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-lg bg-gray-100"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/150';
                      }}
                    />
                  </div>
                )}

                {/* Product Details */}
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black mb-2">{item.name}</h3>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    {/* Color */}
                    {item.color && (
                      <div>
                        <p className="text-sm text-gray-600 mb-1">Màu sắc</p>
                        <p className="font-medium text-black">{item.color}</p>
                      </div>
                    )}

                    {/* Size */}
                    {item.size && (
                      <div>
                        <p className="text-sm text-gray-600 mb-1">Size</p>
                        <p className="font-medium text-black">{item.size}</p>
                      </div>
                    )}

                    {/* Quantity */}
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Số lượng</p>
                      <p className="font-medium text-black">x{item.quantity}</p>
                    </div>

                    {/* Unit Price */}
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Đơn giá</p>
                      <p className="font-medium text-black">đ{item.price.toLocaleString('vi-VN')}</p>
                    </div>
                  </div>

                  {/* Item Total */}
                  <div className="flex justify-end">
                    <p className="text-lg font-bold text-black">
                      Thành tiền: đ{(item.price * item.quantity).toLocaleString('vi-VN')}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary / Total */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 md:p-8">
          <h2 className="text-2xl font-bold text-black mb-6">Tóm tắt đơn hàng</h2>

          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center pb-4 border-b border-gray-200">
              <p className="text-gray-600 font-medium">Tạm tính</p>
              <p className="text-black font-medium">₫{subtotal.toLocaleString('vi-VN')}</p>
            </div>

            {discount > 0 && (
              <div className="flex justify-between items-center pb-4 border-b border-gray-200">
                <p className="text-green-700 font-medium">Giảm giá</p>
                <p className="text-green-700 font-medium">-₫{discount.toLocaleString('vi-VN')}</p>
              </div>
            )}

            <div className="flex justify-between items-center pb-4 border-b border-gray-200">
              <p className="text-gray-600 font-medium">Phí vận chuyển</p>
              <p className="text-black font-medium">{shipping > 0 ? `₫${shipping.toLocaleString('vi-VN')}` : 'Miễn phí'}</p>
            </div>

            <div className="flex justify-between items-center pt-4">
              <p className="text-xl font-bold text-black">Tổng cộng</p>
              <p className="text-3xl font-bold text-black">₫{total.toLocaleString('vi-VN')}</p>
            </div>
          </div>

          {/* Payment Method & Notes & Cancel reason */}
          <div className="border-t border-gray-200 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-semibold text-gray-600 mb-2">Phương thức thanh toán</p>
                <p className="text-black font-medium">{order.paymentMethod || 'COD (mặc định)'}</p>
              </div>
              {order.notes && (
                <div>
                  <p className="text-sm font-semibold text-gray-600 mb-2">Ghi chú</p>
                  <p className="text-black font-medium">{order.notes}</p>
                </div>
              )}
              {order.cancelReason && (
                <div className="md:col-span-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm font-semibold text-red-700 mb-1">Lý do huỷ đơn</p>
                  <p className="text-red-800 text-sm">{order.cancelReason}</p>
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => router.push('/profile?tab=orders')}
              className="flex-1 px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
            >
              Quay lại lịch sử
            </button>
            {canReorder && (
              <button
                onClick={handleReorder}
                className="flex-1 px-6 py-3 bg-blue-50 border-2 border-blue-500 text-blue-600 rounded-lg font-medium hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Đặt lại đơn hàng
              </button>
            )}
            {canCancel && (
              <button
                onClick={handleCancelClick}
                disabled={cancelling}
                className="flex-1 px-6 py-3 bg-red-50 border-2 border-red-500 text-red-600 rounded-lg font-medium hover:bg-red-100 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
              >
                <XCircle className="w-4 h-4" />
                Huỷ đơn hàng
              </button>
            )}
          </div>
          {canCancel && (
            <p className="text-xs text-gray-500 mt-3 text-center sm:text-left">
              Bạn có thể huỷ đơn khi đơn còn ở trạng thái <strong>Chờ xác nhận</strong> hoặc <strong>Đã xác nhận</strong>.
            </p>
          )}

          <CancelOrderModal
            open={confirmCancelOpen}
            orderNumber={order?.orderNumber || order?.id || ''}
            loading={cancelling}
            onConfirm={handleCancelConfirm}
            onCancel={() => setConfirmCancelOpen(false)}
          />
        </div>
      </main>
    </div>
  );
};

export default OrderDetailsPage;
