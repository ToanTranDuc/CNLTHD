"use client";
import React, { useState, useMemo, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Trash2 } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';
import CartItemComponent from '@/components/cart/CartItem';
import CartSummary from '@/components/cart/CartSummary';
import BackButton from '@/components/ui/BackButton';
import ConfirmModal from '@/components/ui/ConfirmModal';
import { CartItem } from '@/types/Cart';

const itemKey = (i: CartItem) => `${i.id}-${i.size}-${i.color}`;

const CartPage = () => {
  const router = useRouter();
  const { items, removeItem } = useCart();
  const { showToast } = useToast();

  const [selectedIds, setSelectedIds] = useState<Set<string>>(
    () => new Set(items.map(itemKey))
  );
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setSelectedIds((prev) => {
      const keys = new Set(items.map(itemKey));
      const next = new Set<string>();
      prev.forEach((k) => { if (keys.has(k)) next.add(k); });
      // Also add newly-added items to selection by default
      items.forEach((i) => {
        const k = itemKey(i);
        if (!prev.has(k)) next.add(k);
      });
      return next;
    });
  }, [items]);

  const toggleSelect = (key: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const allSelected = items.length > 0 && items.every((i) => selectedIds.has(itemKey(i)));
  const toggleAll = () => {
    if (allSelected) setSelectedIds(new Set());
    else setSelectedIds(new Set(items.map(itemKey)));
  };

  const selectedItems = useMemo(
    () => items.filter((i) => selectedIds.has(itemKey(i))),
    [items, selectedIds]
  );

  const handleCheckout = () => {
    if (selectedItems.length === 0) return;
    // Require login at checkout
    const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
    if (!token) {
      showToast('Vui lòng đăng nhập để thanh toán', 'info');
      // Preserve selected ids so after login + return, cart stays selected
      localStorage.setItem('cart_selected_ids', JSON.stringify(Array.from(selectedIds)));
      setTimeout(() => router.push('/login'), 800);
      return;
    }
    localStorage.setItem('cart_selected_ids', JSON.stringify(Array.from(selectedIds)));
    router.push('/checkout');
  };

  const handleBulkDelete = () => {
    const toDelete = selectedItems.slice();
    toDelete.forEach((it) => removeItem(it.id, it.size, it.color));
    showToast(`Đã xóa ${toDelete.length} sản phẩm khỏi giỏ`, 'success');
    setConfirmDelete(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <main className="container mx-auto px-4 md:px-8 py-8">
        <BackButton className="mb-4" />
        <h1 className="text-3xl font-bold text-black mb-8">Bag</h1>

        {items.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-xl text-gray-600 mb-4">Your bag is empty</p>
            <Link href="/products" className="inline-block text-black hover:text-blue-600 font-medium underline">
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column */}
            <div className="md:col-span-2">
              {/* Select All + bulk actions */}
              <div className="flex flex-wrap items-center gap-3 pb-4 border-b border-gray-200 mb-2">
                <input
                  type="checkbox"
                  id="select-all"
                  checked={allSelected}
                  onChange={toggleAll}
                  className="w-4 h-4 accent-black cursor-pointer"
                />
                <label htmlFor="select-all" className="text-sm font-medium text-gray-700 cursor-pointer select-none">
                  Chọn tất cả ({items.length} sản phẩm)
                </label>
                {selectedIds.size > 0 && selectedIds.size < items.length && (
                  <span className="text-xs text-gray-500">— đã chọn {selectedIds.size}</span>
                )}

                {selectedIds.size > 0 && (
                  <button
                    onClick={() => setConfirmDelete(true)}
                    className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 text-sm text-red-600 border border-red-300 rounded-lg hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    Xóa đã chọn ({selectedIds.size})
                  </button>
                )}
              </div>

              <div className="space-y-0">
                {items.map((item) => {
                  const key = itemKey(item);
                  return (
                    <CartItemComponent
                      key={key}
                      item={item}
                      isSelected={selectedIds.has(key)}
                      onToggleSelect={() => toggleSelect(key)}
                    />
                  );
                })}
              </div>
            </div>

            {/* Right Column */}
            <div className="md:col-span-1 md:sticky md:top-20 md:h-fit">
              <CartSummary selectedItems={selectedItems} onCheckout={handleCheckout} />
            </div>
          </div>
        )}

        <ConfirmModal
          open={confirmDelete}
          title={`Xóa ${selectedIds.size} sản phẩm?`}
          message="Bạn có chắc muốn xóa các sản phẩm đã chọn khỏi giỏ hàng?"
          confirmText="Xóa"
          cancelText="Không"
          variant="danger"
          onConfirm={handleBulkDelete}
          onCancel={() => setConfirmDelete(false)}
        />
      </main>
    </div>
  );
};

export default CartPage;
