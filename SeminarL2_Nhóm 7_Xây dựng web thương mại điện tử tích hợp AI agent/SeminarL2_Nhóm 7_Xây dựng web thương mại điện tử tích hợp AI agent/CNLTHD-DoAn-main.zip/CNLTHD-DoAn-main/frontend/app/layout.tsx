'use client';

import type { Metadata } from "next";
// @ts-ignore
import "./globals.css";
// 1. Import component Header
import Header from "@/components/layout/Header";
// 2. Import component Footer (Giả sử bạn để file tại components/layout/Footer.tsx)
import Footer from "@/components/layout/Footer";
// 3. Import CartProvider
import { CartProvider } from "@/context/CartContext";
import { WishlistProvider } from "@/context/WishlistContext";
import { ToastProvider } from "@/context/ToastContext";
import StoreChatWidget from "@/components/chatbot/StoreChatWidget";
import { usePathname } from "next/navigation";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isAdminPage = pathname.startsWith('/admin');

  return (
    <html lang="vi">
      <body className="antialiased flex flex-col min-h-screen">
        <CartProvider>
          <WishlistProvider>
          <ToastProvider>
          {/* Header — luôn hiển thị; ở trang admin sẽ ẩn các icon dành cho khách */}
          <Header />

          {/* main với flex-grow giúp đẩy Footer xuống đáy trang
            ngay cả khi trang đó có ít nội dung
          */}
          <main className="flex-grow">
            {children}
          </main>

          {!isAdminPage && <StoreChatWidget />}

          {/* Footer — ẩn trên trang admin */}
          {!isAdminPage && <Footer />}
          </ToastProvider>
          </WishlistProvider>
        </CartProvider>
      </body>
    </html>
  );
}