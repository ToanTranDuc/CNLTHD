/**
 * Inventory helpers — fetch stock by SKU.
 * Backend endpoint (through gateway): GET /api/v1/stocks/{skuCode}
 * (rewritten to /api/stocks/{skuCode} on inventory-service side)
 */

const API_BASE = typeof window !== 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
  : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

export interface StockInfo {
  skuCode: string;
  quantity: number;
}

export async function fetchStock(skuCode: string): Promise<number> {
  try {
    const res = await fetch(`${API_BASE}/api/v1/stocks/${encodeURIComponent(skuCode)}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });
    if (!res.ok) return 0;
    const data = await res.json();
    const qty = data?.data?.quantity;
    return typeof qty === 'number' ? qty : 0;
  } catch {
    return 0;
  }
}

/** Buffer below stock so we never order to the last unit (warehouse safety stock). */
export const STOCK_SAFETY_BUFFER = 2;

/** Max quantity a customer is allowed to put in cart for a given SKU. */
export function maxOrderable(stock: number): number {
  return Math.max(0, stock - STOCK_SAFETY_BUFFER);
}
