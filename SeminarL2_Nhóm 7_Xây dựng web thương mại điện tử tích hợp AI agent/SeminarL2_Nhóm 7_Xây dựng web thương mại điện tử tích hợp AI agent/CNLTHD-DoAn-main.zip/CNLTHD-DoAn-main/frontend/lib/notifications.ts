export interface NotificationDto {
  id: string;
  recipientUserId: string;
  recipientEmail: string | null;
  title: string;
  message: string;
  type: string;
  status: string;
  channel: string;
  createdAt: string;
  deliveredAt: string | null;
  readAt: string | null;
}

export interface NotificationListResponse {
  items: NotificationDto[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  unreadCount: number;
}

export interface NotificationStatsResponse {
  unreadCount: number;
  totalCount: number;
}

export interface NotificationCreatePayload {
  recipientUserId: string;
  recipientEmail?: string | null;
  title: string;
  message: string;
  type: string;
  channel: string;
}

function getAccessToken(): string | null {
  if (globalThis.window === undefined) {
    return null;
  }

  return localStorage.getItem('accessToken');
}

function getUserId(): string | null {
  if (globalThis.window === undefined) return null;
  return localStorage.getItem('userId');
}

function getApiBaseUrl(): string {
  return process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
}

async function fetchJson<T>(path: string, init?: RequestInit): Promise<T> {
  const accessToken = getAccessToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  if (accessToken) {
    headers.Authorization = `Bearer ${accessToken}`;
  }

  if (init?.headers) {
    Object.assign(headers, init.headers);
  }

  const response = await fetch(`${getApiBaseUrl()}${path}`, {
    cache: 'no-store',
    ...init,
    headers,
  });

  const payload = await response.json();
  if (!response.ok || !payload.success) {
    throw new Error(payload.message || `Request failed with status ${response.status}`);
  }

  return payload.data as T;
}

export async function fetchInboxNotifications(): Promise<NotificationListResponse> {
  const uid = getUserId();
  const qs = uid ? `?userId=${encodeURIComponent(uid)}` : '';
  return fetchJson<NotificationListResponse>(`/api/v1/notifications${qs}`);
}

export async function fetchNotificationStats(): Promise<NotificationStatsResponse> {
  const uid = getUserId();
  const qs = uid ? `?userId=${encodeURIComponent(uid)}` : '';
  return fetchJson<NotificationStatsResponse>(`/api/v1/notifications/stats${qs}`);
}

export async function createNotification(payload: NotificationCreatePayload) {
  return fetchJson<{ id: string }>(`/api/v1/notifications`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export async function markNotificationAsRead(notificationId: string) {
  const uid = getUserId();
  const qs = uid ? `?recipientUserId=${encodeURIComponent(uid)}` : '';
  return fetchJson<void>(`/api/v1/notifications/${notificationId}/read${qs}`, { method: 'PATCH' });
}

export async function markAllNotificationsAsRead() {
  const uid = getUserId();
  const qs = uid ? `?userId=${encodeURIComponent(uid)}` : '';
  return fetchJson<NotificationStatsResponse>(`/api/v1/notifications/read-all${qs}`, { method: 'PATCH' });
}