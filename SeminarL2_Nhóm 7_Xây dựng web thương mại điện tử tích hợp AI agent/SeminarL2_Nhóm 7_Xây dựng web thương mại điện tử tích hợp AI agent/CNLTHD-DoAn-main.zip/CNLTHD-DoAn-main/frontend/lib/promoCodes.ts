/**
 * Promo code client — talks to Order-Service /api/v1/promo-codes.
 * Codes are persisted in the order_service.promo_codes table.
 */

const API_BASE = typeof window !== 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
  : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

function authHeaders(): Record<string, string> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}

export interface PromoCode {
  id: string;
  code: string;
  description?: string;
  percentOff: number;
  amountOff: number;
  maxDiscount: number;
  minSubtotal: number;
  freeShipping: boolean;
  expiresAt?: string | null;
  maxUses: number;
  usedCount: number;
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface PromoApplyResult {
  ok: boolean;
  error?: string;
  promo?: { code: string; description?: string };
  discountAmount: number;
  freeShipping: boolean;
}

export interface PromoCodePayload {
  code: string;
  description?: string;
  percentOff?: number;
  amountOff?: number;
  maxDiscount?: number;
  minSubtotal?: number;
  freeShipping?: boolean;
  expiresAt?: string | null;
  maxUses?: number;
  active?: boolean;
}

/* ───── Admin CRUD ───── */

export async function listPromoCodes(activeOnly = false): Promise<PromoCode[]> {
  const res = await fetch(`${API_BASE}/api/v1/promo-codes?activeOnly=${activeOnly}`, { headers: authHeaders() });
  if (!res.ok) throw new Error(`Lỗi tải danh sách mã (${res.status})`);
  const data = await res.json();
  return (data.data || []) as PromoCode[];
}

export async function createPromoCode(payload: PromoCodePayload): Promise<PromoCode> {
  const res = await fetch(`${API_BASE}/api/v1/promo-codes`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Tạo mã thất bại (${res.status})`);
  }
  const data = await res.json();
  return data.data as PromoCode;
}

export async function togglePromoCode(id: string): Promise<PromoCode> {
  const res = await fetch(`${API_BASE}/api/v1/promo-codes/${id}/toggle`, {
    method: 'PATCH',
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error(`Toggle failed (${res.status})`);
  const data = await res.json();
  return data.data as PromoCode;
}

export async function deletePromoCode(id: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/v1/promo-codes/${id}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error(`Delete failed (${res.status})`);
}

/* ───── Customer validate ───── */

export async function validatePromo(code: string, subtotal: number): Promise<PromoApplyResult> {
  if (!code || !code.trim()) {
    return { ok: false, error: 'Vui lòng nhập mã', discountAmount: 0, freeShipping: false };
  }
  try {
    const res = await fetch(
      `${API_BASE}/api/v1/promo-codes/validate?code=${encodeURIComponent(code.trim())}&subtotal=${subtotal}`,
      { headers: authHeaders() }
    );
    if (!res.ok) {
      return { ok: false, error: 'Không thể kiểm tra mã, thử lại sau', discountAmount: 0, freeShipping: false };
    }
    const data = await res.json();
    const d = data.data || {};
    if (!d.valid) {
      return { ok: false, error: d.message || 'Mã không hợp lệ', discountAmount: 0, freeShipping: false };
    }
    return {
      ok: true,
      promo: { code: d.code, description: d.description },
      discountAmount: Number(d.discountAmount || 0),
      freeShipping: Boolean(d.freeShipping),
    };
  } catch {
    return { ok: false, error: 'Lỗi kết nối', discountAmount: 0, freeShipping: false };
  }
}
