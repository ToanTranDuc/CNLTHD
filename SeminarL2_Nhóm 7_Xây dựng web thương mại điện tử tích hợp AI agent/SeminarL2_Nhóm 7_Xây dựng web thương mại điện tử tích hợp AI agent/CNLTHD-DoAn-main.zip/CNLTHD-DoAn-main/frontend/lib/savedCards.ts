export interface SavedCard {
  id: string;
  cardName: string;
  last4: string;
  expiryDate: string;
  isDefault: boolean;
  createdAt: string;
}

/** Scope cards by current logged-in user so each customer sees only their own saved cards. */
function storageKey(): string {
  if (typeof window === 'undefined') return 'cnlthd_saved_cards_guest';
  const uid = localStorage.getItem('userId');
  return uid ? `cnlthd_saved_cards_${uid}` : 'cnlthd_saved_cards_guest';
}

export function loadSavedCards(): SavedCard[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(storageKey());
    return raw ? (JSON.parse(raw) as SavedCard[]) : [];
  } catch {
    return [];
  }
}

export function saveCard(card: {
  cardName: string;
  cardNumber: string;
  expiryDate: string;
  setAsDefault: boolean;
}): SavedCard {
  const cards = loadSavedCards();
  const digits = card.cardNumber.replace(/\D/g, '');
  const last4 = digits.slice(-4);
  const id = `card_${Date.now()}`;

  const existing = cards.find((c) => c.last4 === last4 && c.expiryDate === card.expiryDate);
  if (existing) {
    if (card.setAsDefault) makeDefault(existing.id);
    return existing;
  }

  let updated = cards;
  if (card.setAsDefault) {
    updated = cards.map((c) => ({ ...c, isDefault: false }));
  }

  const newCard: SavedCard = {
    id,
    cardName: card.cardName,
    last4,
    expiryDate: card.expiryDate,
    isDefault: card.setAsDefault || cards.length === 0,
    createdAt: new Date().toISOString(),
  };

  updated = [...updated, newCard];
  localStorage.setItem(storageKey(), JSON.stringify(updated));
  return newCard;
}

export function removeCard(id: string): void {
  const cards = loadSavedCards().filter((c) => c.id !== id);
  if (cards.length > 0 && !cards.some((c) => c.isDefault)) {
    cards[0].isDefault = true;
  }
  localStorage.setItem(storageKey(), JSON.stringify(cards));
}

export function makeDefault(id: string): void {
  const cards = loadSavedCards().map((c) => ({ ...c, isDefault: c.id === id }));
  localStorage.setItem(storageKey(), JSON.stringify(cards));
}

export function getDefaultCard(): SavedCard | undefined {
  return loadSavedCards().find((c) => c.isDefault);
}
