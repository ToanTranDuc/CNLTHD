import { Order, mapOrderForAdmin } from './orders';

const API_BASE = typeof window !== 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
  : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

function authHeaders(): Record<string, string> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}

export interface AdminUser {
  id: string;
  email: string;
  fullname: string;
  sdt?: string;
  role?: string;
  isActive?: boolean;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export async function activateUser(id: string): Promise<AdminUser> {
  const res = await fetch(`${API_BASE}/api/admin/users/${id}/activate`, {
    method: 'PUT',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Activate failed (${res.status})`);
  }
  const data = await res.json();
  return data.data as AdminUser;
}

export async function deactivateUser(id: string): Promise<AdminUser> {
  const res = await fetch(`${API_BASE}/api/admin/users/${id}/deactivate`, {
    method: 'PUT',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Deactivate failed (${res.status})`);
  }
  const data = await res.json();
  return data.data as AdminUser;
}

export interface UpdateUserPayload {
  fullname?: string;
  email?: string;
  sdt?: string;
  password?: string;
  role?: string;
}

export async function updateUser(id: string, payload: UpdateUserPayload): Promise<AdminUser> {
  const res = await fetch(`${API_BASE}/api/admin/users/${id}`, {
    method: 'PATCH',
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Update failed (${res.status})`);
  }
  const data = await res.json();
  return data.data as AdminUser;
}

export async function fetchAllOrders(): Promise<Order[]> {
  const res = await fetch(`${API_BASE}/api/v1/orders`, { headers: authHeaders() });
  if (!res.ok) throw new Error(`Failed to fetch orders: ${res.statusText}`);
  const data = await res.json();
  if (data.success && Array.isArray(data.data)) {
    return (data.data as Record<string, unknown>[]).map(mapOrderForAdmin);
  }
  return [];
}

export async function updateOrderStatus(orderId: string, status: string): Promise<Order> {
  const res = await fetch(`${API_BASE}/api/v1/orders/${orderId}/status?status=${encodeURIComponent(status)}`, {
    method: 'PATCH',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Update failed (${res.status})`);
  }
  const data = await res.json();
  return mapOrderForAdmin(data.data as Record<string, unknown>);
}

export async function fetchAllUsers(): Promise<AdminUser[]> {
  const res = await fetch(`${API_BASE}/api/admin/users?size=200`, { headers: authHeaders() });
  if (!res.ok) throw new Error(`Failed to fetch users: ${res.statusText}`);
  const data = await res.json();
  // The endpoint may wrap response in Page<UserDto> or list - handle both
  const raw = data.data;
  if (Array.isArray(raw)) return raw as AdminUser[];
  if (raw && Array.isArray(raw.content)) return raw.content as AdminUser[];
  if (raw && Array.isArray(raw.users)) return raw.users as AdminUser[];
  return [];
}

export interface PromotionPayload {
  title: string;
  message: string;
  recipientUserIds: string[]; // empty = broadcast logical (we just create per id)
}

export async function createNotificationForUser(payload: {
  recipientUserId: string;
  recipientEmail?: string | null;
  title: string;
  message: string;
  type?: string;
  channel?: string;
}): Promise<void> {
  const body = {
    recipientUserId: payload.recipientUserId,
    recipientEmail: payload.recipientEmail ?? null,
    title: payload.title,
    message: payload.message,
    type: payload.type ?? 'PROMOTION',
    channel: payload.channel ?? 'IN_APP',
  };
  const res = await fetch(`${API_BASE}/api/v1/notifications`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.message || `Failed to create notification (${res.status})`);
  }
}

export async function sendPromotionToUsers(promo: PromotionPayload): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;
  for (const userId of promo.recipientUserIds) {
    try {
      await createNotificationForUser({
        recipientUserId: userId,
        title: promo.title,
        message: promo.message,
        type: 'PROMOTION',
      });
      success++;
    } catch {
      failed++;
    }
  }
  return { success, failed };
}
