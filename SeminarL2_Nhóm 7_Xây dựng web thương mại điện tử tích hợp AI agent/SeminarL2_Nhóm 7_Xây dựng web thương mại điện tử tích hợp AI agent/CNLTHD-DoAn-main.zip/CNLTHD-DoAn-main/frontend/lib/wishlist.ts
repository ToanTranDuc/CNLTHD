const API_BASE = typeof window !== 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
  : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

function authHeaders(): Record<string, string> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}

export interface WishlistItemDto {
  id: string;
  userId: string;
  productId: string;
  productName: string;
  imageUrl?: string;
  price?: number;
  category?: string;
  createdAt?: string;
}

export async function fetchWishlist(userId: string): Promise<WishlistItemDto[]> {
  const res = await fetch(`${API_BASE}/api/v1/wishlist?userId=${encodeURIComponent(userId)}`, {
    method: 'GET',
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error(`Failed to fetch wishlist: ${res.statusText}`);
  const data = await res.json();
  return (data.data || []) as WishlistItemDto[];
}

export async function addToWishlist(payload: {
  userId: string;
  productId: string;
  productName: string;
  imageUrl?: string;
  price?: number;
  category?: string;
}): Promise<WishlistItemDto> {
  const res = await fetch(`${API_BASE}/api/v1/wishlist`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Add wishlist failed (${res.status})`);
  }
  const data = await res.json();
  return data.data as WishlistItemDto;
}

export async function removeFromWishlist(userId: string, productId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/v1/wishlist/${encodeURIComponent(productId)}?userId=${encodeURIComponent(userId)}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Remove wishlist failed (${res.status})`);
  }
}

export async function clearWishlistApi(userId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/v1/wishlist?userId=${encodeURIComponent(userId)}`, {
    method: 'DELETE',
    headers: authHeaders(),
  });
  if (!res.ok) throw new Error(`Clear wishlist failed (${res.status})`);
}
