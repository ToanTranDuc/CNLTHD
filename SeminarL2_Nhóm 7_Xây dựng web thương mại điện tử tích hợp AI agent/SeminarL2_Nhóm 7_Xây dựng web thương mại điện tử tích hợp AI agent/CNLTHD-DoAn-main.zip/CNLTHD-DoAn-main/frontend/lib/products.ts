import { Product } from '@/types/Product';

const FALLBACK_IMAGE = 'https://placehold.co/800x1000/png?text=No+Image';

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
}

interface BackendApiResponse<T> {
  success: boolean;
  message: string | null;
  data: T;
  timestamp: string;
}

interface BackendProductColor {
  code: string;
  name: string;
  hex: string;
}

interface BackendProductVariant {
  id: string;
  size: string;
  sizeDisplayName: string;
  color: string;
  colorDisplayName: string;
  colorHex: string;
  price: number;
  sku: string;
  inStock: boolean;
}

interface BackendProductDetails {
  colorShown: string;
  style: string;
  country: string;
}

interface BackendProduct {
  id: string;
  name: string;
  description: string;
  brand: string;
  slug: string;
  basePrice: number;
  categoryId: string;
  categoryName: string;
  image: string | null;
  images: string[] | null;
  variants: BackendProductVariant[] | null;
  colors: BackendProductColor[] | null;
  sizes: string[] | null;
  isNew: boolean | null;
  details: BackendProductDetails | null;
  gender: 'MEN' | 'WOMEN' | 'UNISEX' | null;
}

function getApiBaseUrl(): string {
  // API_BASE_URL is for server-side (Docker internal network). Falls back to public URL for dev.
  return process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';
}

async function fetchApi<T>(path: string): Promise<T> {
  const response = await fetch(`${getApiBaseUrl()}${path}`, {
    cache: 'no-store',
  });

  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }

  const payload = (await response.json()) as BackendApiResponse<T>;
  return payload.data;
}

function mapSizes(product: BackendProduct): Product['sizes'] {
  const variants = product.variants ?? [];
  const baseSizes = product.sizes ?? [];
  const seen = new Set<string>();
  const sizes: Product['sizes'] = [];

  for (const size of baseSizes) {
    const matchingVariants = variants.filter((variant) => variant.size === size);
    sizes.push({
      size,
      inStock: matchingVariants.length > 0
        ? matchingVariants.some((variant) => variant.inStock)
        : true,
    });
    seen.add(size);
  }

  for (const variant of variants) {
    if (seen.has(variant.size)) {
      continue;
    }
    sizes.push({
      size: variant.size,
      inStock: variant.inStock,
    });
    seen.add(variant.size);
  }

  return sizes;
}

function mapColors(product: BackendProduct, primaryImage: string): Product['colors'] {
  const backendColors = product.colors ?? [];
  if (backendColors.length > 0) {
    return backendColors.map((color) => ({
      name: color.name,
      image: primaryImage,
      hex: color.hex,
    }));
  }

  const variantColors = new Map<string, Product['colors'][number]>();
  for (const variant of product.variants ?? []) {
    if (!variantColors.has(variant.color)) {
      variantColors.set(variant.color, {
        name: variant.colorDisplayName || variant.color,
        image: primaryImage,
        hex: variant.colorHex,
      });
    }
  }

  return Array.from(variantColors.values());
}

function mapBackendProduct(product: BackendProduct): Product {
  const galleryImages = product.images?.filter(Boolean) ?? [];
  const primaryImage = product.image || galleryImages[0] || FALLBACK_IMAGE;
  const images = galleryImages.length > 0 ? galleryImages : [primaryImage];
  const colors = mapColors(product, primaryImage);
  const sizes = mapSizes(product);

  return {
    id: product.id,
    name: product.name,
    price: Number(product.basePrice ?? 0),
    image: primaryImage,
    category: product.categoryName || product.brand || 'Uncategorized',
    isNew: Boolean(product.isNew),
    variants: product.variants?.map((v) => ({
      size: v.size,
      color: v.color,
      price: v.price,
      sku: v.sku,
      inStock: v.inStock,
    })),
    colors: colors.length > 0 ? colors : [{ name: 'Default', image: primaryImage }],
    sizes: sizes.length > 0 ? sizes : [{ size: 'ONE_SIZE', inStock: true }],
    description: product.description || '',
    details: {
      colorShown: product.details?.colorShown || colors[0]?.name || 'N/A',
      style: product.details?.style || product.slug || 'N/A',
      country: product.details?.country || 'Unknown',
    },
    images,
  };
}

export async function getProducts(): Promise<Product[]> {
  const products = await fetchApi<BackendProduct[]>('/api/v1/products');
  return products.map(mapBackendProduct);
}

export async function getProductById(id: string): Promise<Product | null> {
  try {
    const product = await fetchApi<BackendProduct>(`/api/v1/products/${id}`);
    return mapBackendProduct(product);
  } catch {
    return null;
  }
}

export async function searchProducts(keyword: string): Promise<Product[]> {
  const encoded = encodeURIComponent(keyword.trim());
  const products = await fetchApi<BackendProduct[]>(`/api/v1/products/search?keyword=${encoded}`);
  return products.map(mapBackendProduct);
}

export async function getProductsByGender(gender: 'MEN' | 'WOMEN' | 'UNISEX'): Promise<Product[]> {
  const products = await fetchApi<BackendProduct[]>(`/api/v1/products/gender/${gender}`);
  return products.map(mapBackendProduct);
}

export async function getProductsByCategory(categoryId: string): Promise<Product[]> {
  const products = await fetchApi<BackendProduct[]>(`/api/v1/products/category/${categoryId}`);
  return products.map(mapBackendProduct);
}

interface BackendCategory {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  status: string;
}

export async function getCategories(): Promise<Category[]> {
  const categories = await fetchApi<BackendCategory[]>('/api/v1/categories');
  return categories.map(c => ({
    id: c.id,
    name: c.name,
    slug: c.slug,
    parentId: c.parentId,
  }));
}
