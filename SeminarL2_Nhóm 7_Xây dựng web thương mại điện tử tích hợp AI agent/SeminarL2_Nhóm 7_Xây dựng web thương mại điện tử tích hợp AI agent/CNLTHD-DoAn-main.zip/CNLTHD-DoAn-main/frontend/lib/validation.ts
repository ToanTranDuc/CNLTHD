// Validation utilities cho registration & user management

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

// Email validation - gmail.com
export function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@gmail\.com$/;
  if (!email) {
    return { field: 'email', message: 'Email là bắt buộc' };
  }
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Email phải có định dạng xxx@gmail.com' };
  }
  return null;
}

// Phone validation - 10 digits, starts with 0
export function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^0\d{9}$/;
  if (!phone) {
    return { field: 'sdt', message: 'Số điện thoại là bắt buộc' };
  }
  if (!phoneRegex.test(phone)) {
    return { field: 'sdt', message: 'Số điện thoại phải có 10 chữ số và bắt đầu bằng 0' };
  }
  return null;
}

// Password validation - at least 10 chars, uppercase, special char
export function validatePassword(password: string): ValidationError | null {
  if (!password) {
    return { field: 'password', message: 'Mật khẩu là bắt buộc' };
  }
  if (password.length < 10) {
    return { field: 'password', message: 'Mật khẩu phải có ít nhất 10 ký tự' };
  }
  if (!/[A-Z]/.test(password)) {
    return { field: 'password', message: 'Mật khẩu phải chứa ít nhất 1 chữ in hoa' };
  }
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    return { field: 'password', message: 'Mật khẩu phải chứa ít nhất 1 ký tự đặc biệt' };
  }
  return null;
}

// Full name validation
export function validateFullname(fullname: string): ValidationError | null {
  if (!fullname) {
    return { field: 'fullname', message: 'Họ tên là bắt buộc' };
  }
  if (fullname.trim().length < 2) {
    return { field: 'fullname', message: 'Họ tên phải có ít nhất 2 ký tự' };
  }
  if (fullname.length > 100) {
    return { field: 'fullname', message: 'Họ tên không được quá 100 ký tự' };
  }
  return null;
}

// Validate user update form
export function validateUserUpdate(data: {
  fullname?: string;
  email?: string;
  sdt?: string;
  password?: string;
}): ValidationResult {
  const errors: ValidationError[] = [];

  if (data.fullname) {
    const err = validateFullname(data.fullname);
    if (err) errors.push(err);
  }

  if (data.email) {
    const err = validateEmail(data.email);
    if (err) errors.push(err);
  }

  if (data.sdt) {
    const err = validatePhone(data.sdt);
    if (err) errors.push(err);
  }

  if (data.password) {
    const err = validatePassword(data.password);
    if (err) errors.push(err);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
