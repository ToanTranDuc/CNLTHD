const API_BASE =
  typeof window !== 'undefined'
    ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
    : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

function authHeaders(): Record<string, string> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) h['Authorization'] = `Bearer ${token}`;
  return h;
}

async function apiCall<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { ...authHeaders(), ...(options?.headers ?? {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message || `Request failed (${res.status})`);
  }
  const data = await res.json();
  return data.data as T;
}

// ─── Types ───────────────────────────────────────────────────────────────────

export interface AdminCategory {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
}

export interface AdminProductVariant {
  id: string;
  size: string;
  color: string;
  colorHex?: string;
  price: number | null;
  sku: string;
  status?: string;
}

export interface AdminProduct {
  id: string;
  name: string;
  description: string;
  brand: string;
  country: string;
  basePrice: number;
  categoryId: string;
  categoryName: string;
  gender: 'MEN' | 'WOMEN' | 'UNISEX' | null;
  status: string;
  image: string | null;
  images: string[];
  variants: AdminProductVariant[] | null;
}

export interface StockInfo {
  id: number;
  skuCode: string;
  productName: string;
  quantity: number;
}

export interface ProductCreateDto {
  name: string;
  description?: string;
  brand?: string;
  country?: string;
  basePrice: number;
  categoryId: string;
  gender?: 'MEN' | 'WOMEN' | 'UNISEX';
  status?: 'ACTIVE' | 'INACTIVE';
  imageUrls?: string[];
}

export interface VariantCreateDto {
  productId: string;
  size: string;
  color: string;
  sku: string;
  price?: number | null;
  quantity?: number;
  status?: 'ACTIVE' | 'INACTIVE';
}

// ─── Products ─────────────────────────────────────────────────────────────────

export function fetchAdminProducts(): Promise<AdminProduct[]> {
  return apiCall<AdminProduct[]>('/api/v1/products');
}

export function createProduct(dto: ProductCreateDto): Promise<AdminProduct> {
  return apiCall<AdminProduct>('/api/v1/products', {
    method: 'POST',
    body: JSON.stringify(dto),
  });
}

export function updateProduct(id: string, dto: ProductCreateDto): Promise<AdminProduct> {
  return apiCall<AdminProduct>(`/api/v1/products/${id}`, {
    method: 'PUT',
    body: JSON.stringify(dto),
  });
}

export function deleteProduct(id: string): Promise<void> {
  return apiCall<void>(`/api/v1/products/${id}`, { method: 'DELETE' });
}

// ─── Variants ─────────────────────────────────────────────────────────────────

export function createVariant(dto: VariantCreateDto): Promise<AdminProductVariant> {
  return apiCall<AdminProductVariant>('/api/v1/products/variants', {
    method: 'POST',
    body: JSON.stringify(dto),
  });
}

export function deleteVariant(id: string): Promise<void> {
  return apiCall<void>(`/api/v1/products/variants/${id}`, { method: 'DELETE' });
}

// ─── Categories ───────────────────────────────────────────────────────────────

export function fetchAdminCategories(): Promise<AdminCategory[]> {
  return apiCall<AdminCategory[]>('/api/v1/categories');
}

// ─── Stocks ───────────────────────────────────────────────────────────────────

export function fetchAllStocks(): Promise<StockInfo[]> {
  return apiCall<StockInfo[]>('/api/v1/stocks');
}

export function createStock(skuCode: string, productName: string, quantity: number): Promise<StockInfo> {
  return apiCall<StockInfo>('/api/v1/stocks', {
    method: 'POST',
    body: JSON.stringify({ skuCode, productName, quantity }),
  });
}

export function addStock(skuCode: string, quantityChange: number, reason?: string): Promise<StockInfo> {
  return apiCall<StockInfo>(`/api/v1/stocks/${skuCode}/add`, {
    method: 'POST',
    body: JSON.stringify({ quantityChange, reason }),
  });
}

export function adjustStock(skuCode: string, quantityChange: number, reason?: string): Promise<StockInfo> {
  return apiCall<StockInfo>(`/api/v1/stocks/${skuCode}/adjust`, {
    method: 'POST',
    body: JSON.stringify({ quantityChange, reason }),
  });
}
