const API_BASE = typeof window !== 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080')
  : (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080');

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  color?: string;
  size?: string;
  image?: string;
  skuCode?: string;
}

export interface Order {
  id: string;
  orderNumber?: string;
  customerId?: string;
  userId?: string;
  date?: string;
  createdAt?: string;
  totalAmount: number;
  status: string;
  estimatedDelivery?: string;
  shippingAddress?: string;
  addressLine?: string;
  recipientName?: string;
  phone?: string;
  paymentMethod?: string;
  notes?: string;
  note?: string;
  cancelReason?: string;
  subtotal?: number;
  shippingFee?: number;
  discount?: number;
  items: OrderItem[];
}

export interface OrdersResponse {
  success: boolean;
  data: Order[];
  message?: string;
}

export interface OrderResponse {
  success: boolean;
  data: Order;
  message?: string;
}

function getAuthHeaders(): Record<string, string> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  if (!token) throw new Error('No authentication token found');
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

function mapOrderItem(raw: Record<string, unknown>): OrderItem {
  return {
    ...(raw as unknown as OrderItem),
    name: (raw.productName ?? raw.name ?? '') as string,
    price: Number(raw.unitPrice ?? raw.price ?? 0),
    image: (raw.imageUrl ?? raw.image ?? undefined) as string | undefined,
  };
}

export function mapOrderForAdmin(raw: Record<string, unknown>): Order {
  return mapOrder(raw);
}

function mapOrder(raw: Record<string, unknown>): Order {
  const items = Array.isArray(raw.items)
    ? (raw.items as Record<string, unknown>[]).map(mapOrderItem)
    : [];
  const toNum = (v: unknown): number | undefined => (v == null ? undefined : Number(v));
  return {
    ...(raw as unknown as Order),
    status: (raw.orderStatus ?? raw.status ?? '') as string,
    shippingAddress: (raw.addressLine ?? raw.shippingAddress ?? '') as string,
    subtotal: toNum(raw.subtotal),
    shippingFee: toNum(raw.shippingFee),
    discount: toNum(raw.discount),
    totalAmount: Number(raw.totalAmount ?? 0),
    cancelReason: (raw.cancelReason ?? undefined) as string | undefined,
    items,
  };
}

export async function fetchUserOrders(customerId: string): Promise<Order[]> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}/api/v1/orders/customer/${customerId}`, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    if (response.status === 401) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      throw new Error('Unauthorized');
    }
    throw new Error(`Failed to fetch orders: ${response.statusText}`);
  }

  const data = await response.json();
  if (data.success && Array.isArray(data.data)) {
    return data.data.map((o: Record<string, unknown>) => mapOrder(o));
  }
  return [];
}

export async function fetchOrderByNumber(orderNumber: string): Promise<Order> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}/api/v1/orders/number/${encodeURIComponent(orderNumber)}`, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch order: ${response.statusText}`);
  }

  const data: OrderResponse = await response.json();
  if (data.success && data.data) return mapOrder(data.data as unknown as Record<string, unknown>);
  throw new Error('Invalid order data received');
}

export async function fetchOrderById(orderId: string): Promise<Order> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${API_BASE}/api/v1/orders/${orderId}`, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    if (response.status === 401) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      throw new Error('Unauthorized');
    }
    throw new Error(`Failed to fetch order: ${response.statusText}`);
  }

  const data: OrderResponse = await response.json();
  if (data.success && data.data) return mapOrder(data.data as unknown as Record<string, unknown>);
  throw new Error('Invalid order data received');
}

export interface PlaceOrderPayload {
  customerId?: string;
  recipientEmail?: string;
  recipientName: string;
  phone: string;
  addressLine: string;
  ward?: string;
  district?: string;
  city?: string;
  note?: string;
  discount?: number;
  shippingFee?: number;
  promoCode?: string;
  orderLineItemsDtoList: Array<{ skuCode: string; price: number; quantity: number; productName?: string; imageUrl?: string }>;
}

export async function cancelOrder(orderId: string, reason?: string): Promise<Order> {
  const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const url = reason
    ? `${API_BASE}/api/v1/orders/${orderId}/cancel?reason=${encodeURIComponent(reason)}`
    : `${API_BASE}/api/v1/orders/${orderId}/cancel`;

  const response = await fetch(url, {
    method: 'PATCH',
    headers,
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body?.message || body?.error || `Hủy đơn thất bại (${response.status})`);
  }

  const data: OrderResponse = await response.json();
  return mapOrder(data.data as unknown as Record<string, unknown>);
}

export async function placeOrder(payload: PlaceOrderPayload): Promise<void> {
  const response = await fetch(`${API_BASE}/api/order`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const msg = body?.message || body?.error || `Order failed (${response.status})`;
    throw new Error(msg);
  }
}

export function getOrderStatusDisplay(status: string): string {
  const statusMap: Record<string, string> = {
    PENDING: 'Chờ xác nhận',
    CONFIRMED: 'Đã xác nhận',
    PROCESSING: 'Đang xử lý',
    SHIPPED: 'Đang giao',
    DELIVERED: 'Đã giao',
    CANCELLED: 'Đã hủy',
    FAILED: 'Thất bại',
  };
  return statusMap[status] || status;
}

export function getOrderStatusColor(status: string): string {
  const colorMap: Record<string, string> = {
    PENDING: 'bg-yellow-100 text-yellow-800',
    CONFIRMED: 'bg-blue-100 text-blue-800',
    PROCESSING: 'bg-blue-100 text-blue-800',
    SHIPPED: 'bg-purple-100 text-purple-800',
    DELIVERED: 'bg-green-100 text-green-800',
    CANCELLED: 'bg-red-100 text-red-800',
    FAILED: 'bg-red-100 text-red-800',
  };
  return colorMap[status] || 'bg-gray-100 text-gray-800';
}
