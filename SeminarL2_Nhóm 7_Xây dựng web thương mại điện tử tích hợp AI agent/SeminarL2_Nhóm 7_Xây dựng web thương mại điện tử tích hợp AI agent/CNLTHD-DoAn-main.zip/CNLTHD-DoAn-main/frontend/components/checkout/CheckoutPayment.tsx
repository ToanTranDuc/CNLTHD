"use client";
import React, { useState, useEffect } from 'react';
import { Lock, CreditCard, Trash2, Star } from 'lucide-react';
import { loadSavedCards, removeCard, makeDefault, SavedCard } from '@/lib/savedCards';
import { useToast } from '@/context/ToastContext';

interface PaymentFormData {
  promoCode: string;
  paymentMethod: 'card' | 'paypal' | 'googlepay';
  cardName: string;
  cardNumber: string;
  expiryDate: string;
  securityCode: string;
  saveCard: boolean;
  setAsDefault: boolean;
}

interface CheckoutPaymentProps {
  onFormChange: (data: PaymentFormData) => void;
}

const CheckoutPayment: React.FC<CheckoutPaymentProps> = ({ onFormChange }) => {
  const { showToast } = useToast();
  const [savedCards, setSavedCards] = useState<SavedCard[]>([]);
  const [usingSaved, setUsingSaved] = useState<string | null>(null);
  const [formData, setFormData] = useState<PaymentFormData>({
    promoCode: '',
    paymentMethod: 'card',
    cardName: '',
    cardNumber: '',
    expiryDate: '',
    securityCode: '',
    saveCard: false,
    setAsDefault: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);

  // Load saved cards on mount + auto-select default
  useEffect(() => {
    const cards = loadSavedCards();
    setSavedCards(cards);
    const def = cards.find((c) => c.isDefault);
    if (def) {
      handleSelectSaved(def);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectSaved = (card: SavedCard) => {
    setUsingSaved(card.id);
    const updated = {
      ...formData,
      cardName: card.cardName,
      cardNumber: `•••• •••• •••• ${card.last4}`,
      expiryDate: card.expiryDate,
      securityCode: '',
      saveCard: false,
      setAsDefault: false,
    };
    setFormData(updated);
    onFormChange(updated);
  };

  const handleNewCard = () => {
    setUsingSaved(null);
    const updated = {
      ...formData,
      cardName: '',
      cardNumber: '',
      expiryDate: '',
      securityCode: '',
    };
    setFormData(updated);
    onFormChange(updated);
  };

  const handleRemoveSaved = (id: string) => {
    removeCard(id);
    const fresh = loadSavedCards();
    setSavedCards(fresh);
    if (usingSaved === id) {
      handleNewCard();
    }
    showToast('Đã xóa thẻ đã lưu', 'success');
  };

  const handleMakeDefault = (id: string) => {
    makeDefault(id);
    setSavedCards(loadSavedCards());
    showToast('Đã đặt làm thẻ mặc định', 'success');
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;

    // Format card number (add spaces every 4 digits)
    let finalValue = newValue;
    if (name === 'cardNumber' && typeof newValue === 'string') {
      finalValue = newValue
        .replace(/\D/g, '')
        .replace(/(\d{4})(?=\d)/g, '$1 ')
        .slice(0, 19);
    }

    // Format expiry date (MM/YY)
    if (name === 'expiryDate' && typeof newValue === 'string') {
      finalValue = newValue
        .replace(/\D/g, '')
        .replace(/^(\d{2})/, (_, p1) => p1)
        .slice(0, 4);
      if (finalValue.length >= 2) {
        finalValue = finalValue.slice(0, 2) + '/' + finalValue.slice(2);
      }
    }

    // Format security code (only 3-4 digits)
    if (name === 'securityCode' && typeof newValue === 'string') {
      finalValue = newValue.replace(/\D/g, '').slice(0, 4);
    }

    const updated = { ...formData, [name]: finalValue };
    setFormData(updated);
    onFormChange(updated);

    // Clear error for this field
    if (errors[name]) {
      setErrors({ ...errors, [name]: '' });
    }
  };

  const handleBlur = (field: string) => {
    setFocusedField(null);
    const newErrors = { ...errors };

    if (formData.paymentMethod === 'card') {
      switch (field) {
        case 'cardName':
          if (!formData.cardName) {
            newErrors.cardName = 'Name on card is required';
          }
          break;
        case 'cardNumber':
          if (!formData.cardNumber) {
            newErrors.cardNumber = 'Card number is required';
          } else if (formData.cardNumber.replace(/\s/g, '').length !== 16) {
            newErrors.cardNumber = 'Card number must be 16 digits';
          }
          break;
        case 'expiryDate':
          if (!formData.expiryDate) {
            newErrors.expiryDate = 'Expiry date is required';
          } else if (!/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
            newErrors.expiryDate = 'Invalid format (MM/YY)';
          }
          break;
        case 'securityCode':
          if (!formData.securityCode) {
            newErrors.securityCode = 'Security code is required';
          } else if (formData.securityCode.length < 3) {
            newErrors.securityCode = 'Security code must be 3-4 digits';
          }
          break;
      }
    }

    setErrors(newErrors);
  };

  return (
    <div className="space-y-6 py-8 border-t border-gray-200">
      {/* Promo code moved to Order Summary (right panel) */}

      {/* Payment Method Selection */}
      <div>
        <h3 className="text-base font-semibold text-black mb-4">Payment</h3>
        <div className="space-y-3">
          <button
            onClick={() => setFormData({ ...formData, paymentMethod: 'card' })}
            className={`w-full flex items-center gap-3 px-4 py-4 border-2 rounded-xl font-medium transition-colors ${
              formData.paymentMethod === 'card'
                ? 'border-black bg-white text-black'
                : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
            }`}
          >
            <div className="w-5 h-5 border-2 rounded-full flex items-center justify-center border-current">
              {formData.paymentMethod === 'card' && <div className="w-2.5 h-2.5 bg-current rounded-full"></div>}
            </div>
            Credit or Debit Card
          </button>

          <button
            onClick={() => setFormData({ ...formData, paymentMethod: 'paypal' })}
            className={`w-full flex items-center gap-3 px-4 py-4 border-2 rounded-xl font-medium transition-colors ${
              formData.paymentMethod === 'paypal'
                ? 'border-black bg-white text-black'
                : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
            }`}
          >
            <div className="w-5 h-5 border-2 rounded-full flex items-center justify-center border-current">
              {formData.paymentMethod === 'paypal' && <div className="w-2.5 h-2.5 bg-current rounded-full"></div>}
            </div>
            <span className="text-lg font-bold text-blue-600">PayPal</span>
          </button>

          <button
            onClick={() => setFormData({ ...formData, paymentMethod: 'googlepay' })}
            className={`w-full flex items-center gap-3 px-4 py-4 border-2 rounded-xl font-medium transition-colors ${
              formData.paymentMethod === 'googlepay'
                ? 'border-black bg-white text-black'
                : 'border-gray-300 bg-white text-gray-700 hover:border-gray-400'
            }`}
          >
            <div className="w-5 h-5 border-2 rounded-full flex items-center justify-center border-current">
              {formData.paymentMethod === 'googlepay' && <div className="w-2.5 h-2.5 bg-current rounded-full"></div>}
            </div>
            <span className="text-sm font-semibold">Google Pay</span>
          </button>
        </div>
      </div>

      {/* Saved Cards */}
      {formData.paymentMethod === 'card' && savedCards.length > 0 && (
        <div className="pt-4 border-t border-gray-200">
          <p className="text-base font-semibold text-black mb-3">Thẻ đã lưu</p>
          <div className="space-y-2 mb-3">
            {savedCards.map((card) => (
              <div
                key={card.id}
                className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-colors cursor-pointer ${
                  usingSaved === card.id ? 'border-black bg-gray-50' : 'border-gray-200 hover:border-gray-400'
                }`}
                onClick={() => handleSelectSaved(card)}
              >
                <div className="w-5 h-5 border-2 rounded-full flex items-center justify-center border-current flex-shrink-0">
                  {usingSaved === card.id && <div className="w-2.5 h-2.5 bg-current rounded-full" />}
                </div>
                <CreditCard className="w-5 h-5 text-gray-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-black truncate">
                    {card.cardName} <span className="text-gray-400">•••• {card.last4}</span>
                  </p>
                  <p className="text-xs text-gray-500">Hết hạn {card.expiryDate}</p>
                </div>
                {card.isDefault && (
                  <span className="text-[10px] font-bold uppercase tracking-wide px-2 py-1 bg-black text-white rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3 fill-current" />
                    Mặc định
                  </span>
                )}
                {!card.isDefault && (
                  <button
                    onClick={(e) => { e.stopPropagation(); handleMakeDefault(card.id); }}
                    className="text-xs text-gray-500 hover:text-black underline"
                    title="Đặt làm thẻ mặc định"
                  >
                    Đặt mặc định
                  </button>
                )}
                <button
                  onClick={(e) => { e.stopPropagation(); handleRemoveSaved(card.id); }}
                  className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                  title="Xóa"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={handleNewCard}
            className={`w-full text-sm font-medium py-2 px-4 rounded-lg border transition-colors ${
              usingSaved === null
                ? 'border-black bg-black text-white'
                : 'border-gray-300 text-gray-700 hover:border-black'
            }`}
          >
            + Dùng thẻ mới
          </button>
        </div>
      )}

      {/* Card Details (only show if card payment selected) */}
      {formData.paymentMethod === 'card' && (
        <div className="space-y-4 pt-4 border-t border-gray-200">
          <p className="text-base font-semibold text-black">
            {usingSaved ? 'Nhập mã bảo mật để xác nhận:' : 'Enter your payment details:'}
          </p>

          {/* Card Name */}
          <div className="relative">
            <input
              type="text"
              name="cardName"
              placeholder="Name on card *"
              value={formData.cardName}
              onChange={handleChange}
              onFocus={() => setFocusedField('cardName')}
              onBlur={() => handleBlur('cardName')}
              disabled={!!usingSaved}
              className={`w-full px-4 py-3 border border-gray-300 rounded-md text-black placeholder-gray-400 outline-none transition-colors disabled:bg-gray-50 disabled:text-gray-500 ${
                focusedField === 'cardName' ? 'border-black' : ''
              } ${errors.cardName ? 'border-red-500' : ''}`}
            />
            {errors.cardName && (
              <p className="text-red-500 text-xs mt-1">{errors.cardName}</p>
            )}
          </div>

          {/* Card Number */}
          <div className="relative">
            <div className={`flex items-center gap-3 px-4 py-3 border border-gray-300 rounded-md transition-colors ${
              focusedField === 'cardNumber' ? 'border-black' : ''
            } ${errors.cardNumber ? 'border-red-500' : ''}`}>
              <input
                type="text"
                name="cardNumber"
                placeholder="Card number *"
                value={formData.cardNumber}
                onChange={handleChange}
                onFocus={() => setFocusedField('cardNumber')}
                onBlur={() => handleBlur('cardNumber')}
                disabled={!!usingSaved}
                maxLength={19}
                className="flex-grow bg-transparent text-black placeholder-gray-400 outline-none disabled:text-gray-500"
              />
              <Lock className="w-5 h-5 text-gray-400 flex-shrink-0" />
            </div>
            {errors.cardNumber && (
              <p className="text-red-500 text-xs mt-1">{errors.cardNumber}</p>
            )}
          </div>

          {/* Expiry & Security Code */}
          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <input
                type="text"
                name="expiryDate"
                placeholder="MM/YY *"
                value={formData.expiryDate}
                onChange={handleChange}
                onFocus={() => setFocusedField('expiryDate')}
                onBlur={() => handleBlur('expiryDate')}
                disabled={!!usingSaved}
                maxLength={5}
                className={`w-full px-4 py-3 border border-gray-300 rounded-md text-black placeholder-gray-400 outline-none transition-colors disabled:bg-gray-50 disabled:text-gray-500 ${
                  focusedField === 'expiryDate' ? 'border-black' : ''
                } ${errors.expiryDate ? 'border-red-500' : ''}`}
              />
              {errors.expiryDate && (
                <p className="text-red-500 text-xs mt-1">{errors.expiryDate}</p>
              )}
            </div>

            <div className="relative">
              <input
                type="password"
                name="securityCode"
                placeholder="Security Code *"
                value={formData.securityCode}
                onChange={handleChange}
                onFocus={() => setFocusedField('securityCode')}
                onBlur={() => handleBlur('securityCode')}
                maxLength={4}
                className={`w-full px-4 py-3 border border-gray-300 rounded-md text-black placeholder-gray-400 outline-none transition-colors ${
                  focusedField === 'securityCode' ? 'border-black' : ''
                } ${errors.securityCode ? 'border-red-500' : ''}`}
              />
              {errors.securityCode && (
                <p className="text-red-500 text-xs mt-1">{errors.securityCode}</p>
              )}
              <a href="#" className="text-xs font-semibold text-black underline absolute -bottom-6 left-0">
                {"Where's my Security Code?"}
              </a>
            </div>
          </div>

          {/* Checkboxes - only for new cards */}
          {!usingSaved && (
            <div className="space-y-3 pt-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="saveCard"
                  checked={formData.saveCard}
                  onChange={handleChange}
                  className="w-5 h-5 border border-gray-300 rounded bg-white cursor-pointer accent-black"
                />
                <span className="text-sm text-gray-700">Save card for later use</span>
              </label>

              <label className={`flex items-center gap-3 ${formData.saveCard ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'}`}>
                <input
                  type="checkbox"
                  name="setAsDefault"
                  checked={formData.setAsDefault}
                  onChange={handleChange}
                  disabled={!formData.saveCard}
                  className="w-5 h-5 border border-gray-300 rounded bg-white cursor-pointer accent-black disabled:cursor-not-allowed"
                />
                <span className="text-sm text-gray-700">Set as default card</span>
              </label>

              {formData.saveCard && (
                <p className="text-xs text-gray-500 ml-8">
                  Chỉ lưu 4 số cuối, tên trên thẻ và ngày hết hạn (không lưu CVV).
                </p>
              )}
            </div>
          )}

          {/* Terms */}
          <p className="text-xs text-gray-600 mt-4">
            By clicking Place Order, you agree to the ESW{' '}
            <a href="#" className="text-black underline">
              Terms and Conditions
            </a>
            .
          </p>
        </div>
      )}

      {/* For PayPal/Google Pay - show simple message */}
      {(formData.paymentMethod === 'paypal' || formData.paymentMethod === 'googlepay') && (
        <div className="pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-600 mb-4">
            By clicking Place Order, you agree to the ESW{' '}
            <a href="#" className="text-black underline">
              Terms and Conditions
            </a>
            .
          </p>
        </div>
      )}
    </div>
  );
};

export default CheckoutPayment;
