"use client";
import React from 'react';

const CheckoutShipping: React.FC = () => {
  return (
    <div className="space-y-6 py-8 border-t border-gray-200">
      <div>
        <h2 className="text-2xl font-bold text-black mb-6">Shipping</h2>

        <div className="space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-black font-medium">250,000₫ Shipping</p>
              <p className="text-sm text-gray-600 mt-2">Shipment One</p>
              <p className="text-sm text-gray-600">Arrives Wed, Mar 18 - Wed, Mar 25</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">10 items</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutShipping;
