"use client";
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { TicketPercent, Check, X } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { CartItem } from '@/types/Cart';
import { validatePromo, PromoApplyResult } from '@/lib/promoCodes';

const itemKey = (i: CartItem) => `${i.id}-${i.size}-${i.color}`;

const OrderSummary: React.FC = () => {
  const { items: allItems } = useCart();

  // Filter by selected ids set by /cart before navigating to /checkout.
  // Fall back to allItems only if no selection has ever been made.
  const items = useMemo<CartItem[]>(() => {
    if (typeof window === 'undefined') return allItems;
    const raw = localStorage.getItem('cart_selected_ids');
    if (!raw) return allItems;
    try {
      const selected = JSON.parse(raw) as string[];
      const selectedSet = new Set(selected);
      const filtered = allItems.filter((i) => selectedSet.has(itemKey(i)));
      return filtered.length > 0 ? filtered : allItems;
    } catch {
      return allItems;
    }
  }, [allItems]);

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const deliveryThreshold = 5_000_000;
  const remainingForFree = Math.max(0, deliveryThreshold - subtotal);
  const isThresholdFreeShip = subtotal >= deliveryThreshold;

  // Promo code state
  const [promoInput, setPromoInput] = useState('');
  const [applied, setApplied] = useState<PromoApplyResult | null>(null);
  const [promoError, setPromoError] = useState('');

  // Persist applied promo so place-order can read it
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (applied?.ok) {
      localStorage.setItem(
        'checkout_promo',
        JSON.stringify({
          code: applied.promo?.code,
          discountAmount: applied.discountAmount,
          freeShipping: applied.freeShipping,
        })
      );
    } else {
      localStorage.removeItem('checkout_promo');
    }
  }, [applied]);

  // Re-validate when subtotal changes (e.g. cart updated)
  useEffect(() => {
    if (applied?.ok && applied.promo) {
      validatePromo(applied.promo.code, subtotal).then((result) => {
        setApplied(result);
        if (!result.ok) setPromoError(result.error || 'Mã không còn áp dụng được');
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subtotal]);

  const [validating, setValidating] = useState(false);

  const handleApplyPromo = async () => {
    setPromoError('');
    setValidating(true);
    try {
      const result = await validatePromo(promoInput, subtotal);
      if (!result.ok) {
        setPromoError(result.error || 'Mã không hợp lệ');
        setApplied(null);
        return;
      }
      setApplied(result);
    } finally {
      setValidating(false);
    }
  };

  const handleRemovePromo = () => {
    setApplied(null);
    setPromoInput('');
    setPromoError('');
  };

  const promoFreeShip = applied?.ok && applied.freeShipping;
  const isDeliveryFree = isThresholdFreeShip || promoFreeShip;
  const deliveryCost = isDeliveryFree ? 0 : 100_000;
  const promoDiscount = applied?.ok ? applied.discountAmount : 0;
  const total = Math.max(0, subtotal - promoDiscount + deliveryCost);
  const progressPercentage = Math.min(100, (subtotal / deliveryThreshold) * 100);

  const [showCongrats, setShowCongrats] = useState(false);
  const hasShownCongrats = useRef(false);

  useEffect(() => {
    let hideTimer: NodeJS.Timeout;
    if (isDeliveryFree && !hasShownCongrats.current) {
      hasShownCongrats.current = true;
      requestAnimationFrame(() => setShowCongrats(true));
      hideTimer = setTimeout(() => {
        requestAnimationFrame(() => setShowCongrats(false));
      }, 3000);
    } else if (!isDeliveryFree && hasShownCongrats.current) {
      hasShownCongrats.current = false;
      requestAnimationFrame(() => setShowCongrats(false));
    }
    return () => { if (hideTimer) clearTimeout(hideTimer); };
  }, [isDeliveryFree]);

  return (
    <div className="md:sticky md:top-20 md:h-fit bg-gray-50 rounded-lg p-6 border border-gray-200">
      <h2 className="text-2xl font-bold text-black mb-6">Order Summary</h2>

      {showCongrats && (
        <div className="mb-4 p-4 bg-green-100 border border-green-400 rounded text-green-800 text-sm font-medium animate-pulse">
          {"🎉 Congratulations! You've earned Free Shipping!"}
        </div>
      )}

      <div className="mb-6 pb-6 border-b border-gray-200">
        {!isDeliveryFree ? (
          <p className="text-sm text-gray-700 mb-3">
            Add ₫{remainingForFree.toLocaleString('vi-VN')} more to earn Free Shipping!
          </p>
        ) : (
          <p className="text-sm text-green-700 font-medium mb-3">{"✓ You've earned Free Shipping!"}</p>
        )}
        <div className="w-full bg-gray-300 rounded-full h-2 overflow-hidden">
          <div
            className="bg-green-600 h-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
        <p className="text-xs text-gray-500 mt-2">threshold: ₫{deliveryThreshold.toLocaleString('vi-VN')}</p>
      </div>

      {/* Promo code */}
      <div className="mb-6 pb-6 border-b border-gray-200">
        <p className="text-sm font-semibold text-black mb-2 flex items-center gap-1.5">
          <TicketPercent className="w-4 h-4" />
          Mã giảm giá
        </p>
        {applied?.ok ? (
          <div className="flex items-center justify-between p-3 bg-green-50 border border-green-300 rounded-lg">
            <div className="flex items-center gap-2 min-w-0">
              <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-sm font-semibold text-green-800 truncate">{applied.promo?.code}</p>
                <p className="text-xs text-green-700 truncate">{applied.promo?.description}</p>
              </div>
            </div>
            <button
              onClick={handleRemovePromo}
              className="p-1 rounded-full hover:bg-green-100 flex-shrink-0"
              title="Bỏ mã"
            >
              <X className="w-4 h-4 text-green-700" />
            </button>
          </div>
        ) : (
          <>
            <div className="flex gap-2">
              <input
                type="text"
                value={promoInput}
                onChange={(e) => { setPromoInput(e.target.value.toUpperCase()); setPromoError(''); }}
                onKeyDown={(e) => e.key === 'Enter' && handleApplyPromo()}
                placeholder="Nhập mã..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm outline-none focus:border-black uppercase"
              />
              <button
                onClick={handleApplyPromo}
                disabled={!promoInput.trim() || validating}
                className="px-4 py-2 bg-black text-white text-sm font-semibold rounded-md hover:bg-gray-800 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {validating ? '...' : 'Áp dụng'}
              </button>
            </div>
            {promoError && <p className="text-xs text-red-600 mt-1.5">{promoError}</p>}
            <p className="text-xs text-gray-500 mt-2">
              Mã giảm giá được phát hành qua thông báo từ shop.
            </p>
          </>
        )}
      </div>

      <div className="space-y-3 mb-6 pb-6 border-b border-gray-200">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Subtotal ({items.length} sản phẩm)</span>
          <span className="text-black font-medium">₫{subtotal.toLocaleString('vi-VN')}</span>
        </div>
        {promoDiscount > 0 && (
          <div className="flex justify-between text-sm">
            <span className="text-green-700">Giảm giá ({applied?.promo?.code})</span>
            <span className="text-green-700 font-medium">-₫{promoDiscount.toLocaleString('vi-VN')}</span>
          </div>
        )}
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Shipping {promoFreeShip && !isThresholdFreeShip && <span className="text-green-600 text-xs">(mã free ship)</span>}</span>
          <span className="text-black font-medium">
            {isDeliveryFree ? 'Free' : `₫${deliveryCost.toLocaleString('vi-VN')}`}
          </span>
        </div>
        <div className="flex justify-between text-base font-bold pt-2">
          <span className="text-black">Total</span>
          <span className="text-black">₫{total.toLocaleString('vi-VN')}</span>
        </div>
      </div>

      <div>
        <p className="text-sm font-semibold text-black mb-4">Items ({items.length})</p>
        {items.length > 0 ? (
          <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
            {items.map((item, index) => (
              <div key={`${item.id}-${item.size}-${item.color}-${index}`} className="flex gap-4 pb-4 border-b border-gray-200 last:border-0">
                <div className="relative flex-shrink-0 w-20 h-20 bg-gray-200 rounded overflow-hidden">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/80x80?text=No+Image';
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400 text-[10px]">No image</div>
                  )}
                </div>
                <div className="flex-grow">
                  <p className="text-black font-medium line-clamp-2 text-sm">{item.name}</p>
                  <p className="text-gray-600 text-xs mt-1">Qty {item.quantity} | Size {item.size}</p>
                  <p className="text-black font-semibold mt-2">
                    ₫{(item.price * item.quantity).toLocaleString('vi-VN')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-sm italic">No items in your cart</p>
        )}
      </div>
    </div>
  );
};

export default OrderSummary;
