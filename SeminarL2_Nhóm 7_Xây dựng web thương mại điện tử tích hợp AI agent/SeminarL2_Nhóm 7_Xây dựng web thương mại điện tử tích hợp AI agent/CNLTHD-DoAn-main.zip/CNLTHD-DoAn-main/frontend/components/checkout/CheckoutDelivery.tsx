"use client";
import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface DeliveryFormData {
  email: string;
  firstName: string;
  lastName: string;
  address: string;
  phoneNumber: string;
  billingMatchesShipping: boolean;
}

interface CheckoutDeliveryProps {
  onFormChange: (data: DeliveryFormData) => void;
}

const CheckoutDelivery: React.FC<CheckoutDeliveryProps> = ({ onFormChange }) => {
  const [formData, setFormData] = useState<DeliveryFormData>({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    phoneNumber: '',
    billingMatchesShipping: true,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;

    const updated = { ...formData, [name]: newValue };
    setFormData(updated);
    onFormChange(updated);

    // Clear error for this field
    if (errors[name]) {
      setErrors({ ...errors, [name]: '' });
    }
  };

  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    const re = /^[0-9]{10}$/;
    return re.test(phone.replace(/\D/g, ''));
  };

  const handleBlur = (field: string) => {
    setFocusedField(null);
    const newErrors = { ...errors };

    switch (field) {
      case 'email':
        if (!formData.email) {
          newErrors.email = 'Email is required';
        } else if (!validateEmail(formData.email)) {
          newErrors.email = 'Invalid email format';
        }
        break;
      case 'firstName':
        if (!formData.firstName) newErrors.firstName = 'First name is required';
        break;
      case 'lastName':
        if (!formData.lastName) newErrors.lastName = 'Last name is required';
        break;
      case 'address':
        if (!formData.address) newErrors.address = 'Address is required';
        break;
      case 'phoneNumber':
        if (!formData.phoneNumber) {
          newErrors.phoneNumber = 'Phone number is required';
        } else if (!validatePhone(formData.phoneNumber)) {
          newErrors.phoneNumber = 'Invalid phone format (10 digits)';
        }
        break;
    }

    setErrors(newErrors);
  };

  const hasEmailError = focusedField === null && errors.email;

  return (
    <div className="space-y-8">
      {/* Delivery Section */}
      <div>
        <h2 className="text-2xl font-bold text-black mb-6">Delivery</h2>

        {/* Email */}
        <div className="mb-6 relative">
          <div className={`relative border-b-2 transition-colors ${
            focusedField === 'email' ? 'border-black' : 'border-gray-300'
          } ${hasEmailError ? 'border-red-500' : ''}`}>
            <label className={`absolute text-sm font-medium transition-all pointer-events-none ${
              focusedField === 'email' || formData.email
                ? '-top-5 text-gray-700'
                : 'top-3 text-gray-400'
            }`}>
              Email *
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              onFocus={() => setFocusedField('email')}
              onBlur={() => handleBlur('email')}
              className="w-full bg-transparent py-3 outline-none text-black"
            />
          </div>
          {hasEmailError && (
            <p className="text-red-500 text-xs mt-2">{errors.email}</p>
          )}
          <p className="text-xs text-gray-500 mt-2">A confirmation email will be sent after checkout.</p>
        </div>

        {/* Name and Address Section */}
        <p className="text-base font-semibold text-black mb-4">Enter your name and address:</p>

        <div className="grid grid-cols-2 gap-4 mb-4">
          {/* First Name */}
          <div className="relative">
            <div className={`relative border-b-2 transition-colors ${
              focusedField === 'firstName' ? 'border-black' : 'border-gray-300'
            } ${errors.firstName ? 'border-red-500' : ''}`}>
              <label className={`absolute text-sm font-medium transition-all pointer-events-none ${
                focusedField === 'firstName' || formData.firstName
                  ? '-top-5 text-gray-700'
                  : 'top-3 text-gray-400'
              }`}>
                First Name *
              </label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                onFocus={() => setFocusedField('firstName')}
                onBlur={() => handleBlur('firstName')}
                className="w-full bg-transparent py-3 outline-none text-black"
              />
            </div>
            {errors.firstName && (
              <p className="text-red-500 text-xs mt-2">{errors.firstName}</p>
            )}
          </div>

          {/* Last Name */}
          <div className="relative">
            <div className={`relative border-b-2 transition-colors ${
              focusedField === 'lastName' ? 'border-black' : 'border-gray-300'
            } ${errors.lastName ? 'border-red-500' : ''}`}>
              <label className={`absolute text-sm font-medium transition-all pointer-events-none ${
                focusedField === 'lastName' || formData.lastName
                  ? '-top-5 text-gray-700'
                  : 'top-3 text-gray-400'
              }`}>
                Last Name *
              </label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                onFocus={() => setFocusedField('lastName')}
                onBlur={() => handleBlur('lastName')}
                className="w-full bg-transparent py-3 outline-none text-black"
              />
            </div>
            {errors.lastName && (
              <p className="text-red-500 text-xs mt-2">{errors.lastName}</p>
            )}
          </div>
        </div>

        {/* Address */}
        <div className="mb-4 relative">
          <div className={`relative border border-gray-300 rounded-md px-3 py-3 flex items-center ${
            focusedField === 'address' ? 'border-black' : ''
          } ${errors.address ? 'border-red-500' : ''}`}>
            <Search className="w-5 h-5 text-gray-400 mr-2" />
            <input
              type="text"
              name="address"
              placeholder="Start typing a street address or postcode *"
              value={formData.address}
              onChange={handleChange}
              onFocus={() => setFocusedField('address')}
              onBlur={() => handleBlur('address')}
              className="flex-grow bg-transparent outline-none text-black placeholder-gray-400 text-sm"
            />
          </div>
          {errors.address && (
            <p className="text-red-500 text-xs mt-2">{errors.address}</p>
          )}
          <p className="text-xs text-gray-500 mt-2">We do not ship to P.O. boxes</p>
        </div>

        {/* Enter address manually link */}
        <button className="text-black font-semibold underline text-sm mb-4 hover:text-gray-700">
          Enter address manually
        </button>

        {/* Phone Number */}
        <div className="relative mb-6">
          <div className={`relative border-b-2 transition-colors ${
            focusedField === 'phoneNumber' ? 'border-black' : 'border-gray-300'
          } ${errors.phoneNumber ? 'border-red-500' : ''}`}>
            <label className={`absolute text-sm font-medium transition-all pointer-events-none ${
              focusedField === 'phoneNumber' || formData.phoneNumber
                ? '-top-5 text-gray-700'
                : 'top-3 text-gray-400'
            }`}>
              Phone Number *
            </label>
            <input
              type="tel"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              onFocus={() => setFocusedField('phoneNumber')}
              onBlur={() => handleBlur('phoneNumber')}
              className="w-full bg-transparent py-3 outline-none text-black"
            />
          </div>
          {errors.phoneNumber && (
            <p className="text-red-500 text-xs mt-2">{errors.phoneNumber}</p>
          )}
          <p className="text-xs text-gray-500 mt-2">A carrier might contact you to confirm delivery.</p>
        </div>

        {/* Billing Checkbox */}
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            name="billingMatchesShipping"
            checked={formData.billingMatchesShipping}
            onChange={handleChange}
            className="w-5 h-5 border border-gray-300 rounded bg-white cursor-pointer accent-black"
          />
          <span className="text-base text-black font-medium">Billing matches shipping address</span>
        </label>
      </div>
    </div>
  );
};

export default CheckoutDelivery;
