"use client";
import React from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  /** Optional override — defaults to router.back() */
  href?: string;
  label?: string;
  className?: string;
}

const BackButton: React.FC<BackButtonProps> = ({ href, label = 'Quay lại', className = '' }) => {
  const router = useRouter();
  const handleClick = () => {
    if (href) {
      router.push(href);
    } else if (typeof window !== 'undefined' && window.history.length > 1) {
      router.back();
    } else {
      router.push('/');
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`inline-flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-black transition-colors ${className}`}
    >
      <ArrowLeft className="w-4 h-4" />
      {label}
    </button>
  );
};

export default BackButton;
