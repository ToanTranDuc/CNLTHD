"use client";
import React, { useEffect, useState } from 'react';
import { XCircle, X } from 'lucide-react';

interface CancelOrderModalProps {
  open: boolean;
  orderNumber: string;
  loading?: boolean;
  onConfirm: (reason: string) => void;
  onCancel: () => void;
}

const REASONS = [
  { code: 'CHANGE_QUANTITY', label: 'Tôi muốn đổi số lượng sản phẩm' },
  { code: 'CHANGE_COLOR', label: 'Tôi muốn đổi màu sắc / kích cỡ' },
  { code: 'CHANGE_PAYMENT', label: 'Tôi muốn đổi phương thức thanh toán' },
  { code: 'CHANGE_ADDRESS', label: 'Tôi muốn đổi địa chỉ giao hàng' },
  { code: 'PRICE', label: 'Tôi tìm được giá tốt hơn ở nơi khác' },
  { code: 'WRONG_ORDER', label: 'Tôi đặt nhầm sản phẩm' },
  { code: 'OTHER', label: 'Lý do khác' },
];

const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  open, orderNumber, loading = false, onConfirm, onCancel,
}) => {
  const [selectedCode, setSelectedCode] = useState<string>('');
  const [otherText, setOtherText] = useState('');

  useEffect(() => {
    if (!open) return;
    setSelectedCode('');
    setOtherText('');
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onCancel(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onCancel]);

  if (!open) return null;

  const selectedReason = REASONS.find((r) => r.code === selectedCode);
  const finalReason = selectedReason
    ? (selectedReason.code === 'OTHER' ? `OTHER: ${otherText.trim() || 'Không nêu rõ'}` : `${selectedReason.code}: ${selectedReason.label}`)
    : '';
  const canConfirm = !!selectedCode && (selectedCode !== 'OTHER' || otherText.trim().length > 0);

  return (
    <div
      className="fixed inset-0 z-[9000] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onCancel(); }}
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onCancel}
          className="absolute top-4 right-4 p-1 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>

        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 rounded-full flex-shrink-0 bg-red-100">
            <XCircle className="w-6 h-6 text-red-600" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-black mb-1">Huỷ đơn hàng?</h3>
            <p className="text-sm text-gray-600">Đơn <strong>#{orderNumber}</strong> sẽ bị huỷ và không thể hoàn tác.</p>
          </div>
        </div>

        <p className="text-sm font-semibold text-black mb-3">Vui lòng chọn lý do huỷ:</p>
        <div className="space-y-2 mb-4">
          {REASONS.map((r) => (
            <label
              key={r.code}
              className={`flex items-start gap-3 p-3 border-2 rounded-lg cursor-pointer transition-colors ${
                selectedCode === r.code ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-400'
              }`}
            >
              <input
                type="radio"
                name="reason"
                value={r.code}
                checked={selectedCode === r.code}
                onChange={() => setSelectedCode(r.code)}
                className="mt-0.5 accent-red-600"
              />
              <span className="text-sm text-black">{r.label}</span>
            </label>
          ))}
          {selectedCode === 'OTHER' && (
            <textarea
              value={otherText}
              onChange={(e) => setOtherText(e.target.value)}
              placeholder="Nêu rõ lý do của bạn..."
              rows={3}
              maxLength={300}
              className="w-full px-3 py-2 mt-1 border border-gray-300 rounded-lg text-sm outline-none focus:border-red-500"
            />
          )}
        </div>

        <div className="flex gap-3 justify-end mt-6">
          <button
            onClick={onCancel}
            disabled={loading}
            className="px-5 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-full font-medium transition-colors disabled:opacity-60"
          >
            Không huỷ
          </button>
          <button
            onClick={() => onConfirm(finalReason)}
            disabled={loading || !canConfirm}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-full font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Đang huỷ...' : 'Xác nhận huỷ'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CancelOrderModal;
