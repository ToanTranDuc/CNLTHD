"use client";
import React, { useEffect, useMemo, useState } from 'react';
import { ArrowUp, ArrowDown, RefreshCw } from 'lucide-react';
import { fetchAllOrders } from '@/lib/admin';
import { Order, getOrderStatusDisplay } from '@/lib/orders';
import RevenueChart from '@/components/admin/RevenueChart';

const VND = (n: number) => '₫' + n.toLocaleString('vi-VN');

const REVENUE_STATUSES = new Set(['CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED']);

const RevenueAnalytics: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await fetchAllOrders();
      setOrders(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi tải dữ liệu đơn hàng');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const stats = useMemo(() => {
    const revenueOrders = orders.filter((o) => REVENUE_STATUSES.has(o.status));
    const totalRevenue = revenueOrders.reduce((s, o) => s + (Number(o.totalAmount) || 0), 0);
    const cancelledOrders = orders.filter((o) => o.status === 'CANCELLED');
    const cancelledValue = cancelledOrders.reduce((s, o) => s + (Number(o.totalAmount) || 0), 0);
    const deliveredOrders = orders.filter((o) => o.status === 'DELIVERED');
    const avgOrder = revenueOrders.length > 0 ? totalRevenue / revenueOrders.length : 0;
    return {
      totalRevenue,
      totalOrders: orders.length,
      revenueOrdersCount: revenueOrders.length,
      cancelledCount: cancelledOrders.length,
      cancelledValue,
      deliveredCount: deliveredOrders.length,
      avgOrder,
      completionRate: orders.length > 0 ? (deliveredOrders.length / orders.length) * 100 : 0,
    };
  }, [orders]);

  const topItems = useMemo(() => {
    const map = new Map<string, { name: string; qty: number; revenue: number }>();
    for (const o of orders) {
      if (!REVENUE_STATUSES.has(o.status)) continue;
      for (const it of o.items || []) {
        const key = it.name || it.productId || 'Unknown';
        const cur = map.get(key) || { name: key, qty: 0, revenue: 0 };
        cur.qty += it.quantity;
        cur.revenue += it.price * it.quantity;
        map.set(key, cur);
      }
    }
    return Array.from(map.values()).sort((a, b) => b.qty - a.qty).slice(0, 5);
  }, [orders]);

  const statusBreakdown = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const o of orders) counts[o.status] = (counts[o.status] || 0) + 1;
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [orders]);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-xl font-bold text-black">Báo cáo doanh thu</h3>
          <p className="text-sm text-gray-500 mt-1">Tổng hợp từ {orders.length} đơn hàng thực tế</p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Tải lại
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 text-sm">{error}</div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          label="Tổng doanh thu"
          value={VND(stats.totalRevenue)}
          sub={`${stats.revenueOrdersCount} đơn tính doanh thu`}
        />
        <StatCard
          label="Tổng đơn hàng"
          value={stats.totalOrders.toLocaleString('vi-VN')}
          sub={`${stats.deliveredCount} đã giao thành công`}
        />
        <StatCard
          label="Đơn bị huỷ"
          value={stats.cancelledCount.toLocaleString('vi-VN')}
          sub={`Giá trị mất: ${VND(stats.cancelledValue)}`}
          negative
        />
        <StatCard
          label="Giá trị TB / đơn"
          value={VND(Math.round(stats.avgOrder))}
          sub={`Tỉ lệ hoàn tất: ${stats.completionRate.toFixed(1)}%`}
        />
      </div>

      {loading && orders.length === 0 ? (
        <div className="p-12 text-center text-gray-500">Đang tải dữ liệu...</div>
      ) : (
        <>
        {/* Combined bar + area chart with period selector */}
        <RevenueChart orders={orders} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white border border-gray-200 rounded-lg p-6">
            <h4 className="text-lg font-bold text-black mb-4">Top sản phẩm bán chạy</h4>
            {topItems.length === 0 ? (
              <p className="text-sm text-gray-500">Chưa có sản phẩm nào bán được</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 text-left">
                    <th className="py-2 text-xs font-semibold text-gray-600 uppercase">#</th>
                    <th className="py-2 text-xs font-semibold text-gray-600 uppercase">Sản phẩm</th>
                    <th className="py-2 text-xs font-semibold text-gray-600 uppercase text-right">SL bán</th>
                    <th className="py-2 text-xs font-semibold text-gray-600 uppercase text-right">Doanh thu</th>
                  </tr>
                </thead>
                <tbody>
                  {topItems.map((it, idx) => (
                    <tr key={idx} className="border-b border-gray-100">
                      <td className="py-2 text-gray-600">{idx + 1}</td>
                      <td className="py-2 font-medium text-black">{it.name}</td>
                      <td className="py-2 text-right">{it.qty}</td>
                      <td className="py-2 text-right font-semibold">{VND(it.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h4 className="text-lg font-bold text-black mb-4">Trạng thái đơn hàng</h4>
            {statusBreakdown.length === 0 ? (
              <p className="text-sm text-gray-500">Chưa có dữ liệu</p>
            ) : (
              <div className="space-y-2">
                {statusBreakdown.map(([status, count]) => (
                  <div key={status} className="flex items-center justify-between py-2 border-b last:border-0 border-gray-100">
                    <span className="text-sm text-gray-700">{getOrderStatusDisplay(status)}</span>
                    <span className="text-sm font-semibold text-black">{count}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
        </>
      )}
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string; sub?: string; negative?: boolean }> = ({ label, value, sub, negative }) => (
  <div className="bg-white border border-gray-200 rounded-lg p-6">
    <p className="text-gray-600 text-sm font-medium mb-2">{label}</p>
    <h3 className="text-2xl font-bold text-black mb-2">{value}</h3>
    {sub && (
      <p className="text-xs text-gray-500 flex items-center gap-1">
        {negative ? <ArrowDown className="w-3 h-3 text-red-500" /> : <ArrowUp className="w-3 h-3 text-green-500" />}
        {sub}
      </p>
    )}
  </div>
);

export default RevenueAnalytics;
