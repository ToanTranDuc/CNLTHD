"use client";
import React, { useState, useEffect, useCallback } from 'react';
import { Edit, Trash2, Plus, ChevronDown, ChevronRight, RefreshCw, Package, AlertCircle, X, Save, Loader2 } from 'lucide-react';
import {
  fetchAdminProducts, createProduct, updateProduct, deleteProduct,
  fetchAdminCategories, fetchAllStocks, createStock, addStock, adjustStock,
  createVariant, deleteVariant,
  AdminProduct, AdminProductVariant, AdminCategory, StockInfo,
  ProductCreateDto, VariantCreateDto,
} from '@/lib/adminProducts';

// ─── Constants ────────────────────────────────────────────────────────────────

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'ONE_SIZE'];

const COLORS = [
  { code: 'BLACK',  name: 'Đen',        hex: '#000000' },
  { code: 'WHITE',  name: 'Trắng',       hex: '#FFFFFF' },
  { code: 'RED',    name: 'Đỏ',          hex: '#FF0000' },
  { code: 'BLUE',   name: 'Xanh dương',  hex: '#0000FF' },
  { code: 'NAVY',   name: 'Xanh navy',   hex: '#001F5B' },
  { code: 'GREEN',  name: 'Xanh lá',     hex: '#008000' },
  { code: 'OLIVE',  name: 'Olive',       hex: '#808000' },
  { code: 'YELLOW', name: 'Vàng',        hex: '#FFFF00' },
  { code: 'PINK',   name: 'Hồng',        hex: '#FFC0CB' },
  { code: 'PURPLE', name: 'Tím',         hex: '#800080' },
  { code: 'GRAY',   name: 'Xám',         hex: '#808080' },
  { code: 'BEIGE',  name: 'Beige',       hex: '#F5F5DC' },
  { code: 'BROWN',  name: 'Nâu',         hex: '#8B4513' },
  { code: 'ORANGE', name: 'Cam',         hex: '#FFA500' },
  { code: 'CREAM',  name: 'Kem',         hex: '#FFFDD0' },
  { code: 'KHAKI',  name: 'Khaki',       hex: '#C3B091' },
];

const GENDERS = [
  { value: 'MEN',    label: 'Nam' },
  { value: 'WOMEN',  label: 'Nữ' },
  { value: 'UNISEX', label: 'Unisex' },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getColorInfo(code: string) {
  return COLORS.find(c => c.code === code) ?? { code, name: code, hex: '#cccccc' };
}

function formatPrice(price: number | null | undefined): string {
  if (price == null) return '—';
  return price.toLocaleString('vi-VN') + '₫';
}

function StockBadge({ qty }: { qty: number | undefined }) {
  if (qty == null) return <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full">Chưa đăng ký</span>;
  if (qty === 0) return <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs rounded-full font-medium">Hết hàng</span>;
  if (qty < 5) return <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded-full font-medium">Còn ít ({qty})</span>;
  return <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full font-medium">Còn hàng ({qty})</span>;
}

// ─── Modal State ──────────────────────────────────────────────────────────────

type ModalState =
  | { type: 'none' }
  | { type: 'createProduct' }
  | { type: 'editProduct'; product: AdminProduct }
  | { type: 'deleteProduct'; product: AdminProduct }
  | { type: 'createVariant'; product: AdminProduct }
  | { type: 'adjustStock'; variant: AdminProductVariant; productName: string; currentStock?: number }
  | { type: 'deleteVariant'; variant: AdminProductVariant; productId: string };

// ─── ProductFormModal ─────────────────────────────────────────────────────────

interface ProductFormModalProps {
  title: string;
  initial: Partial<ProductCreateDto>;
  categories: AdminCategory[];
  onSave: (dto: ProductCreateDto) => Promise<void>;
  onClose: () => void;
}

function ProductFormModal({ title, initial, categories, onSave, onClose }: ProductFormModalProps) {
  const [form, setForm] = useState<ProductCreateDto>({
    name: initial.name ?? '',
    description: initial.description ?? '',
    brand: initial.brand ?? '',
    country: initial.country ?? '',
    basePrice: initial.basePrice ?? 0,
    categoryId: initial.categoryId ?? '',
    gender: initial.gender,
    status: initial.status ?? 'ACTIVE',
    imageUrls: initial.imageUrls ?? [],
  });
  const [imgInput, setImgInput] = useState('');
  const [brokenImgs, setBrokenImgs] = useState<Set<number>>(new Set());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const addImg = () => {
    const url = imgInput.trim();
    if (!url) return;
    set('imageUrls', [...(form.imageUrls ?? []), url]);
    setImgInput('');
  };

  const removeImg = (idx: number) => {
    set('imageUrls', (form.imageUrls ?? []).filter((_, i) => i !== idx));
    setBrokenImgs(prev => {
      const next = new Set<number>();
      prev.forEach(i => { if (i < idx) next.add(i); else if (i > idx) next.add(i - 1); });
      return next;
    });
  };

  const set = <K extends keyof ProductCreateDto>(key: K, val: ProductCreateDto[K]) =>
    setForm(f => ({ ...f, [key]: val }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await onSave(form);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi không xác định');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b sticky top-0 bg-white">
          <h2 className="text-lg font-semibold text-black">{title}</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />{error}
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Tên sản phẩm *</label>
              <input
                type="text" required value={form.name}
                onChange={e => set('name', e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Thương hiệu</label>
              <input
                type="text" value={form.brand ?? ''}
                onChange={e => set('brand', e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Xuất xứ</label>
              <input
                type="text" value={form.country ?? ''}
                onChange={e => set('country', e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Giá gốc (₫) *</label>
              <input
                type="number" required min="1" value={form.basePrice || ''}
                onChange={e => set('basePrice', parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Danh mục *</label>
              <select
                required value={form.categoryId}
                onChange={e => set('categoryId', e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm bg-white"
              >
                <option value="">-- Chọn danh mục --</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Giới tính</label>
              <select
                value={form.gender ?? ''}
                onChange={e => set('gender', (e.target.value as 'MEN' | 'WOMEN' | 'UNISEX') || undefined)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm bg-white"
              >
                <option value="">-- Không chọn --</option>
                {GENDERS.map(g => <option key={g.value} value={g.value}>{g.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Trạng thái</label>
              <select
                value={form.status ?? 'ACTIVE'}
                onChange={e => set('status', e.target.value as 'ACTIVE' | 'INACTIVE')}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm bg-white"
              >
                <option value="ACTIVE">Đang bán</option>
                <option value="INACTIVE">Ngừng bán</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Mô tả</label>
              <textarea
                value={form.description ?? ''} rows={3}
                onChange={e => set('description', e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm resize-none"
              />
            </div>

            {/* Image URLs */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Hình ảnh (URL)</label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  value={imgInput}
                  onChange={e => setImgInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addImg(); } }}
                  placeholder="https://example.com/image.jpg"
                  className="flex-1 px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
                />
                <button type="button" onClick={addImg}
                  className="px-3 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800">
                  + Thêm
                </button>
              </div>
              {(form.imageUrls ?? []).length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {(form.imageUrls ?? []).map((url, idx) => (
                    <div key={`${idx}-${url}`} className="relative group w-20 h-20 shrink-0">
                      {brokenImgs.has(idx) ? (
                        <div className="w-20 h-20 rounded border border-dashed border-gray-300 bg-gray-50 flex items-center justify-center p-1">
                          <span className="text-[9px] text-gray-400 text-center break-all line-clamp-4">URL lỗi</span>
                        </div>
                      ) : (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={url}
                          alt={`Ảnh ${idx + 1}`}
                          className="w-20 h-20 object-cover rounded border border-gray-200 bg-gray-100"
                          onError={() => setBrokenImgs(p => new Set(p).add(idx))}
                        />
                      )}
                      <button
                        type="button"
                        onClick={() => removeImg(idx)}
                        className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                      >
                        ×
                      </button>
                      {idx === 0 && (form.imageUrls ?? []).length > 1 && (
                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[9px] text-center py-0.5 rounded-b">
                          Chính
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Hủy</button>
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-60">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Lưu
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── VariantFormModal ─────────────────────────────────────────────────────────

interface VariantFormModalProps {
  product: AdminProduct;
  onSave: (dto: VariantCreateDto) => Promise<void>;
  onClose: () => void;
}

function VariantFormModal({ product, onSave, onClose }: VariantFormModalProps) {
  const [form, setForm] = useState<VariantCreateDto>({
    productId: product.id,
    size: 'M',
    color: 'BLACK',
    sku: '',
    price: null,
    quantity: 0,
    status: 'ACTIVE',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await onSave(form);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi không xác định');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-black">Thêm biến thể</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-sm text-gray-500 -mt-2">{product.name}</p>
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />{error}
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Size *</label>
              <select
                required value={form.size}
                onChange={e => setForm(f => ({ ...f, size: e.target.value }))}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm bg-white"
              >
                {SIZES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Màu sắc *</label>
              <select
                required value={form.color}
                onChange={e => setForm(f => ({ ...f, color: e.target.value }))}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm bg-white"
              >
                {COLORS.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}
              </select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Mã SKU *</label>
              <input
                type="text" required value={form.sku}
                placeholder="VD: NIKE-SHIRT-M-BLACK"
                onChange={e => setForm(f => ({ ...f, sku: e.target.value.toUpperCase() }))}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm font-mono"
              />
              <p className="text-xs text-gray-400 mt-1">Chỉ dùng chữ hoa, số, dấu _ hoặc -</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Giá riêng (₫)</label>
              <input
                type="number" min="0"
                value={form.price ?? ''}
                placeholder={`Mặc định: ${formatPrice(product.basePrice)}`}
                onChange={e => setForm(f => ({ ...f, price: e.target.value ? parseFloat(e.target.value) : null }))}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Số lượng ban đầu</label>
              <input
                type="number" min="0" value={form.quantity ?? 0}
                onChange={e => setForm(f => ({ ...f, quantity: parseInt(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Hủy</button>
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-60">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              Thêm
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── StockAdjustModal ─────────────────────────────────────────────────────────

interface StockAdjustModalProps {
  variant: AdminProductVariant;
  productName: string;
  currentStock?: number;
  onSave: (skuCode: string, quantityChange: number, reason: string, op: 'add' | 'adjust') => Promise<void>;
  onClose: () => void;
}

function StockAdjustModal({ variant, productName, currentStock, onSave, onClose }: StockAdjustModalProps) {
  const [op, setOp] = useState<'add' | 'adjust'>('add');
  const [qty, setQty] = useState(1);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const colorInfo = getColorInfo(variant.color);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (qty < 1) { setError('Số lượng phải >= 1'); return; }
    setSaving(true);
    setError('');
    try {
      await onSave(variant.sku, qty, reason, op);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi không xác định');
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-black">Điều chỉnh tồn kho</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3 bg-gray-50 rounded-lg text-sm space-y-1">
            <p className="font-medium text-black">{productName}</p>
            <p className="text-gray-500 font-mono text-xs">{variant.sku}</p>
            <div className="flex items-center gap-3 text-gray-600">
              <span>Size: {variant.size}</span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 rounded-full border border-gray-200" style={{ backgroundColor: colorInfo.hex }} />
                {colorInfo.name}
              </span>
            </div>
            <p className="text-gray-600">
              Tồn kho hiện tại:{' '}
              <span className="font-semibold text-black">{currentStock ?? 'Chưa đăng ký'}</span>
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />{error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Thao tác</label>
            <div className="flex gap-3">
              <button type="button" onClick={() => setOp('add')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${op === 'add' ? 'bg-green-600 text-white border-green-600' : 'border-gray-300 text-gray-700 hover:bg-gray-50'}`}>
                + Nhập hàng
              </button>
              <button type="button" onClick={() => setOp('adjust')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${op === 'adjust' ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-300 text-gray-700 hover:bg-gray-50'}`}>
                Điều chỉnh
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Số lượng *</label>
            <input
              type="number" required min="1" value={qty}
              onChange={e => setQty(parseInt(e.target.value) || 1)}
              className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Lý do</label>
            <input
              type="text" value={reason}
              placeholder="VD: Nhập hàng tháng 5, Kiểm kê..."
              onChange={e => setReason(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg text-black outline-none focus:border-black text-sm"
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Hủy</button>
            <button type="submit" disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-60">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Xác nhận
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── ConfirmDeleteModal ───────────────────────────────────────────────────────

interface ConfirmDeleteProps {
  message: string;
  onConfirm: () => Promise<void>;
  onClose: () => void;
}

function ConfirmDeleteModal({ message, onConfirm, onClose }: ConfirmDeleteProps) {
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');

  const handleConfirm = async () => {
    setDeleting(true);
    setError('');
    try {
      await onConfirm();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi không xác định');
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-sm shadow-2xl p-6 space-y-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-6 h-6 text-red-500 shrink-0 mt-0.5" />
          <div>
            <h2 className="text-base font-semibold text-black mb-1">Xác nhận xóa</h2>
            <p className="text-sm text-gray-600">{message}</p>
          </div>
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <div className="flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">Hủy</button>
          <button onClick={handleConfirm} disabled={deleting}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 disabled:opacity-60">
            {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            Xóa
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Toast ────────────────────────────────────────────────────────────────────

function Toast({ msg, ok }: { msg: string; ok: boolean }) {
  return (
    <div className={`fixed top-4 right-4 z-[100] px-4 py-3 rounded-lg shadow-lg text-white text-sm font-medium ${ok ? 'bg-green-600' : 'bg-red-600'}`}>
      {msg}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

const ProductManagement: React.FC = () => {
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [categories, setCategories] = useState<AdminCategory[]>([]);
  const [stocks, setStocks] = useState<Map<string, StockInfo>>(new Map());
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterGender, setFilterGender] = useState('all');
  const [search, setSearch] = useState('');
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<ModalState>({ type: 'none' });
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  const closeModal = () => setModal({ type: 'none' });

  const loadData = useCallback(async () => {
    setLoading(true);
    setLoadError('');
    try {
      const [prods, cats, stockList] = await Promise.all([
        fetchAdminProducts(),
        fetchAdminCategories(),
        fetchAllStocks(),
      ]);
      setProducts(prods);
      setCategories(cats);
      const map = new Map<string, StockInfo>();
      stockList.forEach(s => map.set(s.skuCode, s));
      setStocks(map);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : 'Lỗi tải dữ liệu');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const toggleExpand = (id: string) =>
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) { next.delete(id); } else { next.add(id); }
      return next;
    });

  // ── Filtered list ──
  const filtered = products.filter(p => {
    if (filterCategory !== 'all' && p.categoryId !== filterCategory) return false;
    if (filterGender !== 'all' && p.gender !== filterGender) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.name.toLowerCase().includes(q) || (p.brand ?? '').toLowerCase().includes(q);
    }
    return true;
  });

  // ── Handlers ──

  const handleCreateProduct = async (dto: ProductCreateDto) => {
    const created = await createProduct(dto);
    setProducts(prev => [created, ...prev]);
    showToast('Tạo sản phẩm thành công');
    closeModal();
  };

  const handleUpdateProduct = async (id: string, dto: ProductCreateDto) => {
    const updated = await updateProduct(id, dto);
    setProducts(prev => prev.map(p => p.id === id ? updated : p));
    showToast('Cập nhật sản phẩm thành công');
    closeModal();
  };

  const handleDeleteProduct = async (id: string) => {
    await deleteProduct(id);
    setProducts(prev => prev.filter(p => p.id !== id));
    showToast('Đã xóa sản phẩm');
    closeModal();
  };

  const handleCreateVariant = async (dto: VariantCreateDto) => {
    const created = await createVariant(dto);
    // Register stock in Inventory Service
    try {
      const productName = products.find(p => p.id === dto.productId)?.name ?? dto.sku;
      const stock = await createStock(dto.sku, productName, dto.quantity ?? 0);
      setStocks(prev => new Map(prev).set(stock.skuCode, stock));
    } catch {
      // SKU may already exist in inventory - ignore
    }
    setProducts(prev =>
      prev.map(p =>
        p.id === dto.productId
          ? { ...p, variants: [...(p.variants ?? []), created] }
          : p
      )
    );
    showToast('Thêm biến thể thành công');
    closeModal();
  };

  const handleDeleteVariant = async (variantId: string, productId: string) => {
    await deleteVariant(variantId);
    setProducts(prev =>
      prev.map(p =>
        p.id === productId
          ? { ...p, variants: (p.variants ?? []).filter(v => v.id !== variantId) }
          : p
      )
    );
    showToast('Đã xóa biến thể');
    closeModal();
  };

  const handleStockAdjust = async (skuCode: string, quantityChange: number, reason: string, op: 'add' | 'adjust') => {
    let result: StockInfo;
    if (!stocks.has(skuCode)) {
      // Not in inventory yet — register it
      const productName = (() => {
        for (const p of products) {
          if (p.variants?.find(v => v.sku === skuCode)) return p.name;
        }
        return skuCode;
      })();
      result = await createStock(skuCode, productName, quantityChange);
    } else if (op === 'add') {
      result = await addStock(skuCode, quantityChange, reason);
    } else {
      result = await adjustStock(skuCode, quantityChange, reason);
    }
    setStocks(prev => new Map(prev).set(result.skuCode, result));
    showToast('Cập nhật tồn kho thành công');
    closeModal();
  };

  // ── Render ──

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-gray-400 gap-3">
        <Loader2 className="w-6 h-6 animate-spin" />
        <span>Đang tải dữ liệu...</span>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
        <AlertCircle className="w-10 h-10 text-red-400" />
        <p className="text-red-600 text-sm">{loadError}</p>
        <button onClick={loadData} className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800">
          <RefreshCw className="w-4 h-4" /> Thử lại
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {toast && <Toast msg={toast.msg} ok={toast.ok} />}

      {/* Header toolbar */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex gap-2 flex-wrap">
          <input
            type="text" placeholder="Tìm sản phẩm..." value={search}
            onChange={e => setSearch(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-black outline-none w-44 focus:border-black"
          />
          <select
            value={filterCategory} onChange={e => setFilterCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg bg-white text-black text-sm outline-none"
          >
            <option value="all">Tất cả danh mục</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select
            value={filterGender} onChange={e => setFilterGender(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg bg-white text-black text-sm outline-none"
          >
            <option value="all">Tất cả giới tính</option>
            {GENDERS.map(g => <option key={g.value} value={g.value}>{g.label}</option>)}
          </select>
          <button onClick={loadData} title="Làm mới" className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-600">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
        <button
          onClick={() => setModal({ type: 'createProduct' })}
          className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium text-sm">
          <Plus className="w-4 h-4" />
          Thêm sản phẩm
        </button>
      </div>

      <p className="text-xs text-gray-500">{filtered.length} sản phẩm</p>

      {/* Products table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200 bg-gray-50">
              <th className="px-3 py-3 w-8" />
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Sản phẩm</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Danh mục</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Giá gốc</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Giới tính</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Trạng thái</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Biến thể</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-black">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-16 text-center text-gray-400">
                  <Package className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  Không có sản phẩm nào
                </td>
              </tr>
            )}
            {filtered.map(product => {
              const isExpanded = expandedIds.has(product.id);
              const variantCount = product.variants?.length ?? 0;
              const genderLabel = GENDERS.find(g => g.value === product.gender)?.label ?? product.gender ?? '—';

              return (
                <React.Fragment key={product.id}>
                  <tr className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="px-3 py-3 text-center">
                      <button
                        onClick={() => toggleExpand(product.id)}
                        className="p-1 hover:bg-gray-200 rounded text-gray-400"
                      >
                        {isExpanded
                          ? <ChevronDown className="w-4 h-4" />
                          : <ChevronRight className="w-4 h-4" />
                        }
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        {product.image ? (
                          <img src={product.image} alt={product.name} className="w-10 h-10 rounded object-cover bg-gray-100 shrink-0" />
                        ) : (
                          <div className="w-10 h-10 rounded bg-gray-100 flex items-center justify-center shrink-0">
                            <Package className="w-5 h-5 text-gray-300" />
                          </div>
                        )}
                        <div>
                          <p className="text-sm font-medium text-black">{product.name}</p>
                          {product.brand && <p className="text-xs text-gray-400">{product.brand}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{product.categoryName || '—'}</td>
                    <td className="px-4 py-3 text-sm font-medium text-black">{formatPrice(product.basePrice)}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{genderLabel}</td>
                    <td className="px-4 py-3">
                      {product.status === 'ACTIVE'
                        ? <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full font-medium">Đang bán</span>
                        : <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full font-medium">Ngừng bán</span>
                      }
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleExpand(product.id)}
                        className="text-sm text-blue-600 hover:underline font-medium"
                      >
                        {variantCount} biến thể
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setModal({ type: 'createVariant', product })}
                          title="Thêm biến thể"
                          className="p-1.5 hover:bg-blue-50 rounded text-blue-600 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setModal({ type: 'editProduct', product })}
                          title="Sửa sản phẩm"
                          className="p-1.5 hover:bg-gray-100 rounded text-gray-600 transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setModal({ type: 'deleteProduct', product })}
                          title="Xóa sản phẩm"
                          className="p-1.5 hover:bg-red-50 rounded text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>

                  {/* Expanded: variants sub-table */}
                  {isExpanded && (
                    <tr className="bg-blue-50/20">
                      <td colSpan={8} className="px-6 pb-4 pt-2">
                        {variantCount === 0 ? (
                          <p className="text-sm text-gray-400 py-2">Chưa có biến thể. Nhấn + để thêm.</p>
                        ) : (
                          <div className="rounded-lg border border-blue-100 overflow-hidden">
                            <table className="w-full text-sm">
                              <thead>
                                <tr className="bg-blue-50">
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">SKU</th>
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">Size</th>
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">Màu</th>
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">Giá biến thể</th>
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">Tồn kho</th>
                                  <th className="px-4 py-2 text-left text-xs font-semibold text-blue-800">Thao tác</th>
                                </tr>
                              </thead>
                              <tbody className="bg-white">
                                {product.variants?.map(variant => {
                                  const stockInfo = stocks.get(variant.sku);
                                  const colorInfo = getColorInfo(variant.color);
                                  return (
                                    <tr key={variant.id} className="border-t border-gray-100 hover:bg-gray-50">
                                      <td className="px-4 py-2 font-mono text-xs text-gray-600">{variant.sku}</td>
                                      <td className="px-4 py-2 text-xs">{variant.size}</td>
                                      <td className="px-4 py-2">
                                        <div className="flex items-center gap-1.5 text-xs">
                                          <span
                                            className="w-3.5 h-3.5 rounded-full border border-gray-200 shrink-0"
                                            style={{ backgroundColor: colorInfo.hex }}
                                          />
                                          {colorInfo.name}
                                        </div>
                                      </td>
                                      <td className="px-4 py-2 text-xs">
                                        {variant.price
                                          ? formatPrice(variant.price)
                                          : <span className="text-gray-400">Giá gốc</span>
                                        }
                                      </td>
                                      <td className="px-4 py-2">
                                        <StockBadge qty={stockInfo?.quantity} />
                                      </td>
                                      <td className="px-4 py-2">
                                        <div className="flex items-center gap-1">
                                          <button
                                            onClick={() => setModal({
                                              type: 'adjustStock',
                                              variant,
                                              productName: product.name,
                                              currentStock: stockInfo?.quantity,
                                            })}
                                            className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 font-medium"
                                          >
                                            Kho
                                          </button>
                                          <button
                                            onClick={() => setModal({ type: 'deleteVariant', variant, productId: product.id })}
                                            className="p-1 hover:bg-red-50 rounded text-red-400 transition-colors"
                                          >
                                            <Trash2 className="w-3.5 h-3.5" />
                                          </button>
                                        </div>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modals */}
      {modal.type === 'createProduct' && (
        <ProductFormModal
          title="Thêm sản phẩm mới"
          initial={{}}
          categories={categories}
          onSave={handleCreateProduct}
          onClose={closeModal}
        />
      )}

      {modal.type === 'editProduct' && (
        <ProductFormModal
          title="Sửa sản phẩm"
          initial={{
            name: modal.product.name,
            description: modal.product.description,
            brand: modal.product.brand,
            country: modal.product.country,
            basePrice: modal.product.basePrice,
            categoryId: modal.product.categoryId,
            gender: modal.product.gender ?? undefined,
            status: (modal.product.status as 'ACTIVE' | 'INACTIVE') ?? 'ACTIVE',
            imageUrls: modal.product.images ?? [],
          }}
          categories={categories}
          onSave={dto => handleUpdateProduct(modal.product.id, dto)}
          onClose={closeModal}
        />
      )}

      {modal.type === 'deleteProduct' && (
        <ConfirmDeleteModal
          message={`Bạn có chắc muốn xóa "${modal.product.name}"? Sản phẩm sẽ bị ẩn khỏi cửa hàng.`}
          onConfirm={() => handleDeleteProduct(modal.product.id)}
          onClose={closeModal}
        />
      )}

      {modal.type === 'createVariant' && (
        <VariantFormModal
          product={modal.product}
          onSave={handleCreateVariant}
          onClose={closeModal}
        />
      )}

      {modal.type === 'adjustStock' && (
        <StockAdjustModal
          variant={modal.variant}
          productName={modal.productName}
          currentStock={modal.currentStock}
          onSave={handleStockAdjust}
          onClose={closeModal}
        />
      )}

      {modal.type === 'deleteVariant' && (
        <ConfirmDeleteModal
          message={`Xóa biến thể SKU "${modal.variant.sku}"?`}
          onConfirm={() => handleDeleteVariant(modal.variant.id, modal.productId)}
          onClose={closeModal}
        />
      )}
    </div>
  );
};

export default ProductManagement;
