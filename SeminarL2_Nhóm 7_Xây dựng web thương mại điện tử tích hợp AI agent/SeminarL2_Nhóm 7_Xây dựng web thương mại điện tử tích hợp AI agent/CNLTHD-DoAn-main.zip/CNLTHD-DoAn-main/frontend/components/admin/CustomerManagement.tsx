"use client";
import React, { useEffect, useState } from 'react';
import { Lock, Unlock, Search, RefreshCw, Edit } from 'lucide-react';
import { fetchAllUsers, activateUser, deactivateUser, AdminUser } from '@/lib/admin';
import { useToast } from '@/context/ToastContext';
import EditUserModal from './EditUserModal';

const CustomerManagement: React.FC = () => {
  const { showToast } = useToast();
  const [customers, setCustomers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [toggling, setToggling] = useState<string | null>(null);
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);

  const loadCustomers = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await fetchAllUsers();
      data.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      setCustomers(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi tải danh sách khách hàng');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
    // Auto-refresh so new signups appear without manual refresh
    const interval = setInterval(loadCustomers, 30_000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleBlock = async (user: AdminUser) => {
    const isActive = user.isActive ?? user.active ?? true;
    setToggling(user.id);
    try {
      const updated = isActive ? await deactivateUser(user.id) : await activateUser(user.id);
      setCustomers((prev) => prev.map((u) => (u.id === user.id ? { ...u, ...updated } : u)));
      showToast(
        isActive ? `Đã khoá tài khoản ${user.email}` : `Đã kích hoạt ${user.email}`,
        'success'
      );
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Thao tác thất bại', 'error');
    } finally {
      setToggling(null);
    }
  };

  const filtered = customers.filter((c) => {
    const matchSearch = !searchTerm
      || c.fullname?.toLowerCase().includes(searchTerm.toLowerCase())
      || c.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchRole = roleFilter === 'ALL' || (c.role || '').toUpperCase() === roleFilter;
    return matchSearch && matchRole;
  });

  const handleOpenEdit = (user: AdminUser) => {
    // Admin chỉ có thể sửa CUSTOMER (không sửa ADMIN khác, không sửa chính mình)
    const isUserAdmin = (user.role || '').toUpperCase() === 'ADMIN';
    if (isUserAdmin) {
      showToast('Không thể chỉnh sửa thông tin Admin', 'error');
      return;
    }
    setEditingUser(user);
  };

  const handleEditSuccess = (updated: AdminUser) => {
    setCustomers((prev) =>
      prev.map((u) => (u.id === updated.id ? { ...u, ...updated } : u))
    );
    showToast('Cập nhật thành công', 'success');
  };

  const handleEditError = (error: string) => {
    showToast(error, 'error');
  };

  return (
    <>
      <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-xl font-bold text-black">Quản lý khách hàng</h3>
          <p className="text-sm text-gray-500 mt-1">{filtered.length} / {customers.length} tài khoản</p>
        </div>
        <button
          onClick={loadCustomers}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Tải lại
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 flex items-center gap-3 bg-white border border-gray-300 rounded-lg px-4 py-3">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Tìm theo tên hoặc email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-grow outline-none bg-transparent text-black placeholder-gray-400"
          />
        </div>
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-black"
          >
            <option value="ALL">Tất cả vai trò</option>
            <option value="ADMIN">Admin</option>
            <option value="CUSTOMER">Customer</option>
          </select>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 text-sm">{error}</div>
      )}

      {loading ? (
        <div className="p-12 text-center text-gray-500">Đang tải...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <p className="text-gray-600">Không có khách hàng nào.</p>
        </div>
      ) : (
      <div className="bg-white rounded-lg border border-gray-200 overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead>
            <tr className="border-b border-gray-200 bg-gray-50">
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Họ tên</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Email</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">SĐT</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Vai trò</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Ngày tham gia</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Trạng thái</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Chỉnh sửa</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((customer) => {
              const isActive = customer.isActive ?? customer.active ?? true;
              return (
                <tr
                  key={customer.id}
                  className={`border-b border-gray-200 transition-colors ${
                    !isActive ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'
                  }`}
                >
                  <td className="px-6 py-4 text-sm font-medium text-black">{customer.fullname || '-'}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{customer.email}</td>
                  <td className="px-6 py-4 text-sm text-gray-700">{customer.sdt || '-'}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] uppercase tracking-wide px-2 py-1 rounded-full ${
                      (customer.role || '').toUpperCase() === 'ADMIN'
                        ? 'bg-purple-100 text-purple-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {customer.role || 'CUSTOMER'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {customer.createdAt ? new Date(customer.createdAt).toLocaleDateString('vi-VN') : '-'}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        !isActive
                          ? 'bg-red-100 text-red-800'
                          : 'bg-green-100 text-green-800'
                      }`}
                    >
                      {!isActive ? 'Đã khoá' : 'Hoạt động'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleOpenEdit(customer)}
                      disabled={(customer.role || '').toUpperCase() === 'ADMIN'}
                      title={(customer.role || '').toUpperCase() === 'ADMIN' ? 'Không thể chỉnh sửa Admin' : 'Chỉnh sửa'}
                      className="p-2 rounded hover:bg-blue-100 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Edit className="w-5 h-5 text-blue-600" />
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleToggleBlock(customer)}
                      disabled={toggling === customer.id || (customer.role || '').toUpperCase() === 'ADMIN'}
                      title={(customer.role || '').toUpperCase() === 'ADMIN' ? 'Không thể khoá admin' : isActive ? 'Khoá tài khoản' : 'Mở khoá'}
                      className={`p-2 rounded transition-colors disabled:opacity-30 disabled:cursor-not-allowed ${
                        !isActive ? 'hover:bg-green-100' : 'hover:bg-red-100'
                      }`}
                    >
                      {toggling === customer.id ? (
                        <RefreshCw className="w-5 h-5 animate-spin text-gray-500" />
                      ) : !isActive ? (
                        <Unlock className="w-5 h-5 text-green-600" />
                      ) : (
                        <Lock className="w-5 h-5 text-red-600" />
                      )}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      )}
      </div>

      {/* Edit Modal */}
      <EditUserModal
        user={editingUser}
        currentUserRole="ADMIN"
        onClose={() => setEditingUser(null)}
        onSuccess={handleEditSuccess}
        onError={handleEditError}
      />
    </>
  );
};

export default CustomerManagement;
