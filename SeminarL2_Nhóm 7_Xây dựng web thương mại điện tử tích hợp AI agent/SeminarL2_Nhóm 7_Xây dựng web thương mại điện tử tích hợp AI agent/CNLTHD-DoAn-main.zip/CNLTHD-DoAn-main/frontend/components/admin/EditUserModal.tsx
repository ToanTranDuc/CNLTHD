'use client';

import React, { useState, useEffect } from 'react';
import { X, Eye, EyeOff } from 'lucide-react';
import { AdminUser, updateUser } from '@/lib/admin';
import { validateUserUpdate, ValidationError } from '@/lib/validation';

interface EditUserModalProps {
  user: AdminUser | null;
  currentUserRole?: string;
  onClose: () => void;
  onSuccess: (updated: AdminUser) => void;
  onError: (error: string) => void;
}

const EditUserModal: React.FC<EditUserModalProps> = ({
  user,
  currentUserRole,
  onClose,
  onSuccess,
  onError,
}) => {
  const [formData, setFormData] = useState({
    fullname: '',
    email: '',
    sdt: '',
    password: '', // Không lưu password cũ, chỉ password mới
    role: 'CUSTOMER',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Sync form data khi user thay đổi
  useEffect(() => {
    if (user) {
      setFormData({
        fullname: user.fullname || '',
        email: user.email || '',
        sdt: user.sdt || '',
        password: '', // KHÔNG hiển thị password cũ
        role: user.role || 'CUSTOMER',
      });
      setErrors({});
    }
  }, [user]);

  if (!user) return null;

  // Determine if can edit role
  const isUserAdmin = (user.role || '').toUpperCase() === 'ADMIN';
  const canChangeRole = currentUserRole?.toUpperCase() === 'ADMIN' && !isUserAdmin;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Validation
    const validation = validateUserUpdate({
      fullname: formData.fullname,
      email: formData.email,
      sdt: formData.sdt,
      password: formData.password,
    });

    if (!validation.valid) {
      const errorMap: Record<string, string> = {};
      validation.errors.forEach((err: ValidationError) => {
        errorMap[err.field] = err.message;
      });
      setErrors(errorMap);
      return;
    }

    setLoading(true);
    try {
      const payload: Record<string, unknown> = {
        fullname: formData.fullname,
        email: formData.email,
        sdt: formData.sdt,
      };

      if (formData.password) {
        payload.password = formData.password;
      }

      if (canChangeRole) {
        payload.role = formData.role;
      }

      const updated = await updateUser(user.id, payload as any);
      onSuccess(updated);
      onClose();
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Cập nhật thất bại');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 flex justify-between items-center p-6 border-b border-gray-200 bg-white">
          <h2 className="text-lg font-bold text-black">Chỉnh sửa thông tin</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Họ tên */}
          <div>
            <label className="block text-sm font-medium text-black mb-2">Họ tên</label>
            <input
              type="text"
              name="fullname"
              value={formData.fullname}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-lg outline-none transition-colors text-black placeholder-gray-400 ${
                errors.fullname ? 'border-red-500' : 'border-gray-300 focus:border-black'
              }`}
              placeholder="Nhập họ tên"
            />
            {errors.fullname && (
              <p className="text-red-600 text-xs mt-1">{errors.fullname}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-black mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-lg outline-none transition-colors text-black placeholder-gray-400 ${
                errors.email ? 'border-red-500' : 'border-gray-300 focus:border-black'
              }`}
              placeholder="example@gmail.com"
            />
            {errors.email && (
              <p className="text-red-600 text-xs mt-1">{errors.email}</p>
            )}
          </div>

          {/* Số điện thoại */}
          <div>
            <label className="block text-sm font-medium text-black mb-2">Số điện thoại</label>
            <input
              type="tel"
              name="sdt"
              value={formData.sdt}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-lg outline-none transition-colors text-black placeholder-gray-400 ${
                errors.sdt ? 'border-red-500' : 'border-gray-300 focus:border-black'
              }`}
              placeholder="0123456789"
            />
            {errors.sdt && (
              <p className="text-red-600 text-xs mt-1">{errors.sdt}</p>
            )}
          </div>

          {/* Vai trò - chỉ hiển thị nếu có thể thay đổi */}
          {canChangeRole && (
            <div>
              <label className="block text-sm font-medium text-black mb-2">Vai trò</label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none focus:border-black text-black"
              >
                <option value="CUSTOMER">Customer</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>
          )}

          {/* Mật khẩu - Tùy chọn */}
          <div className="pt-2 border-t border-gray-200">
            <p className="text-sm text-gray-600 mb-3">
              <span className="font-medium">Đổi mật khẩu (tùy chọn):</span> Để trống nếu không thay đổi
            </p>
            <div>
              <label className="block text-sm font-medium text-black mb-2">
                Mật khẩu mới
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg outline-none transition-colors text-black placeholder-gray-400 pr-10 ${
                    errors.password ? 'border-red-500' : 'border-gray-300 focus:border-black'
                  }`}
                  placeholder="Để trống nếu không đổi mật khẩu"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
              {errors.password && (
                <p className="text-red-600 text-xs mt-1">{errors.password}</p>
              )}
              {formData.password && (
                <p className="text-gray-500 text-xs mt-2 flex gap-2 flex-wrap">
                  <span className="font-medium">Yêu cầu:</span>
                  <span className={formData.password.length >= 10 ? 'text-green-600' : 'text-red-600'}>
                    {formData.password.length >= 10 ? '✓' : '○'} 10+ ký tự
                  </span>
                  <span className={/[A-Z]/.test(formData.password) ? 'text-green-600' : 'text-red-600'}>
                    {/[A-Z]/.test(formData.password) ? '✓' : '○'} Chữ in hoa
                  </span>
                  <span className={/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(formData.password) ? 'text-green-600' : 'text-red-600'}>
                    {/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(formData.password) ? '✓' : '○'} Ký tự đặc biệt
                  </span>
                </p>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-50 transition-colors"
            >
              {loading ? 'Đang cập nhật...' : 'Cập nhật'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditUserModal;
