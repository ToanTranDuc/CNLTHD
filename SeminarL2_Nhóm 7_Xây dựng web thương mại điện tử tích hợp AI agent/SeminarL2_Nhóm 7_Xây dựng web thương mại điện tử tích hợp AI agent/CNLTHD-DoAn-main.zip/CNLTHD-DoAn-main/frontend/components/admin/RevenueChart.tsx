"use client";
import React, { useMemo, useState } from 'react';
import { Order } from '@/lib/orders';

type Period = 'week' | 'month' | 'quarter' | 'year';

interface RevenueChartProps {
  orders: Order[];
}

interface Bucket {
  label: string;
  fullLabel: string;
  revenue: number;
  orderCount: number;
  cancelledCount: number;
}

const REVENUE_STATUSES = new Set(['CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED']);
const VND_SHORT = (n: number) => {
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(1) + 'B';
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(0) + 'K';
  return String(n);
};
const VND = (n: number) => '₫' + n.toLocaleString('vi-VN');

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function buildBuckets(orders: Order[], period: Period): Bucket[] {
  const now = new Date();
  const buckets: { from: Date; to: Date; label: string; fullLabel: string }[] = [];

  if (period === 'week') {
    // 7 days back, today inclusive
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dow = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'][d.getDay()];
      buckets.push({
        from: startOfDay(d),
        to: new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1),
        label: `${dow} ${d.getDate()}/${d.getMonth() + 1}`,
        fullLabel: d.toLocaleDateString('vi-VN'),
      });
    }
  } else if (period === 'month') {
    // 4 weekly buckets covering last 28 days
    for (let i = 3; i >= 0; i--) {
      const end = new Date(now);
      end.setDate(end.getDate() - i * 7);
      const start = new Date(end);
      start.setDate(start.getDate() - 6);
      buckets.push({
        from: startOfDay(start),
        to: new Date(end.getFullYear(), end.getMonth(), end.getDate() + 1),
        label: `${start.getDate()}/${start.getMonth() + 1}–${end.getDate()}/${end.getMonth() + 1}`,
        fullLabel: `${start.toLocaleDateString('vi-VN')} – ${end.toLocaleDateString('vi-VN')}`,
      });
    }
  } else if (period === 'quarter') {
    // 3 monthly buckets (current + last 2 months)
    for (let i = 2; i >= 0; i--) {
      const ref = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      buckets.push({
        from: ref,
        to: next,
        label: `T${ref.getMonth() + 1}/${ref.getFullYear()}`,
        fullLabel: `Tháng ${ref.getMonth() + 1}/${ref.getFullYear()}`,
      });
    }
  } else {
    // year: 12 monthly buckets
    for (let i = 11; i >= 0; i--) {
      const ref = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      buckets.push({
        from: ref,
        to: next,
        label: `T${ref.getMonth() + 1}`,
        fullLabel: `Tháng ${ref.getMonth() + 1}/${ref.getFullYear()}`,
      });
    }
  }

  return buckets.map((b) => {
    let revenue = 0;
    let orderCount = 0;
    let cancelledCount = 0;
    for (const o of orders) {
      if (!o.createdAt) continue;
      const t = new Date(o.createdAt).getTime();
      if (t < b.from.getTime() || t >= b.to.getTime()) continue;
      orderCount += 1;
      if (o.status === 'CANCELLED') cancelledCount += 1;
      if (REVENUE_STATUSES.has(o.status)) revenue += Number(o.totalAmount) || 0;
    }
    return { label: b.label, fullLabel: b.fullLabel, revenue, orderCount, cancelledCount };
  });
}

const RevenueChart: React.FC<RevenueChartProps> = ({ orders }) => {
  const [period, setPeriod] = useState<Period>('week');
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const buckets = useMemo(() => buildBuckets(orders, period), [orders, period]);

  // Chart dims
  const W = 920;
  const H = 380;
  const padTop = 30;
  const padBottom = 60;
  const padLeft = 70;
  const padRight = 60;
  const chartW = W - padLeft - padRight;
  const chartH = H - padTop - padBottom;

  const n = buckets.length;
  const groupW = chartW / Math.max(n, 1);
  const barW = Math.min(20, groupW / 3);
  const gap = 4;

  const maxRevenue = Math.max(1, ...buckets.map((b) => b.revenue));
  const maxCount = Math.max(1, ...buckets.map((b) => Math.max(b.orderCount, b.cancelledCount)));

  // Build area path for cancelled (smooth curve)
  const cancelPoints = buckets.map((b, i) => {
    const x = padLeft + groupW * (i + 0.5);
    const y = padTop + chartH - (b.cancelledCount / maxCount) * chartH;
    return { x, y };
  });

  const areaPath = (() => {
    if (cancelPoints.length === 0) return '';
    const segments = cancelPoints.map((p, i) => {
      if (i === 0) return `M ${p.x},${p.y}`;
      const prev = cancelPoints[i - 1];
      const cpX = (prev.x + p.x) / 2;
      return `C ${cpX},${prev.y} ${cpX},${p.y} ${p.x},${p.y}`;
    });
    const last = cancelPoints[cancelPoints.length - 1];
    const first = cancelPoints[0];
    return [
      ...segments,
      `L ${last.x},${padTop + chartH}`,
      `L ${first.x},${padTop + chartH}`,
      'Z',
    ].join(' ');
  })();

  const linePath = (() => {
    if (cancelPoints.length === 0) return '';
    return cancelPoints.map((p, i) => {
      if (i === 0) return `M ${p.x},${p.y}`;
      const prev = cancelPoints[i - 1];
      const cpX = (prev.x + p.x) / 2;
      return `C ${cpX},${prev.y} ${cpX},${p.y} ${p.x},${p.y}`;
    }).join(' ');
  })();

  // Y-axis ticks
  const yTicks = 5;
  const leftTicks = Array.from({ length: yTicks + 1 }, (_, i) => i * (maxRevenue / yTicks));
  const rightTicks = Array.from({ length: yTicks + 1 }, (_, i) => Math.round(i * (maxCount / yTicks)));

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h4 className="text-lg font-bold text-black">Biểu đồ tổng quan</h4>
        </div>
        <div className="inline-flex rounded-full bg-gray-100 p-1">
          {(['week', 'month', 'quarter', 'year'] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-4 py-1.5 text-sm font-medium rounded-full transition-all ${
                period === p ? 'bg-black text-white shadow' : 'text-gray-600 hover:text-black'
              }`}
            >
              {p === 'week' ? 'Tuần' : p === 'month' ? 'Tháng' : p === 'quarter' ? 'Quý' : 'Năm'}
            </button>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-5 mb-4 text-sm">
        <LegendDot color="#3b82f6" label="Tổng doanh thu (₫)" />
        <LegendDot color="#a855f7" label="Tổng đơn hàng" />
        <LegendDot color="#ef4444" label="Đơn bị huỷ" isArea />
      </div>

      {/* Chart */}
      <div className="relative w-full overflow-x-auto">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ minWidth: 600 }}>
          <defs>
            <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#60a5fa" />
              <stop offset="100%" stopColor="#2563eb" />
            </linearGradient>
            <linearGradient id="ordersGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#c084fc" />
              <stop offset="100%" stopColor="#9333ea" />
            </linearGradient>
            <linearGradient id="cancelGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#ef4444" stopOpacity="0.05" />
            </linearGradient>
            <filter id="barShadow" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.15" />
            </filter>
          </defs>

          {/* Grid + Y axes */}
          {leftTicks.map((tick, i) => {
            const y = padTop + chartH - (tick / maxRevenue) * chartH;
            return (
              <g key={`grid-${i}`}>
                <line x1={padLeft} y1={y} x2={padLeft + chartW} y2={y} stroke="#f3f4f6" strokeWidth="1" />
                <text x={padLeft - 8} y={y + 4} textAnchor="end" fontSize="11" fill="#6b7280">
                  {VND_SHORT(tick)}
                </text>
              </g>
            );
          })}
          {rightTicks.map((tick, i) => {
            const y = padTop + chartH - (tick / maxCount) * chartH;
            return (
              <text key={`r-${i}`} x={padLeft + chartW + 8} y={y + 4} textAnchor="start" fontSize="11" fill="#6b7280">
                {tick}
              </text>
            );
          })}

          {/* Y-axis labels */}
          <text x={padLeft - 50} y={padTop - 12} fontSize="11" fill="#2563eb" fontWeight="600">₫ Doanh thu</text>
          <text x={padLeft + chartW + 8} y={padTop - 12} fontSize="11" fill="#9333ea" fontWeight="600">Số đơn</text>

          {/* X axis line */}
          <line x1={padLeft} y1={padTop + chartH} x2={padLeft + chartW} y2={padTop + chartH} stroke="#d1d5db" strokeWidth="1.5" />

          {/* Bars + X labels */}
          {buckets.map((b, i) => {
            const cx = padLeft + groupW * (i + 0.5);
            const revH = (b.revenue / maxRevenue) * chartH;
            const ordH = (b.orderCount / maxCount) * chartH;
            const revX = cx - barW - gap / 2;
            const ordX = cx + gap / 2;
            const revY = padTop + chartH - revH;
            const ordY = padTop + chartH - ordH;
            const isHover = hoverIdx === i;
            return (
              <g key={i}
                 onMouseEnter={() => setHoverIdx(i)}
                 onMouseLeave={() => setHoverIdx(null)}>
                {/* Hover background */}
                {isHover && (
                  <rect x={padLeft + groupW * i} y={padTop} width={groupW} height={chartH} fill="#000" fillOpacity="0.03" />
                )}
                {/* Revenue bar */}
                <rect x={revX} y={revY} width={barW} height={revH}
                      fill="url(#revenueGrad)"
                      rx="3" filter="url(#barShadow)"
                      opacity={isHover || hoverIdx === null ? 1 : 0.55} />
                {/* Orders bar */}
                <rect x={ordX} y={ordY} width={barW} height={ordH}
                      fill="url(#ordersGrad)"
                      rx="3" filter="url(#barShadow)"
                      opacity={isHover || hoverIdx === null ? 1 : 0.55} />
                {/* X label */}
                <text x={cx} y={padTop + chartH + 18} textAnchor="middle" fontSize="11" fill="#374151"
                      fontWeight={isHover ? '700' : '500'}>
                  {b.label}
                </text>
              </g>
            );
          })}

          {/* Cancelled area */}
          {areaPath && <path d={areaPath} fill="url(#cancelGrad)" stroke="none" />}
          {linePath && <path d={linePath} fill="none" stroke="#ef4444" strokeWidth="2.5" />}
          {cancelPoints.map((p, i) => (
            <circle key={`pt-${i}`} cx={p.x} cy={p.y} r={hoverIdx === i ? 6 : 4}
                    fill="#fff" stroke="#ef4444" strokeWidth="2.5" />
          ))}

          {/* Hover tooltip */}
          {hoverIdx !== null && buckets[hoverIdx] && (() => {
            const b = buckets[hoverIdx];
            const tipX = Math.min(padLeft + chartW - 200, Math.max(padLeft, padLeft + groupW * (hoverIdx + 0.5) - 100));
            const tipY = padTop + 8;
            return (
              <g style={{ pointerEvents: 'none' }}>
                <rect x={tipX} y={tipY} width="200" height="90" rx="6" fill="#111827" fillOpacity="0.95" />
                <text x={tipX + 10} y={tipY + 18} fontSize="11" fontWeight="600" fill="#fff">{b.fullLabel}</text>
                <text x={tipX + 10} y={tipY + 38} fontSize="10" fill="#60a5fa">● Doanh thu: <tspan fontWeight="700" fill="#fff">{VND(b.revenue)}</tspan></text>
                <text x={tipX + 10} y={tipY + 56} fontSize="10" fill="#c084fc">● Số đơn: <tspan fontWeight="700" fill="#fff">{b.orderCount}</tspan></text>
                <text x={tipX + 10} y={tipY + 74} fontSize="10" fill="#fca5a5">● Đơn huỷ: <tspan fontWeight="700" fill="#fff">{b.cancelledCount}</tspan></text>
              </g>
            );
          })()}
        </svg>
      </div>

    </div>
  );
};

const LegendDot: React.FC<{ color: string; label: string; isArea?: boolean }> = ({ color, label, isArea }) => (
  <div className="flex items-center gap-2">
    {isArea ? (
      <div className="w-4 h-3 rounded" style={{ background: `linear-gradient(180deg, ${color}88, ${color}22)`, border: `1.5px solid ${color}` }} />
    ) : (
      <div className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
    )}
    <span className="text-gray-700">{label}</span>
  </div>
);

export default RevenueChart;
