"use client";
import React, { useState } from 'react';
import { LayoutDashboard, Package, TrendingUp, ShoppingCart, Users, Bell } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const AdminSidebar: React.FC = () => {
  const pathname = usePathname();

  const menuItems = [
    { label: 'Dashboard', icon: LayoutDashboard, href: '/admin' },
    { label: 'Products', icon: Package, href: '/admin/products' },
    { label: 'Revenue', icon: TrendingUp, href: '/admin/revenue' },
    { label: 'Orders', icon: ShoppingCart, href: '/admin/orders' },
    { label: 'Notifications', icon: Bell, href: '/admin/notifications' },
    { label: 'Customers', icon: Users, href: '/admin/customers' },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen flex flex-col fixed left-0 top-0 z-30 overflow-y-auto">
      {/* Logo / Admin Title */}
      <div className="px-6 py-8 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-black">Admin Panel</h1>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-black text-white'
                  : 'text-black hover:bg-gray-100'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      {/* <div className="px-6 py-4 border-t border-gray-200">
        <button className="w-full px-4 py-2 bg-gray-100 text-black rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium">
          Logout
        </button>
      </div> */}
    </div>
  );
};

export default AdminSidebar;
