"use client";
import React, { useEffect, useState } from 'react';
import { Send, Users, Megaphone, RefreshCw, Check } from 'lucide-react';
import { fetchAllUsers, sendPromotionToUsers, AdminUser } from '@/lib/admin';
import { useToast } from '@/context/ToastContext';
import PromoCodeManagement from '@/components/admin/PromoCodeManagement';

const PRESET_TEMPLATES = [
  { title: 'Flash Sale 50%!', message: 'Giảm 50% toàn bộ giày thể thao trong 24 giờ. Mua ngay kẻo hết!' },
  { title: 'Miễn phí vận chuyển', message: 'Tuần này CNLTHD miễn phí vận chuyển cho mọi đơn hàng. Đừng bỏ lỡ!' },
  { title: 'Mã giảm giá WELCOME10', message: 'Nhập mã WELCOME10 khi thanh toán để được giảm 10% cho đơn đầu tiên.' },
  { title: 'Bộ sưu tập mới', message: 'CNLTHD vừa ra mắt bộ sưu tập Thu Đông 2026. Khám phá ngay!' },
];

const NotificationManagement: React.FC = () => {
  const { showToast } = useToast();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [sending, setSending] = useState(false);

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [sendToAll, setSendToAll] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const loadUsers = async () => {
    setLoadingUsers(true);
    try {
      const list = await fetchAllUsers();
      setUsers(list);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Lỗi tải khách hàng', 'error');
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => { loadUsers(); }, []);

  const handleApplyTemplate = (t: { title: string; message: string }) => {
    setTitle(t.title);
    setMessage(t.message);
  };

  const handleToggleUser = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSend = async () => {
    if (!title.trim() || !message.trim()) {
      showToast('Vui lòng nhập tiêu đề và nội dung', 'error');
      return;
    }
    const recipients = sendToAll
      ? users.map((u) => u.id)
      : Array.from(selectedIds);
    if (recipients.length === 0) {
      showToast('Chưa chọn người nhận', 'error');
      return;
    }
    setSending(true);
    try {
      const result = await sendPromotionToUsers({
        title: title.trim(),
        message: message.trim(),
        recipientUserIds: recipients,
      });
      showToast(
        `Đã gửi tới ${result.success}/${recipients.length} khách hàng${result.failed > 0 ? ` (${result.failed} thất bại)` : ''}`,
        result.failed === 0 ? 'success' : 'info'
      );
      if (result.success > 0) {
        setTitle('');
        setMessage('');
        setSelectedIds(new Set());
      }
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Gửi thất bại', 'error');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-xl font-bold text-black flex items-center gap-2">
          <Megaphone className="w-6 h-6" />
          Gửi thông báo / Ưu đãi
        </h3>
        <p className="text-sm text-gray-500 mt-1">
          Tạo thông báo gửi tới chuông của khách hàng. Hỗ trợ broadcast tất cả hoặc chọn từng người.
        </p>
      </div>

      {/* Promo Code Management */}
      <PromoCodeManagement />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="lg:col-span-2 space-y-5">
          <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
            <h4 className="font-semibold text-black">Nội dung thông báo</h4>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tiêu đề</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ví dụ: Flash Sale 50%!"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg outline-none focus:border-black"
                maxLength={180}
              />
              <p className="text-xs text-gray-400 mt-1">{title.length}/180</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nội dung</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Mô tả chi tiết ưu đãi..."
                rows={4}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg outline-none focus:border-black resize-y"
              />
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">Mẫu nhanh</p>
              <div className="flex flex-wrap gap-2">
                {PRESET_TEMPLATES.map((t, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleApplyTemplate(t)}
                    className="text-xs px-3 py-1.5 border border-gray-300 rounded-full hover:bg-gray-100"
                  >
                    {t.title}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
            <h4 className="font-semibold text-black flex items-center gap-2">
              <Users className="w-5 h-5" />
              Đối tượng nhận
            </h4>

            <div className="flex flex-col gap-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  checked={sendToAll}
                  onChange={() => setSendToAll(true)}
                  className="accent-black"
                />
                <span className="text-sm">
                  <strong>Tất cả khách hàng</strong> ({users.length} người)
                </span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="radio"
                  checked={!sendToAll}
                  onChange={() => setSendToAll(false)}
                  className="accent-black"
                />
                <span className="text-sm">
                  <strong>Chọn cụ thể</strong> ({selectedIds.size} đã chọn)
                </span>
              </label>
            </div>

            {!sendToAll && (
              <div className="border border-gray-200 rounded-lg max-h-72 overflow-auto">
                {loadingUsers ? (
                  <div className="p-4 text-sm text-gray-500">Đang tải...</div>
                ) : users.length === 0 ? (
                  <div className="p-4 text-sm text-gray-500">Không có khách hàng nào.</div>
                ) : (
                  users.map((u) => (
                    <label
                      key={u.id}
                      className="flex items-center gap-3 px-4 py-2.5 border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedIds.has(u.id)}
                        onChange={() => handleToggleUser(u.id)}
                        className="w-4 h-4 accent-black"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-black truncate">{u.fullname || u.email}</p>
                        <p className="text-xs text-gray-500 truncate">{u.email}</p>
                      </div>
                      {u.role && (
                        <span className="text-[10px] uppercase px-2 py-0.5 bg-gray-100 rounded-full">{u.role}</span>
                      )}
                    </label>
                  ))
                )}
              </div>
            )}
          </div>

          <button
            onClick={handleSend}
            disabled={sending || !title.trim() || !message.trim()}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-black text-white rounded-full font-semibold hover:bg-gray-800 transition-colors disabled:opacity-50"
          >
            {sending ? (
              <><RefreshCw className="w-5 h-5 animate-spin" /> Đang gửi...</>
            ) : (
              <><Send className="w-5 h-5" /> Gửi thông báo</>
            )}
          </button>
        </div>

        {/* Preview */}
        <div className="space-y-4">
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h4 className="font-semibold text-black mb-3">Xem trước</h4>
            <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 mt-2 rounded-full bg-black flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-black">
                    {title || 'Tiêu đề thông báo'}
                  </p>
                  <p className="text-xs text-gray-600 mt-1 whitespace-pre-wrap">
                    {message || 'Nội dung sẽ hiển thị ở đây...'}
                  </p>
                  <p className="text-[10px] text-gray-400 mt-2">vừa xong</p>
                </div>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-2 text-xs text-gray-500">
              <Check className="w-3.5 h-3.5 text-green-600" />
              Hiện trong chuông 🔔 của khách
            </div>
            <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
              <Check className="w-3.5 h-3.5 text-green-600" />
              Lưu vào DB notification_service
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationManagement;
