"use client";
import React, { useEffect, useState } from 'react';
import { ChevronDown, RefreshCw, Eye } from 'lucide-react';
import Link from 'next/link';
import { fetchAllOrders, updateOrderStatus } from '@/lib/admin';
import { Order, getOrderStatusDisplay, getOrderStatusColor } from '@/lib/orders';
import { useToast } from '@/context/ToastContext';

const STATUS_OPTIONS = ['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'RETURNED'];

const OrderManagement: React.FC = () => {
  const { showToast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [updating, setUpdating] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const loadOrders = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await fetchAllOrders();
      // newest first
      data.sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime());
      setOrders(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Lỗi tải đơn hàng');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
    // Poll every 20s so newly placed customer orders appear without manual refresh
    const interval = setInterval(loadOrders, 20_000);
    return () => clearInterval(interval);
  }, []);

  const handleStatusChange = async (order: Order, newStatus: string) => {
    if (order.status === newStatus) {
      setOpenDropdown(null);
      return;
    }
    setUpdating(order.id);
    try {
      const updated = await updateOrderStatus(order.id, newStatus);
      setOrders((prev) => prev.map((o) => (o.id === order.id ? updated : o)));
      showToast(`Đã cập nhật đơn ${order.orderNumber || order.id} → ${getOrderStatusDisplay(newStatus)}`, 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Cập nhật thất bại', 'error');
    } finally {
      setUpdating(null);
      setOpenDropdown(null);
    }
  };

  const filtered = statusFilter === 'ALL'
    ? orders
    : orders.filter((o) => o.status === statusFilter);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-xl font-bold text-black">Quản lý đơn hàng</h3>
          <p className="text-sm text-gray-500 mt-1">{filtered.length} / {orders.length} đơn hàng</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
          >
            <option value="ALL">Tất cả</option>
            {STATUS_OPTIONS.map((s) => (
              <option key={s} value={s}>{getOrderStatusDisplay(s)}</option>
            ))}
          </select>
          <button
            onClick={loadOrders}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Tải lại
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-300 rounded-lg text-red-700 text-sm">{error}</div>
      )}

      {loading ? (
        <div className="p-12 text-center text-gray-500">Đang tải đơn hàng...</div>
      ) : filtered.length === 0 ? (
        <div className="p-12 text-center text-gray-500 bg-white rounded-lg border border-gray-200">
          Không có đơn hàng nào.
        </div>
      ) : (
      <div className="bg-white rounded-lg border border-gray-200 overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead>
            <tr className="border-b border-gray-200 bg-gray-50">
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Mã đơn</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Khách hàng</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Ngày đặt</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Tổng tiền</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">SP</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Trạng thái</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-black">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((order) => (
              <tr key={order.id} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 text-sm font-semibold text-black">
                  #{order.orderNumber || order.id.substring(0, 8)}
                </td>
                <td className="px-6 py-4 text-sm text-gray-700">
                  <div className="font-medium">{order.recipientName || 'N/A'}</div>
                  <div className="text-xs text-gray-500">{order.phone || ''}</div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-700">
                  {order.createdAt ? new Date(order.createdAt).toLocaleString('vi-VN', { dateStyle: 'short', timeStyle: 'short' }) : '-'}
                </td>
                <td className="px-6 py-4 text-sm font-semibold text-black">
                  ₫{order.totalAmount.toLocaleString('vi-VN')}
                </td>
                <td className="px-6 py-4 text-sm text-gray-700">{order.items?.length || 0}</td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getOrderStatusColor(order.status)}`}>
                    {getOrderStatusDisplay(order.status)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <Link href={`/orders/${order.id}`} className="p-2 hover:bg-gray-200 rounded transition-colors" title="Xem chi tiết">
                      <Eye className="w-5 h-5 text-gray-700" />
                    </Link>
                    <div className="relative">
                      <button
                        onClick={() => setOpenDropdown(openDropdown === order.id ? null : order.id)}
                        disabled={updating === order.id}
                        className="px-3 py-2 hover:bg-gray-200 rounded transition-colors flex items-center gap-1 text-xs font-medium disabled:opacity-50"
                      >
                        {updating === order.id ? 'Đang đổi...' : 'Đổi trạng thái'}
                        <ChevronDown className="w-4 h-4 text-gray-700" />
                      </button>
                      {openDropdown === order.id && (
                        <div className="absolute right-0 mt-2 w-44 bg-white border border-gray-200 rounded-lg shadow-xl z-10">
                          {STATUS_OPTIONS.map((status) => (
                            <button
                              key={status}
                              onClick={() => handleStatusChange(order, status)}
                              className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 transition-colors ${
                                order.status === status ? 'bg-gray-100 font-semibold' : ''
                              }`}
                            >
                              {getOrderStatusDisplay(status)}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      )}
    </div>
  );
};

export default OrderManagement;
