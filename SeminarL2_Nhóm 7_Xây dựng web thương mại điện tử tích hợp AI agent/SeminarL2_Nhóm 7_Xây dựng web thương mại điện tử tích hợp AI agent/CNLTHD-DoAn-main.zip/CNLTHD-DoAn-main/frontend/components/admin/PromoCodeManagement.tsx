"use client";
import React, { useEffect, useState } from 'react';
import { TicketPercent, Plus, RefreshCw, Trash2, Power, PowerOff, X } from 'lucide-react';
import {
  listPromoCodes, createPromoCode, togglePromoCode, deletePromoCode,
  PromoCode, PromoCodePayload,
} from '@/lib/promoCodes';
import { useToast } from '@/context/ToastContext';

const VND = (n: number) => '₫' + (n || 0).toLocaleString('vi-VN');

const initialForm: PromoCodePayload = {
  code: '',
  description: '',
  percentOff: 0,
  amountOff: 0,
  maxDiscount: 0,
  minSubtotal: 0,
  freeShipping: false,
  maxUses: 0,
  active: true,
};

const PromoCodeManagement: React.FC = () => {
  const { showToast } = useToast();
  const [codes, setCodes] = useState<PromoCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<PromoCodePayload>(initialForm);
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await listPromoCodes(false);
      setCodes(data);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Lỗi tải mã giảm giá', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async () => {
    if (!form.code?.trim()) {
      showToast('Vui lòng nhập mã', 'error');
      return;
    }
    if ((form.percentOff || 0) === 0 && (form.amountOff || 0) === 0 && !form.freeShipping) {
      showToast('Mã phải có ít nhất 1 ưu đãi (% / ₫ / free ship)', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const created = await createPromoCode({
        ...form,
        code: form.code.trim().toUpperCase(),
      });
      setCodes((prev) => [created, ...prev]);
      setForm(initialForm);
      setShowForm(false);
      showToast(`Đã tạo mã ${created.code}`, 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Tạo mã thất bại', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggle = async (id: string) => {
    try {
      const updated = await togglePromoCode(id);
      setCodes((prev) => prev.map((c) => (c.id === id ? updated : c)));
      showToast(`Đã ${updated.active ? 'bật' : 'tắt'} mã ${updated.code}`, 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Thao tác thất bại', 'error');
    }
  };

  const handleDelete = async (id: string, code: string) => {
    if (!confirm(`Xoá mã "${code}"?`)) return;
    try {
      await deletePromoCode(id);
      setCodes((prev) => prev.filter((c) => c.id !== id));
      showToast('Đã xoá mã', 'success');
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Xoá thất bại', 'error');
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h4 className="text-lg font-bold text-black flex items-center gap-2">
          <TicketPercent className="w-5 h-5" />
          Mã giảm giá ({codes.length})
        </h4>
        <div className="flex items-center gap-2">
          <button
            onClick={load}
            disabled={loading}
            className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
            title="Tải lại"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setShowForm((v) => !v)}
            className="flex items-center gap-2 px-3 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800"
          >
            {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            {showForm ? 'Đóng' : 'Tạo mã mới'}
          </button>
        </div>
      </div>

      {showForm && (
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 space-y-3 bg-gray-50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Mã *</label>
              <input
                type="text"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                placeholder="WELCOME10"
                maxLength={50}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm uppercase font-mono outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Mô tả</label>
              <input
                type="text"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Giảm 10% cho đơn đầu tiên"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Giảm % (0-100)</label>
              <input
                type="number"
                min={0} max={100}
                value={form.percentOff || ''}
                onChange={(e) => setForm({ ...form, percentOff: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Giảm thẳng (₫)</label>
              <input
                type="number"
                min={0}
                value={form.amountOff || ''}
                onChange={(e) => setForm({ ...form, amountOff: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Cap giảm tối đa (₫)</label>
              <input
                type="number"
                min={0}
                value={form.maxDiscount || ''}
                onChange={(e) => setForm({ ...form, maxDiscount: Number(e.target.value) })}
                placeholder="0 = không cap"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Đơn tối thiểu (₫)</label>
              <input
                type="number"
                min={0}
                value={form.minSubtotal || ''}
                onChange={(e) => setForm({ ...form, minSubtotal: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-gray-600 mb-1">Số lần dùng tối đa</label>
              <input
                type="number"
                min={0}
                value={form.maxUses || ''}
                onChange={(e) => setForm({ ...form, maxUses: Number(e.target.value) })}
                placeholder="0 = không giới hạn"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-600 mb-1">Hết hạn (yyyy-mm-dd)</label>
              <input
                type="date"
                value={form.expiresAt ? form.expiresAt.substring(0, 10) : ''}
                onChange={(e) => setForm({ ...form, expiresAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-black"
              />
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg cursor-pointer w-full">
                <input
                  type="checkbox"
                  checked={!!form.freeShipping}
                  onChange={(e) => setForm({ ...form, freeShipping: e.target.checked })}
                  className="accent-black"
                />
                <span className="text-sm">Free shipping</span>
              </label>
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full px-4 py-2.5 bg-black text-white rounded-lg font-semibold hover:bg-gray-800 disabled:opacity-50"
          >
            {submitting ? 'Đang tạo...' : 'Tạo mã'}
          </button>
        </div>
      )}

      {/* Code list */}
      {loading ? (
        <p className="text-center text-gray-500 py-6">Đang tải...</p>
      ) : codes.length === 0 ? (
        <p className="text-center text-gray-500 py-6">Chưa có mã giảm giá nào.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-left">
                <th className="py-2 px-2 text-xs uppercase text-gray-600">Mã</th>
                <th className="py-2 px-2 text-xs uppercase text-gray-600">Ưu đãi</th>
                <th className="py-2 px-2 text-xs uppercase text-gray-600 text-right">Dùng</th>
                <th className="py-2 px-2 text-xs uppercase text-gray-600">Hết hạn</th>
                <th className="py-2 px-2 text-xs uppercase text-gray-600">Trạng thái</th>
                <th className="py-2 px-2 text-xs uppercase text-gray-600 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {codes.map((c) => (
                <tr key={c.id} className={`border-b border-gray-100 ${!c.active ? 'opacity-50' : ''}`}>
                  <td className="py-3 px-2">
                    <p className="font-mono font-bold text-black">{c.code}</p>
                    {c.description && <p className="text-xs text-gray-500 mt-0.5">{c.description}</p>}
                  </td>
                  <td className="py-3 px-2 text-xs">
                    {Number(c.percentOff) > 0 && <span className="inline-block px-1.5 py-0.5 bg-blue-100 text-blue-700 rounded mr-1">{Number(c.percentOff)}%</span>}
                    {Number(c.amountOff) > 0 && <span className="inline-block px-1.5 py-0.5 bg-green-100 text-green-700 rounded mr-1">-{VND(Number(c.amountOff))}</span>}
                    {c.freeShipping && <span className="inline-block px-1.5 py-0.5 bg-purple-100 text-purple-700 rounded mr-1">Free ship</span>}
                    {Number(c.maxDiscount) > 0 && <span className="block text-[10px] text-gray-500 mt-1">Cap: {VND(Number(c.maxDiscount))}</span>}
                    {Number(c.minSubtotal) > 0 && <span className="block text-[10px] text-gray-500">Min: {VND(Number(c.minSubtotal))}</span>}
                  </td>
                  <td className="py-3 px-2 text-right font-semibold">
                    {c.usedCount}{c.maxUses > 0 && <span className="text-gray-400 font-normal"> / {c.maxUses}</span>}
                  </td>
                  <td className="py-3 px-2 text-xs text-gray-600">
                    {c.expiresAt ? new Date(c.expiresAt).toLocaleDateString('vi-VN') : '∞'}
                  </td>
                  <td className="py-3 px-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${c.active ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'}`}>
                      {c.active ? 'Đang hoạt động' : 'Đã tắt'}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    <button
                      onClick={() => handleToggle(c.id)}
                      className="p-1.5 hover:bg-gray-100 rounded mr-1"
                      title={c.active ? 'Tắt' : 'Bật'}
                    >
                      {c.active ? <PowerOff className="w-4 h-4 text-gray-600" /> : <Power className="w-4 h-4 text-green-600" />}
                    </button>
                    <button
                      onClick={() => handleDelete(c.id, c.code)}
                      className="p-1.5 hover:bg-red-50 rounded"
                      title="Xoá"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default PromoCodeManagement;
