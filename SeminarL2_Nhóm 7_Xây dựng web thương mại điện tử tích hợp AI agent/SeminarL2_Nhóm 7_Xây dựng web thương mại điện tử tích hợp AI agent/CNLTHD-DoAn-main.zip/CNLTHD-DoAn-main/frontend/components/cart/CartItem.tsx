"use client";
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { Heart, Trash2, AlertTriangle } from 'lucide-react';
import { CartItem } from '@/types/Cart';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { useToast } from '@/context/ToastContext';
import { fetchStock, maxOrderable, STOCK_SAFETY_BUFFER } from '@/lib/inventory';

interface CartItemComponentProps {
  item: CartItem;
  isSelected: boolean;
  onToggleSelect: () => void;
}

const CartItemComponent: React.FC<CartItemComponentProps> = ({ item, isSelected, onToggleSelect }) => {
  const { updateQuantity, removeItem } = useCart();
  const { isInWishlist, toggleItem } = useWishlist();
  const { showToast } = useToast();

  const [stock, setStock] = useState<number | null>(null);
  const inWishlist = isInWishlist(item.id);

  // Fetch stock for this SKU
  useEffect(() => {
    if (!item.skuCode) {
      setStock(null);
      return;
    }
    let cancelled = false;
    fetchStock(item.skuCode).then((q) => { if (!cancelled) setStock(q); });
    return () => { cancelled = true; };
  }, [item.skuCode]);

  const maxQty = stock !== null ? maxOrderable(stock) : Infinity;
  const overLimit = stock !== null && item.quantity > maxQty;
  const atLimit = stock !== null && item.quantity >= maxQty;

  const handleIncrease = () => {
    if (atLimit) {
      showToast(`Chỉ được đặt tối đa ${maxQty} sản phẩm (kho còn ${stock}, giữ ${STOCK_SAFETY_BUFFER} dự phòng)`, 'error');
      return;
    }
    updateQuantity(item.id, item.quantity + 1, item.size, item.color);
  };
  const handleDecrease = () => {
    if (item.quantity > 1) updateQuantity(item.id, item.quantity - 1, item.size, item.color);
  };
  const handleRemove = () => removeItem(item.id, item.size, item.color);

  const handleWishlist = () => {
    const wasIn = inWishlist;
    toggleItem({ id: item.id, name: item.name, price: item.price, image: item.image, category: item.category });
    showToast(wasIn ? 'Đã xóa khỏi danh sách yêu thích' : 'Đã thêm vào danh sách yêu thích', 'wishlist');
  };

  return (
    <div className={`py-6 border-b border-gray-200 transition-colors ${isSelected ? '' : 'opacity-60'}`}>
      <div className="flex gap-4">
        {/* Checkbox */}
        <div className="flex items-start pt-1">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={onToggleSelect}
            className="w-4 h-4 accent-black cursor-pointer mt-1"
          />
        </div>

        <Link href={`/products/${item.id}`} className="w-24 h-24 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden block hover:opacity-90 transition-opacity">
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover rounded-lg"
            onError={(e) => { (e.target as HTMLImageElement).src = 'https://via.placeholder.com/96'; }}
          />
        </Link>

        <div className="flex-1 min-w-0">
          <Link href={`/products/${item.id}`} className="text-base font-medium text-black hover:text-blue-600 transition-colors line-clamp-2">
            {item.name}
          </Link>
          <p className="text-sm text-gray-600 mt-0.5">{item.category}</p>
          <p className="text-sm text-gray-600">{item.color} / Size {item.size}</p>

          {/* Quantity controls */}
          <div className="flex items-center gap-4 mt-4 flex-wrap">
            <div className={`flex items-center gap-3 border rounded-lg px-3 py-2 ${overLimit ? 'border-red-400' : 'border-gray-300'}`}>
              {item.quantity === 1 ? (
                <button onClick={handleRemove} className="p-1 hover:bg-gray-100 rounded transition-colors">
                  <Trash2 className="h-4 w-4 text-gray-600" />
                </button>
              ) : (
                <button onClick={handleDecrease} className="p-1 hover:bg-gray-100 rounded transition-colors">
                  <span className="text-lg font-medium text-gray-600">−</span>
                </button>
              )}
              <span className={`text-sm font-medium min-w-[24px] text-center ${overLimit ? 'text-red-600' : 'text-black'}`}>
                {item.quantity}
              </span>
              <button
                onClick={handleIncrease}
                disabled={atLimit || overLimit}
                className="p-1 hover:bg-gray-100 rounded transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <span className="text-lg font-medium text-gray-600">+</span>
              </button>
            </div>

            {/* Wishlist button */}
            <button
              onClick={handleWishlist}
              title={inWishlist ? 'Xóa khỏi yêu thích' : 'Thêm vào yêu thích'}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Heart className={`h-5 w-5 ${inWishlist ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
            </button>

            {/* Delete button */}
            <button
              onClick={handleRemove}
              title="Xóa sản phẩm khỏi giỏ"
              className="p-2 hover:bg-red-50 rounded-full transition-colors"
            >
              <Trash2 className="h-5 w-5 text-gray-600 hover:text-red-500" />
            </button>
          </div>

          {/* Stock warning — always shown */}
          <div className="mt-2 text-xs">
            {!item.skuCode ? (
              <p className="text-orange-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Sản phẩm cũ — thiếu SKU, không kiểm tra được tồn kho
              </p>
            ) : stock === null ? (
              <p className="text-gray-400">Đang kiểm tra tồn kho...</p>
            ) : overLimit ? (
              <p className="text-red-600 flex items-center gap-1 font-medium">
                <AlertTriangle className="w-3.5 h-3.5" />
                Vượt giới hạn — chỉ được đặt tối đa {maxQty} (kho còn {stock})
              </p>
            ) : atLimit ? (
              <p className="text-orange-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Đã đạt giới hạn tối đa ({maxQty})
              </p>
            ) : stock === 0 ? (
              <p className="text-red-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Hết hàng
              </p>
            ) : (
              <p className="text-gray-500 font-medium">
                Còn <span className="text-black">{stock}</span> trong kho · Tối đa đặt: <span className="text-black">{maxQty}</span>
              </p>
            )}
          </div>
        </div>

        <div className="text-right flex-shrink-0">
          <p className="text-base font-medium text-black">₫{(item.price * item.quantity).toLocaleString('vi-VN')}</p>
          <p className="text-xs text-gray-500 mt-1">₫{item.price.toLocaleString('vi-VN')} each</p>
        </div>
      </div>
    </div>
  );
};

export default CartItemComponent;
