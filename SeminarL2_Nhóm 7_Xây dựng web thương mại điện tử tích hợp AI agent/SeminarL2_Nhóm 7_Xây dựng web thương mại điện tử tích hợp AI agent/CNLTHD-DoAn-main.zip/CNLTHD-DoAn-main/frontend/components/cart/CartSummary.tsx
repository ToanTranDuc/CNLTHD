"use client";
import React from 'react';
import Link from 'next/link';
import { CartItem } from '@/types/Cart';

interface CartSummaryProps {
  selectedItems: CartItem[];
  onCheckout: () => void;
}

const CartSummary: React.FC<CartSummaryProps> = ({ selectedItems, onCheckout }) => {
  const subtotal = selectedItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const deliveryThreshold = 5_000_000;
  const isDeliveryFree = subtotal > deliveryThreshold;
  const deliveryCost = isDeliveryFree ? 0 : 100_000;
  const total = subtotal + deliveryCost;
  const canCheckout = selectedItems.length > 0;

  return (
    <div className="bg-white">
      <h2 className="text-2xl font-bold text-black mb-6">Summary</h2>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600 flex items-center gap-2">
            Subtotal
            {selectedItems.length > 0 && (
              <span className="text-xs text-gray-400">({selectedItems.length} sản phẩm)</span>
            )}
          </p>
          <p className="text-sm text-black font-medium">₫{subtotal.toLocaleString('vi-VN')}</p>
        </div>

        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">Estimated Delivery & Handling</p>
          <p className="text-sm text-black font-medium">
            {isDeliveryFree ? 'Free' : `₫${deliveryCost.toLocaleString('vi-VN')}`}
          </p>
        </div>

        {!isDeliveryFree && subtotal > 0 && (
          <p className="text-xs text-gray-500">
            Miễn phí giao hàng cho đơn trên ₫{deliveryThreshold.toLocaleString('vi-VN')}
          </p>
        )}

        <div className="border-t border-gray-200 pt-4" />

        <div className="flex items-center justify-between">
          <p className="text-base font-semibold text-black">Total</p>
          <p className="text-lg font-bold text-black">₫{total.toLocaleString('vi-VN')}</p>
        </div>
      </div>

      <button
        onClick={onCheckout}
        disabled={!canCheckout}
        className={`block w-full text-base font-semibold py-4 rounded-full mt-6 transition-colors text-center ${
          canCheckout
            ? 'bg-black text-white hover:bg-gray-800'
            : 'bg-gray-200 text-gray-400 cursor-not-allowed'
        }`}
      >
        {canCheckout
          ? `Member Checkout (${selectedItems.length})`
          : 'Chọn sản phẩm để thanh toán'}
      </button>

      <p className="text-xs text-gray-500 text-center mt-4">
        or{' '}
        <Link href="/products" className="text-black hover:underline">
          Continue Shopping
        </Link>
      </p>
    </div>
  );
};

export default CartSummary;
