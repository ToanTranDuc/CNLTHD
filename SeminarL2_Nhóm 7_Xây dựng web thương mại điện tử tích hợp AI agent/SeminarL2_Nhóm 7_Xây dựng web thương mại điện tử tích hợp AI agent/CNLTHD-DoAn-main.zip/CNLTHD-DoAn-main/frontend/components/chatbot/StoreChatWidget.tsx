"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";

const StoreChatWidget: React.FC = () => {
  const pathname = usePathname();
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatSessionId, setChatSessionId] = useState<string | null>(null);
  const previousPathnameRef = useRef(pathname);

  const shouldHide = pathname.startsWith("/admin");

  const getSessionStorageKey = (currentPathname: string) => `chatbot-session:${currentPathname}`;

  const createSessionId = () => {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }

    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  };

  const ensureChatSession = () => {
    if (typeof window === "undefined") {
      return null;
    }

    const storageKey = getSessionStorageKey(pathname);
    const existingSessionId = localStorage.getItem(storageKey);

    if (existingSessionId) {
      setChatSessionId(existingSessionId);
      return existingSessionId;
    }

    const nextSessionId = createSessionId();
    localStorage.setItem(storageKey, nextSessionId);
    setChatSessionId(nextSessionId);
    return nextSessionId;
  };

  const clearChatSession = () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem(getSessionStorageKey(pathname));
    }

    setChatSessionId(null);
  };

  useEffect(() => {
    const previousPathname = previousPathnameRef.current;

    if (previousPathname !== pathname && typeof window !== "undefined") {
      localStorage.removeItem(getSessionStorageKey(previousPathname));
      setIsChatOpen(false);
      setChatSessionId(null);
    }

    previousPathnameRef.current = pathname;
  }, [pathname]);

  const chatbotUrl = useMemo(() => {
    const baseUrl =
      process.env.NEXT_PUBLIC_CHATBOT_URL ||
      "/chatbot-service/chatbot_interface.html";

    if (typeof window === "undefined") {
      return baseUrl;
    }

    const role = localStorage.getItem("userRole") || "guest";
    const userId = localStorage.getItem("userId") || "anonymous";
    const userName = localStorage.getItem("userName") || "Khach";
    const isLoggedIn = Boolean(localStorage.getItem("accessToken"));

    const params = new URLSearchParams({
      role,
      userId,
      userName,
      isLoggedIn: String(isLoggedIn),
    });

    if (chatSessionId) {
      params.set("sessionId", chatSessionId);
    }

    return `${baseUrl}?${params.toString()}`;
  }, [chatSessionId]);

  if (shouldHide) {
    return null;
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {isChatOpen && (
        <div className="w-[420px] max-w-[calc(100vw-2rem)] h-[640px] bg-white border border-gray-300 rounded-xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between bg-black text-white px-4 py-3">
            <h3 className="text-sm font-semibold">AI Ho Tro Khach Hang</h3>
            <button
              onClick={() => setIsChatOpen(false)}
              className="text-white/90 hover:text-white text-lg leading-none"
              aria-label="Close chatbot"
            >
              x
            </button>
          </div>
          <iframe
            src={chatbotUrl}
            title="Store Chatbot"
            className="w-full h-[calc(100%-48px)] border-0"
          />
        </div>
      )}

      <button
        onClick={() => {
          if (!isChatOpen) {
            ensureChatSession();
          }

          setIsChatOpen((prev) => !prev);
        }}
        className="bg-black text-white px-5 py-3 rounded-full shadow-lg hover:bg-gray-800 transition-colors font-medium"
      >
        {isChatOpen ? "Hide AI Chat" : "AI Chat"}
      </button>
    </div>
  );
};

export default StoreChatWidget;
