"use client";

import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Bell, CheckCheck, ChevronRight } from 'lucide-react';
import {
  fetchInboxNotifications,
  fetchNotificationStats,
  markAllNotificationsAsRead,
  markNotificationAsRead,
  type NotificationDto,
} from '@/lib/notifications';
import { fetchOrderByNumber } from '@/lib/orders';

function formatTime(value: string): string {
  try {
    return new Intl.DateTimeFormat('vi-VN', {
      dateStyle: 'short',
      timeStyle: 'short',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

const NotificationBell = () => {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationDto[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Re-check auth state on mount + on auth-changed event (same-tab logout/login)
  // Also clear immediately when logged out so previous user's notifications don't leak.
  useEffect(() => {
    if (typeof globalThis.window === 'undefined') return;
    const check = () => {
      const hasAuth = Boolean(localStorage.getItem('accessToken'));
      setIsLoggedIn(hasAuth);
      if (!hasAuth) {
        // Hard-clear state on logout
        setNotifications([]);
        setUnreadCount(0);
        setOpen(false);
      }
    };
    check();
    window.addEventListener('storage', check);
    window.addEventListener('auth-changed', check);
    return () => {
      window.removeEventListener('storage', check);
      window.removeEventListener('auth-changed', check);
    };
  }, []);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const onClickOutside = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const onEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onEscape);
    return () => {
      document.removeEventListener('mousedown', onClickOutside);
      document.removeEventListener('keydown', onEscape);
    };
  }, [open]);

  // Fetch notifications: on mount, when opened, and poll every 30s
  useEffect(() => {
    if (!isLoggedIn) {
      setNotifications([]);
      setUnreadCount(0);
      return;
    }

    const loadNotifications = async () => {
      setLoading(true);
      try {
        const [inbox, stats] = await Promise.all([
          fetchInboxNotifications(),
          fetchNotificationStats(),
        ]);
        setNotifications(inbox.items.slice(0, 5));
        setUnreadCount(stats.unreadCount);
      } catch (error) {
        console.error('Failed to load notifications:', error);
      } finally {
        setLoading(false);
      }
    };

    loadNotifications();
    // Faster polling so customer sees order/promo notifications within a few seconds
    const intervalId = setInterval(loadNotifications, 5_000);
    // Allow other components (e.g. checkout success) to trigger an instant refresh
    const refreshHandler = () => loadNotifications();
    window.addEventListener('notifications-refresh', refreshHandler);
    return () => {
      clearInterval(intervalId);
      window.removeEventListener('notifications-refresh', refreshHandler);
    };
  }, [open, isLoggedIn]);

  const router = useRouter();
  const pathname = usePathname();
  const isAdminPage = pathname?.startsWith('/admin');

  const extractOrderNumber = (text: string): string | null => {
    const match = text.match(/ORD-\d+-[A-Z0-9]+/i);
    return match ? match[0] : null;
  };

  const handleNotificationClick = async (notification: NotificationDto) => {
    // Mark as read (fire-and-forget)
    if (notification.status !== 'READ') {
      markNotificationAsRead(notification.id).catch((err) => console.warn('Mark read failed:', err));
      setNotifications((prev) => prev.map((n) => (n.id === notification.id ? { ...n, status: 'READ' } : n)));
      setUnreadCount((prev) => Math.max(0, prev - 1));
    }

    setOpen(false);

    // Navigate based on type/content
    if (notification.type === 'ORDER') {
      const orderNumber = extractOrderNumber(notification.message) || extractOrderNumber(notification.title);
      if (orderNumber) {
        try {
          const order = await fetchOrderByNumber(orderNumber);
          router.push(`/orders/${order.id}`);
          return;
        } catch {
          // Fallback to orders list
        }
      }
      router.push('/profile?tab=orders');
    } else if (notification.type === 'ACCOUNT') {
      router.push('/profile');
    } else if (notification.type === 'PROMOTION') {
      router.push('/products');
    }
  };

  const handleMarkAllRead = async () => {
    // Optimistic update — badge zeros out immediately
    setNotifications((prev) => prev.map((n) => ({ ...n, status: 'READ' })));
    setUnreadCount(0);
    try {
      await markAllNotificationsAsRead();
    } catch (err) {
      console.error('Mark all read failed:', err);
    }
  };

  return (
    <div className="relative" ref={wrapperRef}>
      <button
        onClick={() => setOpen((prev) => !prev)}
        className="p-2 hover:bg-gray-100 rounded-full transition-all duration-200 relative"
        aria-label="Notifications"
      >
        <Bell className="h-5 w-5 text-gray-600" />
        {isLoggedIn && !isAdminPage && unreadCount > 0 && (
          <span className="absolute top-1 right-1 bg-black text-white text-[10px] min-w-4 h-4 px-1 rounded-full flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-3 w-[22rem] max-w-[calc(100vw-1rem)] rounded-2xl border border-gray-200 bg-white shadow-2xl overflow-hidden z-50">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div>
              <p className="text-sm font-semibold text-black">Thông báo</p>
              <p className="text-[11px] text-gray-500">
                {isLoggedIn ? 'Nhận cập nhật đơn hàng, tài khoản và ưu đãi' : 'Đăng nhập để xem thông báo'}
              </p>
            </div>
            {isLoggedIn && unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-xs font-medium text-blue-600 hover:text-blue-700 inline-flex items-center gap-1"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                Đánh dấu tất cả
              </button>
            )}
          </div>

          <div className="max-h-[28rem] overflow-auto">
            {!isLoggedIn ? (
              <div className="p-4 text-sm text-gray-600">
                <p>Bạn cần đăng nhập để nhận và xem thông báo cá nhân.</p>
                <Link href="/login" className="mt-3 inline-flex items-center gap-1 text-black font-medium hover:underline">
                  Đến trang đăng nhập
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </div>
            ) : loading ? (
              <div className="p-4 text-sm text-gray-500">Đang tải thông báo...</div>
            ) : notifications.length === 0 ? (
              <div className="p-4 text-sm text-gray-600">Chưa có thông báo nào.</div>
            ) : (
              <ul className="divide-y divide-gray-100">
                {notifications.map((notification) => (
                  <li key={notification.id} className={`p-4 ${notification.status !== 'READ' ? 'bg-gray-50' : ''}`}>
                    <button
                      onClick={() => handleNotificationClick(notification)}
                      className="w-full text-left hover:bg-gray-100 transition-colors px-1 py-1 rounded -mx-1"
                    >
                      <div className="flex items-start gap-3">
                        <div className={`mt-1 h-2.5 w-2.5 rounded-full ${notification.status !== 'READ' ? 'bg-black' : 'bg-gray-300'}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-sm font-semibold text-black truncate">{notification.title}</p>
                            <span className="text-[10px] text-gray-400 whitespace-nowrap">{formatTime(notification.createdAt)}</span>
                          </div>
                          <p className="mt-1 text-sm text-gray-600 line-clamp-3">{notification.message}</p>
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="border-t border-gray-100 px-4 py-3 bg-gray-50">
            <Link href="/notifications" className="inline-flex items-center gap-1 text-sm font-medium text-black hover:underline">
              Xem tất cả thông báo
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationBell;
