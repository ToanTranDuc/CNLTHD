"use client";
import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { ShoppingBag, Search, User, Menu, X as XIcon, Heart } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import NotificationBell from '@/components/layout/NotificationBell';
import { Category } from '@/lib/products';

interface CategoryNode extends Category {
  children: CategoryNode[];
}

function buildTree(categories: Category[]): CategoryNode[] {
  const map = new Map<string, CategoryNode>();
  const roots: CategoryNode[] = [];

  for (const cat of categories) {
    map.set(cat.id, { ...cat, children: [] });
  }

  for (const node of map.values()) {
    if (node.parentId && map.has(node.parentId)) {
      map.get(node.parentId)!.children.push(node);
    } else if (!node.parentId) {
      roots.push(node);
    }
  }

  roots.sort((a, b) => a.name.localeCompare(b.name));
  roots.forEach(root => {
    root.children.sort((a, b) => a.name.localeCompare(b.name));
    root.children.forEach(child => {
      child.children.sort((a, b) => a.name.localeCompare(b.name));
    });
  });

  return roots;
}

function categoryLink(cat: CategoryNode) {
  return `/products?categoryId=${cat.id}&categoryName=${encodeURIComponent(cat.name)}`;
}

const Header = () => {
  const { getTotalQuantity } = useCart();
  const { count: wishlistCount } = useWishlist();
  const totalQuantity = getTotalQuantity();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [rootCategories, setRootCategories] = useState<CategoryNode[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const pathname = usePathname();
  const isAdminPage = pathname?.startsWith('/admin');

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    setIsLoggedIn(!!token);
  }, []);

  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => {
        const categories: Category[] = data.data || [];
        setRootCategories(buildTree(categories));
      })
      .catch(() => {});
  }, []);

  const handleOpenSearch = () => {
    setIsSearchOpen(true);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleProfileClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      router.push('/login');
    } else {
      router.push('/profile');
    }
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!isLoggedIn) {
      router.push('/login');
    } else {
      router.push('/wishlist');
    }
  };

  const handleCartClick = (e: React.MouseEvent) => {
    e.preventDefault();
    router.push('/cart');
  };

  const handleClearSearch = () => {
    setSearchValue("");
    inputRef.current?.focus();
  };

  const handleCancelSearch = () => {
    setIsSearchOpen(false);
    setSearchValue("");
  };

  const handleSearch = () => {
    const keyword = searchValue.trim();
    if (!keyword) return;
    setIsSearchOpen(false);
    setSearchValue("");
    router.push(`/products?search=${encodeURIComponent(keyword)}`);
  };

  return (
    <>
      {isSearchOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={handleCancelSearch}
        />
      )}

      <header className={`sticky top-0 z-50 w-full border-b bg-white transition-all duration-300 ${
        isSearchOpen ? 'shadow-lg' : ''
      }`}>
        <div className={`h-16 flex items-center justify-between transition-all duration-300 ${
          isSearchOpen ? 'px-6' : 'container mx-auto px-4'
        }`}>

          {isSearchOpen ? (
            <div className="w-full flex items-center gap-4">
              <img className="h-8 w-8 object-contain flex-shrink-0" src="/footprint.png" alt="Logo" />
              <div className="flex-1 flex items-center bg-gray-100 rounded-2xl px-5 py-2.5 gap-3 transition-all duration-300">
                <Search className="h-5 w-5 text-gray-400 flex-shrink-0" />
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Tìm kiếm sản phẩm..."
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="flex-1 bg-transparent outline-none text-gray-800 placeholder-gray-400 text-base"
                />
                {searchValue && (
                  <button onClick={handleClearSearch} className="flex-shrink-0">
                    <XIcon className="h-5 w-5 text-gray-400" />
                  </button>
                )}
                <button
                  onClick={handleSearch}
                  disabled={!searchValue.trim()}
                  className="flex-shrink-0 px-3 py-1 bg-black text-white text-sm rounded-xl disabled:opacity-30 transition-opacity"
                >
                  Tìm
                </button>
              </div>
              <NotificationBell />
              <button
                onClick={handleCancelSearch}
                className="text-sm font-medium text-gray-600 hover:text-black transition-colors duration-200 whitespace-nowrap"
              >
                Hủy
              </button>
            </div>
          ) : (
            <>
              {/* Logo */}
              <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                <Menu className="h-6 w-6 md:hidden cursor-pointer" />
                <span className="text-xl font-bold tracking-tighter uppercase flex items-center">
                  <img className="h-8 w-8 mr-2 mb-2 object-contain" src="/footprint.png" alt="Logo" />
                  <span className="text-black">RAP<span className="text-blue-600">TOR</span></span>
                </span>
              </Link>

              {/* Main nav */}
              <nav className="hidden md:flex items-center gap-8 text-base font-medium h-full">

                {/* Men */}
                <div className="group h-full flex items-center">
                  <Link href="/products?category=men" className="text-black transition-colors hover:text-blue-600 relative py-5">
                    Men
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-black scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                  </Link>
                  <div className="absolute top-full left-0 w-screen bg-white border-t border-gray-100 shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                    <div className="container mx-auto px-4 py-10 flex justify-center">
                      <div className="grid grid-cols-3 gap-12 w-full max-w-4xl">
                        <div>
                          <h3 className="font-bold mb-4 text-black">Shoes</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=men&search=running" className="hover:text-black">Running</Link></li>
                            <li><Link href="/products?category=men&search=basketball" className="hover:text-black">Basketball</Link></li>
                            <li><Link href="/products?category=men&search=casual" className="hover:text-black">Casual</Link></li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold mb-4 text-black">Clothing</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=men&search=tshirt" className="hover:text-black">T-Shirts</Link></li>
                            <li><Link href="/products?category=men&search=jacket" className="hover:text-black">Jackets</Link></li>
                            <li><Link href="/products?category=men&search=shorts" className="hover:text-black">Shorts</Link></li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold mb-4 text-black">Shop by Sport</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=men&search=football" className="hover:text-black">Football</Link></li>
                            <li><Link href="/products?category=men&search=training" className="hover:text-black">Training</Link></li>
                            <li><Link href="/products?category=men&search=tennis" className="hover:text-black">Tennis</Link></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Women */}
                <div className="group h-full flex items-center">
                  <Link href="/products?category=women" className="text-black transition-colors hover:text-blue-600 relative py-5">
                    Women
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-black scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                  </Link>
                  <div className="absolute top-full left-0 w-screen bg-white border-t border-gray-100 shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                    <div className="container mx-auto px-4 py-10 flex justify-center">
                      <div className="grid grid-cols-3 gap-12 w-full max-w-4xl">
                        <div>
                          <h3 className="font-bold mb-4 text-black">Shoes</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=women&search=running" className="hover:text-black">Running</Link></li>
                            <li><Link href="/products?category=women&search=lifestyle" className="hover:text-black">Lifestyle</Link></li>
                            <li><Link href="/products?category=women&search=casual" className="hover:text-black">Casual</Link></li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold mb-4 text-black">Clothing</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=women&search=dress" className="hover:text-black">Dresses</Link></li>
                            <li><Link href="/products?category=women&search=leggings" className="hover:text-black">Leggings</Link></li>
                            <li><Link href="/products?category=women&search=tops" className="hover:text-black">Tops</Link></li>
                          </ul>
                        </div>
                        <div>
                          <h3 className="font-bold mb-4 text-black">Shop by Sport</h3>
                          <ul className="space-y-2 text-sm text-gray-500 font-medium">
                            <li><Link href="/products?category=women&search=yoga" className="hover:text-black">Yoga</Link></li>
                            <li><Link href="/products?category=women&search=training" className="hover:text-black">Training</Link></li>
                            <li><Link href="/products?category=women&search=tennis" className="hover:text-black">Tennis</Link></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dynamic category nav items from API */}
                {rootCategories.map(root => (
                  <div key={root.id} className="group h-full flex items-center">
                    <Link
                      href={categoryLink(root)}
                      className="text-black transition-colors hover:text-blue-600 relative py-5"
                    >
                      {root.name}
                      <span className="absolute bottom-0 left-0 w-full h-0.5 bg-black scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                    </Link>

                    {root.children.length > 0 && (
                      <div className="absolute top-full left-0 w-screen bg-white border-t border-gray-100 shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                        <div className="container mx-auto px-4 py-10 flex justify-center">
                          <div
                            className="grid gap-12 w-full max-w-5xl"
                            style={{ gridTemplateColumns: `repeat(${Math.min(root.children.length, 5)}, minmax(0, 1fr))` }}
                          >
                            {root.children.map(child => (
                              <div key={child.id}>
                                <h3 className="font-bold mb-4 text-black">
                                  <Link href={categoryLink(child)} className="hover:text-blue-600 transition-colors">
                                    {child.name}
                                  </Link>
                                </h3>
                                {child.children.length > 0 && (
                                  <ul className="space-y-2 text-sm text-gray-500 font-medium">
                                    {child.children.map(grandchild => (
                                      <li key={grandchild.id}>
                                        <Link href={categoryLink(grandchild)} className="hover:text-black transition-colors">
                                          {grandchild.name}
                                        </Link>
                                      </li>
                                    ))}
                                  </ul>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}

                {/* Sale */}
                <div className="group h-full flex items-center">
                  <Link
                    href="/products?category=sale"
                    className="text-red-500 transition-colors hover:text-red-700 relative py-5 font-bold"
                  >
                    Sale
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                  </Link>
                </div>

              </nav>

              {/* Icon group */}
              <div className="flex items-center gap-4">
                <button
                  onClick={handleOpenSearch}
                  className="p-2 hover:bg-gray-100 rounded-full transition-all duration-200"
                >
                  <Search className="h-5 w-5 text-gray-600" />
                </button>

                <button
                  className="p-2 hover:bg-gray-100 rounded-full transition-all duration-200 relative"
                  onClick={handleWishlistClick}
                >
                  <Heart className="h-5 w-5 text-gray-600" />
                  {/* Badge chỉ hiện khi đã đăng nhập (đảm bảo logout không còn badge cũ) */}
                  {isLoggedIn && !isAdminPage && wishlistCount > 0 && (
                    <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                      {wishlistCount > 9 ? '9+' : wishlistCount}
                    </span>
                  )}
                </button>

                <button
                  className="p-2 hover:bg-gray-100 rounded-full transition-all duration-200"
                  onClick={handleProfileClick}
                >
                  <User className="h-5 w-5 text-gray-600" />
                </button>

                <NotificationBell />

                <button
                  className="p-2 hover:bg-gray-100 rounded-full transition-all duration-200 relative"
                  onClick={handleCartClick}
                >
                  <ShoppingBag className="h-5 w-5 text-gray-600" />
                  {isLoggedIn && !isAdminPage && totalQuantity > 0 && (
                    <span className="absolute top-1 right-1 bg-black text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                      {totalQuantity}
                    </span>
                  )}
                </button>
              </div>
            </>
          )}

        </div>
      </header>
    </>
  );
};

export default Header;
