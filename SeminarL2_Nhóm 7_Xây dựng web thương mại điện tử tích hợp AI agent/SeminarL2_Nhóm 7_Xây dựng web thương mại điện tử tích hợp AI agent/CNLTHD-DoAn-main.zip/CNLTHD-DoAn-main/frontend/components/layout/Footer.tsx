import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-100 pt-16 pb-8">
      <div className="container mx-auto px-6 max-w-7xl">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          
          {/* Cột 1: Tìm trợ giúp */}
          <div>
            <h4 className="font-bold text-sm uppercase mb-6 tracking-wider text-black">
              Tìm trợ giúp (Help)
            </h4>
            <ul className="space-y-4 text-gray-500 text-[13px] font-medium">
              <li><a href="#" className="hover:text-black transition-colors">Trạng thái đơn hàng</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Giao hàng & Vận chuyển</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Trả hàng</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Phương thức thanh toán</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Liên hệ chúng tôi</a></li>
            </ul>
          </div>

          {/* Cột 2: Sản phẩm */}
          <div>
            <h4 className="font-bold text-sm uppercase mb-6 tracking-wider text-black">
              Sản phẩm (Resources)
            </h4>
            <ul className="space-y-4 text-gray-500 text-[13px] font-medium">
              <li><a href="#" className="hover:text-black transition-colors">Men</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Women</a></li>
              <li><a href="#" className="hover:text-black transition-colors">New & Featured</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Ưu đãi (Sale)</a></li>
            </ul>
          </div>

          {/* Cột 3: Về RaptorWearing */}
          <div>
            <h4 className="font-bold text-sm uppercase mb-6 tracking-wider text-black">
              Về RaptorWearing (Company)
            </h4>
            <ul className="space-y-4 text-gray-500 text-[13px] font-medium">
              <li><a href="#" className="hover:text-black transition-colors">Câu chuyện thương hiệu</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Tin tức (News)</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Tuyển dụng (Careers)</a></li>
              <li><a href="#" className="hover:text-black transition-colors">Phát triển bền vững</a></li>
            </ul>
          </div>

          {/* Cột 4: Kết nối */}
          <div>
            <h4 className="font-bold text-sm uppercase mb-6 tracking-wider text-black">
              Kết nối (Social)
            </h4>
            <div className="flex gap-4 mb-8">
              {/* Icon Facebook */}
              <a href="#" className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors">
                <svg className="w-4 h-4 text-black" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                </svg>
              </a>
              {/* Icon Instagram */}
              <a href="#" className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors">
                <svg className="w-4 h-4 text-black" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Footer - Tối giản theo Nike */}
        <div className="border-t border-gray-100 pt-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-2 md:gap-6">
            <span className="text-[11px] text-gray-400 font-medium">
              © 2026 RaptorWearing, Inc. All rights reserved
            </span>
            <div className="flex gap-4">
              <a href="#" className="text-[11px] text-gray-400 hover:text-black transition-colors font-medium">Điều khoản bán hàng</a>
              <a href="#" className="text-[11px] text-gray-400 hover:text-black transition-colors font-medium">Điều khoản sử dụng</a>
              <a href="#" className="text-[11px] text-gray-400 hover:text-black transition-colors font-medium">Chính sách bảo mật</a>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-[11px] font-bold text-black group cursor-pointer">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 002 2h.272M22 12c0 5.523-4.477 10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10z" />
            </svg>
            <span>Vietnam</span>
          </div>
        </div>
        
        {/* Thông tin pháp lý doanh nghiệp - Tin cậy theo KFC */}
        <div className="mt-10 text-[10px] text-gray-400 leading-relaxed max-w-2xl">
          <p className="uppercase font-bold mb-1 tracking-wider text-gray-500">
            Công ty TNHH RaptorWearing Việt Nam
          </p>
          <p>Địa chỉ: Số 123 Đường Raptor, Quận 1, Thành phố Hồ Chí Minh</p>
          <p>Điện thoại: (028) 38XX XXXX - Email: contact@raptorwearing.com.vn</p>
          <p>Mã số thuế: 010XXXXXXX - Ngày cấp: 14/02/2026 - Nơi cấp: Sở Kế hoạch và Đầu tư TP. Hồ Chí Minh</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;