"use client";
import React, { useState, useEffect } from 'react';
import { Product } from '@/types/Product';
import ProductFilters from '@/components/product/ProductFilters';
import ProductGrid from '@/components/product/ProductGrid';

interface ProductsContentProps {
  mockProducts: Product[];
  category: string;
  categoryName?: string;
  searchQuery?: string;
}

const CATEGORY_DISPLAY: Record<string, string> = {
  featured: "New & Featured",
  men: "Men's Clothing",
  women: "Women's Clothing",
  sale: "Sale",
};

const ProductsContent: React.FC<ProductsContentProps> = ({ mockProducts, category, categoryName, searchQuery }) => {
  const currentCategory = searchQuery
    ? `Kết quả tìm kiếm cho "${searchQuery}"`
    : (categoryName || CATEGORY_DISPLAY[category] || "New & Featured");
  // const [sortBy, setSortBy] = useState<SortType>('Featured');
  const [products, setProducts] = useState<Product[]>(mockProducts);

  useEffect(() => {
    setProducts(mockProducts);
  }, [mockProducts]);

  const handleSortChange = (newSort: string) => {
    // setSortBy(newSort as SortType);
    let sorted = [...mockProducts];

    switch (newSort) {
      case 'Newest':
        sorted = sorted.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'Price: High-Low':
        sorted = sorted.sort((a, b) => b.price - a.price);
        break;
      case 'Price: Low-High':
        sorted = sorted.sort((a, b) => a.price - b.price);
        break;
      case 'Featured':
      default:
        sorted = mockProducts;
    }

    setProducts(sorted);
  };

  return (
    <>
      {/* Main Content */}
      <main className="container mx-auto px-4 md:px-8 py-6">
        {/* Filters and Sort */}
        <ProductFilters
          totalProducts={mockProducts.length}
          category={currentCategory}
          onSortChange={handleSortChange}
        />

        {/* Products Grid */}
        <ProductGrid products={products} />
      </main>
    </>
  );
};

export default ProductsContent;
