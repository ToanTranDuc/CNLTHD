"use client";
import React, { useState } from 'react';
import { Heart, AlertCircle, Minus, Plus } from 'lucide-react';
import { Product } from '@/types/Product';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { useToast } from '@/context/ToastContext';

interface ProductDetailProps {
  product: Product;
}

const COLOR_HEX_MAP: Record<string, string> = {
  black: '#1a1a1a', white: '#ffffff', red: '#ef4444', blue: '#3b82f6',
  green: '#22c55e', yellow: '#eab308', orange: '#f97316', purple: '#a855f7',
  pink: '#ec4899', gray: '#9ca3af', grey: '#9ca3af', brown: '#92400e',
  beige: '#d4c4a0', navy: '#1e3a5f', cream: '#fdf8ee', silver: '#c0c0c0',
  gold: '#d4af37', khaki: '#c3b091', olive: '#808000', cyan: '#06b6d4',
};

function resolveHex(color: { name: string; hex?: string }): string {
  if (color.hex) return color.hex;
  const lower = color.name.toLowerCase();
  for (const [key, hex] of Object.entries(COLOR_HEX_MAP)) {
    if (lower.includes(key)) return hex;
  }
  return '#d1d5db';
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product }) => {
  const { addItem } = useCart();
  const { isInWishlist, toggleItem } = useWishlist();
  const { showToast } = useToast();
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name);
  const [quantity, setQuantity] = useState(1);
  const [showSizeError, setShowSizeError] = useState(false);
  const [showMoreDetails, setShowMoreDetails] = useState(false);

  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = () => {
    if (!selectedSize) {
      setShowSizeError(true);
      setTimeout(() => setShowSizeError(false), 2000);
      return;
    }

    const color = selectedColor || product.colors[0]?.name || '';
    const matchingVariant = product.variants?.find(
      (v) => v.size === selectedSize && v.color.toUpperCase() === color.toUpperCase()
    ) ?? product.variants?.find((v) => v.size === selectedSize);

    // Check stock: variant explicitly out of stock OR size out of stock
    const sizeInfo = product.sizes.find((s) => s.size === selectedSize);
    if (matchingVariant && matchingVariant.inStock === false) {
      showToast(`Sản phẩm size ${selectedSize} - màu ${color} đã hết hàng`, 'error');
      return;
    }
    if (sizeInfo && !sizeInfo.inStock) {
      showToast(`Size ${selectedSize} đã hết hàng`, 'error');
      return;
    }

    addItem({
      id: product.id,
      name: product.name,
      category: product.category,
      color,
      size: selectedSize,
      price: matchingVariant?.price ?? product.price,
      quantity,
      image: product.image,
      skuCode: matchingVariant?.sku,
    });

    showToast(`Đã thêm ${quantity} sản phẩm vào giỏ hàng`, 'success');
  };

  const handleWishlist = () => {
    const wasIn = inWishlist;
    toggleItem({ id: product.id, name: product.name, price: product.price, image: product.image, category: product.category });
    showToast(
      wasIn ? 'Đã xóa khỏi danh sách yêu thích' : 'Đã thêm vào danh sách yêu thích',
      'wishlist'
    );
  };

  return (
    <div className="lg:sticky lg:top-20 lg:h-fit">
      {/* Product Title & Price */}
      <div className="mb-6">
        <h1 className="text-3xl md:text-4xl font-bold text-black mb-2">
          {product.name}
        </h1>
        <p className="text-lg text-gray-600 mb-4">{product.category}</p>
        <p className="text-2xl font-bold text-black">
          ₫{product.price.toLocaleString('vi-VN')}
        </p>
      </div>

      {/* Color Selection */}
      <div className="mb-8">
        <h3 className="text-sm font-bold text-black mb-1">Select Colour</h3>
        <p className="text-sm text-gray-500 mb-3">{selectedColor}</p>
        <div className="flex gap-3 flex-wrap">
          {product.colors.map((color) => {
            const hex = resolveHex(color);
            const isLight = hex === '#ffffff' || hex === '#fdf8ee' || hex === '#d4c4a0' || hex === '#fdf8ee';
            return (
              <button
                key={color.name}
                onClick={() => setSelectedColor(color.name)}
                title={color.name}
                className={`w-8 h-8 rounded-full border-2 transition-all ${
                  selectedColor === color.name
                    ? 'border-black scale-110 shadow-md'
                    : isLight
                    ? 'border-gray-300 hover:border-gray-500'
                    : 'border-transparent hover:border-gray-400'
                }`}
                style={{ backgroundColor: hex }}
              />
            );
          })}
        </div>
      </div>

      {/* Size Selection */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-black">Select Size</h3>
          <a href="#" className="text-xs text-black hover:underline flex items-center gap-1">
            📏 Size Guide
          </a>
        </div>

        {/* Show error if size not selected */}
        {showSizeError && (
          <div className="mb-3 p-3 bg-red-50 border border-red-300 rounded flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <span className="text-sm text-red-600">Please select a size</span>
          </div>
        )}

        <div className="grid grid-cols-3 gap-3">
          {product.sizes.map((sizeObj) => (
            <button
              key={sizeObj.size}
              onClick={() => sizeObj.inStock && setSelectedSize(sizeObj.size)}
              disabled={!sizeObj.inStock}
              className={`py-3 px-2 text-sm font-medium rounded border-2 transition-all ${
                selectedSize === sizeObj.size
                  ? 'border-black bg-black text-white'
                  : sizeObj.inStock
                  ? 'border-gray-300 text-black hover:border-black'
                  : 'border-gray-200 text-gray-400 bg-gray-50 cursor-not-allowed line-through'
              }`}
            >
              {sizeObj.size}
            </button>
          ))}
        </div>
      </div>

      {/* Quantity Selector */}
      <div className="mb-6">
        <h3 className="text-sm font-bold text-black mb-3">Số lượng</h3>
        <div className="inline-flex items-center border-2 border-gray-300 rounded-full overflow-hidden">
          <button
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="px-4 py-2 hover:bg-gray-100 transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>
          <span className="px-5 py-2 text-base font-semibold min-w-[3rem] text-center">{quantity}</span>
          <button
            onClick={() => setQuantity((q) => q + 1)}
            className="px-4 py-2 hover:bg-gray-100 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Add to Bag Button */}
      <button
        onClick={handleAddToCart}
        className="w-full bg-black text-white text-lg font-bold py-4 rounded-full hover:bg-gray-800 transition-colors mb-4"
      >
        Add to Bag
      </button>

      {/* Favourite Button */}
      <button
        onClick={handleWishlist}
        className={`w-full border-2 text-lg font-bold py-4 rounded-full transition-colors mb-6 flex items-center justify-center gap-2 ${
          inWishlist
            ? 'border-red-500 bg-red-50 text-red-600 hover:bg-red-100'
            : 'border-black text-black hover:bg-gray-50'
        }`}
      >
        <Heart className={`h-5 w-5 ${inWishlist ? 'fill-red-500 text-red-500' : ''}`} />
        {inWishlist ? 'Đã thêm vào yêu thích' : 'Favourite'}
      </button>

      {/* Product Description */}
      <div className="mb-8">
        <p className="text-sm text-gray-700 leading-relaxed">
          {product.description}
        </p>
      </div>

      {/* Product Details */}
      <div className="border-t border-gray-200 pt-6">
        <h4 className="text-sm font-bold text-black mb-4">Product Details</h4>
        <ul className="space-y-3 text-sm text-gray-700">
          <li>
            <strong>Colour Shown:</strong> {product.details.colorShown}
          </li>
          <li>
            <strong>Style:</strong> {product.details.style}
          </li>
          <li>
            <strong>Country/Region of Origin:</strong> {product.details.country}
          </li>
        </ul>
        <button
          type="button"
          onClick={() => setShowMoreDetails((v) => !v)}
          className="text-black text-sm font-medium underline mt-4 inline-block hover:text-gray-700 transition-colors"
        >
          {showMoreDetails ? 'Ẩn chi tiết' : 'View Product Details'}
        </button>

        {showMoreDetails && (
          <div className="mt-4 space-y-4 text-sm text-gray-700 bg-gray-50 p-4 rounded-lg">
            <div>
              <h5 className="font-semibold text-black mb-1">Mô tả sản phẩm</h5>
              <p className="leading-relaxed">{product.description}</p>
            </div>
            <div>
              <h5 className="font-semibold text-black mb-1">Thông số</h5>
              <ul className="space-y-1">
                <li><strong>Danh mục:</strong> {product.category}</li>
                <li><strong>Số màu có sẵn:</strong> {product.colors.length}</li>
                <li><strong>Kích cỡ:</strong> {product.sizes.map((s) => s.size).join(', ')}</li>
                <li><strong>Giá niêm yết:</strong> ₫{product.price.toLocaleString('vi-VN')}</li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold text-black mb-1">Hướng dẫn bảo quản</h5>
              <ul className="list-disc pl-5 space-y-1">
                <li>Giặt máy ở nhiệt độ thấp hoặc giặt tay</li>
                <li>Không tẩy trắng</li>
                <li>Phơi ở nơi thoáng mát, tránh ánh nắng trực tiếp</li>
                <li>Ủi ở nhiệt độ trung bình nếu cần</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
