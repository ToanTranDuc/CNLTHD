"use client";
import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface ProductFiltersProps {
  totalProducts: number;
  category: string;
  onSortChange: (sortBy: string) => void;
}

const ProductFilters: React.FC<ProductFiltersProps> = ({
  totalProducts,
  category,
  onSortChange,
}) => {
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [selectedSort, setSelectedSort] = useState('Featured');

  const sortOptions = [
    'Featured',
    'Newest',
    'Price: High-Low',
    'Price: Low-High',
  ];

  const handleSortSelect = (sort: string) => {
    setSelectedSort(sort);
    onSortChange(sort);
    setIsSortOpen(false);
  };

  return (
    <div className="flex items-center justify-between py-6 border-b border-gray-200">
      {/* Left: Category Title */}
      <h1 className="text-2xl font-bold text-black">
        {category} ({totalProducts})
      </h1>

      {/* Right: Sort By Dropdown */}
      <div className="flex items-center gap-8">
        <div className="relative">
          <button
            onClick={() => setIsSortOpen(!isSortOpen)}
            className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-black transition-colors"
          >
            <span>Sort By: {selectedSort}</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-300 ${
                isSortOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {/* Dropdown Menu */}
          {isSortOpen && (
            <div className="absolute right-0 top-full mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-40">
              {sortOptions.map((option) => (
                <button
                  key={option}
                  onClick={() => handleSortSelect(option)}
                  className={`w-full text-left px-4 py-2.5 text-sm transition-colors ${
                    selectedSort === option
                      ? 'bg-gray-100 font-medium text-black'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductFilters;
