"use client";
import React, { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface ImageGalleryProps {
  images: string[];
  colors: Array<{
    name: string;
    image: string;
  }>;
  onColorChange?: (colorName: string) => void;
}

const ProductImageGallery: React.FC<ImageGalleryProps> = ({ images, colors }) => {
  // Deduplicate images
  const uniqueImages = useMemo(() => {
    const seen = new Set<string>();
    return images.filter((img) => {
      if (!img || seen.has(img)) return false;
      seen.add(img);
      return true;
    });
  }, [images]);

  const [mainImageIndex, setMainImageIndex] = useState(0);
  const fallback = colors[0]?.image || 'https://placehold.co/800x1000?text=No+Image';
  const mainSrc = uniqueImages[mainImageIndex] || fallback;

  const handlePrev = () => setMainImageIndex((p) => (p === 0 ? uniqueImages.length - 1 : p - 1));
  const handleNext = () => setMainImageIndex((p) => (p === uniqueImages.length - 1 ? 0 : p + 1));

  return (
    <div className="flex gap-4">
      {/* Thumbnails left column - only show if 2+ unique images */}
      {uniqueImages.length > 1 && (
        <div className="flex flex-col gap-2 w-20 flex-shrink-0">
          {uniqueImages.map((image, index) => (
            <button
              key={index}
              onClick={() => setMainImageIndex(index)}
              className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                mainImageIndex === index ? 'border-black' : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              <img src={image} alt={`Thumbnail ${index}`} className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}

      {/* Main image */}
      <div className="flex-1 bg-gray-100 rounded-lg overflow-hidden relative aspect-square">
        <img src={mainSrc} alt="Main product" className="w-full h-full object-cover" />

        {uniqueImages.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition-all"
            >
              <ChevronLeft className="h-6 w-6 text-black" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full transition-all"
            >
              <ChevronRight className="h-6 w-6 text-black" />
            </button>
            <div className="absolute bottom-4 right-4 bg-black/60 text-white text-xs px-3 py-1 rounded-full">
              {mainImageIndex + 1} / {uniqueImages.length}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ProductImageGallery;
