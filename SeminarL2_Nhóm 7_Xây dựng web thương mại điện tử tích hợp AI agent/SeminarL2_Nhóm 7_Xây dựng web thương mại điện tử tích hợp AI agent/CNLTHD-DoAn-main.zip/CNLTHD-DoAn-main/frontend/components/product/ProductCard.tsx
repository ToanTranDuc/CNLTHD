"use client";
import React from 'react';
import Link from 'next/link';
import { Product } from '@/types/Product';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/context/ToastContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addItem } = useCart();
  const { showToast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const firstAvailableSize = product.sizes.find((size) => size.inStock);
    if (!firstAvailableSize) {
      showToast(`${product.name} đã hết hàng`, 'error');
      return;
    }
    const firstColor = product.colors[0]?.name || 'Default';

    const matchingVariant = product.variants?.find(
      (v) => v.size === firstAvailableSize.size && v.color.toUpperCase() === firstColor.toUpperCase()
    ) ?? product.variants?.find((v) => v.size === firstAvailableSize.size)
      ?? product.variants?.[0];

    if (matchingVariant && matchingVariant.inStock === false) {
      showToast(`${product.name} - size ${firstAvailableSize.size} đã hết hàng`, 'error');
      return;
    }

    addItem({
      id: product.id,
      name: product.name,
      category: product.category,
      color: matchingVariant?.color ?? firstColor,
      size: matchingVariant?.size ?? firstAvailableSize.size,
      price: matchingVariant?.price ?? product.price,
      quantity: 1,
      image: product.image,
      skuCode: matchingVariant?.sku,
    });

    showToast(`Đã thêm "${product.name}" vào giỏ hàng`, 'success');
  };
  return (
    <Link href={`/products/${product.id}`}>
      <div className="flex flex-col gap-3 group cursor-pointer">
        {/* Product Image */}
        <div className="relative w-full aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />

          {/* Just In Badge */}
          {product.isNew && (
            <div className="absolute bottom-4 left-4">
              <span className="bg-orange-500 text-white text-xs font-bold px-3 py-1 rounded">
                Just In
              </span>
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="flex flex-col gap-1">
          <h3 className="text-sm font-medium text-black hover:text-blue-600 transition-colors cursor-pointer">
            {product.name}
          </h3>
          <p className="text-sm text-gray-600">
            ${product.price.toFixed(2)}
          </p>

          {/* Add to Cart Button */}
          <button
            onClick={handleAddToCart}
            className="mt-3 w-full bg-black text-white text-xs font-semibold py-2 rounded hover:bg-gray-800 transition-colors"
          >
            Add to Bag
          </button>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
