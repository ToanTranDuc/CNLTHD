# 📖 Hướng dẫn Monitoring – Từng bước từ đầu

Khởi động Ngrok ở terminal: ngrok http 3100

> **Thời gian ước tính**: 20–30 phút  
> **Yêu cầu**: Docker Desktop đang chạy, đã có tài khoản GitHub

---

## 📋 Mục lục

1. [Bước 1 – Build & chạy Monitoring Stack](#bước-1--build--chạy-monitoring-stack)
2. [Bước 2 – Kiểm tra Grafana & Prometheus](#bước-2--kiểm-tra-grafana--prometheus)
3. [Bước 3 – Tạo tài khoản & cài ngrok](#bước-3--tạo-tài-khoản--cài-ngrok)
4. [Bước 4 – Expose Loki ra internet bằng ngrok](#bước-4--expose-loki-ra-internet-bằng-ngrok)
5. [Bước 5 – Thêm LOKI_URL vào GitHub Secrets](#bước-5--thêm-loki_url-vào-github-secrets)
6. [Bước 6 – Trigger GitHub Actions & xem logs trong Grafana](#bước-6--trigger-github-actions--xem-logs-trong-grafana)
7. [Xử lý sự cố thường gặp](#xử-lý-sự-cố-thường-gặp)

---

## Bước 1 – Build & chạy Monitoring Stack

### 1.1 Mở Terminal tại thư mục project

```powershell
cd C:\GitHub\cnlthd-doan
```

### 1.2 Build lại tất cả backend services (vì vừa thêm dependency Prometheus)

> ⚠️ Bước này mất **10–20 phút** lần đầu do Maven download dependencies

```powershell
docker compose build `
  eureka-service `
  api-gateway `
  product-service `
  inventory-service `
  order-service `
  notification-service `
  user-service `
  chatbot-service
```

### 1.3 Khởi động Monitoring Stack

```powershell
docker compose --profile monitoring up -d
```

Lệnh này sẽ pull và khởi động 4 containers:
- `cnlthd-prometheus`
- `cnlthd-grafana`
- `cnlthd-loki`
- `cnlthd-promtail`

### 1.4 Kiểm tra containers đang chạy

```powershell
docker compose ps
```

Bạn sẽ thấy các container monitoring có trạng thái **Up**:

```
NAME                 STATUS
cnlthd-prometheus    Up
cnlthd-grafana       Up
cnlthd-loki          Up
cnlthd-promtail      Up
```

---

## Bước 2 – Kiểm tra Grafana & Prometheus

### 2.1 Mở Prometheus

👉 Truy cập: **http://localhost:9090/targets**

Bạn sẽ thấy danh sách các services đang được scrape. Nếu main stack chưa chạy, trạng thái sẽ là **DOWN** – điều đó bình thường.

### 2.2 Mở Grafana

👉 Truy cập: **http://localhost:5000**

- **Username**: `admin`
- **Password**: `admin`
- Grafana sẽ yêu cầu đổi mật khẩu → bấm **Skip** nếu muốn giữ nguyên

### 2.3 Xem Dashboard

1. Vào menu bên trái → **Dashboards**
2. Mở folder **CNLTHD**
3. Click vào **"CNLTHD – Microservices Overview"**

> 📌 Nếu chưa chạy main stack thì các panel Prometheus sẽ hiển thị "No data" – bình thường.

---

## Bước 3 – Tạo tài khoản & cài ngrok

> ngrok giúp tạo một URL public trỏ vào Loki đang chạy trên máy bạn, để GitHub Actions có thể gửi logs về.

### 3.1 Tạo tài khoản ngrok miễn phí

1. Truy cập: **https://ngrok.com** → bấm **Sign Up**
2. Đăng ký bằng GitHub hoặc Email
3. Sau khi đăng nhập, vào **https://dashboard.ngrok.com/get-started/your-authtoken**
4. Copy **Authtoken** (dạng: `2abc123xyz...`)

### 3.2 Cài ngrok trên Windows

**Cách 1 – Dùng Chocolatey** (nếu đã có):
```powershell
choco install ngrok
```

**Cách 2 – Download thủ công**:
1. Vào **https://ngrok.com/download**
2. Download bản **Windows 64-bit**
3. Giải nén file `.zip` → copy file `ngrok.exe` vào `C:\Windows\System32\` (hoặc thêm vào PATH)

**Cách 3 – Dùng Winget**:
```powershell
winget install ngrok.ngrok
```

### 3.3 Đăng nhập ngrok với Authtoken

```powershell
ngrok config add-authtoken <YOUR_AUTHTOKEN_HERE>
```

Ví dụ:
```powershell
ngrok config add-authtoken 2abc123xyz_abcdefghijk
```

---

## Bước 4 – Expose Loki ra internet bằng ngrok

> ⚠️ **Quan trọng**: Loki phải đang chạy (Bước 1 đã hoàn thành) trước khi chạy ngrok.

### 4.1 Mở Terminal mới (KHÔNG đóng terminal cũ)

Mở một PowerShell/Terminal window mới.

### 4.2 Chạy ngrok tunnel đến port 3100 (Loki)

```powershell
ngrok http 3100
```

Bạn sẽ thấy output như sau:

```
Session Status                online
Account                       your-email@gmail.com (Plan: Free)
Version                       3.x.x
Forwarding                    https://abcd-123-456-789.ngrok-free.app -> http://localhost:3100
```

### 4.3 Copy URL ngrok

Copy phần **https URL**, ví dụ:
```
https://abcd-123-456-789.ngrok-free.app
```

> ⚠️ **Lưu ý**: URL này thay đổi mỗi lần bạn restart ngrok (với tài khoản Free).  
> Mỗi khi URL thay đổi, bạn phải cập nhật lại GitHub Secret ở Bước 5.

---

## Bước 5 – Thêm LOKI_URL vào GitHub Secrets

### 5.1 Mở trang Secrets của GitHub repo

1. Truy cập repo trên GitHub: **https://github.com/EgawaMasao/CNLTHD-DoAn**
2. Click vào tab **Settings** (phải là owner của repo)
3. Menu bên trái → **Secrets and variables** → **Actions**
4. Click nút **"New repository secret"**

### 5.2 Tạo secret LOKI_URL

- **Name**: `LOKI_URL`
- **Secret**: dán URL ngrok vừa copy, **KHÔNG có dấu `/` ở cuối**

Ví dụ:
```
https://abcd-123-456-789.ngrok-free.app
```

5. Click **"Add secret"**

---

## Bước 6 – Trigger GitHub Actions & xem logs trong Grafana

### 6.1 Trigger workflow bằng cách push code

```powershell
cd C:\GitHub\cnlthd-doan
git add .
git commit -m "feat: add monitoring stack (Prometheus + Grafana + Loki)"
git push origin main
```

### 6.2 Theo dõi GitHub Actions đang chạy

1. Vào **https://github.com/EgawaMasao/CNLTHD-DoAn/actions**
2. Bạn sẽ thấy workflow **"CI/CD pipeline"** đang chạy
3. Mỗi job khi hoàn thành sẽ tự động gửi logs về Loki

### 6.3 Xem CI/CD logs trong Grafana

1. Mở **http://localhost:5000** (Grafana)
2. Menu bên trái → **Explore** (biểu tượng compass 🧭)
3. Chọn datasource **Loki** (dropdown ở góc trên trái)
4. Nhập query:

```logql
{job="github-actions"}
```

5. Click **"Run query"** hoặc nhấn `Shift+Enter`

Bạn sẽ thấy logs từ tất cả các jobs của GitHub Actions!

### 6.4 Lọc theo job cụ thể

```logql
# Chỉ xem backend-build logs
{job="github-actions", job_name="backend-build"}

# Chỉ xem logs của product-service
{job="github-actions", service="Product-Service"}

# Chỉ xem jobs bị lỗi
{job="github-actions", status="failure"}
```

### 6.5 Xem trên Dashboard tổng hợp

1. Vào **Dashboards** → **CNLTHD** → **"CNLTHD – Microservices Overview"**
2. Kéo xuống phần **"📋 GitHub Actions CI/CD Logs"**

---

## Xử lý sự cố thường gặp

### ❌ Loki không nhận được logs từ GitHub Actions

**Kiểm tra**:
1. ngrok có đang chạy không? (terminal ngrok phải mở)
2. URL trong GitHub Secret có đúng không? (không có `/` cuối)
3. Thử curl test từ máy khác:
   ```powershell
   curl https://abcd-123-456-789.ngrok-free.app/ready
   ```
   Phải trả về `ready`

### ❌ Container monitoring không start

```powershell
# Xem log của container bị lỗi
docker logs cnlthd-loki
docker logs cnlthd-prometheus
docker logs cnlthd-grafana
```

### ❌ Prometheus targets toàn DOWN

Đó là bình thường nếu chưa chạy main stack. Khởi động main stack:
```powershell
docker compose up -d
```

Sau vài phút, vào http://localhost:9090/targets và refresh.

### ❌ Grafana không load dashboard

```powershell
# Restart grafana
docker compose restart grafana

# Xem logs
docker logs cnlthd-grafana
```

### ❌ ngrok báo lỗi "ERR_NGROK_105"

Authtoken chưa đúng. Thực hiện lại:
```powershell
ngrok config add-authtoken <YOUR_AUTHTOKEN>
```

---

## 🔄 Mỗi lần khởi động lại máy

Sau khi restart máy, cần làm theo thứ tự:

```powershell
# 1. Khởi động monitoring stack
docker compose --profile monitoring up -d

# 2. Mở terminal mới, chạy ngrok
ngrok http 3100

# 3. Copy URL ngrok mới → cập nhật GitHub Secret LOKI_URL
#    (URL thay đổi mỗi lần restart với tài khoản Free)
```

> 💡 **Tip**: Nếu muốn URL cố định, upgrade ngrok lên **Pro plan** ($10/tháng) để có **static domain**.

---

## 📊 Tóm tắt các URL quan trọng

| Công cụ | URL | Thông tin đăng nhập |
|---|---|---|
| Grafana | http://localhost:5000 | admin / admin |
| Prometheus | http://localhost:9090 | Không cần |
| Loki (health) | http://localhost:3100/ready | Không cần |
| ngrok dashboard | http://localhost:4040 | Không cần |
| GitHub Actions | https://github.com/EgawaMasao/CNLTHD-DoAn/actions | Tài khoản GitHub |
