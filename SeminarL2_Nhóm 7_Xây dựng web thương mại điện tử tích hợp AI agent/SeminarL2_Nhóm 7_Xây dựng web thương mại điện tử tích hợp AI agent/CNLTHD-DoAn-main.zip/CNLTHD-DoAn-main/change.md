# Changelog – Seed Data & Product Media

## 1. Sinh dữ liệu seed từ `nike_verse.csv`

**Script:** `generate_seed.ps1` → **Output:** `seed_data.sql`

Đọc 1215 dòng từ `nike_verse.csv`, sinh câu lệnh SQL INSERT cho hai database:

### product_service
| Bảng | Số dòng | Ghi chú |
|------|---------|---------|
| `categories` | 42 | 3 master + 11 sub + 28 articleType (3 cấp) |
| `products` | 135 | UUID, slug, gender, base_price, category_id |
| `product_variants` | 1 215 | SKU format: `{productNum}-{COLOR}-{SIZE}` |

### inventory_service
| Bảng | Số dòng | Ghi chú |
|------|---------|---------|
| `stocks` | 1 215 | sku_code, product_name, quantity, version=0 |
| `inventory_log` | 1 215 | operation_type=IN, lý do: "Initial stock load" |

**Các vấn đề đã sửa trong quá trình tạo script:**
- Đổi tên biến `$pid` → `$parentUid` (PS5.1 dùng `$PID` là biến hệ thống)
- Dùng vòng `while` thay `for` để tránh lỗi số học PS5.1
- Cột `sku_code` (không phải `sku`) theo entity JPA thực tế
- Thêm cột `gender` vào INSERT products (ENUM: MEN/WOMEN/UNISEX)
- Mapping 46 màu CSV → 16 giá trị Color ENUM

---

## 2. Insert seed data vào Docker MySQL

**Container:** `cnlthd-mysql` (mysql:8.4, host port 3307, root/root)

**File hỗ trợ:** `truncate_seed.sql` – TRUNCATE tất cả bảng liên quan trước khi insert lại.

```bash
docker cp truncate_seed.sql cnlthd-mysql:/tmp/
docker cp seed_data.sql     cnlthd-mysql:/tmp/
docker exec cnlthd-mysql bash -c "mysql -u root -proot < /tmp/truncate_seed.sql && mysql -u root -proot < /tmp/seed_data.sql"
```

**Kết quả:** 42 categories + 135 products + 1215 variants + 1215 stocks + 1215 inventory_log đã vào DB thành công.

---

## 3. Thêm ảnh placeholder cho tất cả sản phẩm

**Script:** `generate_media.ps1` → **Output:** `seed_media.sql`

- Query DB lấy UUID sản phẩm + articleType
- Map articleType → keyword loremflickr (27 loại)
- Sinh 2 ảnh/sản phẩm: `sort_order=0` (primary), `sort_order=1` (secondary)
- URL format: `https://loremflickr.com/640/480/{keyword}?lock={n}`
- Tổng: **270 rows** trong bảng `product_media`

---

## 4. Cập nhật ảnh thật của Nike / Puma / Adidas

**Script:** `update_media_brand.sql`

Thay thế URL loremflickr bằng ảnh thật từ CDN thương hiệu cho **37 sản phẩm** (74 rows trong `product_media`).

### Nguồn ảnh theo thương hiệu

| Thương hiệu | Nguồn CDN | Số loại |
|-------------|-----------|---------|
| **Puma** | `images.puma.com` (CDN chính thức Puma) | 7/8 loại |
| **Puma** – Tracksuits | `m.media-amazon.com` (qua Zappos) | 1/8 loại |
| **Nike** – Backpacks, Caps, Track Pants | `images.footlocker.com` (Foot Locker CDN) | 3/7 loại |
| **Nike** – Capris, Socks, T-Shirts | `m.media-amazon.com` (qua Zappos) | 3/7 loại |
| **Nike** – Sports Shoes | `loremflickr.com` (fallback – nike.com chặn) | 1/7 loại |
| **Adidas** – 7 loại | `m.media-amazon.com` (qua Zappos) | 7/9 loại |
| **Adidas** – Sports Shoes, Swimwear | `loremflickr.com` (fallback – adidas.com 403) | 2/9 loại |

### Chi tiết sản phẩm được cập nhật

**Puma (14 sản phẩm):**
- Backpacks × 2, Casual Shoes × 2, Jackets × 1, Socks × 1
- Sports Sandals × 3, Sweatshirts × 1, Track Pants × 2, Tracksuits × 2

**Nike (11 sản phẩm):**
- Backpacks × 1, Caps × 2, Capris × 2, Socks × 1
- Sports Shoes × 1, Track Pants × 2, T-Shirts × 2

**Adidas (12 sản phẩm):**
- Caps × 1, Jackets × 1, Sports Sandals × 2, Sports Shoes × 1
- Sweaters × 1, Sweatshirts × 2, Swimwear × 1, Tights × 2, Track Pants × 1

### Chạy lại update
```bash
docker cp update_media_brand.sql cnlthd-mysql:/tmp/
docker exec cnlthd-mysql mysql -u root -proot -e "source /tmp/update_media_brand.sql;"
```

> **Lưu ý sau bước này:** Còn **210 ảnh / 109 sản phẩm** vẫn dùng loremflickr (98 sản phẩm non-brand + 3 sản phẩm Nike/Adidas fallback + 8 sản phẩm brand có ảnh phụ loremflickr). Xem bước 5 để thay thế hoàn toàn.

---

## 5. Thay thế toàn bộ ảnh loremflickr còn lại

**Script:** `update_media_all.sql`

Thay thế **toàn bộ 210 ảnh loremflickr còn lại** bằng ảnh thật từ các CDN thương mại, bao gồm:
- 8 sản phẩm thuộc nhóm A (Nike/Puma – chỉ thiếu sort_order=1)
- 101 sản phẩm thuộc nhóm B (non-brand + Nike Sports Shoes + Adidas fallback)

### Nguồn CDN sau bước 5

| CDN | Số ảnh | Loại sản phẩm |
|-----|--------|---------------|
| `rukminim2.flixcart.com` (Flipkart) | 210 | Tất cả non-brand + fallback |
| `m.media-amazon.com` | 34 | Adidas, Nike, Puma (giữ nguyên từ bước 4) |
| `images.puma.com` | 21 | Puma (giữ nguyên từ bước 4) |
| `images.footlocker.com` | 5 | Nike Backpacks, Caps, Track Pants (giữ nguyên) |
| **loremflickr.com** | **0** | **Không còn** |

### Chiến lược tìm ảnh

- **Nike/Puma sort_order=1**: dùng biến thể ảnh phụ (sv02, mod02) từ cùng CDN với sort_order=0
- **Sản phẩm non-brand**: nhóm theo category, tìm ảnh đại diện thực tế từ Flipkart CDN (612×612, `q=70`)
- **Sản phẩm có brand cụ thể** (Wrangler, Fila, Vans, Skechers…): ưu tiên ảnh khớp brand trên Flipkart

### Kết quả

**270 / 270 rows** trong `product_media` có ảnh thật — 0 loremflickr còn lại.

### Chạy update

```bash
& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -proot -h 127.0.0.1 -P 3307 product_service -e "SOURCE C:/Study/CNLTHD/CNLTHD-DoAn/update_media_all.sql"
```

---

## Tổng kết các file tạo ra

| File | Mô tả |
|------|-------|
| `generate_seed.ps1` | Script PS sinh `seed_data.sql` từ CSV |
| `seed_data.sql` | SQL INSERT cho product_service + inventory_service |
| `truncate_seed.sql` | SQL TRUNCATE để reset trước khi seed lại |
| `generate_media.ps1` | Script PS sinh `seed_media.sql` (ảnh placeholder) |
| `seed_media.sql` | SQL INSERT 270 rows vào product_media (loremflickr) |
| `update_media_brand.sql` | SQL UPDATE 74 rows ảnh thật Nike/Puma/Adidas |
| `update_media_all.sql` | SQL UPDATE 210 rows – thay toàn bộ loremflickr còn lại bằng ảnh thật (Flipkart CDN) |
