# generate_seed.ps1
# Reads nike_verse.csv -> writes seed_data.sql
# Targets: product_service  (categories, products, product_variants)
#          inventory_service (stocks, inventory_log)
# Matches ACTUAL JPA-generated table schema (not ALL_PROJECT_SQL.sql)

param()

$CSV_PATH = "$PSScriptRoot\nike_verse.csv"
$OUT_PATH = "$PSScriptRoot\seed_data.sql"
$NOW      = "2024-01-01 00:00:00.000000"
$BATCHSZ  = [int]200

$csv = Import-Csv $CSV_PATH
Write-Host "Loaded $($csv.Count) rows"

function New-Guid2 { [System.Guid]::NewGuid().ToString() }
function To-Slug([string]$s) { ($s.ToLower() -replace "[^a-z0-9]+" ,'-').Trim('-') }
function Esc-SQL([string]$s)  { $s -replace "'","''" }

# ---- Color -> ENUM mapping ----
# ENUM: BEIGE, BLACK, BLUE, BROWN, CREAM, GRAY, GREEN, KHAKI, NAVY, OLIVE, ORANGE, PINK, PURPLE, RED, WHITE, YELLOW
$colorMap = @{
    'Beige'           = 'BEIGE'
    'Black'           = 'BLACK'
    'Blue'            = 'BLUE'
    'Bronze'          = 'BROWN'
    'Brown'           = 'BROWN'
    'Burgundy'        = 'RED'
    'Charcoal'        = 'GRAY'
    'Coffee Brown'    = 'BROWN'
    'Copper'          = 'BROWN'
    'Cream'           = 'CREAM'
    'Fluorescent Green' = 'GREEN'
    'Gold'            = 'YELLOW'
    'Green'           = 'GREEN'
    'Grey'            = 'GRAY'
    'Grey Melange'    = 'GRAY'
    'Khaki'           = 'KHAKI'
    'Lavender'        = 'PURPLE'
    'Lime Green'      = 'GREEN'
    'Magenta'         = 'PINK'
    'Maroon'          = 'RED'
    'Mauve'           = 'PINK'
    'Metallic'        = 'GRAY'
    'Multi'           = 'GRAY'
    'Mushroom Brown'  = 'BROWN'
    'Mustard'         = 'YELLOW'
    'Navy Blue'       = 'NAVY'
    'Nude'            = 'BEIGE'
    'Off White'       = 'CREAM'
    'Olive'           = 'OLIVE'
    'Orange'          = 'ORANGE'
    'Peach'           = 'PINK'
    'Pink'            = 'PINK'
    'Purple'          = 'PURPLE'
    'Red'             = 'RED'
    'Rose'            = 'PINK'
    'Rust'            = 'RED'
    'Sea Green'       = 'GREEN'
    'Silver'          = 'GRAY'
    'Skin'            = 'BEIGE'
    'Steel'           = 'GRAY'
    'Tan'             = 'BROWN'
    'Taupe'           = 'GRAY'
    'Teal'            = 'GREEN'
    'Turquoise Blue'  = 'BLUE'
    'White'           = 'WHITE'
    'Yellow'          = 'YELLOW'
}

# ---- Gender -> ENUM mapping ----
# ENUM: MEN, UNISEX, WOMEN
$genderMap = @{
    'Men'    = 'MEN'
    'Women'  = 'WOMEN'
    'Unisex' = 'UNISEX'
    'Boys'   = 'MEN'
    'Girls'  = 'WOMEN'
}

$out = [System.Collections.Generic.List[string]]::new()

$out.Add("-- ================================================================")
$out.Add("-- SEED DATA: product_service + inventory_service")
$out.Add("-- Source   : nike_verse.csv ($($csv.Count) variant rows)")
$out.Add("-- Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$out.Add("-- ================================================================")
$out.Add("")
$out.Add("SET FOREIGN_KEY_CHECKS = 0;")
$out.Add("")

# ==================================================================
# A) PRODUCT SERVICE
# ==================================================================
$out.Add("-- ==================================================================")
$out.Add("-- A) product_service")
$out.Add("-- ==================================================================")
$out.Add("USE product_service;")
$out.Add("")

# ---- 1. CATEGORIES ----
$catId = @{}

$masterList = @($csv | Select-Object -ExpandProperty masterCategory -Unique | Sort-Object)
$subList    = @($csv | Select-Object masterCategory, subCategory -Unique | Sort-Object masterCategory, subCategory)
$artList    = @($csv | Select-Object masterCategory, subCategory, articleType -Unique | Sort-Object masterCategory, subCategory, articleType)

foreach ($mc in $masterList) {
    $catId["M:$mc"] = New-Guid2
}
foreach ($r in $subList) {
    $catId["S:$($r.masterCategory):$($r.subCategory)"] = New-Guid2
}
foreach ($r in $artList) {
    $catId["A:$($r.masterCategory):$($r.subCategory):$($r.articleType)"] = New-Guid2
}

$catRows = [System.Collections.Generic.List[string]]::new()

foreach ($mc in $masterList) {
    $uid = $catId["M:$mc"]
    $catRows.Add("  ('$uid', '$(Esc-SQL $mc)', '$(Esc-SQL $mc)', '$(To-Slug $mc)', NULL, '$NOW', '$NOW', 'ACTIVE')")
}
foreach ($r in $subList) {
    $uid       = $catId["S:$($r.masterCategory):$($r.subCategory)"]
    $parentUid = $catId["M:$($r.masterCategory)"]
    $slg       = To-Slug "$($r.masterCategory)-$($r.subCategory)"
    # slug max 150 chars
    if ($slg.Length -gt 140) { $slg = $slg.Substring(0, 140) }
    $catRows.Add("  ('$uid', '$(Esc-SQL $r.subCategory)', '$(Esc-SQL $r.subCategory)', '$slg', '$parentUid', '$NOW', '$NOW', 'ACTIVE')")
}
foreach ($r in $artList) {
    $uid       = $catId["A:$($r.masterCategory):$($r.subCategory):$($r.articleType)"]
    $parentUid = $catId["S:$($r.masterCategory):$($r.subCategory)"]
    $slg       = To-Slug "$($r.masterCategory)-$($r.subCategory)-$($r.articleType)"
    if ($slg.Length -gt 140) { $slg = $slg.Substring(0, 140) }
    $catRows.Add("  ('$uid', '$(Esc-SQL $r.articleType)', '$(Esc-SQL $r.articleType)', '$slg', '$parentUid', '$NOW', '$NOW', 'ACTIVE')")
}

$totalCats = $masterList.Count + $subList.Count + $artList.Count
$out.Add("-- categories: $($masterList.Count) master + $($subList.Count) sub + $($artList.Count) articleType = $totalCats rows")
$out.Add("INSERT INTO categories (id, name, description, slug, parent_id, created_at, updated_at, status) VALUES")
$out.Add(($catRows.ToArray() -join ",`n") + ";")
$out.Add("")

# ---- 2. PRODUCTS ----
$prodId     = @{}
$prodGroups = @($csv | Group-Object { ($_.id -split '_')[0] } | Sort-Object Name)
$prodRows   = [System.Collections.Generic.List[string]]::new()

foreach ($grp in $prodGroups) {
    $first    = $grp.Group[0]
    $pNum     = $grp.Name
    $uid      = New-Guid2
    $prodId[$pNum] = $uid

    $name      = Esc-SQL $first.productDisplayName
    $brand     = Esc-SQL (($first.productDisplayName -split ' ')[0])
    $genderVal = if ($genderMap.ContainsKey($first.gender)) { $genderMap[$first.gender] } else { 'UNISEX' }
    $desc      = Esc-SQL "$($first.gender) $($first.usage) product. Season: $($first.season) $($first.year)."
    $catKey    = "A:$($first.masterCategory):$($first.subCategory):$($first.articleType)"
    $catUid    = $catId[$catKey]
    $minPrice  = ($grp.Group | ForEach-Object { [decimal]$_.price } | Measure-Object -Minimum).Minimum
    $slg       = To-Slug "$pNum-$($first.productDisplayName)"

    $prodRows.Add("  ('$uid', '$name', '$desc', '$brand', NULL, $minPrice, '$slg', '$catUid', '$genderVal', '$NOW', '$NOW', 'ACTIVE')")
}

$out.Add("-- products: $($prodRows.Count) rows")
$out.Add("INSERT INTO products (id, name, description, brand, country, base_price, slug, category_id, gender, created_at, updated_at, status) VALUES")
$out.Add(($prodRows.ToArray() -join ",`n") + ";")
$out.Add("")

# ---- 3. PRODUCT VARIANTS ----
# Actual schema: id, product_id, size, color(ENUM), price, sku_code, created_at, updated_at, status
$variantRows = [System.Collections.Generic.List[string]]::new()
$skuData     = [System.Collections.Generic.List[object]]::new()
$seenSKUs    = [System.Collections.Generic.HashSet[string]]::new()
$skippedColors = [System.Collections.Generic.List[string]]::new()

foreach ($row in $csv) {
    $pNum      = ($row.id -split '_')[0]
    $pUid      = $prodId[$pNum]
    $colorSafe = ($row.baseColour -replace '[^a-zA-Z0-9]','').ToUpper()
    $sku       = "$pNum-$colorSafe-$($row.size)"

    if ($seenSKUs.Add($sku)) {
        # Map color to ENUM
        $colorEnum = if ($colorMap.ContainsKey($row.baseColour)) {
            $colorMap[$row.baseColour]
        } else {
            $skippedColors.Add("Unknown color: $($row.baseColour)")
            'GRAY'
        }

        $vUid  = New-Guid2
        $price = [decimal]$row.price
        $sz    = $row.size   # S, M, L are all valid ENUM values

        $variantRows.Add("  ('$vUid', '$pUid', '$sz', '$colorEnum', $price, '$sku', '$NOW', '$NOW', 'ACTIVE')")
        $skuData.Add([PSCustomObject]@{
            SKU  = $sku
            Name = Esc-SQL $row.productDisplayName
            Qty  = [int]$row.quantity
        })
    }
}

if ($skippedColors.Count -gt 0) {
    Write-Host "WARNING - unmapped colors (defaulted to GRAY): $($skippedColors | Sort-Object -Unique)"
}

$varArr = $variantRows.ToArray()
$out.Add("-- product_variants: $($varArr.Count) rows (batches of $BATCHSZ)")
$i = 0
while ($i -lt $varArr.Count) {
    $end   = [Math]::Min($i + $BATCHSZ, $varArr.Count)
    $chunk = $varArr[$i..($end - 1)]
    $out.Add("INSERT INTO product_variants (id, product_id, size, color, price, sku_code, created_at, updated_at, status) VALUES")
    $out.Add(($chunk -join ",`n") + ";")
    $out.Add("")
    $i = $i + $BATCHSZ
}

$out.Add("-- NOTE: product_media skipped - no image URLs in source CSV.")
$out.Add("")

# ==================================================================
# B) INVENTORY SERVICE
# ==================================================================
$out.Add("-- ==================================================================")
$out.Add("-- B) inventory_service")
$out.Add("-- ==================================================================")
$out.Add("USE inventory_service;")
$out.Add("")

$stockRows = [System.Collections.Generic.List[string]]::new()
$logRows   = [System.Collections.Generic.List[string]]::new()

foreach ($s in $skuData) {
    $stockRows.Add("  ('$($s.SKU)', '$($s.Name)', $($s.Qty), 0)")
    $logRows.Add("  ('$($s.SKU)', 'IN', $($s.Qty), $($s.Qty), NULL, 'Initial stock load from nike_verse.csv', 'system', '$NOW')")
}

$stArr = $stockRows.ToArray()
$out.Add("-- stocks: $($stArr.Count) rows (batches of $BATCHSZ)")
$i = 0
while ($i -lt $stArr.Count) {
    $end   = [Math]::Min($i + $BATCHSZ, $stArr.Count)
    $chunk = $stArr[$i..($end - 1)]
    $out.Add("INSERT INTO stocks (sku_code, product_name, quantity, version) VALUES")
    $out.Add(($chunk -join ",`n") + ";")
    $out.Add("")
    $i = $i + $BATCHSZ
}

$lgArr = $logRows.ToArray()
$out.Add("-- inventory_log: $($lgArr.Count) initial IN entries (batches of $BATCHSZ)")
$i = 0
while ($i -lt $lgArr.Count) {
    $end   = [Math]::Min($i + $BATCHSZ, $lgArr.Count)
    $chunk = $lgArr[$i..($end - 1)]
    $out.Add("INSERT INTO inventory_log (sku_code, operation_type, quantity_change, balance_after, reference_id, reason, created_by, created_at) VALUES")
    $out.Add(($chunk -join ",`n") + ";")
    $out.Add("")
    $i = $i + $BATCHSZ
}

$out.Add("SET FOREIGN_KEY_CHECKS = 1;")
$out.Add("")
$out.Add("-- ================================================================")
$out.Add("-- Seed complete.")
$out.Add("--   categories      : $totalCats")
$out.Add("--   products        : $($prodRows.Count)")
$out.Add("--   product_variants: $($varArr.Count)")
$out.Add("--   stocks          : $($stArr.Count)")
$out.Add("--   inventory_log   : $($lgArr.Count)")
$out.Add("-- ================================================================")

$out | Out-File -FilePath $OUT_PATH -Encoding utf8
Write-Host ""
Write-Host "Done! -> $OUT_PATH"
Write-Host "  Total lines     : $($out.Count)"
Write-Host "  categories      : $totalCats"
Write-Host "  products        : $($prodRows.Count)"
Write-Host "  product_variants: $($varArr.Count)"
Write-Host "  stocks          : $($stArr.Count)"
Write-Host "  inventory_log   : $($lgArr.Count)"
