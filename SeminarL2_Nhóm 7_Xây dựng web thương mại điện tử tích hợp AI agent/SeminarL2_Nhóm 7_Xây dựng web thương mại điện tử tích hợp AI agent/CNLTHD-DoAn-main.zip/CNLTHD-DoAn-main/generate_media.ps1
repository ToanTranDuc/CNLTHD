# generate_media.ps1
# Queries products from DB + maps articleType -> image keywords
# Writes product_media INSERT SQL (2 images per product)

param()

$OUT_PATH = "$PSScriptRoot\seed_media.sql"
$NOW      = "2024-01-01 00:00:00.000000"
$BATCHSZ  = [int]100

# ---- articleType -> loremflickr keyword(s) ----
$keywordMap = @{
    'Backpacks'       = 'backpack,bag'
    'Sunglasses'      = 'sunglasses,eyewear'
    'Caps'            = 'cap,hat'
    'Socks'           = 'socks,feet'
    'Swimwear'        = 'swimwear,swimming'
    'Capris'          = 'capri,leggings'
    'Jeans'           = 'jeans,denim'
    'Leggings'        = 'leggings,sportswear'
    'Shorts'          = 'shorts,sport'
    'Tights'          = 'tights,leggings'
    'Track Pants'     = 'trackpants,sportswear'
    'Tracksuits'      = 'tracksuit,sport'
    'Trousers'        = 'trousers,pants'
    'Dresses'         = 'dress,fashion'
    'Bra'             = 'sportsbra,fitness'
    'Briefs'          = 'underwear,cotton'
    'Innerwear Vests' = 'undershirt,vest'
    'Jackets'         = 'jacket,coat'
    'Rain Jacket'     = 'raincoat,jacket'
    'Shirts'          = 'shirt,fashion'
    'Sweaters'        = 'sweater,knitwear'
    'Sweatshirts'     = 'sweatshirt,hoodie'
    'Tops'            = 'blouse,fashion'
    'Tshirts'         = 'tshirt,casual'
    'Sports Sandals'  = 'sandals,sport'
    'Casual Shoes'    = 'casual,shoes'
    'Sports Shoes'    = 'sneakers,sportswear'
}

function New-Guid2 { [System.Guid]::NewGuid().ToString() }
function Esc-SQL([string]$s) { $s -replace "'","''" }

Write-Host "Querying products from DB..."

# Query DB: id, name, slug, brand, articleType
$rawRows = docker exec cnlthd-mysql mysql -u root -proot --batch --silent -e "
USE product_service;
SELECT p.id, p.name, p.slug, p.brand, c3.name AS articleType
FROM products p
JOIN categories c3 ON p.category_id = c3.id
JOIN categories c2 ON c3.parent_id = c2.id
JOIN categories c1 ON c2.parent_id = c1.id
ORDER BY p.slug;" 2>&1 | Where-Object { $_ -notmatch "Warning" }

$products = [System.Collections.Generic.List[object]]::new()
foreach ($line in $rawRows) {
    $cols = $line -split "`t"
    if ($cols.Count -ge 5) {
        $products.Add([PSCustomObject]@{
            Id          = $cols[0].Trim()
            Name        = $cols[1].Trim()
            Slug        = $cols[2].Trim()
            Brand       = $cols[3].Trim()
            ArticleType = $cols[4].Trim()
        })
    }
}

Write-Host "Loaded $($products.Count) products"

$mediaRows = [System.Collections.Generic.List[string]]::new()

foreach ($p in $products) {
    # Extract numeric product number from slug (e.g. "9573-puma-..." -> 9573)
    $pNum = if ($p.Slug -match '^(\d+)-') { [int]$Matches[1] } else { 1 }

    # Get keywords for this articleType
    $kw1 = if ($keywordMap.ContainsKey($p.ArticleType)) {
        $keywordMap[$p.ArticleType]
    } else {
        'fashion,clothing'
    }

    # Brand keyword (lowercase, strip spaces)
    $brandKw = ($p.Brand -replace '[^a-zA-Z0-9]','').ToLower()
    $kw2     = "$brandKw,fashion"

    # Primary image: article-type focused
    $url1     = "https://loremflickr.com/640/480/$kw1`?lock=$pNum"
    $altText1 = Esc-SQL "$($p.Name) - main view"
    $id1      = New-Guid2
    $mediaRows.Add("  ('$id1', '$($p.Id)', '$url1', 'IMAGE', '$altText1', 0, '$NOW', '$NOW', 'ACTIVE')")

    # Secondary image: brand/style variation using a different lock offset
    $lock2    = $pNum + 5000
    $url2     = "https://loremflickr.com/640/480/$kw1`?lock=$lock2"
    $altText2 = Esc-SQL "$($p.Name) - detail view"
    $id2      = New-Guid2
    $mediaRows.Add("  ('$id2', '$($p.Id)', '$url2', 'IMAGE', '$altText2', 1, '$NOW', '$NOW', 'ACTIVE')")
}

$out = [System.Collections.Generic.List[string]]::new()
$out.Add("-- ================================================================")
$out.Add("-- SEED MEDIA: product_service.product_media")
$out.Add("-- $($mediaRows.Count) rows (2 images per product, loremflickr.com)")
$out.Add("-- Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$out.Add("-- ================================================================")
$out.Add("")
$out.Add("USE product_service;")
$out.Add("")

$arr = $mediaRows.ToArray()
$i = 0
while ($i -lt $arr.Count) {
    $end   = [Math]::Min($i + $BATCHSZ, $arr.Count)
    $chunk = $arr[$i..($end - 1)]
    $out.Add("INSERT INTO product_media (id, product_id, url, media_type, alt_text, sort_order, created_at, updated_at, status) VALUES")
    $out.Add(($chunk -join ",`n") + ";")
    $out.Add("")
    $i = $i + $BATCHSZ
}

$out.Add("-- ================================================================")
$out.Add("-- Done. $($products.Count) products x 2 images = $($mediaRows.Count) rows")
$out.Add("-- ================================================================")

$out | Out-File -FilePath $OUT_PATH -Encoding utf8

Write-Host ""
Write-Host "Done! -> $OUT_PATH ($($mediaRows.Count) media rows)"
