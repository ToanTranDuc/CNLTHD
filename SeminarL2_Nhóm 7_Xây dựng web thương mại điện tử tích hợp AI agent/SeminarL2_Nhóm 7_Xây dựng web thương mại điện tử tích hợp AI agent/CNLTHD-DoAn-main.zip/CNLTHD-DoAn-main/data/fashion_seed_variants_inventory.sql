-- ================================================================
-- FASHION SEED – VARIANTS + MEDIA + INVENTORY ONLY
-- Đã fix: sku→sku_code, size enum, color enum
-- size enum : XS S M L XL XXL XXXL ONE_SIZE
-- color enum: BEIGE BLACK BLUE BROWN CREAM GRAY GREEN
--             KHAKI NAVY OLIVE ORANGE PINK PURPLE RED WHITE YELLOW
-- ================================================================

-- ─── PRODUCT SERVICE ────────────────────────────────────────────
USE product_service;

-- ════════════════════════════════════════════════════════════════
-- PRODUCT VARIANTS  (59 variants)
-- ════════════════════════════════════════════════════════════════
INSERT INTO product_variants (id, product_id, size, color, price, sku_code, created_at, updated_at, status) VALUES

-- ── p01: Nike Men Air Relentless White Sports Shoes ──────────
-- size S=EU39-40 | M=EU41-42 | L=EU43-44
('f3000000-0000-0000-0000-000000000001','f2000000-0000-0000-0000-000000000001','S', 'WHITE',  2100000,'NK-AIRL01-WHT-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000002','f2000000-0000-0000-0000-000000000001','M', 'WHITE',  2100000,'NK-AIRL01-WHT-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000003','f2000000-0000-0000-0000-000000000001','L', 'BLACK',  2300000,'NK-AIRL01-BLK-L', NOW(),NOW(),'ACTIVE'),

-- ── p02: Adidas Men Ultraboost 22 Black Sports Shoes ─────────
('f3000000-0000-0000-0000-000000000004','f2000000-0000-0000-0000-000000000002','S', 'BLACK',  3200000,'AD-UBST01-BLK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000005','f2000000-0000-0000-0000-000000000002','M', 'BLACK',  3200000,'AD-UBST01-BLK-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000006','f2000000-0000-0000-0000-000000000002','L', 'WHITE',  3400000,'AD-UBST01-WHT-L', NOW(),NOW(),'ACTIVE'),

-- ── p05: Nike Women Air Zoom Pegasus Pink ────────────────────
('f3000000-0000-0000-0000-000000000007','f2000000-0000-0000-0000-000000000005','S', 'PINK',   1900000,'NK-WPEG01-PNK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000008','f2000000-0000-0000-0000-000000000005','M', 'PINK',   1900000,'NK-WPEG01-PNK-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000009','f2000000-0000-0000-0000-000000000005','L', 'WHITE',  1900000,'NK-WPEG01-WHT-L', NOW(),NOW(),'ACTIVE'),

-- ── p03: Puma Men Future Cat Black Casual Shoes ───────────────
('f3000000-0000-0000-0000-000000000010','f2000000-0000-0000-0000-000000000003','S', 'BLACK',  1850000,'PM-FCAT01-BLK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000011','f2000000-0000-0000-0000-000000000003','M', 'BLACK',  1850000,'PM-FCAT01-BLK-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000012','f2000000-0000-0000-0000-000000000003','L', 'BLACK',  1850000,'PM-FCAT01-BLK-L', NOW(),NOW(),'ACTIVE'),

-- ── p04: Vans Classic Slip-On ─────────────────────────────────
('f3000000-0000-0000-0000-000000000013','f2000000-0000-0000-0000-000000000004','S', 'BLACK',  1500000,'VN-SLIP01-BLK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000014','f2000000-0000-0000-0000-000000000004','M', 'PURPLE', 1550000,'VN-SLIP01-PRP-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000015','f2000000-0000-0000-0000-000000000004','L', 'BLACK',  1500000,'VN-SLIP01-BLK-L', NOW(),NOW(),'ACTIVE'),

-- ── p06: Nike Men Dri-FIT Black T-shirt ──────────────────────
('f3000000-0000-0000-0000-000000000016','f2000000-0000-0000-0000-000000000006','S', 'BLACK',   450000,'NK-DRFT01-BLK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000017','f2000000-0000-0000-0000-000000000006','M', 'BLACK',   450000,'NK-DRFT01-BLK-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000018','f2000000-0000-0000-0000-000000000006','L', 'WHITE',   450000,'NK-DRFT01-WHT-L', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000019','f2000000-0000-0000-0000-000000000006','XL','BLACK',   450000,'NK-DRFT01-BLK-XL',NOW(),NOW(),'ACTIVE'),

-- ── p07: Adidas Men Club Blue Polo ────────────────────────────
('f3000000-0000-0000-0000-000000000020','f2000000-0000-0000-0000-000000000007','S', 'BLUE',    420000,'AD-POLO01-BLU-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000021','f2000000-0000-0000-0000-000000000007','M', 'BLUE',    420000,'AD-POLO01-BLU-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000022','f2000000-0000-0000-0000-000000000007','L', 'NAVY',    420000,'AD-POLO01-NVY-L', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000023','f2000000-0000-0000-0000-000000000007','XL','NAVY',    440000,'AD-POLO01-NVY-XL',NOW(),NOW(),'ACTIVE'),

-- ── p08: Puma Men Scribble Grey Sweatshirt ────────────────────
('f3000000-0000-0000-0000-000000000024','f2000000-0000-0000-0000-000000000008','S', 'GRAY',    850000,'PM-SWT01-GRY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000025','f2000000-0000-0000-0000-000000000008','M', 'GRAY',    850000,'PM-SWT01-GRY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000026','f2000000-0000-0000-0000-000000000008','L', 'BLACK',   900000,'PM-SWT01-BLK-L',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000027','f2000000-0000-0000-0000-000000000008','XL','BLACK',   900000,'PM-SWT01-BLK-XL', NOW(),NOW(),'ACTIVE'),

-- ── p09: Nike Women Purple Polo ───────────────────────────────
('f3000000-0000-0000-0000-000000000028','f2000000-0000-0000-0000-000000000009','XS','PURPLE',  420000,'NK-WPLO01-PRP-XS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000029','f2000000-0000-0000-0000-000000000009','S', 'PURPLE',  420000,'NK-WPLO01-PRP-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000030','f2000000-0000-0000-0000-000000000009','M', 'WHITE',   420000,'NK-WPLO01-WHT-M', NOW(),NOW(),'ACTIVE'),

-- ── p10: Manchester United Men Red T-shirt ────────────────────
('f3000000-0000-0000-0000-000000000031','f2000000-0000-0000-0000-000000000010','S', 'RED',     550000,'MU-TSH01-RED-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000032','f2000000-0000-0000-0000-000000000010','M', 'RED',     550000,'MU-TSH01-RED-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000033','f2000000-0000-0000-0000-000000000010','L', 'BLACK',   550000,'MU-TSH01-BLK-L',  NOW(),NOW(),'ACTIVE'),

-- ── p11: Levis Men 511 Blue Jeans ─────────────────────────────
-- S=W28-30 | M=W32 | L=W34
('f3000000-0000-0000-0000-000000000034','f2000000-0000-0000-0000-000000000011','S', 'BLUE',   1200000,'LV-511-BLU-S',    NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000035','f2000000-0000-0000-0000-000000000011','M', 'BLUE',   1200000,'LV-511-BLU-M',    NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000036','f2000000-0000-0000-0000-000000000011','L', 'BLACK',  1250000,'LV-511-BLK-L',    NOW(),NOW(),'ACTIVE'),

-- ── p12: Jealous 21 Women Black Jeans ────────────────────────
('f3000000-0000-0000-0000-000000000037','f2000000-0000-0000-0000-000000000012','XS','BLACK',   950000,'J21-SLM-BLK-XS',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000038','f2000000-0000-0000-0000-000000000012','S', 'BLACK',   950000,'J21-SLM-BLK-S',   NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000039','f2000000-0000-0000-0000-000000000012','M', 'BLUE',    980000,'J21-SLM-BLU-M',   NOW(),NOW(),'ACTIVE'),

-- ── p13: Puma Men Black Bermuda Shorts ────────────────────────
('f3000000-0000-0000-0000-000000000040','f2000000-0000-0000-0000-000000000013','S', 'BLACK',   480000,'PM-BRM01-BLK-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000041','f2000000-0000-0000-0000-000000000013','M', 'BLACK',   480000,'PM-BRM01-BLK-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000042','f2000000-0000-0000-0000-000000000013','L', 'GRAY',    480000,'PM-BRM01-GRY-L',  NOW(),NOW(),'ACTIVE'),

-- ── p14: Nike Women Pink Shorts ───────────────────────────────
('f3000000-0000-0000-0000-000000000043','f2000000-0000-0000-0000-000000000014','XS','PINK',    520000,'NK-WSHT01-PNK-XS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000044','f2000000-0000-0000-0000-000000000014','S', 'PINK',    520000,'NK-WSHT01-PNK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000045','f2000000-0000-0000-0000-000000000014','M', 'BLACK',   520000,'NK-WSHT01-BLK-M', NOW(),NOW(),'ACTIVE'),

-- ── p20: Levis Men Grey Innerwear Vest ────────────────────────
('f3000000-0000-0000-0000-000000000046','f2000000-0000-0000-0000-000000000020','S', 'GRAY',    280000,'LV-VST01-GRY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000047','f2000000-0000-0000-0000-000000000020','M', 'GRAY',    280000,'LV-VST01-GRY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000048','f2000000-0000-0000-0000-000000000020','L', 'WHITE',   280000,'LV-VST01-WHT-L',  NOW(),NOW(),'ACTIVE'),

-- ── p15: Nike Unisex Black Backpack ───────────────────────────
('f3000000-0000-0000-0000-000000000049','f2000000-0000-0000-0000-000000000015','ONE_SIZE','BLACK',  1490000,'NK-BKPK01-BLK-OS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000050','f2000000-0000-0000-0000-000000000015','ONE_SIZE','GRAY',   1490000,'NK-BKPK01-GRY-OS',NOW(),NOW(),'ACTIVE'),

-- ── p16: Adidas Red Backpack ──────────────────────────────────
('f3000000-0000-0000-0000-000000000051','f2000000-0000-0000-0000-000000000016','ONE_SIZE','RED',    1250000,'AD-BKPK01-RED-OS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000052','f2000000-0000-0000-0000-000000000016','ONE_SIZE','BLACK',  1250000,'AD-BKPK01-BLK-OS',NOW(),NOW(),'ACTIVE'),

-- ── p17: Ray-Ban Sunglasses ───────────────────────────────────
('f3000000-0000-0000-0000-000000000053','f2000000-0000-0000-0000-000000000017','ONE_SIZE','BROWN',  2800000,'RB-SG01-BRN-OS',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000054','f2000000-0000-0000-0000-000000000017','ONE_SIZE','BLACK',  2600000,'RB-SG01-BLK-OS',  NOW(),NOW(),'ACTIVE'),

-- ── p18: Manchester United White Cap ──────────────────────────
('f3000000-0000-0000-0000-000000000055','f2000000-0000-0000-0000-000000000018','ONE_SIZE','WHITE',   380000,'MU-CAP01-WHT-OS', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000056','f2000000-0000-0000-0000-000000000018','ONE_SIZE','RED',     380000,'MU-CAP01-RED-OS', NOW(),NOW(),'ACTIVE'),

-- ── p19: Puma Navy Blue Socks ─────────────────────────────────
('f3000000-0000-0000-0000-000000000057','f2000000-0000-0000-0000-000000000019','S', 'NAVY',    180000,'PM-SCK01-NVY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000058','f2000000-0000-0000-0000-000000000019','M', 'NAVY',    180000,'PM-SCK01-NVY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000059','f2000000-0000-0000-0000-000000000019','L', 'WHITE',   180000,'PM-SCK01-WHT-L',  NOW(),NOW(),'ACTIVE')

ON DUPLICATE KEY UPDATE
  size=VALUES(size), color=VALUES(color), price=VALUES(price),
  updated_at=NOW(), status=VALUES(status);

-- ════════════════════════════════════════════════════════════════
-- PRODUCT MEDIA  (2 ảnh / sản phẩm = 40 records)
-- ════════════════════════════════════════════════════════════════
INSERT INTO product_media (id, product_id, url, media_type, alt_text, sort_order, created_at, updated_at, status) VALUES

-- p01: Nike Men Air Relentless White
('f4000000-0000-0000-0000-000000000001','f2000000-0000-0000-0000-000000000001',
 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Air Relentless White – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000002','f2000000-0000-0000-0000-000000000001',
 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Air Relentless White – side',1,NOW(),NOW(),'ACTIVE'),

-- p02: Adidas Ultraboost Black
('f4000000-0000-0000-0000-000000000003','f2000000-0000-0000-0000-000000000002',
 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Ultraboost 22 Black – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000004','f2000000-0000-0000-0000-000000000002',
 'https://images.unsplash.com/photo-1539185441755-769473a23570?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Ultraboost 22 Black – detail',1,NOW(),NOW(),'ACTIVE'),

-- p05: Nike Women Pink Shoes
('f4000000-0000-0000-0000-000000000005','f2000000-0000-0000-0000-000000000005',
 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Pegasus Pink – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000006','f2000000-0000-0000-0000-000000000005',
 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Pegasus Pink – side',1,NOW(),NOW(),'ACTIVE'),

-- p03: Puma Future Cat Black
('f4000000-0000-0000-0000-000000000007','f2000000-0000-0000-0000-000000000003',
 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Future Cat Black – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000008','f2000000-0000-0000-0000-000000000003',
 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Future Cat Black – angle',1,NOW(),NOW(),'ACTIVE'),

-- p04: Vans Classic Slip-On
('f4000000-0000-0000-0000-000000000009','f2000000-0000-0000-0000-000000000004',
 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Vans Classic Slip-On – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000010','f2000000-0000-0000-0000-000000000004',
 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Vans Classic Slip-On – flat lay',1,NOW(),NOW(),'ACTIVE'),

-- p06: Nike Men Dri-FIT Black T-shirt
('f4000000-0000-0000-0000-000000000011','f2000000-0000-0000-0000-000000000006',
 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Dri-FIT Black – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000012','f2000000-0000-0000-0000-000000000006',
 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Dri-FIT Black – worn',1,NOW(),NOW(),'ACTIVE'),

-- p07: Adidas Men Blue Polo
('f4000000-0000-0000-0000-000000000013','f2000000-0000-0000-0000-000000000007',
 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Club Blue Polo – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000014','f2000000-0000-0000-0000-000000000007',
 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Club Blue Polo – detail',1,NOW(),NOW(),'ACTIVE'),

-- p08: Puma Men Grey Sweatshirt
('f4000000-0000-0000-0000-000000000015','f2000000-0000-0000-0000-000000000008',
 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Scribble Grey Sweatshirt – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000016','f2000000-0000-0000-0000-000000000008',
 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Scribble Grey Sweatshirt – worn',1,NOW(),NOW(),'ACTIVE'),

-- p09: Nike Women Purple Polo
('f4000000-0000-0000-0000-000000000017','f2000000-0000-0000-0000-000000000009',
 'https://images.unsplash.com/photo-1523381294911-8d3cead13475?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Purple Polo – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000018','f2000000-0000-0000-0000-000000000009',
 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Purple Polo – worn',1,NOW(),NOW(),'ACTIVE'),

-- p10: Manchester United Red T-shirt
('f4000000-0000-0000-0000-000000000019','f2000000-0000-0000-0000-000000000010',
 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Red T-shirt – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000020','f2000000-0000-0000-0000-000000000010',
 'https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Red T-shirt – detail',1,NOW(),NOW(),'ACTIVE'),

-- p11: Levis Men Blue Jeans
('f4000000-0000-0000-0000-000000000021','f2000000-0000-0000-0000-000000000011',
 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men 511 Blue Jeans – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000022','f2000000-0000-0000-0000-000000000011',
 'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men 511 Blue Jeans – detail',1,NOW(),NOW(),'ACTIVE'),

-- p12: Jealous 21 Women Black Jeans
('f4000000-0000-0000-0000-000000000023','f2000000-0000-0000-0000-000000000012',
 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Jealous 21 Women Black Jeans – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000024','f2000000-0000-0000-0000-000000000012',
 'https://images.unsplash.com/photo-1555689502-c4b22d76c56f?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Jealous 21 Women Black Jeans – worn',1,NOW(),NOW(),'ACTIVE'),

-- p13: Puma Men Black Shorts
('f4000000-0000-0000-0000-000000000025','f2000000-0000-0000-0000-000000000013',
 'https://images.unsplash.com/photo-1565084888279-aca607ecce0c?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Black Shorts – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000026','f2000000-0000-0000-0000-000000000013',
 'https://images.unsplash.com/photo-1591195853828-11db59a44f43?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Black Shorts – worn',1,NOW(),NOW(),'ACTIVE'),

-- p14: Nike Women Pink Shorts
('f4000000-0000-0000-0000-000000000027','f2000000-0000-0000-0000-000000000014',
 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Pink Shorts – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000028','f2000000-0000-0000-0000-000000000014',
 'https://images.unsplash.com/photo-1571945192669-a39b2e8cae41?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Pink Shorts – worn',1,NOW(),NOW(),'ACTIVE'),

-- p20: Levis Men Grey Vest
('f4000000-0000-0000-0000-000000000029','f2000000-0000-0000-0000-000000000020',
 'https://images.unsplash.com/photo-1547308283-f90048ede2e7?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men Grey Innerwear Vest – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000030','f2000000-0000-0000-0000-000000000020',
 'https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men Grey Innerwear Vest – detail',1,NOW(),NOW(),'ACTIVE'),

-- p15: Nike Black Backpack
('f4000000-0000-0000-0000-000000000031','f2000000-0000-0000-0000-000000000015',
 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Swoosh Black Backpack – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000032','f2000000-0000-0000-0000-000000000015',
 'https://images.unsplash.com/photo-1491637639811-60e2756cc1c7?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Swoosh Black Backpack – worn',1,NOW(),NOW(),'ACTIVE'),

-- p16: Adidas Red Backpack
('f4000000-0000-0000-0000-000000000033','f2000000-0000-0000-0000-000000000016',
 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Bulls Red Backpack – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000034','f2000000-0000-0000-0000-000000000016',
 'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Bulls Red Backpack – side',1,NOW(),NOW(),'ACTIVE'),

-- p17: Ray-Ban Sunglasses
('f4000000-0000-0000-0000-000000000035','f2000000-0000-0000-0000-000000000017',
 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Ray-Ban Copper Sunglasses – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000036','f2000000-0000-0000-0000-000000000017',
 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Ray-Ban Copper Sunglasses – worn',1,NOW(),NOW(),'ACTIVE'),

-- p18: Manchester United White Cap
('f4000000-0000-0000-0000-000000000037','f2000000-0000-0000-0000-000000000018',
 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United White Cap – front',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000038','f2000000-0000-0000-0000-000000000018',
 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United White Cap – worn',1,NOW(),NOW(),'ACTIVE'),

-- p19: Puma Navy Blue Socks
('f4000000-0000-0000-0000-000000000039','f2000000-0000-0000-0000-000000000019',
 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Navy Blue Sports Socks – main',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000040','f2000000-0000-0000-0000-000000000019',
 'https://images.unsplash.com/photo-1559563458-527698bf5295?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Navy Blue Sports Socks – packaged',1,NOW(),NOW(),'ACTIVE')

ON DUPLICATE KEY UPDATE
  url=VALUES(url), alt_text=VALUES(alt_text),
  updated_at=NOW(), status=VALUES(status);


-- ─── INVENTORY SERVICE ──────────────────────────────────────────
USE inventory_service;

-- ════════════════════════════════════════════════════════════════
-- STOCKS
-- ════════════════════════════════════════════════════════════════
INSERT INTO stocks (sku_code, product_name, quantity, version) VALUES
('NK-AIRL01-WHT-S', 'Nike Men Air Relentless White S',       80,0),
('NK-AIRL01-WHT-M', 'Nike Men Air Relentless White M',      120,0),
('NK-AIRL01-BLK-L', 'Nike Men Air Relentless Black L',       65,0),
('AD-UBST01-BLK-S', 'Adidas Ultraboost Black S',             60,0),
('AD-UBST01-BLK-M', 'Adidas Ultraboost Black M',             90,0),
('AD-UBST01-WHT-L', 'Adidas Ultraboost White L',             45,0),
('NK-WPEG01-PNK-S', 'Nike Women Pegasus Pink S',             50,0),
('NK-WPEG01-PNK-M', 'Nike Women Pegasus Pink M',             75,0),
('NK-WPEG01-WHT-L', 'Nike Women Pegasus White L',            55,0),
('PM-FCAT01-BLK-S', 'Puma Future Cat Black S',              100,0),
('PM-FCAT01-BLK-M', 'Puma Future Cat Black M',              130,0),
('PM-FCAT01-BLK-L', 'Puma Future Cat Black L',               90,0),
('VN-SLIP01-BLK-S', 'Vans Slip-On Black S',                 110,0),
('VN-SLIP01-PRP-M', 'Vans Slip-On Purple M',                 40,0),
('VN-SLIP01-BLK-L', 'Vans Slip-On Black L',                  85,0),
('NK-DRFT01-BLK-S', 'Nike Dri-FIT Black T-shirt S',         150,0),
('NK-DRFT01-BLK-M', 'Nike Dri-FIT Black T-shirt M',         200,0),
('NK-DRFT01-WHT-L', 'Nike Dri-FIT White T-shirt L',         180,0),
('NK-DRFT01-BLK-XL','Nike Dri-FIT Black T-shirt XL',        120,0),
('AD-POLO01-BLU-S', 'Adidas Club Blue Polo S',              100,0),
('AD-POLO01-BLU-M', 'Adidas Club Blue Polo M',              150,0),
('AD-POLO01-NVY-L', 'Adidas Club Navy Polo L',              130,0),
('AD-POLO01-NVY-XL','Adidas Club Navy Polo XL',              80,0),
('PM-SWT01-GRY-S',  'Puma Sweatshirt Gray S',                60,0),
('PM-SWT01-GRY-M',  'Puma Sweatshirt Gray M',                90,0),
('PM-SWT01-BLK-L',  'Puma Sweatshirt Black L',               70,0),
('PM-SWT01-BLK-XL', 'Puma Sweatshirt Black XL',              50,0),
('NK-WPLO01-PRP-XS','Nike Women Purple Polo XS',             45,0),
('NK-WPLO01-PRP-S', 'Nike Women Purple Polo S',              80,0),
('NK-WPLO01-WHT-M', 'Nike Women White Polo M',               95,0),
('MU-TSH01-RED-S',  'Manchester United Red T-shirt S',      120,0),
('MU-TSH01-RED-M',  'Manchester United Red T-shirt M',      160,0),
('MU-TSH01-BLK-L',  'Manchester United Black T-shirt L',     90,0),
('LV-511-BLU-S',    'Levis 511 Blue Jeans S',                70,0),
('LV-511-BLU-M',    'Levis 511 Blue Jeans M',               100,0),
('LV-511-BLK-L',    'Levis 511 Black Jeans L',               55,0),
('J21-SLM-BLK-XS',  'Jealous21 Women Black Jeans XS',        60,0),
('J21-SLM-BLK-S',   'Jealous21 Women Black Jeans S',         85,0),
('J21-SLM-BLU-M',   'Jealous21 Women Blue Jeans M',          70,0),
('PM-BRM01-BLK-S',  'Puma Black Shorts S',                  110,0),
('PM-BRM01-BLK-M',  'Puma Black Shorts M',                  150,0),
('PM-BRM01-GRY-L',  'Puma Gray Shorts L',                    80,0),
('NK-WSHT01-PNK-XS','Nike Women Pink Shorts XS',             50,0),
('NK-WSHT01-PNK-S', 'Nike Women Pink Shorts S',              90,0),
('NK-WSHT01-BLK-M', 'Nike Women Black Shorts M',            100,0),
('LV-VST01-GRY-S',  'Levis Men Gray Vest S',                120,0),
('LV-VST01-GRY-M',  'Levis Men Gray Vest M',                180,0),
('LV-VST01-WHT-L',  'Levis Men White Vest L',               140,0),
('NK-BKPK01-BLK-OS','Nike Swoosh Black Backpack',           200,0),
('NK-BKPK01-GRY-OS','Nike Swoosh Gray Backpack',             80,0),
('AD-BKPK01-RED-OS','Adidas Bulls Red Backpack',            150,0),
('AD-BKPK01-BLK-OS','Adidas Bulls Black Backpack',          100,0),
('RB-SG01-BRN-OS',  'Ray-Ban Brown Sunglasses',              35,0),
('RB-SG01-BLK-OS',  'Ray-Ban Black Sunglasses',              50,0),
('MU-CAP01-WHT-OS', 'Manchester United White Cap',          200,0),
('MU-CAP01-RED-OS', 'Manchester United Red Cap',            150,0),
('PM-SCK01-NVY-S',  'Puma Navy Socks S',                    300,0),
('PM-SCK01-NVY-M',  'Puma Navy Socks M',                    400,0),
('PM-SCK01-WHT-L',  'Puma White Socks L',                   250,0)

ON DUPLICATE KEY UPDATE
  product_name=VALUES(product_name),
  quantity=VALUES(quantity),
  version=VALUES(version);

-- ════════════════════════════════════════════════════════════════
-- INVENTORY LOG  (chỉ insert nếu chưa có log nhập kho ban đầu)
-- ════════════════════════════════════════════════════════════════
INSERT INTO inventory_log
  (sku_code, operation_type, quantity_change, balance_after, reference_id, reason, created_by, created_at)
SELECT s.sku_code,'IN',s.quantity,s.quantity,
       CONCAT('INIT-',s.sku_code),'Nhập kho ban đầu – fashion seed','system',NOW()
FROM inventory_service.stocks s
WHERE s.sku_code NOT IN (
  SELECT sku_code FROM inventory_service.inventory_log WHERE reference_id LIKE 'INIT-%'
);
