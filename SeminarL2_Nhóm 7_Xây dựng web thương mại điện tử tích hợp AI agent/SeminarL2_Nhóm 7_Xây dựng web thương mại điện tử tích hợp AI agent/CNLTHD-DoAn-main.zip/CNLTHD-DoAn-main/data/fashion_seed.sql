-- ================================================================
-- FASHION SEED DATA  –  Based on styles_nike_style.csv
-- Databases : product_service  |  inventory_service
-- Products  : 20  |  Variants : 56  |  Media : 40 images
-- Chạy SAU khi Hibernate/ALL_PROJECT_SQL.sql đã tạo tables
-- ================================================================

-- ─── PRODUCT SERVICE ────────────────────────────────────────────
USE product_service;

-- ════════════════════════════════════════════════════════════════
-- CATEGORIES  (3 root + 9 sub = 12)
-- ════════════════════════════════════════════════════════════════
INSERT INTO categories (id, name, description, slug, parent_id, created_at, updated_at, status) VALUES
-- Root
('f1000000-0000-0000-0000-000000000001', 'Footwear',    'Giày dép các loại',              'footwear',    NULL,                                   NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000004', 'Apparel',     'Quần áo thời trang',             'apparel',     NULL,                                   NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000008', 'Accessories', 'Phụ kiện thời trang',            'accessories', NULL,                                   NOW(), NOW(), 'ACTIVE'),
-- Footwear sub
('f1000000-0000-0000-0000-000000000002', 'Casual Shoes','Giày casual hàng ngày',          'casual-shoes','f1000000-0000-0000-0000-000000000001', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000003', 'Sports Shoes','Giày thể thao chuyên dụng',      'sports-shoes','f1000000-0000-0000-0000-000000000001', NOW(), NOW(), 'ACTIVE'),
-- Apparel sub
('f1000000-0000-0000-0000-000000000005', 'Topwear',    'Áo thun, polo, sweatshirt',       'topwear',     'f1000000-0000-0000-0000-000000000004', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000006', 'Bottomwear', 'Quần jeans, short, track pants',  'bottomwear',  'f1000000-0000-0000-0000-000000000004', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000007', 'Innerwear',  'Áo lót ba lỗ, quần lót',         'innerwear',   'f1000000-0000-0000-0000-000000000004', NOW(), NOW(), 'ACTIVE'),
-- Accessories sub
('f1000000-0000-0000-0000-000000000009', 'Bags',       'Balo, túi xách',                  'bags',        'f1000000-0000-0000-0000-000000000008', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000010', 'Eyewear',    'Kính mát, kính râm',              'eyewear',     'f1000000-0000-0000-0000-000000000008', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000011', 'Headwear',   'Mũ lưỡi trai, nón',              'headwear',    'f1000000-0000-0000-0000-000000000008', NOW(), NOW(), 'ACTIVE'),
('f1000000-0000-0000-0000-000000000012', 'Socks',      'Vớ, tất thể thao',               'socks',       'f1000000-0000-0000-0000-000000000008', NOW(), NOW(), 'ACTIVE')
ON DUPLICATE KEY UPDATE name=VALUES(name), updated_at=NOW(), status=VALUES(status);

-- ════════════════════════════════════════════════════════════════
-- PRODUCTS  (20)
-- ════════════════════════════════════════════════════════════════
INSERT INTO products (id, name, description, brand, country, base_price, slug, category_id, created_at, updated_at, status) VALUES

-- ── Sports Shoes ──────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000001',
 'Nike Men Air Relentless 2 MSL White Sports Shoes',
 'Giày chạy bộ Nike Air Relentless với đệm khí thoải mái và đế cao su chống trượt. Thiết kế lưới thoáng khí, phù hợp tập gym và chạy bộ hàng ngày.',
 'Nike', 'USA', 2100000, 'nike-men-air-relentless-white',
 'f1000000-0000-0000-0000-000000000003', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000002',
 'Adidas Men Ultraboost 22 Black Sports Shoes',
 'Giày chạy bộ Adidas Ultraboost 22 với công nghệ Boost cho cảm giác đệm êm ái, upper Primeknit ôm sát và thoáng khí xuất sắc.',
 'Adidas', 'Germany', 3200000, 'adidas-men-ultraboost-22-black',
 'f1000000-0000-0000-0000-000000000003', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000005',
 'Nike Women Air Zoom Pegasus Pink Sports Shoes',
 'Giày chạy bộ Nike Air Zoom Pegasus nữ với đệm Zoom Air phản hồi nhanh, nhẹ và thoáng khí. Thiết kế màu hồng năng động.',
 'Nike', 'USA', 1900000, 'nike-women-air-zoom-pegasus-pink',
 'f1000000-0000-0000-0000-000000000003', NOW(), NOW(), 'ACTIVE'),

-- ── Casual Shoes ──────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000003',
 'Puma Men Future Cat Remix SF Black Casual Shoes',
 'Giày casual Puma Future Cat lấy cảm hứng từ đường đua. Upper da tổng hợp mịn mà, đế chunky bền bỉ, phong cách retro.',
 'Puma', 'Germany', 1850000, 'puma-men-future-cat-black',
 'f1000000-0000-0000-0000-000000000002', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000004',
 'Vans Men Classic Slip-On Black & Purple Casual Shoes',
 'Giày Vans Classic Slip-On kinh điển, không dây, canvas bền chắc. Đế Waffle bánh quế đặc trưng, dễ phối đồ mọi phong cách.',
 'Vans', 'USA', 1500000, 'vans-men-classic-slip-on',
 'f1000000-0000-0000-0000-000000000002', NOW(), NOW(), 'ACTIVE'),

-- ── Topwear ───────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000006',
 'Nike Men Dri-FIT Black T-shirt',
 'Áo thun Nike Dri-FIT công nghệ thấm hút mồ hôi nhanh. Polyester nhẹ thoáng mát, phù hợp tập luyện và mặc casual hàng ngày.',
 'Nike', 'Vietnam', 450000, 'nike-men-dri-fit-black-tshirt',
 'f1000000-0000-0000-0000-000000000005', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000007',
 'Adidas Men Club 3-Stripe Blue Polo T-shirt',
 'Áo polo Adidas Men Club chất liệu piqué cotton thoáng mát. Sọc 3 vạch đặc trưng, cổ bẻ thanh lịch. Phù hợp thể thao và casual.',
 'Adidas', 'Vietnam', 420000, 'adidas-men-club-blue-polo',
 'f1000000-0000-0000-0000-000000000005', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000008',
 'Puma Men Scribble Grey Sweatshirt',
 'Áo sweatshirt Puma fleece dày dặn giữ ấm tốt. Logo Puma in phản quang nổi bật, phong cách thể thao năng động mùa thu đông.',
 'Puma', 'Vietnam', 850000, 'puma-men-scribble-grey-sweatshirt',
 'f1000000-0000-0000-0000-000000000005', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000009',
 'Nike Women Purple Polo T-shirt',
 'Áo polo nữ Nike màu tím thanh lịch. Cotton-poly blend mềm mại, dáng slim fit tôn vóc dáng, cổ polo trẻ trung.',
 'Nike', 'Vietnam', 420000, 'nike-women-purple-polo',
 'f1000000-0000-0000-0000-000000000005', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000010',
 'Manchester United Men Solid Red T-shirt',
 'Áo thun Manchester United màu đỏ đặc trưng, logo CLB thêu tinh tế. Cotton 100% thoáng mát, dành cho fan MU.',
 'Manchester United', 'UK', 550000, 'manchester-united-men-red-tshirt',
 'f1000000-0000-0000-0000-000000000005', NOW(), NOW(), 'ACTIVE'),

-- ── Bottomwear ────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000011',
 'Levis Men 511 Slim Blue Jeans',
 'Quần jeans Levis 511 dáng slim fit co giãn 2 chiều. Denim 99% cotton + 1% elastane, wash indigo cổ điển không bao giờ lỗi mốt.',
 'Levis', 'USA', 1200000, 'levis-men-511-slim-blue-jeans',
 'f1000000-0000-0000-0000-000000000006', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000012',
 'Jealous 21 Women Black Slim Jeans',
 'Quần jeans nữ Jealous 21 dáng slim màu đen thời trang. Denim co giãn 4 chiều, tôn dáng và thoải mái suốt ngày dài.',
 'Jealous 21', 'India', 950000, 'jealous-21-women-black-slim-jeans',
 'f1000000-0000-0000-0000-000000000006', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000013',
 'Puma Men Long Logo Black Bermuda Shorts',
 'Quần short thể thao Puma dáng bermuda màu đen. Polyester khô nhanh thoáng mát, logo Puma lớn ở đùi, phù hợp gym và casual.',
 'Puma', 'Vietnam', 480000, 'puma-men-long-logo-black-shorts',
 'f1000000-0000-0000-0000-000000000006', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000014',
 'Nike Women Solid Pink Sports Shorts',
 'Quần short thể thao nữ Nike màu hồng năng động. Dri-FIT thoáng khí, lưng thun co giãn thoải mái khi chạy bộ và yoga.',
 'Nike', 'Vietnam', 520000, 'nike-women-solid-pink-shorts',
 'f1000000-0000-0000-0000-000000000006', NOW(), NOW(), 'ACTIVE'),

-- ── Innerwear ─────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000020',
 'Levis Men Comfort Style Grey Innerwear Vest',
 'Áo thun lót nam Levis cotton-modal mềm mại co giãn 2 chiều. Cổ tròn classic, mỏng nhẹ thoáng mát, mặc trong hoặc ngoài đều đẹp.',
 'Levis', 'USA', 280000, 'levis-men-comfort-grey-innerwear-vest',
 'f1000000-0000-0000-0000-000000000007', NOW(), NOW(), 'ACTIVE'),

-- ── Bags ──────────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000015',
 'Nike Unisex Swoosh Black Backpack',
 'Balo Nike Swoosh logo iconic. Ngăn chính rộng rãi, ngăn laptop riêng biệt, dây đeo có đệm êm. Polyester bền, phù hợp học và tập gym.',
 'Nike', 'Vietnam', 1490000, 'nike-unisex-swoosh-black-backpack',
 'f1000000-0000-0000-0000-000000000009', NOW(), NOW(), 'ACTIVE'),

('f2000000-0000-0000-0000-000000000016',
 'Adidas Unisex Chicago Bulls Red Backpack',
 'Balo Adidas phiên bản Chicago Bulls màu đỏ đặc trưng. Dung tích 25L, logo Bulls nổi bật, dây đeo có đệm, phù hợp đi học và gym.',
 'Adidas', 'Vietnam', 1250000, 'adidas-unisex-chicago-bulls-red-backpack',
 'f1000000-0000-0000-0000-000000000009', NOW(), NOW(), 'ACTIVE'),

-- ── Eyewear ───────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000017',
 'Ray-Ban Men Active Lifestyle Copper Sunglasses',
 'Kính mát Ray-Ban Active Lifestyle gọng acetate nhẹ, tròng polarized chống UV400. Kiểu dáng Aviator thanh lịch, bảo vệ mắt tối ưu.',
 'Ray-Ban', 'Italy', 2800000, 'ray-ban-men-active-copper-sunglasses',
 'f1000000-0000-0000-0000-000000000010', NOW(), NOW(), 'ACTIVE'),

-- ── Headwear ──────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000018',
 'Manchester United Men Solid White Cap',
 'Mũ lưỡi trai Manchester United màu trắng, logo CLB thêu sắc nét. Cotton 100%, dây điều chỉnh size linh hoạt phía sau.',
 'Manchester United', 'UK', 380000, 'manchester-united-men-white-cap',
 'f1000000-0000-0000-0000-000000000011', NOW(), NOW(), 'ACTIVE'),

-- ── Socks ─────────────────────────────────────────────────────
('f2000000-0000-0000-0000-000000000019',
 'Puma Men Pack of 3 Navy Blue Sports Socks',
 'Bộ 3 đôi tất thể thao Puma màu xanh Navy. Cotton-polyester co giãn tốt, phần gót và mũi gia cố chắc chắn, thoáng mát.',
 'Puma', 'Vietnam', 180000, 'puma-men-3-pack-navy-blue-socks',
 'f1000000-0000-0000-0000-000000000012', NOW(), NOW(), 'ACTIVE')

ON DUPLICATE KEY UPDATE
  name=VALUES(name), description=VALUES(description), base_price=VALUES(base_price),
  brand=VALUES(brand), updated_at=NOW(), status=VALUES(status);

-- ════════════════════════════════════════════════════════════════
-- PRODUCT VARIANTS  (56 total)
-- SKU format: {BRAND}-{PRODUCT_CODE}-{COLOR}-{SIZE}
-- ════════════════════════════════════════════════════════════════
INSERT INTO product_variants (id, product_id, size, color, price, sku, created_at, updated_at, status) VALUES

-- ── p01: Nike Men Air Relentless White Sports Shoes ──────────
('f3000000-0000-0000-0000-000000000001','f2000000-0000-0000-0000-000000000001','40','WHITE',   2100000,'NK-AIRL01-WHT-40',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000002','f2000000-0000-0000-0000-000000000001','41','WHITE',   2100000,'NK-AIRL01-WHT-41',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000003','f2000000-0000-0000-0000-000000000001','42','BLACK',   2300000,'NK-AIRL01-BLK-42',NOW(),NOW(),'ACTIVE'),

-- ── p02: Adidas Men Ultraboost 22 Black Sports Shoes ─────────
('f3000000-0000-0000-0000-000000000004','f2000000-0000-0000-0000-000000000002','40','BLACK',   3200000,'AD-UBST01-BLK-40',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000005','f2000000-0000-0000-0000-000000000002','41','BLACK',   3200000,'AD-UBST01-BLK-41',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000006','f2000000-0000-0000-0000-000000000002','42','WHITE',   3400000,'AD-UBST01-WHT-42',NOW(),NOW(),'ACTIVE'),

-- ── p05: Nike Women Air Zoom Pegasus Pink ────────────────────
('f3000000-0000-0000-0000-000000000007','f2000000-0000-0000-0000-000000000005','36','PINK',    1900000,'NK-WPEG01-PNK-36',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000008','f2000000-0000-0000-0000-000000000005','37','PINK',    1900000,'NK-WPEG01-PNK-37',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000009','f2000000-0000-0000-0000-000000000005','38','WHITE',   1900000,'NK-WPEG01-WHT-38',NOW(),NOW(),'ACTIVE'),

-- ── p03: Puma Men Future Cat Black Casual Shoes ───────────────
('f3000000-0000-0000-0000-000000000010','f2000000-0000-0000-0000-000000000003','40','BLACK',   1850000,'PM-FCAT01-BLK-40',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000011','f2000000-0000-0000-0000-000000000003','41','BLACK',   1850000,'PM-FCAT01-BLK-41',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000012','f2000000-0000-0000-0000-000000000003','42','BLACK',   1850000,'PM-FCAT01-BLK-42',NOW(),NOW(),'ACTIVE'),

-- ── p04: Vans Classic Slip-On ─────────────────────────────────
('f3000000-0000-0000-0000-000000000013','f2000000-0000-0000-0000-000000000004','40','BLACK',   1500000,'VN-SLIP01-BLK-40',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000014','f2000000-0000-0000-0000-000000000004','41','PURPLE',  1550000,'VN-SLIP01-PRP-41',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000015','f2000000-0000-0000-0000-000000000004','42','BLACK',   1500000,'VN-SLIP01-BLK-42',NOW(),NOW(),'ACTIVE'),

-- ── p06: Nike Men Dri-FIT Black T-shirt ──────────────────────
('f3000000-0000-0000-0000-000000000016','f2000000-0000-0000-0000-000000000006','S', 'BLACK',    450000,'NK-DRFT01-BLK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000017','f2000000-0000-0000-0000-000000000006','M', 'BLACK',    450000,'NK-DRFT01-BLK-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000018','f2000000-0000-0000-0000-000000000006','L', 'WHITE',    450000,'NK-DRFT01-WHT-L', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000019','f2000000-0000-0000-0000-000000000006','XL','BLACK',    450000,'NK-DRFT01-BLK-XL',NOW(),NOW(),'ACTIVE'),

-- ── p07: Adidas Men Club Blue Polo ────────────────────────────
('f3000000-0000-0000-0000-000000000020','f2000000-0000-0000-0000-000000000007','S', 'BLUE',     420000,'AD-POLO01-BLU-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000021','f2000000-0000-0000-0000-000000000007','M', 'BLUE',     420000,'AD-POLO01-BLU-M', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000022','f2000000-0000-0000-0000-000000000007','L', 'NAVY BLUE',420000,'AD-POLO01-NVY-L', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000023','f2000000-0000-0000-0000-000000000007','XL','NAVY BLUE',440000,'AD-POLO01-NVY-XL',NOW(),NOW(),'ACTIVE'),

-- ── p08: Puma Men Scribble Grey Sweatshirt ────────────────────
('f3000000-0000-0000-0000-000000000024','f2000000-0000-0000-0000-000000000008','S', 'GREY',     850000,'PM-SWT01-GRY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000025','f2000000-0000-0000-0000-000000000008','M', 'GREY',     850000,'PM-SWT01-GRY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000026','f2000000-0000-0000-0000-000000000008','L', 'BLACK',    900000,'PM-SWT01-BLK-L',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000027','f2000000-0000-0000-0000-000000000008','XL','BLACK',    900000,'PM-SWT01-BLK-XL', NOW(),NOW(),'ACTIVE'),

-- ── p09: Nike Women Purple Polo ───────────────────────────────
('f3000000-0000-0000-0000-000000000028','f2000000-0000-0000-0000-000000000009','XS','PURPLE',   420000,'NK-WPLO01-PRP-XS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000029','f2000000-0000-0000-0000-000000000009','S', 'PURPLE',   420000,'NK-WPLO01-PRP-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000030','f2000000-0000-0000-0000-000000000009','M', 'WHITE',    420000,'NK-WPLO01-WHT-M', NOW(),NOW(),'ACTIVE'),

-- ── p10: Manchester United Men Red T-shirt ────────────────────
('f3000000-0000-0000-0000-000000000031','f2000000-0000-0000-0000-000000000010','S', 'RED',      550000,'MU-TSH01-RED-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000032','f2000000-0000-0000-0000-000000000010','M', 'RED',      550000,'MU-TSH01-RED-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000033','f2000000-0000-0000-0000-000000000010','L', 'BLACK',    550000,'MU-TSH01-BLK-L',  NOW(),NOW(),'ACTIVE'),

-- ── p11: Levis Men 511 Blue Jeans ─────────────────────────────
('f3000000-0000-0000-0000-000000000034','f2000000-0000-0000-0000-000000000011','30','BLUE',    1200000,'LV-511-BLU-30',   NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000035','f2000000-0000-0000-0000-000000000011','32','BLUE',    1200000,'LV-511-BLU-32',   NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000036','f2000000-0000-0000-0000-000000000011','34','BLACK',   1250000,'LV-511-BLK-34',   NOW(),NOW(),'ACTIVE'),

-- ── p12: Jealous 21 Women Black Jeans ────────────────────────
('f3000000-0000-0000-0000-000000000037','f2000000-0000-0000-0000-000000000012','26','BLACK',    950000,'J21-SLM-BLK-26',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000038','f2000000-0000-0000-0000-000000000012','28','BLACK',    950000,'J21-SLM-BLK-28',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000039','f2000000-0000-0000-0000-000000000012','30','BLUE',     980000,'J21-SLM-BLU-30',  NOW(),NOW(),'ACTIVE'),

-- ── p13: Puma Men Black Bermuda Shorts ────────────────────────
('f3000000-0000-0000-0000-000000000040','f2000000-0000-0000-0000-000000000013','S', 'BLACK',    480000,'PM-BRM01-BLK-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000041','f2000000-0000-0000-0000-000000000013','M', 'BLACK',    480000,'PM-BRM01-BLK-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000042','f2000000-0000-0000-0000-000000000013','L', 'GREY',     480000,'PM-BRM01-GRY-L',  NOW(),NOW(),'ACTIVE'),

-- ── p14: Nike Women Pink Shorts ───────────────────────────────
('f3000000-0000-0000-0000-000000000043','f2000000-0000-0000-0000-000000000014','XS','PINK',     520000,'NK-WSHT01-PNK-XS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000044','f2000000-0000-0000-0000-000000000014','S', 'PINK',     520000,'NK-WSHT01-PNK-S', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000045','f2000000-0000-0000-0000-000000000014','M', 'BLACK',    520000,'NK-WSHT01-BLK-M', NOW(),NOW(),'ACTIVE'),

-- ── p20: Levis Men Grey Innerwear Vest ────────────────────────
('f3000000-0000-0000-0000-000000000046','f2000000-0000-0000-0000-000000000020','S', 'GREY',     280000,'LV-VST01-GRY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000047','f2000000-0000-0000-0000-000000000020','M', 'GREY',     280000,'LV-VST01-GRY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000048','f2000000-0000-0000-0000-000000000020','L', 'WHITE',    280000,'LV-VST01-WHT-L',  NOW(),NOW(),'ACTIVE'),

-- ── p15: Nike Unisex Black Backpack ───────────────────────────
('f3000000-0000-0000-0000-000000000049','f2000000-0000-0000-0000-000000000015','OS','BLACK',   1490000,'NK-BKPK01-BLK-OS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000050','f2000000-0000-0000-0000-000000000015','OS','GREY',    1490000,'NK-BKPK01-GRY-OS',NOW(),NOW(),'ACTIVE'),

-- ── p16: Adidas Red Backpack ──────────────────────────────────
('f3000000-0000-0000-0000-000000000051','f2000000-0000-0000-0000-000000000016','OS','RED',     1250000,'AD-BKPK01-RED-OS',NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000052','f2000000-0000-0000-0000-000000000016','OS','BLACK',   1250000,'AD-BKPK01-BLK-OS',NOW(),NOW(),'ACTIVE'),

-- ── p17: Ray-Ban Copper Sunglasses ────────────────────────────
('f3000000-0000-0000-0000-000000000053','f2000000-0000-0000-0000-000000000017','OS','COPPER',  2800000,'RB-SG01-CPR-OS',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000054','f2000000-0000-0000-0000-000000000017','OS','BLACK',   2600000,'RB-SG01-BLK-OS',  NOW(),NOW(),'ACTIVE'),

-- ── p18: Manchester United White Cap ──────────────────────────
('f3000000-0000-0000-0000-000000000055','f2000000-0000-0000-0000-000000000018','OS','WHITE',    380000,'MU-CAP01-WHT-OS', NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000056','f2000000-0000-0000-0000-000000000018','OS','RED',      380000,'MU-CAP01-RED-OS', NOW(),NOW(),'ACTIVE'),

-- ── p19: Puma Navy Blue Socks ─────────────────────────────────
('f3000000-0000-0000-0000-000000000057','f2000000-0000-0000-0000-000000000019','S', 'NAVY BLUE',180000,'PM-SCK01-NVY-S',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000058','f2000000-0000-0000-0000-000000000019','M', 'NAVY BLUE',180000,'PM-SCK01-NVY-M',  NOW(),NOW(),'ACTIVE'),
('f3000000-0000-0000-0000-000000000059','f2000000-0000-0000-0000-000000000019','L', 'WHITE',    180000,'PM-SCK01-WHT-L',  NOW(),NOW(),'ACTIVE')

ON DUPLICATE KEY UPDATE
  size=VALUES(size), color=VALUES(color), price=VALUES(price), updated_at=NOW(), status=VALUES(status);

-- ════════════════════════════════════════════════════════════════
-- PRODUCT MEDIA  (2 images per product = 40 records)
-- Nguồn ảnh: Unsplash (ảnh thật, public domain)
-- ════════════════════════════════════════════════════════════════
INSERT INTO product_media (id, product_id, url, media_type, alt_text, sort_order, created_at, updated_at, status) VALUES

-- p01: Nike Men Air Relentless White
('f4000000-0000-0000-0000-000000000001','f2000000-0000-0000-0000-000000000001',
 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Air Relentless White Sports Shoes main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000002','f2000000-0000-0000-0000-000000000001',
 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Air Relentless White Sports Shoes side view',1,NOW(),NOW(),'ACTIVE'),

-- p02: Adidas Ultraboost Black
('f4000000-0000-0000-0000-000000000003','f2000000-0000-0000-0000-000000000002',
 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Men Ultraboost 22 Black Sports Shoes main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000004','f2000000-0000-0000-0000-000000000002',
 'https://images.unsplash.com/photo-1539185441755-769473a23570?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Men Ultraboost 22 Black Sports Shoes detail',1,NOW(),NOW(),'ACTIVE'),

-- p05: Nike Women Pink Shoes
('f4000000-0000-0000-0000-000000000005','f2000000-0000-0000-0000-000000000005',
 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Air Zoom Pegasus Pink Sports Shoes main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000006','f2000000-0000-0000-0000-000000000005',
 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Air Zoom Pegasus Pink Sports Shoes side view',1,NOW(),NOW(),'ACTIVE'),

-- p03: Puma Future Cat Black
('f4000000-0000-0000-0000-000000000007','f2000000-0000-0000-0000-000000000003',
 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Future Cat Black Casual Shoes main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000008','f2000000-0000-0000-0000-000000000003',
 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Future Cat Black Casual Shoes angle view',1,NOW(),NOW(),'ACTIVE'),

-- p04: Vans Classic Slip-On
('f4000000-0000-0000-0000-000000000009','f2000000-0000-0000-0000-000000000004',
 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Vans Classic Slip-On Black main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000010','f2000000-0000-0000-0000-000000000004',
 'https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Vans Classic Slip-On flat lay',1,NOW(),NOW(),'ACTIVE'),

-- p06: Nike Men Dri-FIT Black T-shirt
('f4000000-0000-0000-0000-000000000011','f2000000-0000-0000-0000-000000000006',
 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Dri-FIT Black T-shirt front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000012','f2000000-0000-0000-0000-000000000006',
 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Men Dri-FIT Black T-shirt worn view',1,NOW(),NOW(),'ACTIVE'),

-- p07: Adidas Men Blue Polo
('f4000000-0000-0000-0000-000000000013','f2000000-0000-0000-0000-000000000007',
 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Men Club Blue Polo front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000014','f2000000-0000-0000-0000-000000000007',
 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Men Club Blue Polo detail',1,NOW(),NOW(),'ACTIVE'),

-- p08: Puma Men Grey Sweatshirt
('f4000000-0000-0000-0000-000000000015','f2000000-0000-0000-0000-000000000008',
 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Scribble Grey Sweatshirt front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000016','f2000000-0000-0000-0000-000000000008',
 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Scribble Grey Sweatshirt worn view',1,NOW(),NOW(),'ACTIVE'),

-- p09: Nike Women Purple Polo
('f4000000-0000-0000-0000-000000000017','f2000000-0000-0000-0000-000000000009',
 'https://images.unsplash.com/photo-1523381294911-8d3cead13475?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Purple Polo T-shirt front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000018','f2000000-0000-0000-0000-000000000009',
 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Purple Polo T-shirt worn view',1,NOW(),NOW(),'ACTIVE'),

-- p10: Manchester United Red T-shirt
('f4000000-0000-0000-0000-000000000019','f2000000-0000-0000-0000-000000000010',
 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Men Red T-shirt front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000020','f2000000-0000-0000-0000-000000000010',
 'https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Men Red T-shirt detail',1,NOW(),NOW(),'ACTIVE'),

-- p11: Levis Men Blue Jeans
('f4000000-0000-0000-0000-000000000021','f2000000-0000-0000-0000-000000000011',
 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men 511 Slim Blue Jeans front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000022','f2000000-0000-0000-0000-000000000011',
 'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men 511 Slim Blue Jeans detail',1,NOW(),NOW(),'ACTIVE'),

-- p12: Jealous 21 Women Black Jeans
('f4000000-0000-0000-0000-000000000023','f2000000-0000-0000-0000-000000000012',
 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Jealous 21 Women Black Slim Jeans front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000024','f2000000-0000-0000-0000-000000000012',
 'https://images.unsplash.com/photo-1555689502-c4b22d76c56f?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Jealous 21 Women Black Slim Jeans worn view',1,NOW(),NOW(),'ACTIVE'),

-- p13: Puma Men Black Shorts
('f4000000-0000-0000-0000-000000000025','f2000000-0000-0000-0000-000000000013',
 'https://images.unsplash.com/photo-1565084888279-aca607ecce0c?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Long Black Bermuda Shorts front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000026','f2000000-0000-0000-0000-000000000013',
 'https://images.unsplash.com/photo-1591195853828-11db59a44f43?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Long Black Bermuda Shorts worn view',1,NOW(),NOW(),'ACTIVE'),

-- p14: Nike Women Pink Shorts
('f4000000-0000-0000-0000-000000000027','f2000000-0000-0000-0000-000000000014',
 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Solid Pink Sports Shorts front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000028','f2000000-0000-0000-0000-000000000014',
 'https://images.unsplash.com/photo-1571945192669-a39b2e8cae41?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Women Solid Pink Sports Shorts worn view',1,NOW(),NOW(),'ACTIVE'),

-- p20: Levis Men Grey Vest
('f4000000-0000-0000-0000-000000000029','f2000000-0000-0000-0000-000000000020',
 'https://images.unsplash.com/photo-1547308283-f90048ede2e7?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men Comfort Grey Innerwear Vest front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000030','f2000000-0000-0000-0000-000000000020',
 'https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Levis Men Comfort Grey Innerwear Vest detail',1,NOW(),NOW(),'ACTIVE'),

-- p15: Nike Black Backpack
('f4000000-0000-0000-0000-000000000031','f2000000-0000-0000-0000-000000000015',
 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Unisex Swoosh Black Backpack front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000032','f2000000-0000-0000-0000-000000000015',
 'https://images.unsplash.com/photo-1491637639811-60e2756cc1c7?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Nike Unisex Swoosh Black Backpack worn view',1,NOW(),NOW(),'ACTIVE'),

-- p16: Adidas Red Backpack
('f4000000-0000-0000-0000-000000000033','f2000000-0000-0000-0000-000000000016',
 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Unisex Chicago Bulls Red Backpack front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000034','f2000000-0000-0000-0000-000000000016',
 'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Adidas Unisex Chicago Bulls Red Backpack side view',1,NOW(),NOW(),'ACTIVE'),

-- p17: Ray-Ban Copper Sunglasses
('f4000000-0000-0000-0000-000000000035','f2000000-0000-0000-0000-000000000017',
 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Ray-Ban Men Active Lifestyle Copper Sunglasses main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000036','f2000000-0000-0000-0000-000000000017',
 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Ray-Ban Men Active Lifestyle Copper Sunglasses worn view',1,NOW(),NOW(),'ACTIVE'),

-- p18: Manchester United White Cap
('f4000000-0000-0000-0000-000000000037','f2000000-0000-0000-0000-000000000018',
 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Men White Cap front view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000038','f2000000-0000-0000-0000-000000000018',
 'https://images.unsplash.com/photo-1521369909029-2afed882baee?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Manchester United Men White Cap worn view',1,NOW(),NOW(),'ACTIVE'),

-- p19: Puma Navy Blue Socks
('f4000000-0000-0000-0000-000000000039','f2000000-0000-0000-0000-000000000019',
 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Navy Blue Sports Socks main view',0,NOW(),NOW(),'ACTIVE'),
('f4000000-0000-0000-0000-000000000040','f2000000-0000-0000-0000-000000000019',
 'https://images.unsplash.com/photo-1559563458-527698bf5295?w=800&auto=format&fit=crop&q=80',
 'IMAGE','Puma Men Navy Blue Sports Socks packaged view',1,NOW(),NOW(),'ACTIVE')

ON DUPLICATE KEY UPDATE url=VALUES(url), alt_text=VALUES(alt_text), updated_at=NOW(), status=VALUES(status);

-- ─── INVENTORY SERVICE ──────────────────────────────────────────
USE inventory_service;

-- ════════════════════════════════════════════════════════════════
-- STOCKS  (1 row per variant SKU)
-- ════════════════════════════════════════════════════════════════
INSERT INTO stocks (sku_code, product_name, quantity, version) VALUES
-- Sports Shoes – Nike Air Relentless
('NK-AIRL01-WHT-40','Nike Men Air Relentless White size 40', 80, 0),
('NK-AIRL01-WHT-41','Nike Men Air Relentless White size 41',120, 0),
('NK-AIRL01-BLK-42','Nike Men Air Relentless Black size 42', 65, 0),
-- Sports Shoes – Adidas Ultraboost
('AD-UBST01-BLK-40','Adidas Men Ultraboost Black size 40',  60, 0),
('AD-UBST01-BLK-41','Adidas Men Ultraboost Black size 41',  90, 0),
('AD-UBST01-WHT-42','Adidas Men Ultraboost White size 42',  45, 0),
-- Sports Shoes – Nike Women Pegasus
('NK-WPEG01-PNK-36','Nike Women Air Zoom Pegasus Pink 36',  50, 0),
('NK-WPEG01-PNK-37','Nike Women Air Zoom Pegasus Pink 37',  75, 0),
('NK-WPEG01-WHT-38','Nike Women Air Zoom Pegasus White 38', 55, 0),
-- Casual Shoes – Puma Future Cat
('PM-FCAT01-BLK-40','Puma Men Future Cat Black size 40',   100, 0),
('PM-FCAT01-BLK-41','Puma Men Future Cat Black size 41',   130, 0),
('PM-FCAT01-BLK-42','Puma Men Future Cat Black size 42',    90, 0),
-- Casual Shoes – Vans Classic
('VN-SLIP01-BLK-40','Vans Classic Slip-On Black size 40',  110, 0),
('VN-SLIP01-PRP-41','Vans Classic Slip-On Purple size 41',  40, 0),
('VN-SLIP01-BLK-42','Vans Classic Slip-On Black size 42',   85, 0),
-- Topwear – Nike Dri-FIT T-shirt
('NK-DRFT01-BLK-S', 'Nike Men Dri-FIT Black T-shirt S',   150, 0),
('NK-DRFT01-BLK-M', 'Nike Men Dri-FIT Black T-shirt M',   200, 0),
('NK-DRFT01-WHT-L', 'Nike Men Dri-FIT White T-shirt L',   180, 0),
('NK-DRFT01-BLK-XL','Nike Men Dri-FIT Black T-shirt XL',  120, 0),
-- Topwear – Adidas Club Polo
('AD-POLO01-BLU-S', 'Adidas Men Club Blue Polo S',        100, 0),
('AD-POLO01-BLU-M', 'Adidas Men Club Blue Polo M',        150, 0),
('AD-POLO01-NVY-L', 'Adidas Men Club Navy Polo L',        130, 0),
('AD-POLO01-NVY-XL','Adidas Men Club Navy Polo XL',        80, 0),
-- Topwear – Puma Sweatshirt
('PM-SWT01-GRY-S',  'Puma Men Scribble Grey Sweatshirt S', 60, 0),
('PM-SWT01-GRY-M',  'Puma Men Scribble Grey Sweatshirt M', 90, 0),
('PM-SWT01-BLK-L',  'Puma Men Scribble Black Sweatshirt L',70, 0),
('PM-SWT01-BLK-XL', 'Puma Men Scribble Black Sweatshirt XL',50, 0),
-- Topwear – Nike Women Purple Polo
('NK-WPLO01-PRP-XS','Nike Women Purple Polo XS',           45, 0),
('NK-WPLO01-PRP-S', 'Nike Women Purple Polo S',            80, 0),
('NK-WPLO01-WHT-M', 'Nike Women White Polo M',             95, 0),
-- Topwear – Manchester United Red T-shirt
('MU-TSH01-RED-S',  'Manchester United Red T-shirt S',    120, 0),
('MU-TSH01-RED-M',  'Manchester United Red T-shirt M',    160, 0),
('MU-TSH01-BLK-L',  'Manchester United Black T-shirt L',   90, 0),
-- Bottomwear – Levis 511 Jeans
('LV-511-BLU-30',   'Levis Men 511 Blue Jeans W30',        70, 0),
('LV-511-BLU-32',   'Levis Men 511 Blue Jeans W32',       100, 0),
('LV-511-BLK-34',   'Levis Men 511 Black Jeans W34',       55, 0),
-- Bottomwear – Jealous 21 Jeans
('J21-SLM-BLK-26',  'Jealous 21 Women Black Jeans 26',    60, 0),
('J21-SLM-BLK-28',  'Jealous 21 Women Black Jeans 28',    85, 0),
('J21-SLM-BLU-30',  'Jealous 21 Women Blue Jeans 30',     70, 0),
-- Bottomwear – Puma Shorts
('PM-BRM01-BLK-S',  'Puma Men Black Bermuda Shorts S',    110, 0),
('PM-BRM01-BLK-M',  'Puma Men Black Bermuda Shorts M',    150, 0),
('PM-BRM01-GRY-L',  'Puma Men Grey Bermuda Shorts L',      80, 0),
-- Bottomwear – Nike Women Shorts
('NK-WSHT01-PNK-XS','Nike Women Pink Sports Shorts XS',    50, 0),
('NK-WSHT01-PNK-S', 'Nike Women Pink Sports Shorts S',     90, 0),
('NK-WSHT01-BLK-M', 'Nike Women Black Sports Shorts M',   100, 0),
-- Innerwear – Levis Men Vest
('LV-VST01-GRY-S',  'Levis Men Grey Innerwear Vest S',    120, 0),
('LV-VST01-GRY-M',  'Levis Men Grey Innerwear Vest M',    180, 0),
('LV-VST01-WHT-L',  'Levis Men White Innerwear Vest L',   140, 0),
-- Bags – Nike Backpack
('NK-BKPK01-BLK-OS','Nike Unisex Swoosh Black Backpack',  200, 0),
('NK-BKPK01-GRY-OS','Nike Unisex Swoosh Grey Backpack',    80, 0),
-- Bags – Adidas Backpack
('AD-BKPK01-RED-OS','Adidas Unisex Bulls Red Backpack',   150, 0),
('AD-BKPK01-BLK-OS','Adidas Unisex Bulls Black Backpack', 100, 0),
-- Eyewear – Ray-Ban Sunglasses
('RB-SG01-CPR-OS',  'Ray-Ban Active Copper Sunglasses',    35, 0),
('RB-SG01-BLK-OS',  'Ray-Ban Active Black Sunglasses',     50, 0),
-- Headwear – Manchester United Cap
('MU-CAP01-WHT-OS', 'Manchester United White Cap',        200, 0),
('MU-CAP01-RED-OS', 'Manchester United Red Cap',          150, 0),
-- Socks – Puma Socks
('PM-SCK01-NVY-S',  'Puma Navy Blue Sports Socks S',      300, 0),
('PM-SCK01-NVY-M',  'Puma Navy Blue Sports Socks M',      400, 0),
('PM-SCK01-WHT-L',  'Puma White Sports Socks L',          250, 0)

ON DUPLICATE KEY UPDATE
  product_name=VALUES(product_name),
  quantity=VALUES(quantity),
  version=VALUES(version);

-- ════════════════════════════════════════════════════════════════
-- INVENTORY LOG  (nhập kho ban đầu cho toàn bộ variants)
-- ════════════════════════════════════════════════════════════════
INSERT INTO inventory_log (sku_code, operation_type, quantity_change, balance_after, reference_id, reason, created_by, created_at)
SELECT
  sku_code,
  'IN',
  quantity,
  quantity,
  CONCAT('INIT-', sku_code),
  'Nhập kho ban đầu – fashion seed data',
  'system',
  NOW()
FROM stocks
WHERE sku_code IN (
  'NK-AIRL01-WHT-40','NK-AIRL01-WHT-41','NK-AIRL01-BLK-42',
  'AD-UBST01-BLK-40','AD-UBST01-BLK-41','AD-UBST01-WHT-42',
  'NK-WPEG01-PNK-36','NK-WPEG01-PNK-37','NK-WPEG01-WHT-38',
  'PM-FCAT01-BLK-40','PM-FCAT01-BLK-41','PM-FCAT01-BLK-42',
  'VN-SLIP01-BLK-40','VN-SLIP01-PRP-41','VN-SLIP01-BLK-42',
  'NK-DRFT01-BLK-S','NK-DRFT01-BLK-M','NK-DRFT01-WHT-L','NK-DRFT01-BLK-XL',
  'AD-POLO01-BLU-S','AD-POLO01-BLU-M','AD-POLO01-NVY-L','AD-POLO01-NVY-XL',
  'PM-SWT01-GRY-S','PM-SWT01-GRY-M','PM-SWT01-BLK-L','PM-SWT01-BLK-XL',
  'NK-WPLO01-PRP-XS','NK-WPLO01-PRP-S','NK-WPLO01-WHT-M',
  'MU-TSH01-RED-S','MU-TSH01-RED-M','MU-TSH01-BLK-L',
  'LV-511-BLU-30','LV-511-BLU-32','LV-511-BLK-34',
  'J21-SLM-BLK-26','J21-SLM-BLK-28','J21-SLM-BLU-30',
  'PM-BRM01-BLK-S','PM-BRM01-BLK-M','PM-BRM01-GRY-L',
  'NK-WSHT01-PNK-XS','NK-WSHT01-PNK-S','NK-WSHT01-BLK-M',
  'LV-VST01-GRY-S','LV-VST01-GRY-M','LV-VST01-WHT-L',
  'NK-BKPK01-BLK-OS','NK-BKPK01-GRY-OS',
  'AD-BKPK01-RED-OS','AD-BKPK01-BLK-OS',
  'RB-SG01-CPR-OS','RB-SG01-BLK-OS',
  'MU-CAP01-WHT-OS','MU-CAP01-RED-OS',
  'PM-SCK01-NVY-S','PM-SCK01-NVY-M','PM-SCK01-WHT-L'
);

-- ================================================================
-- DONE
-- Summary:
--   product_service.categories   : 12 rows
--   product_service.products     : 20 rows
--   product_service.variants     : 59 rows
--   product_service.product_media: 40 rows
--   inventory_service.stocks     : 59 rows
--   inventory_service.log        : 59 rows (IN – initial stock)
-- ================================================================
