-- ================================================================
-- Chat History Schema — Jelly Fashion Chatbot
-- Database: chatbot_service
--
-- Chạy lệnh:
--   mysql -u cnlthd_user -pjelly1810 < data/chat_history_schema.sql
-- Hoặc paste vào MySQL Workbench / DBeaver
-- ================================================================

CREATE DATABASE IF NOT EXISTS chatbot_service
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE chatbot_service;

-- ----------------------------------------------------------------
-- 1. Phiên chat  (chat_sessions)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_sessions (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    session_id  VARCHAR(255) NOT NULL,
    user_id     VARCHAR(255) NOT NULL DEFAULT 'anonymous',
    user_name   VARCHAR(255),
    role        ENUM('user','admin','guest') NOT NULL DEFAULT 'user',
    started_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_user    (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- 2. Tin nhắn chat  (chat_messages)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS chat_messages (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    session_id  VARCHAR(255) NOT NULL,
    user_id     VARCHAR(255) NOT NULL DEFAULT 'anonymous',
    role        ENUM('user','assistant') NOT NULL,
    content     TEXT         NOT NULL,
    intent      VARCHAR(100) NOT NULL DEFAULT 'general'
                  COMMENT 'product_search | style_advice | logistics | general',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session    (session_id),
    INDEX idx_user       (user_id),
    INDEX idx_user_time  (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- 3. Hồ sơ & sở thích người dùng  (user_preferences)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_preferences (
    user_id             VARCHAR(255) PRIMARY KEY,
    preferred_categories JSON    COMMENT 'VD: ["Áo khoác","Quần jeans"]',
    preferred_colors     JSON    COMMENT 'VD: ["đen","trắng","navy"]',
    preferred_sizes      JSON    COMMENT 'VD: ["M","L"]',
    style_keywords       JSON    COMMENT 'VD: ["minimalist","old money","streetwear"]',
    price_range_min      INT UNSIGNED DEFAULT 0,
    price_range_max      INT UNSIGNED DEFAULT 0,
    interaction_count    INT UNSIGNED DEFAULT 0,
    last_updated         TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
                           ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- Cấp quyền (bỏ comment nếu cần)
-- ----------------------------------------------------------------
-- GRANT ALL PRIVILEGES ON chatbot_service.* TO 'cnlthd_user'@'%';
-- FLUSH PRIVILEGES;

-- ----------------------------------------------------------------
-- Kiểm tra nhanh
-- ----------------------------------------------------------------
SELECT
  TABLE_NAME       AS `Bảng`,
  TABLE_ROWS       AS `Số dòng (ước)`,
  CREATE_TIME      AS `Tạo lúc`
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'chatbot_service'
ORDER BY TABLE_NAME;
