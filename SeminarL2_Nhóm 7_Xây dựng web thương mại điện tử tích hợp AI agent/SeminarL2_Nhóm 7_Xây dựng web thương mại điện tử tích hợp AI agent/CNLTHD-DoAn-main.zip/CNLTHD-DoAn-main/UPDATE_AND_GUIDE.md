# Hướng dẫn cập nhật: Chat History & Personalization cho Jelly Fashion Chatbot

> **Ngày thực hiện:** 2026-05-07  
> **Phạm vi:** n8n workflow + MySQL schema  
> **Mục tiêu:** Lưu lịch sử chat người dùng và để chatbot học hành vi, cá nhân hóa câu trả lời theo từng khách hàng.

---

## Tổng quan thay đổi

| Hạng mục | Trước | Sau |
|----------|-------|-----|
| Bộ nhớ session | `memoryBufferWindow` 3 lượt, mất khi đóng tab | 10 lượt trong session + lưu MySQL vĩnh viễn |
| Lịch sử chat | Không lưu | Lưu đầy đủ vào `chatbot_service.chat_messages` |
| Hồ sơ người dùng | Không có | Tự động tích lũy sở thích vào `user_preferences` |
| Cá nhân hóa | Không | Inject profile + lịch sử vào mỗi tin nhắn |
| Phân loại intent | Không | Tự động: `product_search / style_advice / logistics / general` |

---

## Danh sách file thay đổi

```
CNLTHD-DoAn/
├── data/
│   └── chat_history_schema.sql     ← TẠO MỚI: schema 3 bảng MySQL
└── workflow/
    └── My workflow.json            ← CẬP NHẬT: thêm 7 node mới
```

---

## Bước 1 — Chạy SQL Schema

### 1.1 Lệnh chạy
```bash
# Từ thư mục gốc dự án
mysql -u cnlthd_user -pjelly1810 < data/chat_history_schema.sql
```

Hoặc mở file `data/chat_history_schema.sql` trong MySQL Workbench / DBeaver và Execute.

### 1.2 Ba bảng được tạo trong database `chatbot_service`

**`chat_sessions`** — Phiên chat
```sql
id, session_id, user_id, user_name, role, started_at, last_active
```

**`chat_messages`** — Tin nhắn (bảng quan trọng nhất)
```sql
id, session_id, user_id, role (user|assistant), content, intent, created_at
```
- `intent`: `product_search` | `style_advice` | `logistics` | `general`

**`user_preferences`** — Hồ sơ & sở thích (tự tích lũy theo thời gian)
```sql
user_id (PK), preferred_categories, preferred_colors, preferred_sizes,
style_keywords, price_range_min, price_range_max, interaction_count, last_updated
```

### 1.3 Kiểm tra sau khi chạy
```sql
USE chatbot_service;
SHOW TABLES;
-- Kết quả mong đợi: chat_messages, chat_sessions, user_preferences
```

---

## Bước 2 — Import Workflow vào n8n

### 2.1 Import file
1. Mở n8n UI
2. Vào **Settings** → **Import Workflow** (hoặc nút **Import** ở góc trên)
3. Chọn file: `workflow/My workflow.json`
4. Nhấn **Import**

> **Lưu ý:** Nếu workflow đang active, n8n sẽ hỏi có muốn overwrite không — chọn **Yes**.

### 2.2 Map lại MySQL credentials (bắt buộc)

Sau khi import, các node MySQL mới sẽ báo lỗi credential. Làm lần lượt cho **4 node** sau:

| Tên node | Việc cần làm |
|----------|-------------|
| `Load User Profile` | Click node → chọn lại credential `testdb` |
| `Load Recent History` | Click node → chọn lại credential `testdb` |
| `Save Messages` | Click node → chọn lại credential `testdb` |
| `Upsert Preferences` | Click node → chọn lại credential `testdb` |

Credential `testdb` phải kết nối đến MySQL server có quyền đọc/ghi database `chatbot_service`.

### 2.3 Kích hoạt workflow
Bật toggle **Active** ở góc trên phải → workflow sẵn sàng.

---

## Bước 3 — Kiểm tra hoạt động

### 3.1 Test gửi tin nhắn
Gửi tin nhắn qua chatbot như bình thường (ví dụ: "Tôi muốn tìm áo khoác màu đen size M").

### 3.2 Xác nhận dữ liệu được lưu
```sql
-- Xem tin nhắn vừa lưu
SELECT * FROM chatbot_service.chat_messages
ORDER BY created_at DESC LIMIT 10;

-- Xem sở thích đã tích lũy
SELECT * FROM chatbot_service.user_preferences;
```

### 3.3 Test cá nhân hóa (sau 2–3 lượt chat)
Hỏi chatbot: `"Cho tôi xem sản phẩm phù hợp"`  
→ Chatbot sẽ chủ động gợi ý theo màu/size/phong cách đã học từ lịch sử.

---

## Kiến trúc flow mới (chi tiết)

```
[Webhook] → [Code in JavaScript2: normalize input]
                        ↓
                    [Switch]
                   /        \
          role=admin        role=user / default
              ↓                    ↓
         [Admin Agent]    [Load User Profile]  ← MySQL: chatbot_service.user_preferences
                                  ↓
                         [Load Recent History] ← MySQL: chatbot_service.chat_messages (10 tin nhắn)
                                  ↓
                         [Build User Context]  ← Code: gộp profile + history vào chatInput
                                  ↓
                         [Information Agent]   ← LLM thấy ngữ cảnh cá nhân hóa
                                  ↓
                      [Prepare Save Messages]  ← Code: escape SQL + detect intent
                                  ↓
                         [Save Messages]       ← MySQL: INSERT 2 dòng (user + bot)
                                  ↓
                      [Extract Preferences]    ← Code: phân tích màu/size/style/giá
                                  ↓
                   [Has Preference Signals]    ← IF: có tín hiệu mới?
                       /              \
                    true             false
                      ↓                ↓
              [Upsert Preferences]   (kết thúc)
              ← MySQL: ON DUPLICATE KEY UPDATE
```

---

## Giải thích 7 node mới

### Node 1: `Load User Profile` (MySQL)
Truy vấn hồ sơ sở thích của người dùng từ `user_preferences`.  
- Nếu người dùng chưa có hồ sơ → trả về rỗng (node có `alwaysOutputData: true` để không bị lỗi).
- Dùng `userId` từ node `Code in JavaScript2`.

### Node 2: `Load Recent History` (MySQL)
Lấy 10 tin nhắn gần nhất của người dùng (cả user lẫn assistant), sắp xếp DESC.  
- Dùng để Build User Context biết khách đã nói gì trước đó.

### Node 3: `Build User Context` (Code JS)
Gộp profile và lịch sử thành đoạn context, ghép vào đầu `chatInput`:
```
--- CONTEXT NGƯỜI DÙNG ---
[HỒ SƠ KHÁCH HÀNG – Nguyễn Văn A | Đã ghé 5 lần]
Danh mục ưa thích: Áo khoác, Hoodie
Màu ưa thích: đen, navy
Size thường dùng: L

[LỊCH SỬ CHAT GẦN ĐÂY]
Khách: tôi thích phong cách minimalist
Jelly: Dạ, phong cách Minimalist...
--- END CONTEXT ---

[CÂU HỎI HIỆN TẠI]
Có áo nào đang sale không?
```
Information Agent nhìn thấy toàn bộ context này và trả lời phù hợp hơn.

### Node 4: `Prepare Save Messages` (Code JS)
Chuẩn bị dữ liệu để lưu:
- Escape ký tự đặc biệt (`'`, `\`) tránh SQL injection
- Phát hiện intent từ từ khóa trong câu hỏi
- Build câu INSERT 2 dòng cho user + bot trong 1 query

**Intent detection logic:**
| Từ khóa | Intent |
|---------|--------|
| phối đồ, style, phong cách, mặc gì, màu da | `style_advice` |
| đổi trả, hoàn tiền, vận chuyển, giao hàng, COD | `logistics` |
| áo, quần, giày, túi, size, giá, sản phẩm, mã hàng | `product_search` |
| (mặc định) | `general` |

### Node 5: `Save Messages` (MySQL)
Thực thi câu INSERT đã chuẩn bị — lưu cả user message lẫn bot response trong 1 lượt.

### Node 6: `Extract Preferences` (Code JS)
Phân tích `originalChatInput` để tìm tín hiệu sở thích:

| Loại tín hiệu | Ví dụ từ khóa phát hiện |
|---------------|------------------------|
| Màu sắc | đen, trắng, navy, đỏ, be, xám, nâu, hồng, tím... |
| Size | xs, s, m, l, xl, xxl, 3xl |
| Phong cách | minimalist, old money, streetwear, casual, công sở, đi tiệc... |
| Danh mục | áo khoác, áo thun, quần jean, giày sneaker, túi xách, hoodie, blazer... |
| Khoảng giá | "dưới 500k", "tầm 1 triệu", "khoảng 300k" |

Kết quả được **merge với sở thích cũ** (không ghi đè hoàn toàn), tối đa 10 items/category.

### Node 7: `Upsert Preferences` (MySQL)
```sql
INSERT INTO user_preferences (...) VALUES (...)
ON DUPLICATE KEY UPDATE
  preferred_categories = '...merged...',
  preferred_colors     = '...merged...',
  ...
  interaction_count    = interaction_count + 1,
  last_updated         = NOW()
```
Lần đầu → INSERT. Lần sau → UPDATE (cộng dồn sở thích).

---

## Troubleshooting

### Lỗi: MySQL node báo "Table doesn't exist"
→ Chưa chạy `data/chat_history_schema.sql`. Chạy lại Bước 1.

### Lỗi: MySQL node báo credential error
→ Vào từng node MySQL mới, chọn lại credential `testdb`. Xem lại Bước 2.2.

### Lỗi: "Build User Context" node không có data từ "Load User Profile"
→ Kiểm tra node `Load User Profile` có bật `Always Output Data` không (phải bật để không bị break khi user mới chưa có profile).

### Chatbot không hiển thị context người dùng
→ Kiểm tra `userId` trong request có đúng không. Nếu `userId = 'anonymous'` thì không có profile để load. Frontend cần truyền đúng `metadata.userId` trong payload.

### Muốn xem lịch sử chat của 1 user cụ thể
```sql
SELECT role, content, intent, created_at
FROM chatbot_service.chat_messages
WHERE user_id = 'your_user_id'
ORDER BY created_at ASC;
```

### Muốn reset hồ sơ sở thích của 1 user
```sql
DELETE FROM chatbot_service.user_preferences WHERE user_id = 'your_user_id';
```

---

## Ghi chú kỹ thuật

- **Database mới:** `chatbot_service` — hoàn toàn tách biệt khỏi các service DB hiện có.
- **Không ảnh hưởng** đến flow Admin Agent (vẫn hoạt động như cũ).
- **Backward compatible:** Nếu người dùng mới (chưa có lịch sử), workflow vẫn chạy bình thường — context rỗng, chatbot trả lời như cũ.
- **`Simple Memory` context window** tăng từ 3 → 10 lượt (chỉ trong session hiện tại).
- Credential MySQL trong workflow dùng ID `c6f2Sl5ASgv84vUk` (tên: `testdb`) — phải map lại sau khi import vào n8n instance.
